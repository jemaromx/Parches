"""
Configuración central del Launcher de la Suite de Diseño Estructural.

Aquí se define:
  • La paleta "Professional Dark Mode" del launcher (independiente de la
    paleta clara que usan los módulos individuales — el launcher es la
    "puerta de entrada" y puede tener identidad propia).
  • Las fuentes.
  • El registro de módulos (REGISTRY): un único lugar donde agregar /
    quitar / mover herramientas de la suite sin tocar la GUI.

Para agregar un nuevo módulo basta con añadir un diccionario a MODULES.
"""

from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# 1. RUTA BASE DE LOS PROYECTOS
# ─────────────────────────────────────────────────────────────────────────────
# En distribución: el launcher está en <suite_root>/suite_launcher/
# Los módulos están en <suite_root>/<módulo>/
# suite_shared está en <suite_root>/suite_shared/
PROJECTS_ROOT = Path(__file__).resolve().parent.parent.parent

# ─────────────────────────────────────────────────────────────────────────────
# 2. PALETA — Professional Dark Mode
# ─────────────────────────────────────────────────────────────────────────────
COLORS = {
    "bg":          "#0F1B2B",   # Fondo general — azul marino muy oscuro
    "bg_grid":     "#0B1622",   # Fondo del área de tarjetas (ligeramente más oscuro)
    "panel":       "#16243A",   # Header / StatusBar / barra de categorías
    "card":        "#1C2E45",   # Fondo de tarjetas en reposo
    "card_hover":  "#243958",   # Fondo de tarjetas al pasar el cursor
    "border":      "#2A3F5A",   # Bordes sutiles
    "text":        "#ECF0F1",   # Texto principal (blanco hueso)
    "text_dim":    "#9FB3C8",   # Texto secundario / subtítulos
    "text_faint":  "#5D7491",   # Texto terciario (badges, versión)
    "accent":      "#1ABC9C",   # Acento principal — verde azulado de ingeniería
    "accent_alt":  "#3498DB",   # Acento secundario — azul de ingeniería
}

# Identidad visual por categoría (color del ícono / borde de hover / badge)
CATEGORY_COLORS = {
    "mamposteria": "#9B59B6",   # Morado
    "concreto":    "#3498DB",   # Azul de ingeniería
    "acero":       "#E67E22",   # Naranja estructural
}

CATEGORY_LABELS = {
    "todas":       "Todas",
    "mamposteria": "Mampostería",
    "concreto":    "Concreto",
    "acero":       "Acero",
}

# Íconos de categoría (paquete FontAwesome5-Solid vía qtawesome)
CATEGORY_ICONS = {
    "todas":       "fa5s.th",
    "mamposteria": "fa5s.border-all",
    "concreto":    "fa5s.layer-group",
    "acero":       "fa5s.industry",
}

# ─────────────────────────────────────────────────────────────────────────────
# 3. TIPOGRAFÍA
# ─────────────────────────────────────────────────────────────────────────────
FONT_FAMILY     = "Segoe UI"
FONT_MONO       = "Consolas"

FONT_APP_TITLE  = (FONT_FAMILY, 14, "Bold")
FONT_APP_SUB    = (FONT_FAMILY, 9)
FONT_VERSION    = (FONT_FAMILY, 8)
FONT_CATEGORY   = (FONT_FAMILY, 10, "Bold")
FONT_CARD_TITLE = (FONT_FAMILY, 11, "Bold")
FONT_CARD_DESC  = (FONT_FAMILY, 9)
FONT_CARD_BADGE = (FONT_MONO, 8)

# ─────────────────────────────────────────────────────────────────────────────
# 4. ICONOGRAFÍA CUSTOM
# ─────────────────────────────────────────────────────────────────────────────
# PNG planos (RGBA, fondo translúcido) generados por assets/generate_icons.py,
# uno por módulo, ilustrando el elemento estructural que cada script diseña.
ICONS_DIR = Path(__file__).resolve().parent.parent / "assets" / "icons"

# ─────────────────────────────────────────────────────────────────────────────
# 5. DIMENSIONES
# ─────────────────────────────────────────────────────────────────────────────
# La tarjeta y la ventana se dimensionan en función del tamaño del ícono
# custom (más grande que un ícono de fuente tipográfica) para que la
# ilustración se aprecie con nitidez.
CARD_ICON_SIZE      = 104                      # px — lado del ícono cuadrado dentro de la tarjeta
CARD_SIZE           = (320, 250)               # px — ancho × alto de cada ToolCard
GRID_COLUMNS        = 3
GRID_SPACING        = 20

HEADER_HEIGHT       = 72
CATEGORY_BAR_HEIGHT = 52

# Ancho de ventana ajustado a: 3 columnas de tarjetas + separaciones + márgenes
_GRID_MARGINS = 24 * 2
WINDOW_DEFAULT_SIZE = (
    GRID_COLUMNS * CARD_SIZE[0] + (GRID_COLUMNS - 1) * GRID_SPACING + _GRID_MARGINS + 40,
    HEADER_HEIGHT + CATEGORY_BAR_HEIGHT + 2 * CARD_SIZE[1] + GRID_SPACING + _GRID_MARGINS + 80,
)
WINDOW_MINIMUM_SIZE = (
    CARD_SIZE[0] + _GRID_MARGINS + 60,
    HEADER_HEIGHT + CATEGORY_BAR_HEIGHT + CARD_SIZE[1] + _GRID_MARGINS + 80,
)

# ─────────────────────────────────────────────────────────────────────────────
# 6. REGISTRO DE MÓDULOS
# ─────────────────────────────────────────────────────────────────────────────
# category  : "mamposteria" | "concreto" | "acero"
# icon      : ícono qtawesome de respaldo (paquetes fa5s.* o mdi6.*) — se usa
#             solo si "icon_file" no existe en disco.
# icon_file : ilustración custom (PNG RGBA, fondo translúcido) del elemento
#             estructural que diseña el script — ver assets/generate_icons.py
# folder    : nombre de carpeta dentro de PROJECTS_ROOT
# entry    : script de entrada a ejecutar con `python <entry>`
MODULES = [
    {
        "id":       "wall_masonry",
        "category": "mamposteria",
        "title":    "Muros de Mampostería\ny Concreto",
        "subtitle": "Diseño de muros de mampostería / Muro de concreto",
        "norm":     "NTC-DEM / NTC-DEC",
        "icon":     "fa5s.border-all",
        "icon_file": ICONS_DIR / "wall_masonry.png",
        # Segun el componente STAAD elegido en el instalador solo una de estas
        # dos carpetas existira; el launcher prueba en orden y usa la primera.
        "folder":   ["wall_design_pro", "wall_design_pro_anl"],
        "entry":    "main.py",
    },
    {
        "id":       "beam_concrete",
        "category": "concreto",
        "title":    "Trabes de Concreto",
        "subtitle": "Diseño a flexión, cortante y torsión de elementos de concreto reforzado",
        "norm":     "NTC-DEC 2023 / ACI 318-25",
        "icon":     "fa5s.grip-lines",
        "icon_file": ICONS_DIR / "beam_concrete.png",
        "folder":   "beam_design_pro",
        "entry":    "main.py",
    },
    {
        "id":       "column_concrete",
        "category": "concreto",
        "title":    "Columnas de Concreto",
        "subtitle": "Interacción carga-momento (P-M), confinamiento y factor K vía STAAD",
        "norm":     "NTC-DEC 2023 / ACI 318-25",
        "icon":     "fa5s.grip-lines-vertical",
        "icon_file": ICONS_DIR / "column_concrete.png",
        "folder":   "column_design_pro",
        "entry":    "main.py",
    },
    {
        "id":       "footing_concrete",
        "category": "concreto",
        "title":    "Zapatas Aisladas",
        "subtitle": "Diseño estructural de zapatas aisladas",
        "norm":     "NTC-DEC 2023 / ACI 318-25",
        "icon":     "fa5s.layer-group",
        "icon_file": ICONS_DIR / "footing_concrete.png",
        "folder":   "footing_design_pro",
        "entry":    "main.py",
    },

    {
        "id":       "beam_steel",
        "category": "acero",
        "title":    "Trabes de Acero",
        "subtitle": "Diseño a flexión y cortante de elementos de acero estructural",
        "norm":     "NTC-DEA / AISC 360",
        "icon":     "mdi6.format-line-weight",
        "icon_file": ICONS_DIR / "beam_steel.png",
        "folder":   "beamsteel_design_pro",
        "entry":    "main.py",
    },
    {
        "id":       "column_steel",
        "category": "acero",
        "title":    "Columnas de Acero",
        "subtitle": "Diseño de columnas y contravientos de acero estructural",
        "norm":     "NTC-DEA / AISC 360",
        "icon":     "mdi6.pillar",
        "icon_file": ICONS_DIR / "column_steel.png",
        "folder":   "columnsteel_design_pro",
        "entry":    "main.py",
    },
    {
        "id":       "composite_column",
        "category": "acero",
        "title":    "Columnas Compuestas",
        "subtitle": "Diseño de columnas compuestas acero-concreto embebido o relleno",
        "norm":     "NTC-DEA / ACI 318-25",
        "icon":     "mdi6.circle-double",
        "icon_file": ICONS_DIR / "composite_column.png",
        "folder":   "compositecolumn_design_pro",
        "entry":    "main.py",
    },
    {
        "id":       "nudo",
        "category": "concreto",
        "title":    "Nudo Viga-Columna",
        "subtitle": "Diseño de nudo viga-columna: cortante de nudo, confinamiento y diseño por capacidad",
        "norm":     "NTC 2023 / ACI 318-25",
        "icon":     "mdi6.plus-box",
        "icon_file": ICONS_DIR / "nudo.png",
        "folder":   "nudo",
        "entry":    "main.py",
    },
    {
        "id":       "secciones",
        "category": "concreto",
        "title":    "Secciones",
        "subtitle": "Propiedades geométricas de secciones (Ix, Iy, Sx, radio de giro, plástico)",
        "norm":     "AISC / NTC",
        "icon":     "mdi6.shape",
        "icon_file": ICONS_DIR / "secciones.png",
        "folder":   "Secciones",
        "entry":    "main.py",
    },
    {
        "id":       "diagrama_interaccion",
        "category": "concreto",
        "title":    "Diagrama de Interacción",
        "subtitle": "Superficie 3D P-Mx-My, M-φ y σ-ε para secciones de concreto reforzado",
        "norm":     "NTC 2023 / ACI 318-25",
        "icon":     "mdi6.chart-scatter-plot",
        "icon_file": ICONS_DIR / "diagrama_interaccion.png",
        "folder":   "Diagrama Interacción",
        "entry":    "main.py",
    },
]
