﻿# ui/tab_trabe_compuesta.py  — Tab "Trabe Compuesta"
from __future__ import annotations
import math
import numpy as np
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, QPushButton,
    QComboBox, QDoubleSpinBox, QSplitter, QScrollArea, QTabWidget,
    QTextEdit, QSpinBox, QFormLayout, QRadioButton, QButtonGroup,
    QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from core.composite_beam import design, BeamInput
from data.steel_db import get_sections_by_type, get_props, estimate_from_dimensions
from ui.widgets import MplCanvas, NavToolbar, make_result_table, set_item
from fileio.word_exporter import export_tab_memory
from config.settings import (
    COLORS, STEEL_MATERIALS, NELSON_STUDS, CE_CONNECTORS, HILTI_HVB
)

P    = COLORS["primary"]
OK   = "#D5F5E3"
WARN = "#FDEBD0"
FAIL = "#FADBD8"
SEP  = "#D4E6F1"


class TabTrabeCompuesta(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._result = None
        self._inp    = None
        self._build_ui()

    def _build_ui(self):
        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0)
        spl  = QSplitter(Qt.Horizontal)
        spl.setCollapsible(0, False); spl.setCollapsible(1, False)

        # ── Panel izquierdo ───────────────────────────────────────────────────
        left_scroll = QScrollArea(); left_scroll.setWidgetResizable(True)
        left_w = QWidget(); left_w.setMinimumWidth(320)
        lv = QVBoxLayout(left_w); lv.setSpacing(6)

        def dsb(lo, hi, val, suf=" cm", dec=2):
            w = QDoubleSpinBox(); w.setRange(lo, hi); w.setValue(val)
            w.setSuffix(suf); w.setDecimals(dec); return w

        # Código de diseño
        grp_code = QGroupBox("Norma de Diseño")
        cf = QFormLayout(grp_code)
        self.cb_code = QComboBox()
        self.cb_code.addItems(["NTC DEA 2023 LRFD", "AISC 360-22 LRFD", "AISC 360-22 ASD"])
        cf.addRow("Código:", self.cb_code)
        lv.addWidget(grp_code)

        # Geometría
        grp_geo = QGroupBox("Geometría — Trabe y Losa")
        gf = QFormLayout(grp_geo)
        self.dsb_L    = dsb(100, 5000, 800,  " cm")
        self.dsb_s    = dsb(20,  1500, 300,  " cm")
        self.dsb_tc   = dsb(5,   50,   12,  " cm")
        self.dsb_hr   = dsb(0,   20,   0,   " cm")
        self.dsb_fc   = dsb(100, 700,  250,  " kg/cm²")
        self.dsb_wc   = dsb(1.5, 3.0,  2.4,  " t/m³")
        self.cb_btype = QComboBox()
        self.cb_btype.addItems(["Interior", "Borde"])
        gf.addRow("L (longitud):", self.dsb_L)
        gf.addRow("s (separación):", self.dsb_s)
        gf.addRow("tc (losa):", self.dsb_tc)
        gf.addRow("hr (deck):", self.dsb_hr)
        gf.addRow("f'c:", self.dsb_fc)
        gf.addRow("γc:", self.dsb_wc)
        self.dsb_Ec = dsb(0, 1_000_000, 0, " kg/cm²", 0)
        self.dsb_Ec.setToolTip(
            "Módulo de elasticidad del concreto.\n"
            "0 = calcular automáticamente con la fórmula del código.")
        gf.addRow("Ec (0=auto):", self.dsb_Ec)
        gf.addRow("Tipo viga:", self.cb_btype)
        lv.addWidget(grp_geo)

        # Perfil
        grp_prof = QGroupBox("Perfil de Acero")
        pf = QFormLayout(grp_prof)
        self.cb_mat  = QComboBox(); self.cb_mat.addItems(list(STEEL_MATERIALS.keys()))
        self.cb_perfil_type = QComboBox()
        self.cb_perfil_type.addItems(["W / IR", "Manual (definido por usuario)"])
        self.cb_prof = QComboBox()
        self._refresh_profiles()
        self.cb_perfil_type.currentIndexChanged.connect(self._on_perfil_type_changed)
        pf.addRow("Material:", self.cb_mat)
        pf.addRow("Tipo de perfil:", self.cb_perfil_type)
        pf.addRow("Perfil W:", self.cb_prof)
        lv.addWidget(grp_prof)

        # Dimensiones manuales (perfil I genérico, armado de 3 placas simétrico)
        self.grp_manual_perfil = QGroupBox("Dimensiones Manuales del Perfil")
        gmp = QFormLayout(self.grp_manual_perfil)
        self.dsb_d_manual  = dsb(5,  300, 40,  " cm")
        self.dsb_bf_manual = dsb(2,  100, 20,  " cm")
        self.dsb_tf_manual = dsb(0.3, 10, 1.5, " cm")
        self.dsb_tw_manual = dsb(0.3, 10, 1.0, " cm")
        gmp.addRow("d (peralte total):", self.dsb_d_manual)
        gmp.addRow("bf (ancho patín):", self.dsb_bf_manual)
        gmp.addRow("tf (espesor patín):", self.dsb_tf_manual)
        gmp.addRow("tw (espesor alma):", self.dsb_tw_manual)
        self.grp_manual_perfil.setVisible(False)
        lv.addWidget(self.grp_manual_perfil)

        lbl_scope = QLabel(
            "Canal CE y HSS como perfil de viga: próximamente — requieren validar\n"
            "las fórmulas de flexión/cortante de composite_beam.py para esas\n"
            "geometrías (actualmente asumen perfil I simétrico, AISC I3.2)."
        )
        lbl_scope.setStyleSheet("color: #2874A6; font-style: italic; font-size: 8pt;")
        lv.addWidget(lbl_scope)

        # Factores de carga LRFD
        grp_fac = QGroupBox("Factores de Carga LRFD")
        ff = QFormLayout(grp_fac)
        self.dsb_gCM = dsb(1.0, 2.0, 1.2, "", 2)
        self.dsb_gCV = dsb(1.0, 2.0, 1.6, "", 2)
        ff.addRow("γCM:", self.dsb_gCM)
        ff.addRow("γCV:", self.dsb_gCV)
        lv.addWidget(grp_fac)

        # Cargas pre-curado  (kg/m²  → el tab convierte a t/m usando s)
        grp_pre = QGroupBox("Cargas — Pre Curado")
        prv = QFormLayout(grp_pre)
        self.dsb_wCM_losa = dsb(0, 5000, 350, " kg/m²", 1)
        self.dsb_wCV_cons = dsb(0, 5000, 100, " kg/m²", 1)
        prv.addRow("wCM losa (kg/m²):", self.dsb_wCM_losa)
        prv.addRow("wCV construcción:", self.dsb_wCV_cons)
        lv.addWidget(grp_pre)

        # Cargas post-curado (kg/m²)
        grp_post = QGroupBox("Cargas — Post Curado")
        pov = QFormLayout(grp_post)
        self.dsb_wCM    = dsb(0, 5000, 150, " kg/m²", 1)
        self.dsb_wCVmax = dsb(0, 5000, 300, " kg/m²", 1)
        self.dsb_P      = dsb(0, 200000, 0, " kg",  1)
        self.dsb_a      = dsb(0, 500,    0, " cm",  2)
        pov.addRow("wCM muerta (kg/m²):", self.dsb_wCM)
        pov.addRow("wCV viva max (kg/m²):", self.dsb_wCVmax)
        pov.addRow("P puntual (kg):", self.dsb_P)
        pov.addRow("a dist. P desde apoyo:", self.dsb_a)
        lv.addWidget(grp_post)

        # Conectores
        grp_con = QGroupBox("Conectores de Cortante")
        cov = QFormLayout(grp_con)
        self.cb_con_type = QComboBox()
        self.cb_con_type.addItems(["Pernos Nelson", "Canal CE soldado", "Hilti X-ENP HVB"])
        self.cb_con_size = QComboBox()

        self.rb_completa = QRadioButton("Completamente compuesta")
        self.rb_parcial  = QRadioButton("Parcialmente compuesta")
        self.rb_completa.setChecked(True)
        self.bg_modo = QButtonGroup(self)
        self.bg_modo.addButton(self.rb_completa)
        self.bg_modo.addButton(self.rb_parcial)
        self.rb_completa.toggled.connect(self._on_modo_toggled)

        self.spb_n_con   = QSpinBox(); self.spb_n_con.setRange(1, 500); self.spb_n_con.setValue(20)
        self.spb_n_con.setEnabled(False)
        self.dsb_Rg      = dsb(0.5, 1.0, 1.0, "", 2)
        self.dsb_Rp      = dsb(0.5, 1.0, 0.75, "", 2)
        self.cb_con_type.currentIndexChanged.connect(self._refresh_connectors)
        self._refresh_connectors()
        cov.addRow("Tipo:", self.cb_con_type)
        cov.addRow("Tamaño:", self.cb_con_size)
        cov.addRow(self.rb_completa)
        cov.addRow(self.rb_parcial)
        cov.addRow("N conectores (semi-claro):", self.spb_n_con)
        cov.addRow("Rg (factor grupo):", self.dsb_Rg)
        cov.addRow("Rp (factor posición):", self.dsb_Rp)
        lv.addWidget(grp_con)

        # ── Esquema de referencia (imagen) en el panel de controles ────────
        # Se inserta HASTA ARRIBA del panel (posición 0): es lo primero que
        # se ve en el cuadro de controles.
        grp_esq = QGroupBox("Esquema de Variables")
        ev_l = QVBoxLayout(grp_esq)
        self._lbl_esquema = QLabel()
        self._lbl_esquema.setAlignment(Qt.AlignCenter)
        from pathlib import Path as _P
        _img = _P(__file__).resolve().parent.parent / "assets" / "vigacompuesta.png"
        if _img.exists():
            from PySide6.QtGui import QPixmap as _QPix
            self._esq_pix = _QPix(str(_img))
            self._lbl_esquema.setPixmap(self._esq_pix.scaledToWidth(
                300, Qt.SmoothTransformation))
            self._lbl_esquema.setToolTip(
                "Significado de las variables de entrada (be, tc, d, bf, Fy, "
                "f'c) y del diagrama de esfuerzos plástico (Cc, Cp, T, ENP).")
        else:
            self._lbl_esquema.setText("(imagen vigacompuesta.png no encontrada)")
        ev_l.addWidget(self._lbl_esquema)
        lv.insertWidget(0, grp_esq)

        btn_opt = QPushButton("⭐  Proponer Perfil Óptimo (por peso)")
        btn_opt.setObjectName("btn_run")
        btn_opt.setToolTip(
            "Recorre el catálogo W/IR y selecciona el perfil MÁS LIGERO que "
            "cumple flexión, cortante y deflexiones con los datos actuales.")
        btn_opt.clicked.connect(self._optimal_profile)
        lv.addWidget(btn_opt)

        btn_run = QPushButton("⚙  Diseñar Trabe Compuesta")
        btn_run.setObjectName("btn_run")
        btn_run.clicked.connect(self._calculate)
        lv.addWidget(btn_run)

        self.btn_export_word = QPushButton("📄  Exportar Word")
        self.btn_export_word.setEnabled(False)
        self.btn_export_word.clicked.connect(self._export_word)
        lv.addWidget(self.btn_export_word)
        lv.addStretch()
        left_scroll.setWidget(left_w)

        # ── Panel derecho ─────────────────────────────────────────────────────
        right_tabs = QTabWidget()

        tab_res = QWidget(); rv = QVBoxLayout(tab_res)
        self.res_table = make_result_table(cols=["Concepto", "Valor", "Unidad", "Ratio"])
        rv.addWidget(self.res_table)
        right_tabs.addTab(tab_res, "Resultados")

        tab_diag = QWidget(); dv = QVBoxLayout(tab_diag)
        self.canvas_sec = MplCanvas(figsize=(8, 4.5), dpi=90)
        self.toolbar_sec = NavToolbar(self.canvas_sec, tab_diag)
        dv.addWidget(self.toolbar_sec); dv.addWidget(self.canvas_sec)
        right_tabs.addTab(tab_diag, "Sección / Esfuerzos")

        # (La pestaña "Esquema" se movió como imagen al panel izquierdo.)

        tab_mem = QWidget(); mv = QVBoxLayout(tab_mem)
        self.mem_text = QTextEdit(); self.mem_text.setReadOnly(True)
        self.mem_text.setFont(QFont("Consolas", 8))
        mv.addWidget(self.mem_text)
        right_tabs.addTab(tab_mem, "Memoria de Cálculo")

        spl.addWidget(left_scroll); spl.addWidget(right_tabs)
        spl.setStretchFactor(0, 0); spl.setStretchFactor(1, 1)
        spl.setSizes([340, 750])
        root.addWidget(spl)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _refresh_profiles(self):
        profs = get_sections_by_type("W")
        self.cb_prof.clear(); self.cb_prof.addItems(profs)

    def _on_perfil_type_changed(self):
        is_manual = "Manual" in self.cb_perfil_type.currentText()
        self.cb_prof.setVisible(not is_manual)
        self.grp_manual_perfil.setVisible(is_manual)

    def _get_steel_props_trabe(self) -> dict | None:
        if "Manual" in self.cb_perfil_type.currentText():
            sp = estimate_from_dimensions(
                self.dsb_d_manual.value(), self.dsb_bf_manual.value(),
                self.dsb_tf_manual.value(), self.dsb_tw_manual.value()
            )
            sp["name"] = "PERFIL MANUAL"
            return sp
        return get_props(self.cb_prof.currentText())

    def _on_modo_toggled(self, completa: bool):
        self.spb_n_con.setEnabled(not completa)

    def _export_word(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar memoria de cálculo", "", "Word (*.docx)"
        )
        if not path:
            return
        result = export_tab_memory(self, path)
        if result.startswith("ERROR"):
            QMessageBox.critical(self, "Exportar Word", result)
        else:
            QMessageBox.information(self, "Exportar Word", f"Documento creado:\n{result}")

    def _refresh_connectors(self):
        t = self.cb_con_type.currentText()
        self.cb_con_size.clear()
        if "Nelson" in t:
            self.cb_con_size.addItems(list(NELSON_STUDS.keys()))
        elif "Canal" in t:
            self.cb_con_size.addItems(list(CE_CONNECTORS.keys()))
        else:
            self.cb_con_size.addItems(list(HILTI_HVB.keys()))

    def _build_input(self) -> BeamInput:
        mat_key  = self.cb_mat.currentText()
        mat      = STEEL_MATERIALS[mat_key]
        sp       = self._get_steel_props_trabe()
        code_str = self.cb_code.currentText()
        code = "NTC_LRFD" if "NTC" in code_str else ("AISC_ASD" if "ASD" in code_str else "AISC_LRFD")

        con_t    = self.cb_con_type.currentText()
        con_s    = self.cb_con_size.currentText()
        # Modo "completamente compuesta": no se pasa n_partial, de modo que
        # core.composite_beam.design() use por defecto N_half_span (full).
        # Modo "parcialmente compuesta": se usa el valor indicado por el
        # usuario en spb_n_con.
        n_half   = self.spb_n_con.value() if self.rb_parcial.isChecked() else None
        if "Nelson" in con_t:
            cd = dict(NELSON_STUDS.get(con_s, {}))
            cd.update({"Rg": self.dsb_Rg.value(), "Rp": self.dsb_Rp.value()})
            ctype = "stud"
        elif "Canal" in con_t:
            cd = dict(CE_CONNECTORS.get(con_s, {}))
            ctype = "channel"
        else:
            cd = dict(HILTI_HVB.get(con_s, {}))
            ctype = "hilti"
        if n_half is not None:
            cd["n_partial"] = n_half

        beam_t = "interior" if self.cb_btype.currentIndex() == 0 else "edge"

        return BeamInput(
            L_m               = self.dsb_L.value() / 100,
            s_m               = self.dsb_s.value() / 100,
            tc_cm             = self.dsb_tc.value(),
            hr_cm             = self.dsb_hr.value(),
            fc                = self.dsb_fc.value(),
            wc                = self.dsb_wc.value(),
            Fy                = mat["Fy"],
            Fu                = mat["Fu"],
            sp                = sp,
            beam_type         = beam_t,
            code              = code,
            gCM               = self.dsb_gCM.value(),
            gCV               = self.dsb_gCV.value(),
            wCM_losa_kgm2     = self.dsb_wCM_losa.value(),
            wCV_const_kgm2    = self.dsb_wCV_cons.value(),
            wCM_kgm2          = self.dsb_wCM.value(),
            wCV_kgm2          = self.dsb_wCVmax.value(),
            P_kg              = self.dsb_P.value(),
            a_m               = self.dsb_a.value() / 100,
            connector_type    = ctype,
            connector_params  = cd,
            Ec_user           = self.dsb_Ec.value(),
        )

    # ── Perfil óptimo por peso ────────────────────────────────────────────────
    def _optimal_profile(self):
        """Recorre el catálogo W y elige el perfil más ligero que cumple
        flexión (pre y compuesta), cortante y deflexiones."""
        if "Manual" in self.cb_perfil_type.currentText():
            QMessageBox.information(
                self, "Perfil óptimo",
                "La búsqueda del perfil óptimo aplica al catálogo W/IR.\n"
                "Cambie el tipo de perfil a 'W / IR'.")
            return
        from PySide6.QtWidgets import QApplication
        from PySide6.QtGui import QCursor
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        best_name, best_A = None, None
        try:
            base_inp = self._build_input()
            for name in get_sections_by_type("W"):
                sp = get_props(name)
                if not sp:
                    continue
                A = sp.get("A", 0.0)
                if best_A is not None and A >= best_A:
                    continue          # ya hay uno más ligero que cumple
                try:
                    inp = self._build_input()
                    inp.sp = sp
                    r = design(inp)
                except Exception:
                    continue
                ratios = [r.ratio_flex_pre, r.ratio_shear_pre,
                          r.ratio_shear_post]
                # Flexión compuesta: parcial si el usuario la eligió
                if self.rb_parcial.isChecked() and r.phi_Mn_partial:
                    ratios.append(r.ratio_flex_partial)
                else:
                    ratios.append(r.ratio_flex_post)
                # Deflexión total contra límite
                if getattr(r, "defl_lim_cm", 0) > 0:
                    ratios.append(r.delta_total / r.defl_lim_cm)
                if all(x <= 1.0 for x in ratios if x):
                    best_name, best_A = name, A
        finally:
            QApplication.restoreOverrideCursor()
        if best_name is None:
            QMessageBox.warning(
                self, "Perfil óptimo",
                "Ningún perfil W del catálogo cumple con los datos actuales.\n"
                "Revise claro, cargas o espesor de losa.")
            return
        peso_kgm = best_A * 0.785   # A [cm²] × 7850 kg/m³ / 1e4
        idx = self.cb_prof.findText(best_name)
        if idx >= 0:
            self.cb_prof.setCurrentIndex(idx)
        self._calculate()
        QMessageBox.information(
            self, "Perfil óptimo",
            f"Perfil más ligero que CUMPLE: {best_name}\n"
            f"Área = {best_A:.1f} cm²  (≈ {peso_kgm:.1f} kg/m)\n\n"
            "Se seleccionó en la lista y se recalculó el diseño.")

    # ── Cálculo ───────────────────────────────────────────────────────────────
    def _calculate(self):
        inp = self._build_input()
        r   = design(inp)
        self._result = r
        self._inp    = inp
        self._fill_results(r, inp)
        self._draw_section(r, inp)
        self._fill_memory(r, inp)
        self.btn_export_word.setEnabled(True)

    # ── Resultados ────────────────────────────────────────────────────────────
    def _fill_results(self, r, inp: BeamInput):
        tbl = self.res_table; tbl.setRowCount(0)
        is_lrfd = 'ASD' not in inp.code
        phi = "φ" if is_lrfd else "1/Ω"

        def sep(label):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            for c in range(4): set_item(tbl, ri, c, label if c == 0 else "", SEP, bold=True)

        def row(name, val, unit, ratio=None):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            set_item(tbl, ri, 0, name)
            set_item(tbl, ri, 1, f"{val:.4g}" if isinstance(val, float) else str(val))
            set_item(tbl, ri, 2, unit)
            if ratio is not None:
                col = OK if ratio <= 1.0 else FAIL
                fg  = None if ratio <= 1.0 else "#C0392B"
                set_item(tbl, ri, 3, f"{ratio:.3f}", col, bold=True, fg=fg)
            else:
                set_item(tbl, ri, 3, "—")

        L  = inp.L_m * 100
        sp = inp.sp or {}

        sep("SECCIÓN EFECTIVA")
        row("beff (ancho efect. losa)", r.beff, "cm")
        row("As (área acero)",          sp.get("A", 0), "cm²")
        row("Ixx acero",                sp.get("Ix", 0), "cm⁴")

        sep("PRE-CURADO (perfil solo)")
        row(f"Mu pre-curado",           r.Mu_pre / 100_000,  "t·m")  # kg·cm → t·m
        row("Mn acero (nominal)",       r.Mn_pre / 100_000, "t·m")
        row(f"FR flexión aplicado",     r.FR_flex, "—")
        row(f"{phi}Mn acero (= FR·Mn)", r.phi_Mn_pre / 100_000, "t·m", r.ratio_flex_pre)
        row(f"Vu pre-curado",           r.Vu_pre / 1000,  "t")
        row(f"{phi}Vn acero",           r.phi_Vn_pre / 1000, "t", r.ratio_shear_pre)
        row("δ pre-curado",             r.delta_pre, "cm")

        sep("CONECTORES DE CORTANTE")
        row("Qn (un conector)",         r.Qn / 1000,     "t")
        row("Cf (fuerza horiz. total)", r.C_total / 1000, "t")
        row("N req. (semi-claro full)", r.N_half_span,   "—")
        row("N total requerido",        r.N_full,         "—")
        row("% compuesto (parcial)",    r.ratio_partial * 100, "%")

        sep("SECCIÓN COMPUESTA TRANSFORMADA")
        row("n = Es/Ec",                r.n,       "—")
        row("Ec concreto",              r.Ec,      "kg/cm²")
        row("Itr (inercia transf.)",    r.Itr,     "cm⁴")
        row("ILB (cota inferior)",      r.ILB,     "cm⁴")

        sep("POST-CURADO (sección compuesta)")
        modo_completa = self.rb_completa.isChecked()
        row(f"Mu post-curado",          r.Mu_post / 100_000,      "t·m")
        row(f"Mn compuesto",            r.Mn_comp / 100_000,      "t·m")
        if modo_completa:
            row(f"{phi}Mn comp. (completa) — DISEÑO", r.phi_Mn_post / 100_000, "t·m", r.ratio_flex_post)
        else:
            row(f"{phi}Mn comp. (full, referencia)", r.phi_Mn_post / 100_000, "t·m", r.ratio_flex_post)
            row(f"{phi}Mn comp. (parcial) — DISEÑO",  r.phi_Mn_partial / 100_000, "t·m", r.ratio_flex_partial)
        row(f"Vu post-curado",          r.Vu_post / 1000,     "t")
        row(f"{phi}Vn post",            r.phi_Vn_post / 1000, "t", r.ratio_shear_post)
        sep("FLECHAS (cargas de servicio)")
        row("δ pre-fraguado (CM+CV montaje, perfil solo)", r.delta_pre, "cm")
        row("δ post (diferencial de carga, secc. compuesta)",
            r.delta_post_dif, "cm")
        _lim = getattr(r, "defl_lim_cm", L / 360) or (L / 360)
        row("δ TOTAL (pre + diferencial)", r.delta_total, "cm",
            (r.delta_total / _lim) if _lim > 0 else None)
        row("δ CV post (ILB)",          r.delta_partial_LL,   "cm")
        row(f"δ límite L/{getattr(r, 'defl_lim_denom', 360)}",
            _lim, "cm")

        if r.warnings:
            sep("⚠  ADVERTENCIAS")
            for w in r.warnings:
                ri = tbl.rowCount(); tbl.insertRow(ri)
                set_item(tbl, ri, 0, w, WARN)
                for c in (1, 2, 3): set_item(tbl, ri, c, "", WARN)

    # ── Diagramas ─────────────────────────────────────────────────────────────
    def _draw_section(self, r, inp: BeamInput):
        fig = self.canvas_sec.fig; fig.clf()
        ax1 = fig.add_subplot(2, 2, 1)
        ax2 = fig.add_subplot(2, 2, 2)
        ax_esq = fig.add_subplot(2, 1, 2)
        self._draw_esquema(ax_esq, r, inp)

        sp = inp.sp
        if sp is None:
            self.canvas_sec.redraw(); return
        d  = sp["d"]; bf = sp["bf"]; tf = sp["tf"]; tw = sp["tw"]
        tc = inp.tc_cm; hr = inp.hr_cm; beff = r.beff

        import matplotlib.patches as mpp
        ax1.set_aspect("equal"); ax1.set_title("Sección Transversal", fontsize=9, color=P)

        # Losa
        ax1.add_patch(mpp.Rectangle((-beff/2, d+hr), beff, tc,
                                    color="#90CAF9", alpha=0.7, label="Losa"))
        if hr > 0:
            ax1.add_patch(mpp.Rectangle((-beff/2, d), beff, hr,
                                        color="#CFD8DC", alpha=0.5, label="Deck"))
        # Perfil I
        hw = d - 2*tf
        ax1.add_patch(mpp.Rectangle((-bf/2, 0),    bf, tf, color="#1565C0", alpha=0.9))
        ax1.add_patch(mpp.Rectangle((-tw/2, tf),   tw, hw, color="#1565C0", alpha=0.9))
        ax1.add_patch(mpp.Rectangle((-bf/2, d-tf), bf, tf, color="#1565C0", alpha=0.9, label="Acero W"))
        # Centroide
        ax1.axhline(r.yna, color="red", ls="--", lw=1, label=f"CG y={r.yna:.1f}cm")
        ax1.set_xlim(-beff/2 - 5, beff/2 + 5)
        ax1.set_ylim(-5, d + hr + tc + 5)
        ax1.legend(fontsize=7); ax1.grid(ls=":", alpha=0.3)
        ax1.set_xlabel("X (cm)", fontsize=8); ax1.set_ylabel("Y (cm)", fontsize=8)

        # Distribución de esfuerzos (elástica lineal para referencia)
        ax2.set_title("Esfuerzos elásticos (referencia)", fontsize=9, color=P)
        if r.Itr > 0 and r.Mu_post > 0:
            n   = r.n; Ec = r.Ec
            ys  = [0, r.yna, d, d+hr, d+hr+tc]
            # esfuerzos en acero (sin transformar)
            sig_bot  =  r.Mu_post * r.yna / r.Itr
            sig_topS = -r.Mu_post * (d - r.yna) / r.Itr
            sig_topL = -r.Mu_post * (d+hr+tc - r.yna) / r.Itr / n
            sigs = [sig_bot, 0, sig_topS, sig_topS, sig_topL]
            ax2.plot([0]*5, ys, "k--", lw=0.5)
            ax2.plot(sigs, ys, "b-o", lw=2, ms=5)
            ax2.fill_betweenx(ys, 0, sigs, alpha=0.15, color="blue")
        ax2.axvline(0, color="k", lw=0.8)
        ax2.set_xlabel("σ (kg/cm²)", fontsize=8)
        ax2.set_ylabel("Y (cm)", fontsize=8)
        ax2.grid(ls=":", alpha=0.3)

        fig.tight_layout(pad=1.5)
        self.canvas_sec.redraw()

    # ── Esquema de variables ──────────────────────────────────────────────────
    def _draw_esquema(self, ax, r, inp: BeamInput):
        """Elevación esquemática con las variables del modelo."""
        import matplotlib.patches as mpp
        L  = inp.L_m
        tc = inp.tc_cm; hr = inp.hr_cm
        ax.set_title("Esquema de variables", fontsize=9, color=P)
        ax.set_xlim(-0.08 * L, 1.08 * L)
        ax.set_ylim(-0.65, 1.05)
        ax.axis("off")

        # Losa + deck (franjas sobre la trabe)
        ax.add_patch(mpp.Rectangle((0, 0.28), L, 0.16,
                                   color="#90CAF9", alpha=0.8))
        if hr > 0:
            ax.add_patch(mpp.Rectangle((0, 0.20), L, 0.08,
                                       color="#CFD8DC", alpha=0.8))
        # Trabe de acero
        ax.add_patch(mpp.Rectangle((0, 0.0), L, 0.20,
                                   color="#1565C0", alpha=0.95))
        # Apoyos
        for xa in (0.0, L):
            ax.plot([xa], [-0.06], marker="^", ms=13, color="#37474F")
        # Cota L
        ax.annotate("", xy=(L, -0.28), xytext=(0, -0.28),
                    arrowprops=dict(arrowstyle="<->", color="#37474F"))
        ax.text(L / 2, -0.40, f"L = {L:.2f} m", ha="center", fontsize=8)
        # Cargas distribuidas
        wpre = inp.wCM_losa_kgm2 + inp.wCV_const_kgm2
        wpos = inp.wCM_kgm2 + inp.wCV_kgm2
        for i in range(7):
            xq = L * (0.08 + 0.14 * i)
            ax.annotate("", xy=(xq, 0.46), xytext=(xq, 0.72),
                        arrowprops=dict(arrowstyle="->", color="#C0392B", lw=1.1))
        ax.text(L / 2, 0.84,
                f"pre: wCM+wCV = {wpre:.0f} kg/m²   |   "
                f"post: wCM+wCV = {wpos:.0f} kg/m²   |   s = {inp.s_m:.2f} m",
                ha="center", fontsize=8, color="#C0392B")
        # Carga puntual
        if inp.P_kg > 0:
            xa = max(min(inp.a_m, L), 0.0)
            ax.annotate("", xy=(xa, 0.46), xytext=(xa, 0.95),
                        arrowprops=dict(arrowstyle="-|>", color="#7D3C98", lw=2))
            ax.text(xa, 0.99, f"P = {inp.P_kg:.0f} kg  (a = {inp.a_m:.2f} m)",
                    ha="center", fontsize=8, color="#7D3C98")
        # Etiquetas tc / hr / perfil
        ax.text(1.015 * L, 0.36, f"tc = {tc:.1f} cm", fontsize=8, va="center")
        if hr > 0:
            ax.text(1.015 * L, 0.24, f"hr = {hr:.1f} cm", fontsize=8, va="center")
        nom = (inp.sp or {}).get("name", "perfil")
        ax.text(1.015 * L, 0.09, str(nom), fontsize=8, va="center",
                color="#1565C0")

    # ── Memoria de cálculo ────────────────────────────────────────────────────
    def _fill_memory(self, r, inp: BeamInput):
        sp   = inp.sp or {}
        is_l = 'ASD' not in inp.code
        phi  = "φ" if is_l else "1/Ω"
        L    = inp.L_m * 100

        def tm(kgcm: float) -> float:
            return kgcm / 100_000   # kg·cm → t·m  (1 t·m = 100 000 kg·cm)

        lines = [
            "═"*64,
            " TRABE COMPUESTA — MEMORIA DE CÁLCULO",
            f" Norma: {inp.code}",
            "═"*64,
            "",
            "1. DATOS DE ENTRADA",
            f"   Perfil       = {sp.get('name','—')}",
            f"   L            = {inp.L_m:.2f} m  ({L:.0f} cm)",
            f"   s            = {inp.s_m:.2f} m  ({inp.s_m*100:.0f} cm)",
            f"   tc           = {inp.tc_cm:.1f} cm",
            f"   hr           = {inp.hr_cm:.1f} cm",
            f"   f'c          = {inp.fc:.0f} kg/cm²",
            f"   γc           = {inp.wc:.2f} t/m³",
            f"   Fy           = {inp.Fy:.0f} kg/cm²",
            f"   As           = {sp.get('A',0):.4f} cm²",
            f"   d            = {sp.get('d',0):.2f} cm",
            f"   Ix (acero)   = {sp.get('Ix',0):.4f} cm⁴",
            f"   Zx           = {sp.get('Zx',0):.4f} cm³",
            "",
            "2. ANCHO EFECTIVO DE LOSA (AISC I3.1 / NTC DEA 10.3.1)",
            f"   beff         = {r.beff:.2f} cm",
            "",
            "3. PRE-CURADO (viga no compuesta)",
            f"   wCM losa     = {inp.wCM_losa_kgm2:.1f} kg/m²",
            f"   wCV const    = {inp.wCV_const_kgm2:.1f} kg/m²",
            f"   wu pre       = {r.wu_pre:.2f} kg/cm",
            f"   Mu pre       = {tm(r.Mu_pre):.4f} t·m",
            f"   {phi}Mn acero = {tm(r.phi_Mn_pre):.4f} t·m",
            f"   Ratio M pre  = {r.ratio_flex_pre:.3f}",
            f"   Vu pre       = {r.Vu_pre/1000:.4f} t",
            f"   {phi}Vn      = {r.phi_Vn_pre/1000:.4f} t",
            f"   Ratio V pre  = {r.ratio_shear_pre:.3f}",
            f"   δ pre-curado = {r.delta_pre:.4f} cm",
            "",
            "4. SECCIÓN COMPUESTA TRANSFORMADA",
            f"   Ec           = {r.Ec:.0f} kg/cm²",
            f"   n = Es/Ec    = {r.n:.2f}",
            f"   yna (CG comp)= {r.yna:.4f} cm",
            f"   Itr          = {r.Itr:.4f} cm⁴",
            "",
            "5. CONECTORES DE CORTANTE",
            f"   Tipo         = {inp.connector_type}",
            f"   Qn           = {r.Qn/1000:.4f} t",
            f"   Cf (total)   = {r.C_total/1000:.4f} t",
            f"   N (semi-claro full) = {r.N_half_span}",
            f"   N total req. = {r.N_full}",
            f"   N usuario    = {inp.connector_params.get('n_partial','—')}",
            f"   % compuesto  = {r.ratio_partial*100:.1f}%",
            f"   ILB          = {r.ILB:.4f} cm⁴",
            "",
            "6. POST-CURADO (sección compuesta)",
            f"   wCM post     = {inp.wCM_kgm2:.1f} kg/m²",
            f"   wCV max      = {inp.wCV_kgm2:.1f} kg/m²",
            f"   Mu post      = {tm(r.Mu_post):.4f} t·m",
            f"   Mn comp.     = {tm(r.Mn_comp):.4f} t·m",
            f"   {phi}Mn full = {tm(r.phi_Mn_post):.4f} t·m  Ratio={r.ratio_flex_post:.3f}",
            f"   {phi}Mn par. = {tm(r.phi_Mn_partial):.4f} t·m  Ratio={r.ratio_flex_partial:.3f}",
            f"   Vu post      = {r.Vu_post/1000:.4f} t",
            f"   {phi}Vn post = {r.phi_Vn_post/1000:.4f} t  Ratio={r.ratio_shear_post:.3f}",
            f"   δ CV (ILB)   = {r.delta_partial_LL:.4f} cm",
            f"   δ límite     = {L/360:.4f} cm  (L/360)",
            "═"*64,
        ]
        if r.warnings:
            lines.append("ADVERTENCIAS:")
            for w in r.warnings:
                lines.append(f"  ⚠  {w}")
            lines.append("═"*64)
        self.mem_text.setPlainText("\n".join(lines))
