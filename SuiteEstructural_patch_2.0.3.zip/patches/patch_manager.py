"""
Sistema de parches para la Struct-Link.

Flujo:
  1. El launcher llama a PatchManager.check_on_startup() al iniciar.
  2. Si hay conexión a internet, consulta el servidor de parches (JSON).
  3. Si la versión remota > versión local, muestra diálogo de actualización.
  4. El usuario acepta → se descarga el parche (.zip) y se aplica en caliente.
  5. No requiere reinstalar la suite completa.

Formato del parche (.zip):
  patch_1.0.1/
  ├── manifest.json          ← lista de archivos a reemplazar
  ├── beam_design_pro/
  │   └── gui/main_window.py ← archivo corregido
  └── suite_shared/
      └── error_reporter.py

Formato manifest.json:
  {
    "version": "1.0.1",
    "date": "2026-07-01",
    "notes": "Corrección en exportación Word de trabes.",
    "files": [
      "beam_design_pro/gui/main_window.py",
      "suite_shared/error_reporter.py"
    ]
  }
"""

import base64
import hashlib
import json
import os
import shutil
import zipfile
import logging
from pathlib import Path
from typing   import Optional

from suite_shared.version import SUITE_VERSION

log = logging.getLogger(__name__)

# Clave PÚBLICA Ed25519 (raw, base64) — la misma raíz de confianza que el
# licenciamiento. Todo parche descargado debe venir firmado con la privada.
_PUBKEY_B64 = "7cirnMjx3NtjYzEJn4UTHuV9XqQ1yRbNqGNdDAptjKU="

# URL del manifest de parches (JSON con {"version": "x.y.z", "url": "...zip"}).
# Opción recomendada: GitHub Releases — sube latest.json como release asset.
# Ejemplo:  https://raw.githubusercontent.com/TU_USUARIO/suite-estructural/master/patches/latest.json
PATCH_SERVER_URL = "https://raw.githubusercontent.com/jemaromx/Parches/main/latest.json"
SUITE_ROOT       = Path(__file__).resolve().parent.parent


class PatchManager:

    def __init__(self, suite_root: Path = SUITE_ROOT):
        self.suite_root = suite_root

    # ── API pública ──────────────────────────────────────────────────────────

    def check_on_startup(self, parent_widget=None) -> None:
        """Verificar parches disponibles; mostrar diálogo si los hay."""
        try:
            info = self._fetch_patch_info()
        except Exception as exc:
            log.debug("Sin acceso al servidor de parches: %s", exc)
            return

        if info is None:
            return

        remote_version = info.get("version", "")
        if not self._is_newer(remote_version, SUITE_VERSION):
            log.info("Suite actualizada (%s).", SUITE_VERSION)
            return

        log.info("Parche disponible: %s → %s", SUITE_VERSION, remote_version)
        self._prompt_and_apply(info, parent_widget)

    def apply_patch_file(self, zip_path: Path) -> bool:
        """Aplica un archivo .zip de parche descargado manualmente."""
        ok, err = self._apply_zip(zip_path)
        if not ok:
            log.error("Parche manual no aplicado: %s", err)
        return ok

    # ── Internos ─────────────────────────────────────────────────────────────

    def _fetch_patch_info(self) -> Optional[dict]:
        import urllib.request
        with urllib.request.urlopen(PATCH_SERVER_URL, timeout=5) as resp:
            return json.loads(resp.read().decode())

    @staticmethod
    def _is_newer(remote: str, local: str) -> bool:
        def _parts(v): return tuple(int(x) for x in v.split("."))
        try:
            return _parts(remote) > _parts(local)
        except ValueError:
            return False

    def _cadena_pendiente(self, info: dict) -> list:
        """
        Lista ORDENADA de parches que faltan por instalar, desde la versión
        local (exclusiva) hasta la remota (inclusiva).

        El manifest remoto puede incluir "patches": [ {version, notes,
        download_url, sha256, signature}, ... ] con el historial completo de
        parches. Cada entrada representa un parche ACUMULATIVO; se instalan
        en orden todos los que sean más nuevos que la versión local, de modo
        que un usuario que saltó versiones reciba primero las que le faltan.

        Si el manifest no trae "patches" (formato antiguo), se usa el propio
        manifest como único parche (comportamiento previo).
        """
        cadena = info.get("patches")
        if not isinstance(cadena, list) or not cadena:
            # Formato antiguo: un solo parche descrito en la raíz del manifest.
            cadena = [info]

        pendientes = [p for p in cadena
                      if self._is_newer(p.get("version", ""), SUITE_VERSION)]
        pendientes.sort(key=lambda p: self._version_key(p.get("version", "")))
        return pendientes

    @staticmethod
    def _version_key(v: str):
        try:
            return tuple(int(x) for x in v.split("."))
        except ValueError:
            return (0,)

    def _prompt_and_apply(self, info: dict, parent=None) -> None:
        from PySide6.QtWidgets import QMessageBox

        pendientes = self._cadena_pendiente(info)
        if not pendientes:
            return

        version_final = pendientes[-1].get("version", "?")

        # Resumen de todo lo que se instalará (incluye parches saltados).
        if len(pendientes) == 1:
            detalle = pendientes[0].get("notes", "Sin notas.")
            titulo_msg = f"Versión {version_final} disponible."
        else:
            lineas = "\n".join(
                f"  • {p.get('version', '?')} — {p.get('notes', '').splitlines()[0] if p.get('notes') else 'Actualización'}"
                for p in pendientes)
            titulo_msg = (
                f"Su versión ({SUITE_VERSION}) está {len(pendientes)} "
                f"actualizaciones por detrás.\nSe instalarán en orden hasta "
                f"la versión {version_final}:\n\n{lineas}")

        ans = QMessageBox.question(
            parent,
            "Actualización disponible",
            f"{titulo_msg}\n\n¿Desea instalar ahora?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if ans != QMessageBox.Yes:
            return

        aplicados = []
        for idx, p in enumerate(pendientes, 1):
            ver = p.get("version", "?")
            ok, err = self._descargar_y_aplicar(p, parent)
            if not ok:
                # Falla cerrada: se detiene la cadena. Lo ya aplicado queda,
                # pero NO se salta ningún parche intermedio.
                faltan = [q.get("version", "?") for q in pendientes[idx - 1:]]
                QMessageBox.critical(
                    parent, "Actualización interrumpida",
                    f"No se pudo instalar la actualización {ver}.\n\n"
                    f"Detalle: {err}\n\n"
                    f"{'Se instalaron: ' + ', '.join(aplicados) if aplicados else 'No se instaló ninguna.'}\n"
                    f"Pendientes: {', '.join(faltan)}\n\n"
                    "La suite reintentará las faltantes en el próximo inicio. "
                    "Si el problema persiste, contacte a soporte.")
                return
            aplicados.append(ver)

        QMessageBox.information(
            parent,
            "Actualización completada",
            f"La suite se actualizó a la versión {version_final}.\n"
            + (f"Se instalaron {len(aplicados)} actualizaciones: "
               f"{', '.join(aplicados)}.\n" if len(aplicados) > 1 else "")
            + "Los cambios se aplican al reiniciar cada módulo.",
        )

    def _descargar_y_aplicar(self, info: dict, parent=None) -> tuple:
        """Descarga, verifica firma y aplica UN parche. Regresa (ok, error)."""
        version = info.get("version", "?")
        url = info.get("download_url")
        if not url:
            return False, "URL de descarga no disponible."

        zip_path = self.suite_root / "_patches_tmp" / f"patch_{version}.zip"
        zip_path.parent.mkdir(exist_ok=True)
        try:
            import urllib.request
            urllib.request.urlretrieve(url, zip_path)
            # Verificación de integridad y autenticidad ANTES de aplicar:
            # firma Ed25519 + SHA-256 válidos. Sin ellos (o inválidos) se
            # rechaza (falla cerrada).
            err = self._verify_download(zip_path, info)
            if err:
                log.error("Parche %s rechazado: %s", version, err)
                return False, err
            ok, err = self._apply_zip(zip_path)
            if not ok:
                return False, err
            return True, ""
        except Exception as exc:                    # noqa: BLE001
            return False, str(exc)
        finally:
            shutil.rmtree(zip_path.parent, ignore_errors=True)

    @staticmethod
    def _verify_download(zip_path: Path, info: dict) -> str:
        """
        Verifica SHA-256 y firma Ed25519 del zip contra el manifest remoto.
        Regresa "" si todo es válido; un mensaje de error en caso contrario
        (falla cerrada: sin sha256/firma el parche se rechaza).
        """
        sha_esp   = str(info.get("sha256", "")).lower().strip()
        firma_b64 = str(info.get("signature", "")).strip()
        if not sha_esp or not firma_b64:
            return "el manifest no incluye sha256/firma"

        data = zip_path.read_bytes()
        sha_real = hashlib.sha256(data).hexdigest()
        if sha_real != sha_esp:
            return "el hash SHA-256 no coincide"

        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey)
            pub = Ed25519PublicKey.from_public_bytes(
                base64.b64decode(_PUBKEY_B64))
            pub.verify(base64.b64decode(firma_b64), data)
        except Exception:
            return "la firma Ed25519 no es válida"
        return ""

    # Archivo que declara la versión instalada. DEBE escribirse al final:
    # si se escribe antes y algo falla, la suite queda diciendo que ya está
    # actualizada y nunca vuelve a ofrecer el parche, dejando los motores de
    # cálculo (.pyd) sin actualizar y sin ningún aviso al usuario.
    _VERSION_FILE = "suite_shared/version.py"

    def _apply_zip(self, zip_path: Path) -> tuple:
        """Aplica un parche de forma TRANSACCIONAL: o entra completo, o la
        instalación queda como estaba.

        Regresa (ok, error). El error es un texto ya legible para el usuario.

        En Windows un .pyd es una DLL: mientras un módulo esté abierto, su
        motor de cálculo está cargado en memoria y NO se puede sobrescribir.
        Por eso se comprueba primero que TODOS los destinos sean escribibles
        y sólo entonces se escribe nada.
        """
        try:
            suite_base = self.suite_root.resolve()
            with zipfile.ZipFile(zip_path) as zf:
                manifest = json.loads(zf.read("manifest.json"))
                files_to_patch = list(manifest.get("files", []))

                # `version.py` siempre al final del orden de escritura.
                files_to_patch.sort(key=lambda r: r == self._VERSION_FILE)

                # ── 1. Validación de rutas (anti Zip-Slip) ──────────────
                destinos = []
                for rel_path in files_to_patch:
                    dest = (self.suite_root / rel_path).resolve()
                    if not dest.is_relative_to(suite_base):
                        log.error("Ruta fuera del árbol de la suite "
                                  "rechazada: %s", rel_path)
                        return False, ("el parche contiene una ruta inválida "
                                       f"({rel_path}).")
                    destinos.append((rel_path, dest))

                # ── 1b. Idempotencia: lo que ya está igual no se toca ───
                # Un cliente que quedó a medias (aplicador anterior) ya
                # tiene parte de los archivos; reescribirlos no aporta y
                # sólo añade puntos donde un bloqueo puede fallar.
                def _igual(dest: Path, rel: str) -> bool:
                    if not dest.exists():
                        return False
                    h = hashlib.sha256()
                    with open(dest, "rb") as fh:
                        for chunk in iter(lambda: fh.read(65536), b""):
                            h.update(chunk)
                    return h.hexdigest() == hashlib.sha256(
                        zf.read(rel)).hexdigest()
                destinos = [(rel, dest) for rel, dest in destinos
                            if not _igual(dest, rel)]
                if not destinos:
                    log.info("Parche %s: ya estaba aplicado por completo.",
                             manifest["version"])
                    return True, ""

                # ── 2. Comprobar que se puede escribir TODO ─────────────
                # Antes de tocar un solo archivo, para no dejar la
                # instalación a medias.
                bloqueados = [rel for rel, dest in destinos
                              if not self._escribible(dest)]
                if bloqueados:
                    modulos = sorted({rel.split("/")[0]
                                      for rel in bloqueados})
                    log.error("Archivos bloqueados (%d): %s",
                              len(bloqueados), ", ".join(bloqueados[:10]))
                    return False, (
                        "hay módulos abiertos y sus archivos no se pueden "
                        "reemplazar.\nCierre la suite por completo "
                        "(incluidos los módulos ya abiertos) e inténtelo de "
                        "nuevo.\n\nMódulos en uso: " + ", ".join(modulos))

                # ── 3. Escribir a temporales ────────────────────────────
                # Nada definitivo hasta que TODOS los temporales existan.
                backup_dir = self.suite_root / "_backup" / manifest["version"]
                backup_dir.mkdir(parents=True, exist_ok=True)
                temporales = []
                try:
                    for rel_path, dest in destinos:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        tmp = dest.with_name(dest.name + ".parche_nuevo")
                        with zf.open(rel_path) as src, open(tmp, "wb") as out:
                            shutil.copyfileobj(src, out)
                        temporales.append((rel_path, dest, tmp))
                except Exception:
                    for _, _, tmp in temporales:
                        tmp.unlink(missing_ok=True)
                    raise

                # ── 4. Respaldar y mover a su lugar ─────────────────────
                movidos = []
                try:
                    for rel_path, dest, tmp in temporales:
                        if dest.exists():
                            backup = backup_dir / rel_path
                            backup.parent.mkdir(parents=True, exist_ok=True)
                            if not backup.exists():
                                shutil.copy2(dest, backup)
                        os.replace(tmp, dest)      # atómico en el mismo disco
                        movidos.append((rel_path, dest))
                except Exception as exc:
                    log.error("Fallo al instalar %s; revirtiendo.", exc)
                    self._revertir(movidos, backup_dir)
                    for _, _, tmp in temporales:
                        tmp.unlink(missing_ok=True)
                    return False, (f"no se pudo reemplazar un archivo ({exc}). "
                                   "Se restauró la versión anterior.")

                log.info("Parche %s aplicado: %d archivo(s).",
                         manifest["version"], len(movidos))
            return True, ""
        except Exception as exc:
            log.error("Error al aplicar parche: %s", exc)
            return False, f"no se pudo aplicar el contenido del parche ({exc})."

    @staticmethod
    def _escribible(dest: Path) -> bool:
        """¿Se puede reemplazar `dest`? Si existe, pide permiso de escritura
        sin modificarlo (falla si otro proceso lo tiene tomado); si no
        existe, comprueba que su carpeta sea creable/escribible."""
        try:
            if dest.exists():
                with open(dest, "r+b"):
                    pass
                return True
            dest.parent.mkdir(parents=True, exist_ok=True)
            sonda = dest.with_name(dest.name + ".parche_prueba")
            sonda.write_bytes(b"")
            sonda.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    @staticmethod
    def _revertir(movidos: list, backup_dir: Path) -> None:
        """Restaura desde el respaldo los archivos ya reemplazados."""
        for rel_path, dest in reversed(movidos):
            try:
                backup = backup_dir / rel_path
                if backup.exists():
                    shutil.copy2(backup, dest)
                else:
                    dest.unlink(missing_ok=True)   # era un archivo nuevo
            except Exception:                       # noqa: BLE001
                log.exception("No se pudo revertir %s", rel_path)
