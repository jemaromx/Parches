"""Hoja de estilos QSS estándar para la Suite de Diseño Estructural (PySide6).

Sistema visual unificado: azul técnico + acento ámbar sobre neutros slate.
Look profesional, sobrio y de alta densidad de datos. Fuente única de verdad
para los 11 módulos: cada `<modulo>/gui/styles.py` construye su MAIN_STYLE
desde aquí.

Las medidas son deliberadamente COMPACTAS: los paneles de captura de la suite
son angostos (270–400 px) y con scroll, así que un padding generoso provoca
que campos y botones se recorten. Cualquier cambio de tamaño aquí debe
verificarse con `herramientas_admin/revisar_recortes.py`.
"""

# ── Tokens del sistema visual ────────────────────────────────────────────────
PRIMARY   = "#1B4F72"   # azul marca (encabezado, tabla, pestaña activa)
PRIMARY_D = "#153A56"   # azul marca oscuro (pressed)
INK       = "#1E293B"   # texto principal (slate-800)
MUTED     = "#64748B"   # texto secundario (slate-500)
APP_BG    = "#F1F5F9"   # fondo de la app (slate-100)
PANEL     = "#FFFFFF"   # paneles / tarjetas
BORDER    = "#E2E8F0"   # borde suave (slate-200)
BORDER_D  = "#CBD5E1"   # borde marcado (slate-300)
FOCUS     = "#2563EB"   # azul de foco / interacción
ACCENT    = "#D97706"   # ámbar — resaltes
OK        = "#15803D"   # verde (cumple / ejecutar)
OK_D      = "#116330"
WARN      = "#B45309"   # ámbar oscuro (excel / dxf)
WARN_D    = "#8A3F07"
DANGER    = "#DC2626"   # rojo (limpiar)
DANGER_D  = "#B91C1C"
WORD      = "#2563EB"   # azul (Word)
WORD_D    = "#1D4ED8"
MEMORY    = "#6D28D9"   # morado (memoria)
MEMORY_D  = "#5B21B6"
TEAL      = "#0F766E"   # verde azulado (conectar)
TEAL_D    = "#0B5A54"

# Compatibilidad con el diccionario COLORS previo
COLORS = {
    "primary": PRIMARY, "secondary": FOCUS, "bg": APP_BG, "panel": PANEL,
    "text": INK, "accent": DANGER, "success": OK, "warning": WARN,
    "ok": OK, "border": BORDER, "muted": MUTED,
}

TABLE_OK   = "#DCFCE7"
TABLE_WARN = "#FEF3C7"
TABLE_FAIL = "#FEE2E2"
TABLE_SEP  = "#DBEAFE"


def make_main_style(accent: str | None = None) -> str:
    """QSS completo del módulo. `accent` sobreescribe el color del botón
    de conexión (identidad por módulo)."""
    connect = accent or TEAL
    return f"""
QMainWindow, QDialog {{
    background-color: {APP_BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9pt;
    color: {INK};
}}

/* ── Paneles ────────────────────────────────────────────────────────────── */
QGroupBox {{
    border: 1px solid {BORDER};
    border-radius: 7px;
    margin-top: 9px;
    padding: 8px 6px 6px 6px;
    background: {PANEL};
    font-weight: 600;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 9px;
    top: 1px;
    padding: 0 4px;
    color: {PRIMARY};
    font-weight: bold;
}}

/* ── Botones ────────────────────────────────────────────────────────────── */
QPushButton {{
    background-color: {PRIMARY};
    color: white;
    border: none;
    border-radius: 5px;
    padding: 4px 11px;
    min-height: 23px;
    font-weight: 600;
}}
QPushButton:hover   {{ background-color: {FOCUS}; }}
QPushButton:pressed {{ background-color: {PRIMARY_D}; }}
QPushButton:disabled {{ background-color: {BORDER_D}; color: {APP_BG}; }}

QPushButton#btn_run, QPushButton#btnGreen {{
    background-color: {OK}; font-weight: bold; font-size: 10.5pt; min-height: 32px;
}}
QPushButton#btn_run:hover, QPushButton#btnGreen:hover {{ background-color: {OK_D}; }}

QPushButton#btn_word {{ background-color: {WORD}; }}
QPushButton#btn_word:hover {{ background-color: {WORD_D}; }}
QPushButton#btn_memory {{ background-color: {MEMORY}; }}
QPushButton#btn_memory:hover {{ background-color: {MEMORY_D}; }}
QPushButton#btn_excel, QPushButton#btn_dxf,
QPushButton#btnOrange, QPushButton#btn_plots {{ background-color: {WARN}; }}
QPushButton#btn_excel:hover, QPushButton#btn_dxf:hover,
QPushButton#btnOrange:hover, QPushButton#btn_plots:hover {{ background-color: {WARN_D}; }}
QPushButton#btn_clear, QPushButton#btnRed {{ background-color: {DANGER}; }}
QPushButton#btn_clear:hover, QPushButton#btnRed:hover {{ background-color: {DANGER_D}; }}
QPushButton#btn_export {{ background-color: {PRIMARY}; }}
QPushButton#btn_template {{
    background-color: {BORDER}; color: {INK}; font-size: 8pt;
    min-height: 20px; padding: 3px 9px; font-weight: 600;
}}
QPushButton#btn_template:hover {{ background-color: {BORDER_D}; }}
QPushButton#btn_connect {{ background-color: {connect}; font-weight: bold; }}
QPushButton#btn_connect:hover    {{ background-color: {TEAL_D}; }}
QPushButton#btn_connect:disabled {{ background-color: {BORDER_D}; }}

/* ── Campos ─────────────────────────────────────────────────────────────── */
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {{
    border: 1px solid {BORDER_D};
    border-radius: 4px;
    padding: 2px 6px;
    background: {PANEL};
    min-height: 21px;
    selection-background-color: {FOCUS};
    selection-color: white;
}}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {{
    border: 1.5px solid {FOCUS};
}}
QLineEdit:hover, QDoubleSpinBox:hover, QSpinBox:hover, QComboBox:hover {{
    border-color: #94A3B8;
}}
QLineEdit:disabled, QDoubleSpinBox:disabled,
QSpinBox:disabled, QComboBox:disabled {{
    background: {APP_BG}; color: {MUTED};
}}
QComboBox::drop-down {{ border: none; width: 18px; }}
QComboBox QAbstractItemView {{
    border: 1px solid {BORDER_D};
    background: {PANEL};
    selection-background-color: {TABLE_SEP};
    selection-color: {INK};
    outline: none;
}}

QRadioButton {{ spacing: 5px; }}
QRadioButton::indicator {{ width: 14px; height: 14px; }}
QCheckBox {{ spacing: 5px; }}
QCheckBox::indicator {{
    width: 15px; height: 15px;
    border: 1px solid {BORDER_D}; border-radius: 3px; background: {PANEL};
}}
QCheckBox::indicator:checked {{ background: {FOCUS}; border-color: {FOCUS}; }}

/* ── Pestañas (tarjeta, activa en blanco) ───────────────────────────────── */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    border-radius: 7px;
    background: {PANEL};
    top: -1px;
}}
QTabBar::tab {{
    background: #E9EEF3;
    color: {MUTED};
    padding: 6px 15px;
    border: 1px solid {BORDER};
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    margin-right: 2px;
    font-weight: 600;
}}
QTabBar::tab:selected {{
    background: {PANEL};
    color: {PRIMARY};
    font-weight: bold;
}}
QTabBar::tab:hover:!selected {{ background: {BORDER}; color: {INK}; }}

/* ── Tablas ─────────────────────────────────────────────────────────────── */
QTableWidget {{
    border: 1px solid {BORDER};
    border-radius: 7px;
    gridline-color: {BORDER};
    background-color: {PANEL};
    alternate-background-color: #F8FAFC;
    selection-background-color: {TABLE_SEP};
    selection-color: {INK};
}}
QTableWidget::item {{ padding: 3px 6px; }}
QTableWidget::item:selected {{ color: {INK}; }}
QHeaderView::section {{
    background-color: {PRIMARY};
    color: white;
    padding: 5px 4px;
    border: none;
    border-right: 1px solid #2E6B94;
    font-weight: bold;
}}
QTableCornerButton::section {{ background-color: {PRIMARY}; border: none; }}

/* ── Scrollbars ─────────────────────────────────────────────────────────── */
QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{
    background: {BORDER_D}; border-radius: 5px; min-height: 22px;
}}
QScrollBar::handle:vertical:hover {{ background: #94A3B8; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{ height: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:horizontal {{
    background: {BORDER_D}; border-radius: 5px; min-width: 22px;
}}
QScrollBar::handle:horizontal:hover {{ background: #94A3B8; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}

/* ── Barra de estado / progreso ─────────────────────────────────────────── */
QStatusBar {{ background: {PRIMARY}; color: white; font-size: 8.5pt; }}
QStatusBar QLabel {{ color: white; }}
QProgressBar {{
    border: none; border-radius: 3px; text-align: center;
    height: 6px; background: {BORDER};
}}
QProgressBar::chunk {{ background: {OK}; border-radius: 3px; }}

QSplitter::handle {{ background: {BORDER}; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}

QToolBar {{
    background: {PANEL};
    border-bottom: 1px solid {BORDER};
    spacing: 4px; padding: 3px;
}}
QToolBar QToolButton {{
    color: {INK}; padding: 4px 9px; border-radius: 4px; font-weight: 600;
}}
QToolBar QToolButton:hover {{ background: {BORDER}; }}

QToolTip {{
    background: {INK}; color: white; border: none;
    padding: 4px 7px; border-radius: 4px; font-size: 8pt;
}}
"""


HEADER_STYLE = f"""
QFrame {{
    background-color: {PRIMARY};
}}
"""

# Alias usado por algunos módulos
MAIN_STYLE = make_main_style()
