# -*- coding: utf-8 -*-
"""
Estilo unificado de gráficas matplotlib para la Suite de Diseño Estructural.

Un solo lugar define la paleta y los ajustes de ejes, de modo que todas las
gráficas de todos los módulos compartan el mismo look técnico y sobrio
(fondo claro, rejilla slate discreta, curvas en azul + ámbar, semántica
verde/rojo para cumple/no cumple).

Uso mínimo en un módulo:
    from suite_shared.plot_style import install_rcparams, PALETTE, style_axes
    install_rcparams()          # una vez, al importar el módulo de gráficas
    ...
    style_axes(ax)              # tras crear cada eje 2D (opcional pero recomendado)
"""
from __future__ import annotations

# ── Paleta (azul técnico + ámbar sobre slate) ────────────────────────────────
PALETTE = {
    "fig_bg":    "#F8FAFC",   # marco de la figura (slate-50)
    "axes_bg":   "#FFFFFF",   # área de trazado
    "grid":      "#E2E8F0",   # rejilla (slate-200)
    "spine":     "#CBD5E1",   # ejes (slate-300)
    "tick":      "#475569",   # marcas y números (slate-600)
    "label":     "#1E293B",   # etiquetas de ejes (slate-800)
    "title":     "#0F172A",   # títulos (slate-900)
    "nominal":   "#93C5FD",   # curva nominal (azul claro)
    "factored":  "#1E40AF",   # curva factorada φ (azul intenso)
    "fill":      "#DBEAFE",   # relleno de superficie (azul-100)
    "accent":    "#D97706",   # ámbar — resaltes/segundo dato
    "ok":        "#15803D",   # cumple (verde-700)
    "fail":      "#DC2626",   # no cumple (rojo-600)
    "axis0":     "#94A3B8",   # líneas de eje 0 (slate-400)
}

_INSTALADO = False


def install_rcparams() -> None:
    """Ajusta los rcParams globales de matplotlib al estilo de la suite."""
    global _INSTALADO
    if _INSTALADO:
        return
    try:
        import matplotlib as mpl
    except Exception:                               # noqa: BLE001
        return
    p = PALETTE
    mpl.rcParams.update({
        "figure.facecolor":  p["fig_bg"],
        "savefig.facecolor":  p["fig_bg"],
        "axes.facecolor":    p["axes_bg"],
        "axes.edgecolor":    p["spine"],
        "axes.labelcolor":   p["label"],
        "axes.titlecolor":   p["title"],
        "axes.titleweight":  "bold",
        "axes.linewidth":    0.9,
        "axes.grid":         True,
        "grid.color":        p["grid"],
        "grid.linewidth":    0.8,
        "grid.alpha":        1.0,
        "xtick.color":       p["tick"],
        "ytick.color":       p["tick"],
        "xtick.labelsize":   8.5,
        "ytick.labelsize":   8.5,
        "font.family":       ["Segoe UI", "DejaVu Sans", "sans-serif"],
        "font.size":         9.0,
        "legend.frameon":    True,
        "legend.framealpha": 0.92,
        "legend.edgecolor":  p["spine"],
        "legend.fontsize":   8.0,
        "axes.spines.top":   False,
        "axes.spines.right": False,
    })
    _INSTALADO = True


def style_axes(ax, fig=None) -> None:
    """Aplica el estilo de la suite a un eje 2D ya creado."""
    p = PALETTE
    try:
        ax.set_facecolor(p["axes_bg"])
        if fig is not None:
            fig.patch.set_facecolor(p["fig_bg"])
        ax.grid(True, color=p["grid"], linewidth=0.8)
        ax.set_axisbelow(True)
        for lado in ("top", "right"):
            if lado in ax.spines:
                ax.spines[lado].set_visible(False)
        for lado in ("left", "bottom"):
            if lado in ax.spines:
                ax.spines[lado].set_color(p["spine"])
        ax.tick_params(colors=p["tick"], labelsize=8.5)
    except Exception:                               # noqa: BLE001
        pass
