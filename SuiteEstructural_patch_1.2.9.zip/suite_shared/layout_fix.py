# -*- coding: utf-8 -*-
"""
Corrección de recortes de la UI — común a todos los módulos de la suite.

Resuelve dos defectos que hacían que la suite se viera poco profesional:

  A) Panel de captura MÁS ANGOSTO que sus campos: los combos, spinboxes y
     botones quedaban cortados por la derecha (el área con scroll tiene el
     scroll horizontal desactivado, así que no había forma de verlos).
     → Se relajan los anchos máximos hacia arriba hasta que el contenido
       quepa, incluyendo el ancho de la barra de desplazamiento.

  B) BOTÓN PRINCIPAL dentro del área con scroll: al haber mucho contenido
     quedaba cortado abajo y obligaba a desplazarse para verlo completo.
     → Se mueve a un pie fijo, fuera del scroll, siempre visible.

Uso (una línea al final del __init__ de la ventana principal):

    from suite_shared.layout_fix import corregir_recortes
    corregir_recortes(self)

Verificación: `herramientas_admin/revisar_recortes.py`.
"""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

# Holgura para la barra de desplazamiento vertical + margen del marco.
_HOLGURA = 22


def es_accion_principal(btn) -> bool:
    """
    ¿Es EL botón de ejecutar del módulo?

    Convención de la suite: objectName 'btn_run', o un texto que empieza con
    el triángulo ▶. Se excluyen a propósito:
      • 'btnGreen' a secas — lo usan botones auxiliares (p. ej. «Auto K»)
        que sólo buscan el color verde.
      • Flechas de navegación «▶» / «▶▶» (texto de 1-2 caracteres).
    """
    if (btn.objectName() or "").strip() == "btn_run":
        return True
    txt = (btn.text() or "").strip()
    return txt.startswith("▶") and len(txt) > 3


def _asegurar_ancho(scroll, necesario: int) -> None:
    """Relaja hacia arriba los anchos máximos para que el contenido quepa."""
    from PySide6.QtWidgets import QSplitter

    if scroll.minimumWidth() < necesario:
        scroll.setMinimumWidth(necesario)

    w = scroll
    while w is not None and not w.isWindow():
        # Sólo se AMPLÍA: nunca se reduce un ancho ya definido.
        if 0 < w.maximumWidth() < necesario:
            w.setMaximumWidth(necesario)
        if w.minimumWidth() < necesario and w.parentWidget() is not None:
            padre = w.parentWidget()
            if isinstance(padre, QSplitter):
                w.setMinimumWidth(necesario)
        w = w.parentWidget()

    # Repartir de nuevo el splitter para que el panel tome el ancho pedido.
    padre = scroll.parentWidget()
    while padre is not None and not padre.isWindow():
        if isinstance(padre, QSplitter):
            tam = padre.sizes()
            if tam and len(tam) >= 2 and tam[0] < necesario:
                extra = necesario - tam[0]
                tam[0] = necesario
                tam[1] = max(200, tam[1] - extra)
                padre.setSizes(tam)
            break
        padre = padre.parentWidget()


def _fijar_accion_principal(scroll) -> int:
    """Mueve el botón principal fuera del scroll, a un pie fijo. Devuelve
    cuántos botones movió."""
    from PySide6.QtWidgets import (QPushButton, QVBoxLayout, QWidget,
                                   QBoxLayout)

    from PySide6.QtWidgets import QSplitter

    inner = scroll.widget()
    contenedor = scroll.parentWidget()
    if inner is None or contenedor is None:
        return 0

    botones = [b for b in inner.findChildren(QPushButton)
               if es_accion_principal(b)]
    if not botones:
        return 0

    lay_ext = contenedor.layout()

    if not isinstance(lay_ext, QBoxLayout):
        # El scroll cuelga directamente de un QSplitter (sin layout): se
        # envuelve en un contenedor propio para poder colgarle el pie fijo.
        if not isinstance(contenedor, QSplitter):
            return 0
        splitter = contenedor
        idx = splitter.indexOf(scroll)
        if idx < 0:
            return 0
        ancho_min, ancho_max = scroll.minimumWidth(), scroll.maximumWidth()
        envoltura = QWidget()
        envoltura.setObjectName("panel_con_pie")
        lay_ext = QVBoxLayout(envoltura)
        lay_ext.setContentsMargins(0, 0, 0, 0)
        lay_ext.setSpacing(0)
        lay_ext.addWidget(scroll)          # reparenta el scroll
        splitter.insertWidget(idx, envoltura)
        if ancho_min:
            envoltura.setMinimumWidth(ancho_min)
        if 0 < ancho_max < 16777215:
            envoltura.setMaximumWidth(ancho_max)
        contenedor = envoltura

    pie = contenedor.findChild(QWidget, "pie_acciones")
    if pie is None:
        pie = QWidget(contenedor)
        pie.setObjectName("pie_acciones")
        pl = QVBoxLayout(pie)
        pl.setContentsMargins(8, 6, 8, 8)
        pl.setSpacing(6)
        # Justo debajo del área con scroll.
        idx = lay_ext.indexOf(scroll)
        lay_ext.insertWidget(idx + 1 if idx >= 0 else lay_ext.count(), pie)

    movidos = 0
    for b in botones:
        lay_orig = b.parentWidget().layout() if b.parentWidget() else None
        if lay_orig is not None:
            lay_orig.removeWidget(b)
        pie.layout().addWidget(b)   # reparenta y conserva sus conexiones
        b.show()
        movidos += 1
    return movidos


def corregir_recortes(win) -> None:
    """Aplica ambas correcciones a la ventana. Nunca interrumpe el arranque."""
    try:
        from PySide6.QtWidgets import QScrollArea
    except Exception:                               # noqa: BLE001
        return

    for scroll in win.findChildren(QScrollArea):
        try:
            inner = scroll.widget()
            if inner is None:
                continue
            # (B) primero: al sacar el botón, el contenido se vuelve más bajo.
            _fijar_accion_principal(scroll)
            # (A) después: ancho definitivo del contenido restante.
            necesario = inner.sizeHint().width() + _HOLGURA
            _asegurar_ancho(scroll, necesario)
        except Exception as exc:                    # noqa: BLE001
            log.warning("corregir_recortes: %s", exc)
