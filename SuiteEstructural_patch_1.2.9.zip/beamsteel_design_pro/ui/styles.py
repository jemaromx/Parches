# ui/styles.py  — colores idénticos a beam_design_pro
from config.settings import COLORS

P  = COLORS["primary"]      # #1B4F72
S  = COLORS["secondary"]    # #2874A6
A  = COLORS["accent"]       # #E74C3C
OK = COLORS["success"]      # #1E8449
WA = COLORS["warning"]      # #D68910
BG = COLORS["bg"]           # #EBF5FB
PN = COLORS["panel"]        # #FFFFFF
TX = COLORS["text"]         # #1C2833

MAIN_STYLE = f"""
QMainWindow, QDialog {{
    background: {BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9pt;
    color: {TX};
}}
QTabWidget::pane {{
    border: 1px solid #B2BABB;
    background: {PN};
    border-radius: 4px;
}}
QTabBar::tab {{
    background: #D5D8DC;
    padding: 8px 20px;
    margin-right: 2px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    font-weight: bold;
    color: {TX};
}}
QTabBar::tab:selected {{
    background: {P};
    color: white;
}}
QTabBar::tab:hover:!selected {{
    background: {S};
    color: white;
}}
QPushButton {{
    background: {P};
    color: white;
    border: none;
    border-radius: 4px;
    padding: 7px 16px;
    font-weight: bold;
}}
QPushButton:hover {{ background: {S}; }}
QPushButton:disabled {{ background: #BDC3C7; color: #7F8C8D; }}
QPushButton#btnGreen, QPushButton#btn_run {{
    background: {OK}; color: white; font-weight: bold; min-height: 32px; font-size: 10pt;
}}
QPushButton#btnGreen:hover, QPushButton#btn_run:hover {{ background: #239B56; }}
QPushButton#btn_run {{ font-size: 10pt; }}
QPushButton#btnOrange, QPushButton#btn_excel, QPushButton#btn_dxf {{
    background: {WA}; color: white;
}}
QPushButton#btnOrange:hover, QPushButton#btn_excel:hover, QPushButton#btn_dxf:hover {{
    background: #B7770D;
}}
QPushButton#btnRed, QPushButton#btn_clear {{
    background: {A}; color: white;
}}
QPushButton#btnRed:hover, QPushButton#btn_clear:hover {{ background: #CB4335; }}
QPushButton#btn_word {{ background: #2E86C1; color: white; }}
QPushButton#btn_word:hover {{ background: #1A5276; }}
QPushButton#btn_memory {{ background: #7D3C98; color: white; }}
QPushButton#btn_memory:hover {{ background: #6C3483; }}
QPushButton#btn_connect {{ background: #117A65; color: white; font-weight: bold; }}
QPushButton#btn_connect:hover {{ background: #0E6655; }}
QPushButton#btn_connect:disabled {{ background: #BDC3C7; color: #7F8C8D; }}
QGroupBox {{
    border: 1px solid #A9CCE3;
    border-radius: 6px;
    margin-top: 14px;
    padding-top: 6px;
    font-weight: bold;
    color: {P};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
    background: {BG};
}}
QTableWidget {{
    gridline-color: #D5D8DC;
    selection-background-color: {S};
    selection-color: white;
    alternate-background-color: #EAF4FB;
    background: white;
}}
QTableWidget::item {{ padding: 3px 6px; }}
QHeaderView::section {{
    background: {P};
    color: white;
    font-weight: bold;
    padding: 6px 4px;
    border: none;
    border-right: 1px solid #2874A6;
}}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    border: 1px solid #A9CCE3;
    border-radius: 3px;
    padding: 4px 6px;
    background: white;
}}
QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus {{ border-color: {S}; }}
QProgressBar {{
    border: none;
    border-radius: 0px;
    height: 5px;
    background: #AED6F1;
}}
QProgressBar::chunk {{ background: {OK}; border-radius: 0px; }}
QStatusBar {{
    background: {P};
    color: white;
    font-weight: bold;
    padding-left: 6px;
}}
QStatusBar QLabel {{ color: white; }}
QScrollBar:vertical {{
    background: {BG};
    width: 10px;
    border-radius: 5px;
}}
QScrollBar::handle:vertical {{
    background: {S};
    border-radius: 5px;
    min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{
    height: 10px;
    background: {BG};
    border-radius: 5px;
}}
QScrollBar::handle:horizontal {{
    background: {S};
    border-radius: 5px;
    min-width: 20px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
QSplitter::handle {{ background: #A9CCE3; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}
QStatusBar {{
    background: {P};
    color: white;
    font-size: 9pt;
    font-weight: bold;
    padding-left: 6px;
}}
QStatusBar QLabel {{ color: white; }}
QCheckBox {{ spacing: 6px; }}
QCheckBox::indicator {{
    width: 15px; height: 15px;
    border: 1px solid #A9CCE3;
    border-radius: 3px;
    background: white;
}}
QCheckBox::indicator:checked {{ background: {S}; }}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Sistema visual unificado de la suite (azul técnico + ámbar sobre slate).
# Sobrescribe la hoja anterior; los tokens de arriba se conservan porque
# otros archivos del módulo los importan. Si suite_shared no estuviera
# disponible, se mantiene el estilo previo como respaldo.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from suite_shared.styles import (make_main_style as _mk,
                                     HEADER_STYLE as _HDR)
    MAIN_STYLE = _mk()
except Exception:  # noqa: BLE001
    pass
