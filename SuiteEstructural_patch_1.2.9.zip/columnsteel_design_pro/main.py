#!/usr/bin/env python3
"""Column Steel Design Pro — Punto de entrada."""
import sys
from pathlib import Path

# ── suite_shared ──────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.splash import make_splash

log = setup_logging("columnsteel_design_pro")
install_excepthook("columnsteel_design_pro")

from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import QTimer
from ui.main_window   import MainWindow
from config.settings  import APP_NAME, APP_VERSION

def _make_splash():
    return make_splash(APP_NAME, "Diseño de Columnas de Acero Estructural", APP_VERSION, "NTC DEA / AISC 360")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    splash = _make_splash()
    splash.show()
    app.processEvents()
    win = MainWindow()
    def _show():
        splash.finish(win)
        win.showMaximized()
    QTimer.singleShot(400, _show)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
