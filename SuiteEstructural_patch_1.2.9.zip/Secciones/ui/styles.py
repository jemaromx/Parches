# ui/styles.py
from config.settings import COLORS

P  = COLORS["primary"]
S  = COLORS["secondary"]
BG = COLORS["bg"]
SU = COLORS["success"]
AC = COLORS["accent"]
WA = COLORS["warning"]
TX = COLORS["text"]

MAIN_STYLE = f"""
QMainWindow, QDialog {{
    background-color: {BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9pt;
    color: {TX};
}}
QGroupBox {{
    border: 1px solid #AED6F1;
    border-radius: 6px;
    margin-top: 10px;
    padding: 8px 6px 6px 6px;
    background: white;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    top: -1px;
    padding: 0 6px;
    color: {P};
    font-weight: bold;
    font-size: 9pt;
}}
QPushButton {{
    background-color: {S};
    color: white;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    min-height: 24px;
}}
QPushButton:hover   {{ background-color: {P}; }}
QPushButton:pressed {{ background-color: #154360; }}
QPushButton:disabled {{ background-color: #AEB6BF; color: #ECF0F1; }}
QPushButton#btn_run, QPushButton#btnGreen {{
    background-color: {SU};
    font-weight: bold;
    font-size: 10pt;
    min-height: 32px;
}}
QPushButton#btn_run:hover {{ background-color: #145A32; }}
QPushButton#btn_word  {{ background-color: #2E86C1; }}
QPushButton#btn_word:hover {{ background-color: #1A5276; }}
QPushButton#btn_memory {{ background-color: #7D3C98; }}
QPushButton#btn_memory:hover {{ background-color: #6C3483; }}
QPushButton#btn_excel, QPushButton#btnOrange {{
    background-color: {WA};
}}
QPushButton#btn_excel:hover, QPushButton#btnOrange:hover {{ background-color: #B7770D; }}
QPushButton#btn_clear, QPushButton#btnRed {{
    background-color: {AC};
}}
QPushButton#btn_clear:hover, QPushButton#btnRed:hover {{ background-color: #CB4335; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    border: 1px solid #AED6F1;
    border-radius: 3px;
    padding: 3px 6px;
    background: white;
    min-height: 22px;
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1.5px solid {S};
}}
QComboBox::drop-down {{ border: none; width: 20px; }}
QTabWidget::pane {{ border: 1px solid #AED6F1; background: white; }}
QTabBar::tab {{
    background: #D6EAF8;
    color: {P};
    padding: 5px 14px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}}
QTabBar::tab:selected {{ background: {P}; color: white; font-weight: bold; }}
QTabBar::tab:hover:!selected {{ background: {S}; color: white; }}
QTableWidget {{
    border: 1px solid #AED6F1;
    border-radius: 4px;
    gridline-color: #D5D8DC;
    background-color: white;
    alternate-background-color: {BG};
    selection-background-color: #D6EAF8;
    font-size: 8pt;
}}
QTableWidget::item {{
    padding: 3px 8px;
    border-bottom: 1px solid #EBF5FB;
}}
QTableWidget::item:selected {{
    background-color: #D6EAF8;
    color: {P};
}}
QHeaderView::section {{
    background-color: {P};
    color: white;
    padding: 5px 6px;
    border: none;
    border-right: 1px solid {S};
    font-weight: bold;
    font-size: 8pt;
}}
QScrollBar:vertical {{ width: 10px; background: {BG}; border-radius: 5px; }}
QScrollBar::handle:vertical {{ background: #AED6F1; border-radius: 5px; min-height: 20px; }}
QScrollBar::handle:vertical:hover {{ background: {S}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{ height: 10px; background: {BG}; border-radius: 5px; }}
QScrollBar::handle:horizontal {{ background: #AED6F1; border-radius: 5px; min-width: 20px; }}
QScrollBar::handle:horizontal:hover {{ background: {S}; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
QSplitter::handle {{ background: #AED6F1; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}
QStatusBar {{ background: {P}; color: white; font-size: 9pt; }}
QStatusBar QLabel {{ color: white; }}
QProgressBar {{ border: none; border-radius: 0px; height: 5px; background: #AED6F1; }}
QProgressBar::chunk {{ background: {SU}; border-radius: 0px; }}
QCheckBox {{ spacing: 6px; }}
QCheckBox::indicator {{ width: 15px; height: 15px; border: 1px solid #AED6F1; border-radius: 3px; background: white; }}
QCheckBox::indicator:checked {{ background: {S}; }}
QRadioButton {{ spacing: 5px; }}
QRadioButton::indicator {{ width: 14px; height: 14px; }}
"""

HEADER_STYLE = f"QFrame {{ background-color: {P}; }}"


# ─────────────────────────────────────────────────────────────────────────────
# Sistema visual unificado de la suite (azul técnico + ámbar sobre slate).
# Sobrescribe la hoja anterior; los tokens de arriba se conservan porque
# otros archivos del módulo los importan. Si suite_shared no estuviera
# disponible, se mantiene el estilo previo como respaldo.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from suite_shared.styles import (make_main_style as _mk,
                                     HEADER_STYLE as _HDR)
    MAIN_STYLE = _mk()
    HEADER_STYLE = _HDR
except Exception:  # noqa: BLE001
    pass
