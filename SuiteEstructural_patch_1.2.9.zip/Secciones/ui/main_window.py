# ui/main_window.py  — Ventana principal de Seccion Design Pro
from __future__ import annotations
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QFrame, QLabel, QTabWidget, QProgressBar, QStatusBar
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QIcon

from config.settings import APP_NAME, APP_VERSION, CODE_BADGE, COLORS
from ui.styles import MAIN_STYLE, HEADER_STYLE
from ui.widgets import header_label
from ui.tab_prop_geom import TabPropGeom
from ui.tab_seccion_compuesta import TabSeccionCompuesta
from ui.tab_trabe_compuesta import TabTrabeCompuesta

P = COLORS["primary"]


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{APP_NAME}  {APP_VERSION}")
        self.resize(1280, 820)
        self.setMinimumSize(900, 600)
        self.setStyleSheet(MAIN_STYLE)
        self._build_ui()



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "secciones")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        root = QVBoxLayout(central); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        # ── Encabezado 60px ───────────────────────────────────────────────────
        header = QFrame(); header.setFixedHeight(60)
        header.setStyleSheet(HEADER_STYLE)
        hl = QHBoxLayout(header); hl.setContentsMargins(16, 0, 16, 0)

        lbl_title = header_label(f"  {APP_NAME}", 14)
        lbl_ver   = header_label(APP_VERSION, 10)
        lbl_code  = header_label(f"[ {CODE_BADGE} ]", 8)
        lbl_code.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        hl.addWidget(lbl_title)
        hl.addWidget(lbl_ver)
        hl.addStretch()
        hl.addWidget(lbl_code)
        root.addWidget(header)

        # ── Barra de progreso 5px (decorativa / uso futuro) ───────────────────
        self.progress = QProgressBar()
        self.progress.setFixedHeight(5)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        # ── Pestañas principales ──────────────────────────────────────────────
        self.tabs = QTabWidget()
        self.tabs.setFont(QFont("Segoe UI", 9))

        self.tab1 = TabPropGeom()
        self.tab2 = TabSeccionCompuesta()
        self.tab3 = TabTrabeCompuesta()

        self.tabs.addTab(self.tab1, "  Prop. Geom. Secc.  ")
        self.tabs.addTab(self.tab2, "  Sección Compuesta  ")
        self.tabs.addTab(self.tab3, "  Trabe Compuesta  ")
        root.addWidget(self.tabs, stretch=1)

        # ── Barra de estado ───────────────────────────────────────────────────
        status: QStatusBar = self.statusBar()
        lbl_status = QLabel(f"  {APP_NAME}  {APP_VERSION}  |  {CODE_BADGE}  |  Unidades MKS (kg, m, cm, kg/cm²)")
        lbl_status.setStyleSheet("color: white;")
        status.addPermanentWidget(lbl_status)
