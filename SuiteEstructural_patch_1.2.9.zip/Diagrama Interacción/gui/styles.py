"""Hoja de estilos Qt para Interaction Design Pro — paleta estándar de la suite."""
import sys
from pathlib import Path
_SUITE_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(_SUITE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SUITE_ROOT))

from suite_shared.styles import make_main_style, HEADER_STYLE  # noqa: E402

MAIN_STYLE = make_main_style()

# Alias para compatibilidad con el código existente
DARK_STYLE = MAIN_STYLE

# ── Colores matplotlib — paleta clara (coincide con fondo #EBF5FB) ────────────
PLOT_STYLE = {
    "figure.facecolor":  "#EBF5FB",   # fondo figura = bg de la suite
    "axes.facecolor":    "#FFFFFF",   # fondo axes blanco
    "axes.edgecolor":    "#AED6F1",   # borde axes azul claro
    "axes.labelcolor":   "#1C2833",   # texto ejes gris oscuro
    "xtick.color":       "#1C2833",
    "ytick.color":       "#1C2833",
    "text.color":        "#1C2833",
    "grid.color":        "#D4E6F1",
    "grid.linestyle":    "--",
    "grid.alpha":        0.7,
    "legend.facecolor":  "#FFFFFF",
    "legend.edgecolor":  "#AED6F1",
    "legend.labelcolor": "#1C2833",
    "lines.linewidth":   1.8,
}
