"""
Interaction Design Pro — Punto de entrada.

Diagrama de interacción 3D P-Mx-My para secciones de concreto reforzado.
Normativas: NTC 2023 DEC · ACI 318-25

Uso:
    python main.py
"""
import sys
from pathlib import Path

# ── suite_shared ──────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.splash import make_splash

log = setup_logging("diagrama_interaccion")
install_excepthook("diagrama_interaccion")

from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import QTimer
from gui.main_window   import MainWindow
from config.settings   import APP_NAME, APP_VERSION

def _make_splash():
    return make_splash(APP_NAME, "Diagrama de Interacción P-Mx-My", APP_VERSION, "NTC 2023 / ACI 318-25")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)

    # Verificar dependencias
    missing = []
    for pkg, name in [
        ("shapely", "shapely"),
        ("docx", "python-docx"),
        ("openpyxl", "openpyxl"),
    ]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(name)

    if missing:
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.warning(
            None, "Dependencias faltantes",
            f"Los siguientes paquetes no están instalados:\n"
            + "\n".join(f"  • {m}" for m in missing)
            + "\n\nInstale con:\n  pip install " + " ".join(missing),
        )

    log.info(f"Iniciando {APP_NAME} v{APP_VERSION}")
    splash = _make_splash()
    splash.show()
    app.processEvents()
    window = MainWindow()
    def _show():
        splash.finish(window)
        window.showMaximized()
    QTimer.singleShot(400, _show)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
