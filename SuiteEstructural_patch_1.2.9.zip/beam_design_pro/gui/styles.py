"""Hojas de estilo PySide6 para BeamDesignPro."""
from config.settings import COLORS

P  = COLORS["primary"]    # #1B4F72
S  = COLORS["secondary"]  # #2874A6
BG = COLORS["bg"]         # #EBF5FB

MAIN_STYLE = f"""
QMainWindow, QDialog {{
    background-color: {BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9pt;
    color: {COLORS['text']};
}}
QGroupBox {{
    border: 1px solid #AED6F1;
    border-radius: 5px;
    margin-top: 8px;
    padding: 6px;
    background: white;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
    color: {P};
    font-weight: bold;
}}
QPushButton {{
    background-color: {S};
    color: white;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    min-height: 24px;
}}
QPushButton:hover   {{ background-color: {P}; }}
QPushButton:pressed {{ background-color: #154360; }}
QPushButton:disabled {{ background-color: #AEB6BF; color: #ECF0F1; }}
QPushButton#btn_run {{
    background-color: {COLORS['success']};
    font-weight: bold;
    font-size: 10pt;
    min-height: 32px;
}}
QPushButton#btn_run:hover {{ background-color: #145A32; }}
QPushButton#btn_word {{
    background-color: #2E86C1;
}}
QPushButton#btn_word:hover {{ background-color: #1A5276; }}
QPushButton#btn_memory {{
    background-color: #7D3C98;
}}
QPushButton#btn_memory:hover {{ background-color: #6C3483; }}
QPushButton#btn_dxf, QPushButton#btn_excel {{
    background-color: #D68910;
}}
QPushButton#btn_dxf:hover, QPushButton#btn_excel:hover {{ background-color: #B7770D; }}
QPushButton#btn_connect {{
    background-color: #117A65;
    font-weight: bold;
}}
QPushButton#btn_connect:hover    {{ background-color: #0E6655; }}
QPushButton#btn_connect:disabled {{ background-color: #AEB6BF; }}
QPushButton#btnGreen, QPushButton#btn_run {{
    background-color: {COLORS['success']};
    font-weight: bold;
    font-size: 10pt;
    min-height: 32px;
}}
QPushButton#btnGreen:hover {{ background-color: #145A32; }}
QPushButton#btnOrange {{ background-color: #D68910; }}
QPushButton#btnOrange:hover {{ background-color: #B7770D; }}
QPushButton#btnRed {{ background-color: #E74C3C; }}
QPushButton#btnRed:hover {{ background-color: #CB4335; }}
QPushButton#btn_clear {{ background-color: #566573; }}
QPushButton#btn_clear:hover {{ background-color: #4A535E; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    border: 1px solid #AED6F1;
    border-radius: 3px;
    padding: 3px 6px;
    background: white;
    min-height: 22px;
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1.5px solid {S};
}}
QTabWidget::pane {{
    border: 1px solid #AED6F1;
    background: white;
}}
QTabBar::tab {{
    background: #D6EAF8;
    color: {P};
    padding: 5px 18px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}}
QTabBar::tab:selected {{
    background: {P};
    color: white;
    font-weight: bold;
}}
QHeaderView::section {{
    background-color: {P};
    color: white;
    padding: 4px;
    border: none;
    font-weight: bold;
}}
QTableWidget {{
    gridline-color: #D6EAF8;
    alternate-background-color: #EBF5FB;
}}
QScrollBar:vertical {{
    width: 10px;
    background: #EBF5FB;
    border-radius: 5px;
}}
QScrollBar::handle:vertical {{
    background: #AED6F1;
    border-radius: 5px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{ background: {S}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{
    height: 10px;
    background: #EBF5FB;
    border-radius: 5px;
}}
QScrollBar::handle:horizontal {{
    background: #AED6F1;
    border-radius: 5px;
    min-width: 20px;
}}
QScrollBar::handle:horizontal:hover {{ background: {S}; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
QSplitter::handle {{ background: #AED6F1; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}
QStatusBar {{
    background: {P};
    color: white;
}}
QProgressBar {{
    border: none;
    border-radius: 0px;
    height: 5px;
    background: #AED6F1;
}}
QProgressBar::chunk {{
    background: {COLORS['success']};
    border-radius: 0px;
}}
QCheckBox {{ spacing: 6px; }}
QCheckBox::indicator {{
    width: 16px; height: 16px;
    border: 1px solid #AED6F1;
    border-radius: 3px;
    background: white;
}}
QCheckBox::indicator:checked {{
    background: {S};
    image: url(none);
}}
"""

HEADER_STYLE = f"""
QFrame {{
    background-color: {P};
}}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Sistema visual unificado de la suite (azul técnico + ámbar sobre slate).
# Sobrescribe la hoja anterior; los tokens de arriba se conservan porque
# otros archivos del módulo los importan. Si suite_shared no estuviera
# disponible, se mantiene el estilo previo como respaldo.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from suite_shared.styles import (make_main_style as _mk,
                                     HEADER_STYLE as _HDR)
    MAIN_STYLE = _mk()
    HEADER_STYLE = _HDR
except Exception:  # noqa: BLE001
    pass
