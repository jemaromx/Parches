"""Hojas de estilo PySide6 para ColumnDesignPro.

Sistema visual refrescado de la suite (piloto): azul técnico + acento ámbar
sobre neutros slate. Look profesional, sobrio y de alta densidad de datos.
Mantiene los mismos objectName que el resto del módulo.
"""
from config.settings import COLORS

# ── Tokens del sistema visual ────────────────────────────────────────────────
PRIMARY   = "#1B4F72"   # azul marca (encabezado, tabla, pestaña activa)
PRIMARY_D = "#153A56"   # azul marca oscuro (pressed)
INK       = "#1E293B"   # texto principal (slate-800)
MUTED     = "#64748B"   # texto secundario (slate-500)
APP_BG    = "#F1F5F9"   # fondo de la app (slate-100)
PANEL     = "#FFFFFF"   # paneles / tarjetas
BORDER    = "#E2E8F0"   # borde suave (slate-200)
BORDER_D  = "#CBD5E1"   # borde marcado (slate-300)
FOCUS     = "#2563EB"   # azul de foco / interacción
ACCENT    = "#D97706"   # ámbar — resaltes
OK        = "#15803D"   # verde (cumple / ejecutar)
OK_D      = "#116330"
WARN      = "#B45309"   # ámbar oscuro (excel / dxf)
WARN_D    = "#8A3F07"
DANGER    = "#DC2626"   # rojo (limpiar)
DANGER_D  = "#B91C1C"
WORD      = "#2563EB"   # azul (Word)
WORD_D    = "#1D4ED8"
MEMORY    = "#6D28D9"   # morado (memoria)
MEMORY_D  = "#5B21B6"
TEAL      = "#0F766E"   # verde azulado (conectar)
TEAL_D    = "#0B5A54"

MAIN_STYLE = f"""
QMainWindow, QDialog {{
    background-color: {APP_BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9.5pt;
    color: {INK};
}}

/* ── Paneles ────────────────────────────────────────────────────────────── */
QGroupBox {{
    border: 1px solid {BORDER};
    border-radius: 8px;
    margin-top: 10px;
    padding: 10px 8px 8px 8px;
    background: {PANEL};
    font-weight: 600;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    top: 1px;
    padding: 0 5px;
    color: {PRIMARY};
    font-weight: bold;
}}

/* ── Botones ────────────────────────────────────────────────────────────── */
QPushButton {{
    background-color: {PRIMARY};
    color: white;
    border: none;
    border-radius: 6px;
    padding: 6px 14px;
    min-height: 26px;
    font-weight: 600;
}}
QPushButton:hover   {{ background-color: {FOCUS}; }}
QPushButton:pressed {{ background-color: {PRIMARY_D}; }}
QPushButton:disabled {{ background-color: #CBD5E1; color: #F1F5F9; }}

QPushButton#btn_run, QPushButton#btnGreen {{
    background-color: {OK}; font-weight: bold; font-size: 11pt; min-height: 36px;
}}
QPushButton#btn_run:hover, QPushButton#btnGreen:hover {{ background-color: {OK_D}; }}

QPushButton#btn_word {{ background-color: {WORD}; }}
QPushButton#btn_word:hover {{ background-color: {WORD_D}; }}
QPushButton#btn_memory {{ background-color: {MEMORY}; }}
QPushButton#btn_memory:hover {{ background-color: {MEMORY_D}; }}
QPushButton#btn_excel, QPushButton#btn_dxf, QPushButton#btnOrange {{ background-color: {WARN}; }}
QPushButton#btn_excel:hover, QPushButton#btn_dxf:hover, QPushButton#btnOrange:hover {{ background-color: {WARN_D}; }}
QPushButton#btn_clear, QPushButton#btnRed {{ background-color: {DANGER}; }}
QPushButton#btn_clear:hover, QPushButton#btnRed:hover {{ background-color: {DANGER_D}; }}
QPushButton#btn_export {{ background-color: {PRIMARY}; }}
QPushButton#btn_template {{
    background-color: #E2E8F0; color: {INK}; font-size: 8.5pt;
    min-height: 22px; padding: 4px 10px; font-weight: 600;
}}
QPushButton#btn_template:hover {{ background-color: {BORDER_D}; }}
QPushButton#btn_connect {{ background-color: {TEAL}; font-weight: bold; }}
QPushButton#btn_connect:hover    {{ background-color: {TEAL_D}; }}
QPushButton#btn_connect:disabled {{ background-color: #CBD5E1; }}

/* ── Campos ─────────────────────────────────────────────────────────────── */
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {{
    border: 1px solid {BORDER_D};
    border-radius: 5px;
    padding: 4px 8px;
    background: {PANEL};
    min-height: 24px;
    selection-background-color: {FOCUS};
    selection-color: white;
}}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {{
    border: 1.5px solid {FOCUS};
}}
QLineEdit:hover, QDoubleSpinBox:hover, QSpinBox:hover, QComboBox:hover {{
    border-color: #94A3B8;
}}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    border: 1px solid {BORDER_D};
    background: {PANEL};
    selection-background-color: #DBEAFE;
    selection-color: {INK};
    outline: none;
}}

QRadioButton {{ spacing: 6px; }}
QRadioButton::indicator {{ width: 15px; height: 15px; }}
QCheckBox {{ spacing: 6px; }}
QCheckBox::indicator {{
    width: 16px; height: 16px;
    border: 1px solid {BORDER_D}; border-radius: 4px; background: {PANEL};
}}
QCheckBox::indicator:checked {{
    background: {FOCUS}; border-color: {FOCUS};
}}

/* ── Pestañas (estilo tarjeta con activa blanca) ────────────────────────── */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    border-radius: 8px;
    background: {PANEL};
    top: -1px;
}}
QTabBar::tab {{
    background: #E9EEF3;
    color: {MUTED};
    padding: 7px 18px;
    border: 1px solid {BORDER};
    border-bottom: none;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
    margin-right: 3px;
    font-weight: 600;
}}
QTabBar::tab:selected {{
    background: {PANEL};
    color: {PRIMARY};
    font-weight: bold;
}}
QTabBar::tab:hover:!selected {{ background: {BORDER}; color: {INK}; }}

/* ── Tablas ─────────────────────────────────────────────────────────────── */
QTableWidget {{
    border: 1px solid {BORDER};
    border-radius: 8px;
    gridline-color: {BORDER};
    background-color: {PANEL};
    alternate-background-color: #F8FAFC;
    selection-background-color: #DBEAFE;
    selection-color: {INK};
}}
QTableWidget::item {{ padding: 4px 8px; }}
QTableWidget::item:selected {{ color: {INK}; }}
QHeaderView::section {{
    background-color: {PRIMARY};
    color: white;
    padding: 6px 4px;
    border: none;
    border-right: 1px solid #2E6B94;
    font-weight: bold;
}}
QTableCornerButton::section {{ background-color: {PRIMARY}; border: none; }}

/* ── Scrollbars ─────────────────────────────────────────────────────────── */
QScrollBar:vertical {{ width: 11px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{
    background: {BORDER_D}; border-radius: 5px; min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{ background: #94A3B8; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{ height: 11px; background: transparent; margin: 2px; }}
QScrollBar::handle:horizontal {{
    background: {BORDER_D}; border-radius: 5px; min-width: 24px;
}}
QScrollBar::handle:horizontal:hover {{ background: #94A3B8; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}

/* ── Barra de estado / progreso ─────────────────────────────────────────── */
QStatusBar {{
    background: {PRIMARY};
    color: white;
    font-size: 9pt;
}}
QStatusBar QLabel {{ color: white; }}
QProgressBar {{
    border: none; border-radius: 3px; text-align: center;
    height: 6px; background: {BORDER};
}}
QProgressBar::chunk {{ background: {OK}; border-radius: 3px; }}

QSplitter::handle {{ background: {BORDER}; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}

QToolBar {{
    background: {PANEL};
    border-bottom: 1px solid {BORDER};
    spacing: 4px; padding: 3px;
}}
QToolBar QToolButton {{
    color: {INK}; padding: 4px 10px; border-radius: 5px; font-weight: 600;
}}
QToolBar QToolButton:hover {{ background: {BORDER}; }}

QToolTip {{
    background: {INK}; color: white; border: none;
    padding: 5px 8px; border-radius: 5px; font-size: 8.5pt;
}}
"""

HEADER_STYLE = f"""
QFrame {{
    background-color: {PRIMARY};
}}
"""
