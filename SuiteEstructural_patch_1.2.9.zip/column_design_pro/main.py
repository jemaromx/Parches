﻿"""
ColumnDesignPro — Punto de entrada.

Uso:
    python main.py

Requiere:
    PySide6, openpyxl, python-docx, matplotlib, numpy, ezdxf (opcional)
"""
import sys
import platform
from pathlib import Path

# ── suite_shared — resolución autónoma de ruta (independiente del CWD) ────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ── matplotlib debe configurarse ANTES de cualquier import de la GUI ──────────
import matplotlib
matplotlib.use("QtAgg")

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook

log = setup_logging("column_design_pro")
install_excepthook("column_design_pro")

# ── PySide6 ─────────────────────────────────────────────────────────────────────
from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import Qt, QTimer
from PySide6.QtGui     import QPixmap, QColor, QPainter, QFont

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE, COLORS
from gui.main_window import MainWindow
from gui.styles      import MAIN_STYLE

from suite_shared.splash import make_splash

def _make_splash():
    return make_splash(APP_NAME, "Diseño de Columnas de Concreto Reforzado", APP_VERSION, "NTC 2023 / ACI 318-25")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    # ── Info de entorno al arranque ───────────────────────────────────────────
    log.info("Iniciando %s v%s", APP_NAME, APP_VERSION)
    log.info("Python %s | %s | %s",
             platform.python_version(), platform.system(), platform.machine())


    # ── Configuracion de Qt ───────────────────────────────────────────────────

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("ColumnDesignPro")
    app.setStyle("Fusion")

    font = QFont("Segoe UI", 9)
    app.setFont(font)
    app.setStyleSheet(MAIN_STYLE)

    # ── Splash ────────────────────────────────────────────────────────────────
    splash = _make_splash()
    splash.show()
    app.processEvents()

    # ── Ventana principal (diferida para que el splash se vea) ────────────────
    window = MainWindow()

    def _show_window():
        splash.finish(window)
        window.show()
        log.info("Ventana principal lista.")

    QTimer.singleShot(400, _show_window)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
