"""Hojas de estilo PySide6 para Footing Design Pro — paleta gris azulada."""
from config.settings import COLORS

P  = COLORS["primary"]    # #1B4F72
S  = COLORS["secondary"]  # #2874A6
BG = COLORS["bg"]         # #F4F6F7
AC = COLORS["accent"]     # #475C6B  gris azulado oscuro

# Sombra más oscura del accent (para hover/pressed)
AC_DARK = "#374A57"
AC_MED  = "#566573"   # gris medio (mismo que btn_template original)

MAIN_STYLE = f"""
QMainWindow, QDialog {{
    background-color: {BG};
}}
QWidget {{
    font-family: "Segoe UI";
    font-size: 9pt;
    color: {COLORS["text"]};
}}
QGroupBox {{
    border: 1px solid #BDC3C7;
    border-radius: 5px;
    margin-top: 8px;
    padding: 6px;
    background: white;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
    color: {AC};
    font-weight: bold;
}}
QPushButton {{
    background-color: {S};
    color: white;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    min-height: 24px;
}}
QPushButton:hover   {{ background-color: {P}; }}
QPushButton:pressed {{ background-color: #154360; }}
QPushButton:disabled {{ background-color: #AEB6BF; color: #ECF0F1; }}
QPushButton#btn_run, QPushButton#btnGreen {{
    background-color: {COLORS["success"]};
    font-weight: bold;
    font-size: 11pt;
    min-height: 36px;
}}
QPushButton#btn_run:hover, QPushButton#btnGreen:hover {{ background-color: #145A32; }}
QPushButton#btn_word {{
    background-color: #2E86C1;
    font-weight: bold;
}}
QPushButton#btn_word:hover {{ background-color: #1A5276; }}
QPushButton#btn_memory {{
    background-color: #7D3C98;
    font-weight: bold;
}}
QPushButton#btn_memory:hover {{ background-color: #6C3483; }}
QPushButton#btn_excel, QPushButton#btn_dxf, QPushButton#btnOrange {{
    background-color: {COLORS["warning"]};
}}
QPushButton#btn_excel:hover, QPushButton#btn_dxf:hover, QPushButton#btnOrange:hover {{
    background-color: #B7770D;
}}
QPushButton#btn_clear, QPushButton#btnRed {{ background-color: {COLORS["accent"]}; }}
QPushButton#btn_clear:hover, QPushButton#btnRed:hover {{ background-color: #CB4335; }}
QPushButton#btn_export {{
    background-color: {AC};
    font-weight: bold;
}}
QPushButton#btn_export:hover {{ background-color: {AC_DARK}; }}
QPushButton#btn_memo {{
    background-color: {P};
    font-weight: bold;
}}
QPushButton#btn_memo:hover {{ background-color: #154360; }}
QPushButton#btn_template {{
    background-color: {AC_MED};
    font-size: 8pt;
    min-height: 20px;
    padding: 3px 10px;
}}
QPushButton#btn_connect {{
    background-color: {AC};
    font-weight: bold;
    min-height: 28px;
}}
QPushButton#btn_connect:hover    {{ background-color: {AC_DARK}; }}
QPushButton#btn_connect:disabled {{ background-color: #AEB6BF; }}
QLineEdit, QDoubleSpinBox, QSpinBox {{
    border: 1px solid #BDC3C7;
    border-radius: 3px;
    padding: 3px 6px;
    background: white;
    min-height: 22px;
}}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus {{
    border: 1.5px solid {AC};
}}
QComboBox {{
    border: 1px solid #BDC3C7;
    border-radius: 3px;
    padding: 3px 6px;
    background: white;
    min-height: 22px;
}}
QComboBox:focus {{ border: 1.5px solid {AC}; }}
QComboBox::drop-down {{ border: none; width: 20px; }}
QRadioButton {{ spacing: 5px; }}
QRadioButton::indicator {{ width: 14px; height: 14px; }}
QCheckBox {{ spacing: 5px; }}
QTabWidget::pane {{
    border: 1px solid #BDC3C7;
    background: white;
}}
QTabBar::tab {{
    background: #D5D8DC;
    color: {AC};
    padding: 5px 16px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}}
QTabBar::tab:selected {{
    background: {AC};
    color: white;
    font-weight: bold;
}}
QTableWidget {{
    border: 1px solid #BDC3C7;
    border-radius: 4px;
    gridline-color: #D5D8DC;
    background-color: white;
    alternate-background-color: {BG};
    selection-background-color: #D5D8DC;
}}
QTableWidget::item {{ padding: 3px 6px; }}
QHeaderView::section {{
    background-color: {AC};
    color: white;
    padding: 4px 6px;
    border: none;
    font-weight: bold;
    font-size: 8pt;
}}
QHeaderView::section:horizontal {{
    border-right: 1px solid {AC_DARK};
}}
QScrollBar:vertical {{
    width: 10px;
    background: {BG};
}}
QScrollBar::handle:vertical {{
    background: #BDC3C7;
    border-radius: 5px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{ background: {AC}; }}
QScrollBar:horizontal {{
    height: 10px;
    background: {BG};
}}
QScrollBar::handle:horizontal {{
    background: #BDC3C7;
    border-radius: 5px;
    min-width: 20px;
}}
QStatusBar {{
    background: {P};
    color: white;
    font-size: 9pt;
}}
QProgressBar {{
    border: none;
    border-radius: 0px;
    text-align: center;
    height: 5px;
    background: #BDC3C7;
}}
QProgressBar::chunk {{
    background: {COLORS["success"]};
    border-radius: 0px;
}}
QSplitter::handle {{ background: #BDC3C7; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical   {{ height: 4px; }}
QLabel#lbl_section {{
    font-weight: bold;
    color: {AC};
    font-size: 9pt;
    border-bottom: 1px solid #BDC3C7;
    padding-bottom: 2px;
}}
"""

HEADER_STYLE = f"""
QFrame {{
    background-color: {P};
}}
"""

SUBHEADER_STYLE = f"""
QFrame {{
    background-color: {AC};
    border-radius: 3px;
}}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Sistema visual unificado de la suite (azul técnico + ámbar sobre slate).
# Sobrescribe la hoja anterior; los tokens de arriba se conservan porque
# otros archivos del módulo los importan. Si suite_shared no estuviera
# disponible, se mantiene el estilo previo como respaldo.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from suite_shared.styles import (make_main_style as _mk,
                                     HEADER_STYLE as _HDR)
    MAIN_STYLE = _mk()
    HEADER_STYLE = _HDR
except Exception:  # noqa: BLE001
    pass
