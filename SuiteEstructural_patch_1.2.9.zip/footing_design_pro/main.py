"""
Footing Design Pro — Punto de entrada.

Uso:
    python main.py

Requiere:
    PySide6, openstaadpy, python-docx
"""
import sys
from pathlib import Path

# ── suite_shared — paquete compartido de la suite ────────────────────────────
import sys as _sys
from pathlib import Path as _Path
_SUITE_ROOT = _Path(__file__).resolve().parent.parent
if str(_SUITE_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_SUITE_ROOT))
del _sys, _Path

# ── Asegurar que el directorio del proyecto esté en sys.path ─────────────────
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook

log = setup_logging("footing_design_pro")
install_excepthook("footing_design_pro")

# ── PySide6 ─────────────────────────────────────────────────────────────────────
from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import Qt, QTimer
from PySide6.QtGui     import QPixmap, QColor, QPainter, QFont, QPen, QLinearGradient

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE, COLORS

# ── Pantalla de presentación ──────────────────────────────────────────────────

from suite_shared.splash import make_splash

def _make_splash():
    return make_splash(APP_NAME, "Diseño de Zapatas Aisladas de Concreto", APP_VERSION, "NTC 2023 / ACI 318-25")

def _draw_footing_icon(painter: QPainter,
                       x: int, y: int,
                       w: int, h: int) -> None:
    """
    Dibuja un ícono esquemático de una zapata aislada:
        │col│
        ─────────
        │ zapata│
        ─────────
    """
    ac = QColor(COLORS["accent"])
    bg = QColor("#D5D8DC")

    # Columna (rectángulo estrecho arriba)
    col_w = w // 4
    col_h = h // 3
    col_x = x + (w - col_w) // 2
    painter.fillRect(col_x, y, col_w, col_h, ac)

    # Zapata (rectángulo ancho abajo)
    zap_h = h // 3
    zap_y = y + col_h + 2
    painter.fillRect(x, zap_y, w, zap_h, ac)

    # Línea de suelo
    painter.setPen(QPen(QColor("#808B96"), 1, Qt.DashLine))
    painter.drawLine(x - 4, zap_y + zap_h + 4,
                     x + w + 4, zap_y + zap_h + 4)

    # Líneas de suelo (hatching)
    painter.setPen(QPen(QColor("#BDC3C7"), 1))
    for i in range(4):
        sx = x + i * (w + 8) // 4 - 4
        painter.drawLine(sx, zap_y + zap_h + 4,
                         sx - 8, zap_y + zap_h + 14)

# ── Punto de entrada ──────────────────────────────────────────────────────────

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    # Alta resolución en Windows

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("Ingenieria Estructural")

    log.info("Iniciando %s v%s", APP_NAME, APP_VERSION)

    # Pantalla de presentación
    splash = _make_splash()
    splash.show()
    app.processEvents()

    # Importar y construir la ventana principal
    # (se hace después del splash para que éste sea visible de inmediato)
    from gui.main_window import MainWindow
    window = MainWindow()

    def _show_window():
        splash.finish(window)
        window.show()
        log.info("Ventana principal lista.")

    # El splash se muestra ~1.8 s antes de mostrar la ventana principal
    QTimer.singleShot(400, _show_window)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
