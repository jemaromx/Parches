﻿# -*- coding: utf-8 -*-
"""Ventana principal — Joint Design Pro.

Cambios en esta version:
  - Seleccion por NODO en STAAD Pro (no por columna).
  - Pestana Topologia integra SteelTableWidget para editar areas de acero.
  - Las areas de acero para el diseno se leen de SteelTableWidget.
  - _on_refresh llama get_selected_nodes() primero; si no hay nodos
    seleccionados, intenta get_selected_beams() como fallback.
  - Arbol de topologia muestra miembros por nodo con clasificacion.
"""
from __future__ import annotations
import os
import logging
from datetime import datetime

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QSplitter, QTabWidget,
    QVBoxLayout, QHBoxLayout, QStatusBar, QProgressBar,
    QLabel, QPushButton, QMessageBox, QFileDialog, QPlainTextEdit,
    QTreeWidget, QTreeWidgetItem, QGroupBox, QSizePolicy,
)
from PySide6.QtCore import Qt, QThread, Signal, QObject
from PySide6.QtGui import QFont, QColor

from gui.input_panel        import InputPanel
from gui.steel_table_widget import SteelTableWidget
from gui.results_widget     import ResultsWidget
from gui.plan_widget        import PlanWidget
from gui.elevation_widget   import ElevationWidget
from gui.joint_3d_widget    import Joint3DWidget

from staad.connector  import STAADConnector
from staad.extractor  import STAADExtractor
from staad.selector   import STAADSelector, NodeJointData
from design.joint_designer import JointDesigner, DesignParams
from report.pdf_generator  import PDFGenerator

log = logging.getLogger("joint_design.main_window")


# ══════════════════════════════════════════════════════════════════════════════
# Workers QThread
# ══════════════════════════════════════════════════════════════════════════════

class DesignWorker(QObject):
    sig_progress = Signal(int, str)
    sig_finished = Signal(list)
    sig_error    = Signal(str)

    def __init__(self, designer: JointDesigner, col_joint_data: list):
        super().__init__()
        self._designer = designer
        self._data     = col_joint_data
        # Route JointDesigner progress through the signal (thread-safe)
        self._designer._prog = self.sig_progress.emit

    def run(self):
        try:
            results = self._designer.run(self._data)
            self.sig_finished.emit(results)
        except Exception as exc:
            log.exception("Error en diseno")
            self.sig_error.emit(str(exc))


class ExportWorker(QObject):
    sig_progress = Signal(int, str)
    sig_finished = Signal(str)
    sig_error    = Signal(str)

    def __init__(self, pdf_gen: PDFGenerator, results: list, figs: tuple,
                 figs_por_nudo: dict | None = None):
        super().__init__()
        self._gen     = pdf_gen
        self._results = results
        self._figs    = figs
        self._figs_nudo = figs_por_nudo or {}

    def run(self):
        try:
            kwargs = {}
            if self._figs_nudo:
                kwargs["figs_por_nudo"] = self._figs_nudo
            ok = self._gen.generate(
                self._results,
                fig_plan=self._figs[0],
                fig_elev=self._figs[1],
                fig_3d=self._figs[2],
                progress_cb=lambda p, m: self.sig_progress.emit(p, m),
                **kwargs,
            )
            if ok:
                self.sig_finished.emit(self._gen.output_path)
            else:
                self.sig_error.emit("No se pudo generar el PDF.")
        except Exception as exc:
            log.exception("Error exportando PDF")
            self.sig_error.emit(str(exc))


# ══════════════════════════════════════════════════════════════════════════════
# Ventana principal
# ══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Joint Design Pro — Nudos Columna-Trabe")
        self.resize(1440, 860)

        self._connector  = STAADConnector()
        self._extractor  = None
        self._selector   = None
        self._node_joints: list[NodeJointData] = []   # nodosseleccionados
        self._col_joint_data: list[dict] = []          # formato para JointDesigner
        self._results: list = []
        self._designer_thread: QThread | None = None
        self._export_thread:   QThread | None = None

        self._build_ui()
        self._connect_signals()
        self._append_log("Joint Design Pro iniciado.")
        self._append_log("Conecte a STAAD Pro, seleccione NODOS en el modelo y presione 'Actualizar'.")

    # ── Construccion de la UI ─────────────────────────────────────────────────



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "nudo")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)

        self.input_panel = InputPanel()
        splitter.addWidget(self.input_panel)

        right = QWidget()
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(4, 4, 4, 4)
        right_lay.setSpacing(4)

        self._build_toolbar(right_lay)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(5)
        right_lay.addWidget(self.progress_bar)

        self.lbl_progress = QLabel("")
        self.lbl_progress.setStyleSheet("color:#1B4F72; font-size:8pt; font-style:italic;")
        self.lbl_progress.setVisible(False)
        right_lay.addWidget(self.lbl_progress)

        self.tabs = QTabWidget()
        self._tab_results  = ResultsWidget()
        self._tab_topology = self._build_topology_tab()
        self._tab_plan     = PlanWidget()
        self._tab_elev     = ElevationWidget()
        self._tab_3d       = Joint3DWidget()
        self._tab_log      = self._build_log_tab()

        self._tab_summary = self._build_summary_tab()
        self.tabs.addTab(self._tab_topology, "Topologia y Acero")
        self.tabs.addTab(self._tab_results,  "Resultados")
        self.tabs.addTab(self._tab_summary,  "Resumen")
        self.tabs.addTab(self._tab_plan,     "Planta")
        self.tabs.addTab(self._tab_elev,     "Elevacion")
        self.tabs.addTab(self._tab_3d,       "3D")
        self.tabs.addTab(self._tab_log,      "Log")

        right_lay.addWidget(self.tabs)
        splitter.addWidget(right)
        splitter.setSizes([365, 1075])
        root.addWidget(splitter)

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Listo")

    def _build_toolbar(self, lay):
        bar = QHBoxLayout()
        bar.setSpacing(6)

        self.btn_export_pdf = QPushButton("Memoria PDF")
        self.btn_export_pdf.setObjectName("btn_export")
        self.btn_export_pdf.setEnabled(False)
        self.btn_export_pdf.clicked.connect(lambda: self._export_memoria("pdf"))
        bar.addWidget(self.btn_export_pdf)

        self.btn_export_docx = QPushButton("Memoria Word")
        self.btn_export_docx.setObjectName("btn_export")
        self.btn_export_docx.setEnabled(False)
        self.btn_export_docx.clicked.connect(lambda: self._export_memoria("docx"))
        bar.addWidget(self.btn_export_docx)

        self.btn_export_plan = QPushButton("Guardar Planta")
        self.btn_export_plan.setObjectName("btn_export")
        self.btn_export_plan.setEnabled(False)
        self.btn_export_plan.clicked.connect(lambda: self._save_fig("plan"))
        bar.addWidget(self.btn_export_plan)

        self.btn_export_elev = QPushButton("Guardar Elevacion")
        self.btn_export_elev.setObjectName("btn_export")
        self.btn_export_elev.setEnabled(False)
        self.btn_export_elev.clicked.connect(lambda: self._save_fig("elev"))
        bar.addWidget(self.btn_export_elev)

        self.btn_export_3d = QPushButton("Guardar 3D")
        self.btn_export_3d.setObjectName("btn_export")
        self.btn_export_3d.setEnabled(False)
        self.btn_export_3d.clicked.connect(lambda: self._save_fig("3d"))
        bar.addWidget(self.btn_export_3d)

        bar.addStretch()
        lay.addLayout(bar)

    def _build_topology_tab(self) -> QWidget:
        """Pestana con arbol de topologia + tabla editable de acero."""
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        # Splitter vertical: arbol arriba, tabla abajo
        vsplit = QSplitter(Qt.Vertical)

        # ── Arbol de topologia ────────────────────────────────────────────────
        tree_w = QWidget()
        tree_lay = QVBoxLayout(tree_w)
        tree_lay.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel("Topologia del modelo: Nodo → Miembros conectados y clasificacion")
        lbl.setStyleSheet("font-weight:bold; color:#1B4F72; padding:4px;")
        tree_lay.addWidget(lbl)

        self.tree_topology = QTreeWidget()
        self.tree_topology.setHeaderLabels(
            ["Elemento", "Tipo", "angulo vert.", "b (cm)", "h (cm)", "Observacion"]
        )
        self.tree_topology.setAlternatingRowColors(True)
        self.tree_topology.header().setStretchLastSection(True)
        tree_lay.addWidget(self.tree_topology)
        vsplit.addWidget(tree_w)

        # ── Tabla de acero editable ───────────────────────────────────────────
        self.steel_table = SteelTableWidget()
        vsplit.addWidget(self.steel_table)

        vsplit.setSizes([250, 350])
        lay.addWidget(vsplit)
        return w

    def _build_summary_tab(self) -> QWidget:
        """Resumen: una fila por nudo con los indicadores principales."""
        from PySide6.QtWidgets import QTableWidget
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        lbl = QLabel("Resumen de nudos disenados")
        lbl.setStyleSheet("font-weight:bold; color:#1B4F72; padding:4px;")
        lay.addWidget(lbl)
        self._summary_table = QTableWidget(0, 8)
        self._summary_table.setHorizontalHeaderLabels(
            ["Columna", "Nodo", "Tipo de nudo", "b x h (cm)",
             "Vjh max (ton)", "DCR NTC", "DCR ACI", "Estado"])
        self._summary_table.horizontalHeader().setStretchLastSection(True)
        self._summary_table.setAlternatingRowColors(True)
        self._summary_table.setEditTriggers(QTableWidget.NoEditTriggers)
        lay.addWidget(self._summary_table)
        return w

    def _fill_summary(self, results, use_ntc=True, use_aci=True):
        from PySide6.QtWidgets import QTableWidgetItem
        from PySide6.QtGui import QColor, QBrush
        t = self._summary_table
        t.setRowCount(0)
        for env in results:
            jg = getattr(env, "joint_geometry", None)
            dims = f"{jg.b_col:.0f} x {jg.h_col:.0f}" if jg else "-"
            jtype = (jg.joint_type if jg else "-")
            Vjh_max = 0.0
            for c in getattr(env, "combos", []):
                jf = getattr(c, "joint_force", None)
                if jf is not None:
                    Vjh_max = max(Vjh_max, abs(getattr(jf, "Vjh", 0.0)))
            dcr_ntc = getattr(env, "DCR_NTC_max", 0.0)
            dcr_aci = getattr(env, "DCR_ACI_max", 0.0)
            _gov = max(dcr_ntc if use_ntc else 0.0,
                       dcr_aci if use_aci else 0.0)
            ok = _gov <= 1.0
            row = t.rowCount()
            t.insertRow(row)
            vals = [str(env.col_id), str(env.node_id), jtype, dims,
                    f"{Vjh_max/1000:.2f}", f"{dcr_ntc:.3f}",
                    f"{dcr_aci:.3f}", "CUMPLE" if ok else "NO CUMPLE"]
            for col, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                if col == 7:
                    it.setForeground(QBrush(QColor(
                        "#1E8449" if ok else "#C0392B")))
                t.setItem(row, col, it)
        t.setColumnHidden(5, not use_ntc)   # DCR NTC
        t.setColumnHidden(6, not use_aci)   # DCR ACI
        t.resizeColumnsToContents()

    def _build_log_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        hdr = QHBoxLayout()
        hdr.addWidget(QLabel("Log de mensajes:"))
        hdr.addStretch()
        btn_clear = QPushButton("Limpiar")
        btn_clear.clicked.connect(lambda: self._log_widget.clear())
        hdr.addWidget(btn_clear)
        lay.addLayout(hdr)
        self._log_widget = QPlainTextEdit()
        self._log_widget.setReadOnly(True)
        self._log_widget.setMaximumBlockCount(2000)
        lay.addWidget(self._log_widget)
        return w

    # ── Senales ────────────────────────────────────────────────────────────────

    def _connect_signals(self):
        self.input_panel.sig_connect_staad.connect(self._on_connect)
        self.input_panel.sig_refresh_selection.connect(self._on_refresh)
        self.input_panel.sig_run_design.connect(self._on_run)
        self.input_panel.sig_demo_mode.connect(self._on_demo_mode)

    # ── Handlers ───────────────────────────────────────────────────────────────

    def _on_connect(self):
        self._append_log("Conectando a STAAD Pro via openstaadpy...")
        self._connector = STAADConnector()
        ok, msg = self._connector.connect()
        if ok:
            self._extractor = STAADExtractor(self._connector)
            self._selector  = STAADSelector(self._connector, self._extractor)
            fname = self._connector.get_file_name()
            self.input_panel.set_connected(True, fname)
            self.status_bar.showMessage(f"Conectado: {fname}")
            self._append_log(f"OK Conectado | {msg}")
            lcs = self._connector.get_load_cases()
            if lcs:
                self._append_log(f"Casos de carga: {lcs[0]} a {lcs[-1]} ({len(lcs)} total)")
                self.input_panel.spin_lc_ini.setValue(lcs[0])
                self.input_panel.spin_lc_fin.setValue(lcs[-1])
        else:
            self.input_panel.set_connected(False)
            self._append_log(f"ERROR conexion: {msg}")
            dlg = QMessageBox(self)
            dlg.setWindowTitle("Conexion fallida")
            dlg.setIcon(QMessageBox.Warning)
            dlg.setText("<b>No se pudo conectar a STAAD Pro.</b>")
            dlg.setInformativeText(msg)
            dlg.setStandardButtons(QMessageBox.Ok)
            dlg.exec()

    def _on_demo_mode(self):
        self._append_log("=== MODO DEMO — sin STAAD Pro ===")
        self._extractor = _DemoExtractor()
        self._selector  = None

        # Crear NodeJointData de ejemplo
        from staad.selector import NodeJointData, MemberInfo
        njd1 = NodeJointData(node_id=5)
        col1 = MemberInfo(1); col1.kind = "columna"; col1.b_cm = 40; col1.h_cm = 40
        t1   = MemberInfo(10); t1.kind = "trabe";   t1.b_cm = 30; t1.h_cm = 50
        t2   = MemberInfo(11); t2.kind = "trabe";   t2.b_cm = 30; t2.h_cm = 50
        njd1.col_member = col1
        njd1.trabe_members = [t1, t2]
        njd1.members = [col1, t1, t2]

        njd2 = NodeJointData(node_id=6)
        col2 = MemberInfo(2); col2.kind = "columna"; col2.b_cm = 40; col2.h_cm = 40
        t3   = MemberInfo(20); t3.kind = "trabe";   t3.b_cm = 30; t3.h_cm = 50
        t4   = MemberInfo(21); t4.kind = "trabe";   t4.b_cm = 30; t4.h_cm = 50
        njd2.col_member = col2
        njd2.trabe_members = [t3, t4]
        njd2.members = [col2, t3, t4]

        self._node_joints    = [njd1, njd2]
        self._col_joint_data = [njd1.to_dict(), njd2.to_dict()]

        self._post_selection_update()
        self.input_panel.set_connected(True, "MODO DEMO — sin STAAD Pro")
        self.status_bar.showMessage("Modo Demo activo — 2 nudos de ejemplo")
        self._append_log("Modo Demo: 2 nudos con 2 trabes cada uno.")
        self._append_log("Importe los JSON de trabes y columnas en la pestana 'Topologia y Acero',")
        self._append_log("o edite las areas manualmente en la tabla. Luego presione EJECUTAR DISENO.")

    def _on_refresh(self):
        """Lee nodos (o columnas) seleccionados en STAAD Pro."""
        if not self._connector.is_connected:
            QMessageBox.warning(self, "Sin conexion", "Conecte a STAAD Pro primero.")
            return
        if self._selector is None:
            return

        self._append_log("Recuperando seleccion de STAAD Pro...")

        # Intentar primero nodos
        node_ids = self._selector.get_selected_nodes()
        if node_ids:
            self._append_log(f"Nodos seleccionados: {node_ids}")
            self._node_joints    = self._selector.get_joints_from_nodes(node_ids)
            self._col_joint_data = [nj.to_dict() for nj in self._node_joints]
        else:
            # Fallback: columnas seleccionadas
            self._append_log("No hay nodos seleccionados — intentando con columnas...")
            col_ids = self._selector.get_selected_beams()
            if not col_ids:
                QMessageBox.information(
                    self, "Sin seleccion",
                    "No hay nodos ni columnas seleccionados en STAAD Pro.\n\n"
                    "Opcion A: Seleccione NODOS en STAAD Pro y vuelva a intentar.\n"
                    "Opcion B: Seleccione las COLUMNAS y vuelva a intentar."
                )
                return
            self._append_log(f"Columnas seleccionadas: {col_ids}")
            self._node_joints    = self._selector.get_joints_from_columns(col_ids)
            self._col_joint_data = [nj.to_dict() for nj in self._node_joints]

        self._post_selection_update()
        n_trabes = sum(len(nj.trabe_members) for nj in self._node_joints)
        n_diags  = sum(len(nj.diag_members)  for nj in self._node_joints)
        self._append_log(
            f"OK: {len(self._node_joints)} nudo(s) | "
            f"{n_trabes} trabe(s) | {n_diags} diagonal(es)"
        )

    def _post_selection_update(self):
        """Actualiza UI despues de cargar la topologia de nudos."""
        self.input_panel.load_nodes(self._node_joints)
        self._update_topology_tree()
        self.steel_table.populate(self._node_joints)
        # Cambiar a la pestana de topologia para que el usuario vea la tabla
        self.tabs.setCurrentIndex(1)

    def _on_run(self):
        if not self._col_joint_data:
            QMessageBox.warning(self, "Sin datos",
                                "Primero seleccione nodos/columnas y presione 'Actualizar'.")
            return
        if self._extractor is None:
            self._extractor = _DemoExtractor()

        params_raw  = self.input_panel.get_params()
        steel_data  = self.steel_table.get_steel_data()   # {beams: {...}, columns: {...}}

        params = DesignParams()
        params.ductility  = params_raw["ductility"]
        params.fc         = params_raw["fc"]
        params.fy         = params_raw["fy"]
        params.rec_col    = params_raw["rec_col"]
        params.rec_trabe  = params_raw["rec_trabe"]
        params.db_long    = params_raw["db_long"]
        params.db_est     = params_raw["db_est"]
        params.lc_ini     = params_raw["lc_ini"]
        params.lc_fin     = params_raw["lc_fin"]

        # Llenar diccionarios As desde la tabla editable
        for mid, d in steel_data["columns"].items():
            params.As_col_cm2[mid] = d["As_total"]
            if d.get("db_cm"):
                params.db_col_cm[mid] = d["db_cm"]
        for mid, d in steel_data["beams"].items():
            # Usar el maximo entre As_inf y As_sup como valor gobernante para el nudo
            params.As_trabe_cm2[mid] = max(d["As_inf"], d["As_sup"])
            if d.get("db_cm"):
                params.db_trabe_cm[mid] = d["db_cm"]

        # Valores por defecto para elementos sin dato en tabla
        for d in self._col_joint_data:
            col_id = d["col_id"]
            if col_id not in params.As_col_cm2:
                params.As_col_cm2[col_id] = 20.0
            for tid in d.get("trabes_start", []) + d.get("trabes_end", []):
                if tid not in params.As_trabe_cm2:
                    params.As_trabe_cm2[tid] = 10.0

        designer = JointDesigner(
            extractor=self._extractor,
            selector=self._selector,
            params=params,
        )

        self._append_log(
            f"Iniciando diseno: {len(self._col_joint_data)} nudo(s) | "
            f"LC [{params.lc_ini}-{params.lc_fin}] | {params.ductility}"
        )
        self._set_progress(0, "Iniciando diseno...", visible=True)
        self._set_export_buttons(False)

        # PRE-CARGA en el HILO PRINCIPAL (COM STA): las llamadas OpenSTAAD solo
        # funcionan desde el hilo que conecto. Se cachean TODAS las fuerzas para
        # que el QThread lea del cache y no toque STAAD (evita Vjh/vu vacios).
        if hasattr(self._extractor, "pre_fetch"):
            try:
                _col_ids = []
                _trabe_ids = []
                for d in self._col_joint_data:
                    _col_ids.append(d["col_id"])
                    _trabe_ids += d.get("trabes_start", []) + d.get("trabes_end", [])
                _lc_ids = list(range(params.lc_ini, params.lc_fin + 1))
                self._set_progress(5, "Leyendo fuerzas de STAAD...", visible=True)
                self._extractor.pre_fetch(_col_ids, _trabe_ids, _lc_ids)
                self._append_log(
                    f"Fuerzas pre-cargadas: {len(set(_col_ids + _trabe_ids))} "
                    f"miembro(s) x {len(_lc_ids)} caso(s).")
            except Exception as exc:
                self._append_log(f"Aviso pre-carga: {exc}")

        self._designer_thread = QThread()
        self._worker = DesignWorker(designer, self._col_joint_data)
        self._worker.moveToThread(self._designer_thread)
        self._designer_thread.started.connect(self._worker.run)
        self._worker.sig_progress.connect(self._on_design_progress)
        self._worker.sig_finished.connect(self._on_design_finished)
        self._worker.sig_error.connect(self._on_design_error)
        self._worker.sig_finished.connect(self._designer_thread.quit)
        self._worker.sig_error.connect(self._designer_thread.quit)
        self._designer_thread.start()

    def _on_design_progress(self, pct: int, msg: str):
        self._set_progress(pct, msg, visible=True)
        self._append_log(f"[{pct:3d}%] {msg}")

    def _on_design_finished(self, results: list):
        self._results = results
        self._set_progress(100, "Diseno completado", visible=False)
        self._append_log(f"OK Diseno completado: {len(results)} nudos procesados")
        self.status_bar.showMessage(f"Diseno completado — {len(results)} nudos")

        _pr = self.input_panel.get_params()
        _ntc = bool(_pr.get("use_ntc", True))
        _aci = bool(_pr.get("use_aci", True))
        if not (_ntc or _aci):
            _ntc = _aci = True     # nada seleccionado → mostrar ambos
        self._tab_results.load_results(results, use_ntc=_ntc, use_aci=_aci)
        try:
            self._fill_summary(results, use_ntc=_ntc, use_aci=_aci)
        except Exception as exc:
            self._append_log(f"Aviso resumen: {exc}")
        self._safe_load_viz(results)
        self._set_export_buttons(True)
        self.tabs.setCurrentIndex(0)

        n_fail = sum(1 for e in results if not e.all_ok)
        if n_fail:
            self.status_bar.showMessage(
                f"ATENCION: {n_fail} nudo(s) no cumplen — Revise la pestana Resultados"
            )

    def _on_design_error(self, msg: str):
        self._set_progress(0, "", visible=False)
        self._append_log(f"ERROR en diseno: {msg}")
        QMessageBox.critical(self, "Error de diseno", f"Ocurrio un error:\n{msg}")

    def _safe_load_viz(self, results: list):
        """Carga las graficas con manejo de errores para no crashear la UI."""
        try:
            self._tab_plan.load_results(results, self._extractor)
        except Exception as exc:
            self._append_log(f"Advertencia — vista Planta: {exc}")
        try:
            self._tab_elev.load_results(results, self._extractor)
        except Exception as exc:
            self._append_log(f"Advertencia — vista Elevacion: {exc}")
        try:
            self._tab_3d.load_results(results, self._extractor)
        except Exception as exc:
            self._append_log(f"Advertencia — vista 3D: {exc}")

    def _export_memoria(self, fmt: str = "pdf"):
        """Genera la memoria en PDF o Word; el usuario elige la ruta."""
        if not self._results:
            QMessageBox.warning(self, "Sin resultados", "Ejecute el diseno primero.")
            return
        params  = self.input_panel.get_params()
        out_dir = params.get("output_dir") or os.path.expanduser("~")
        ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
        ext     = "docx" if fmt == "docx" else "pdf"
        filtro  = ("Documento Word (*.docx)" if fmt == "docx"
                   else "Documento PDF (*.pdf)")
        sugerido = os.path.join(out_dir, f"Memoria_Nudos_{ts}.{ext}")
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar memoria de calculo", sugerido, filtro)
        if not fname:
            return
        if not fname.lower().endswith(f".{ext}"):
            fname += f".{ext}"

        _ntc = bool(params.get("use_ntc", True))
        _aci = bool(params.get("use_aci", True))
        if not (_ntc or _aci):
            _ntc = _aci = True
        if fmt == "docx":
            from report.docx_generator import DocxGenerator
            gen = DocxGenerator(
                output_path=fname,
                project_name=params.get("project", "Sin nombre"),
                engineer=params.get("engineer", ""),
                revision="A",
                params=params, use_ntc=_ntc, use_aci=_aci,
            )
        else:
            gen = PDFGenerator(
                output_path=fname,
                project_name=params.get("project", "Sin nombre"),
                engineer=params.get("engineer", ""),
                revision="A",
            )

        # Graficas por NUDO (todas las columnas, no solo la visible).
        # Se generan en el hilo principal (matplotlib) y se pasan al worker.
        self._export_figs_nudo = {}
        if fmt == "docx":
            try:
                from viz.plan_view import draw_plan_view
                from viz.elevation_view import draw_elevation_view
                from viz.render_3d import draw_3d_render
                self._set_progress(0, "Generando graficas por nudo...",
                                   visible=True)
                for _env in self._results:
                    try:
                        self._export_figs_nudo[_env.col_id] = (
                            draw_plan_view(_env, self._extractor),
                            draw_elevation_view(_env, self._extractor),
                            draw_3d_render(_env, self._extractor),
                        )
                    except Exception as exc:
                        self._append_log(
                            f"Aviso graficas nudo {_env.col_id}: {exc}")
                    QApplication.processEvents()
            except Exception as exc:
                self._append_log(f"Aviso graficas memoria: {exc}")
        figs = (
            getattr(self._tab_plan, "fig", None),
            getattr(self._tab_elev, "fig", None),
            getattr(self._tab_3d,   "fig", None),
        )
        self._set_progress(0, f"Generando {ext.upper()}...", visible=True)
        self._export_thread = QThread()
        self._exp_worker    = ExportWorker(gen, self._results, figs,
                                           figs_por_nudo=self._export_figs_nudo)
        self._exp_worker.moveToThread(self._export_thread)
        self._export_thread.started.connect(self._exp_worker.run)
        self._exp_worker.sig_progress.connect(self._on_design_progress)
        self._exp_worker.sig_finished.connect(self._on_export_done)
        self._exp_worker.sig_error.connect(self._on_design_error)
        self._exp_worker.sig_finished.connect(self._export_thread.quit)
        self._exp_worker.sig_error.connect(self._export_thread.quit)
        self._export_thread.start()

    def _on_export_done(self, path: str):
        try:
            import matplotlib.pyplot as _plt
            for _figs in getattr(self, "_export_figs_nudo", {}).values():
                for _f in _figs:
                    if _f is not None:
                        _plt.close(_f)
            self._export_figs_nudo = {}
        except Exception:
            pass
        self._set_progress(100, "Memoria generada", visible=False)
        self._append_log(f"OK memoria guardada: {path}")
        QMessageBox.information(self, "Memoria generada",
                                f"Memoria de calculo guardada en:\n{path}")

    def _save_fig(self, which: str):
        widgets = {"plan": self._tab_plan, "elev": self._tab_elev, "3d": self._tab_3d}
        w = widgets.get(which)
        if not w or not hasattr(w, "fig") or w.fig is None:
            QMessageBox.warning(self, "Sin grafica", "Ejecute el diseno primero.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar imagen", "", "PNG (*.png);;SVG (*.svg)"
        )
        if path:
            w.fig.savefig(path, dpi=300, bbox_inches="tight")
            self._append_log(f"Imagen guardada: {path}")

    # ── Arbol de topologia ────────────────────────────────────────────────────

    def _update_topology_tree(self):
        """Llena el arbol con la clasificacion por nodo."""
        self.tree_topology.clear()

        _TIPO_COLORS = {
            "columna":  QColor("#D6EAF8"),
            "trabe":    QColor("#D5F5E3"),
            "diagonal": QColor("#FEF9E7"),
            "ignorar":  QColor("#F2F3F4"),
        }

        for njd in self._node_joints:
            node_item = QTreeWidgetItem([
                f"Nodo {njd.node_id}",
                "Nudo",
                "—",
                f"{njd.col_member.member_id if njd.col_member else '—'}",
                "—",
                f"{len(njd.trabe_members)} trabes, {len(njd.diag_members)} diagonales",
            ])
            node_item.setFont(0, QFont("Segoe UI", 9, QFont.Weight.Bold))
            node_item.setBackground(0, _TIPO_COLORS.get("trabe", QColor()))

            for info in njd.members:
                obs = ""
                if not info.is_concrete:
                    obs = "PERFIL METALICO — ignorado"
                elif info.kind == "ignorar":
                    obs = "Seccion no prismatica — ignorado"

                child = QTreeWidgetItem([
                    f"Barra {info.member_id}",
                    info.kind.upper(),
                    f"{info.angle_deg:.1f} deg",
                    f"{info.b_cm:.1f}" if info.b_cm else "—",
                    f"{info.h_cm:.1f}" if info.h_cm else "—",
                    obs,
                ])
                color = _TIPO_COLORS.get(info.kind, QColor("#F2F3F4"))
                for c in range(6):
                    child.setBackground(c, color)
                node_item.addChild(child)

            self.tree_topology.addTopLevelItem(node_item)

        self.tree_topology.expandAll()
        self.tree_topology.resizeColumnToContents(0)
        self.tree_topology.resizeColumnToContents(1)

    # ── Utilidades UI ─────────────────────────────────────────────────────────

    def _set_progress(self, pct: int, msg: str, visible: bool = True):
        self.progress_bar.setValue(pct)
        self.progress_bar.setVisible(visible)
        self.lbl_progress.setText(msg)
        self.lbl_progress.setVisible(visible)

    def _set_export_buttons(self, enabled: bool):
        self.btn_export_docx.setEnabled(enabled)
        for btn in (self.btn_export_pdf, self.btn_export_plan,
                    self.btn_export_elev, self.btn_export_3d):
            btn.setEnabled(enabled)

    def _append_log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self._log_widget.appendPlainText(f"[{ts}] {msg}")
        log.info(msg)


# ══════════════════════════════════════════════════════════════════════════════
# DemoExtractor — datos ficticios sin STAAD Pro
# ══════════════════════════════════════════════════════════════════════════════

class _DemoExtractor:
    """Extractor de demostracion con datos ficticios."""

    def get_member_section(self, mid: int):
        from staad.extractor import SectionProps
        return SectionProps(b=40.0, h=40.0, Ag=1600.0)

    def get_member_material(self, mid: int):
        from staad.extractor import MaterialProps
        return MaterialProps()

    def get_member_incidence(self, mid: int):
        from staad.extractor import MemberIncidence
        # Pares plausibles: columnas 1,2 van de nodo 5→7 y 6→8
        if mid in (1, 2):
            return MemberIncidence(id=mid, node_start=mid*4+1, node_end=mid*4+2)
        return MemberIncidence(id=mid, node_start=5, node_end=6)

    def get_member_length(self, mid: int) -> float:
        return 300.0  # cm

    def get_member_end_forces(self, mid: int, lc: int):
        from staad.extractor import MemberEndForces
        import random
        random.seed(mid * 100 + lc)
        f = random.uniform(0.8, 2.5)
        return MemberEndForces(
            lc_id=lc,
            Mz_i=f * 1_800_000,  Fy_i=f * 9_000,
            Mz_f=f * 1_400_000,  Fy_f=f * 8_000,
        )

    def get_node_coord(self, nid: int):
        from staad.extractor import NodeCoord
        coords = {5: (0, 0, 0), 6: (0, 3, 0), 7: (5, 0, 0), 8: (5, 3, 0)}
        x, y, z = coords.get(nid, (0, 0, 0))
        return NodeCoord(id=nid, x=x, y=y, z=z)

    def find_members_at_node(self, node_id: int, exclude_ids=None):
        return []
