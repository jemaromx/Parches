"""QSS Stylesheet — Joint Design Pro (paleta gris-azulada idéntica a Footing Design Pro)."""

STYLESHEET = """
/* ── Variables globales ─────────────────────────────────────────────────────── */
QWidget {
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 9pt;
    color: #1C2833;
    background-color: #F4F6F7;
}

/* ── Ventana principal ───────────────────────────────────────────────────────── */
QMainWindow {
    background-color: #F4F6F7;
}

/* ── Panel izquierdo (scroll) ───────────────────────────────────────────────── */
QScrollArea {
    border: none;
    background-color: #F4F6F7;
}
QScrollBar:vertical {
    background: #EAECEE;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #2874A6;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

/* ── GroupBox ────────────────────────────────────────────────────────────────── */
QGroupBox {
    border: 1px solid #B2C2CC;
    border-radius: 4px;
    margin-top: 18px;
    font-weight: bold;
    color: #1B4F72;
    background-color: #FAFBFC;
    padding: 4px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 8px;
    background-color: #1B4F72;
    color: white;
    border-radius: 2px;
    font-size: 8pt;
}

/* ── Label ───────────────────────────────────────────────────────────────────── */
QLabel {
    color: #1C2833;
    background: transparent;
}
QLabel#status_ok   { color: #1E8449; font-weight: bold; }
QLabel#status_fail { color: #922B21; font-weight: bold; }
QLabel#status_warn { color: #D68910; font-weight: bold; }

/* ── Botones ─────────────────────────────────────────────────────────────────── */
QPushButton {
    background-color: #2874A6;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    font-weight: bold;
    font-size: 8.5pt;
    min-height: 24px;
}
QPushButton:hover   { background-color: #1A5276; }
QPushButton:pressed { background-color: #154360; }
QPushButton:disabled { background-color: #B2BEB5; color: #666; }

QPushButton#btn_connect {
    background-color: #1B4F72;
    font-size: 9pt;
    min-height: 28px;
}
QPushButton#btn_connect:hover { background-color: #154360; }

QPushButton#btn_run {
    background-color: #1E8449;
    font-size: 10pt;
    min-height: 30px;
}
QPushButton#btn_run:hover   { background-color: #196F3D; }
QPushButton#btn_run:pressed { background-color: #145A32; }

QPushButton#btn_export {
    background-color: #475C6B;
    font-size: 8.5pt;
}
QPushButton#btn_export:hover { background-color: #34495E; }

/* ── SpinBox y DoubleSpinBox ─────────────────────────────────────────────────── */
QDoubleSpinBox, QSpinBox {
    border: 1px solid #B2C2CC;
    border-radius: 3px;
    padding: 2px 4px;
    background: white;
    min-height: 22px;
}
QDoubleSpinBox:focus, QSpinBox:focus { border-color: #2874A6; }

/* ── ComboBox ────────────────────────────────────────────────────────────────── */
QComboBox {
    border: 1px solid #B2C2CC;
    border-radius: 3px;
    padding: 2px 6px;
    background: white;
    min-height: 22px;
}
QComboBox:focus   { border-color: #2874A6; }
QComboBox::drop-down { border: none; width: 18px; }
QComboBox QAbstractItemView {
    background: white;
    selection-background-color: #2874A6;
    selection-color: white;
    border: 1px solid #B2C2CC;
}

/* ── CheckBox / RadioButton ──────────────────────────────────────────────────── */
QCheckBox, QRadioButton {
    spacing: 5px;
    color: #1C2833;
}
QCheckBox::indicator:checked, QRadioButton::indicator:checked {
    background-color: #2874A6;
    border: 2px solid #1B4F72;
    border-radius: 2px;
}

/* ── TabWidget ───────────────────────────────────────────────────────────────── */
QTabWidget::pane {
    border: 1px solid #B2C2CC;
    background: white;
    border-radius: 0 4px 4px 4px;
}
QTabBar::tab {
    background: #D5D8DC;
    color: #475C6B;
    border: 1px solid #B2C2CC;
    border-bottom: none;
    padding: 6px 14px;
    font-weight: bold;
    font-size: 8.5pt;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background: #1B4F72;
    color: white;
}
QTabBar::tab:hover:!selected { background: #AEB6BF; }

/* ── TableWidget ─────────────────────────────────────────────────────────────── */
QTableWidget {
    background: white;
    alternate-background-color: #EAECEE;
    gridline-color: #CACFD2;
    border: 1px solid #B2C2CC;
    border-radius: 3px;
    font-size: 8pt;
}
QTableWidget::item:selected {
    background-color: #2874A6;
    color: white;
}
QHeaderView::section {
    background-color: #1B4F72;
    color: white;
    font-weight: bold;
    font-size: 8pt;
    padding: 4px;
    border: none;
    border-right: 1px solid #154360;
}

/* ── TreeWidget ──────────────────────────────────────────────────────────────── */
QTreeWidget {
    background: white;
    alternate-background-color: #EAECEE;
    border: 1px solid #B2C2CC;
    border-radius: 3px;
    font-size: 8pt;
}
QTreeWidget::item:selected { background: #2874A6; color: white; }

/* ── TextEdit / PlainTextEdit (log) ──────────────────────────────────────────── */
QPlainTextEdit, QTextEdit {
    background: #1C2833;
    color: #E8F8F5;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 8pt;
    border: 1px solid #475C6B;
    border-radius: 3px;
}

/* ── Splitter ────────────────────────────────────────────────────────────────── */
QSplitter::handle { background: #B2C2CC; width: 3px; }
QSplitter::handle:hover { background: #2874A6; }

/* ── ProgressBar ─────────────────────────────────────────────────────────────── */
QProgressBar {
    border: 1px solid #B2C2CC;
    border-radius: 4px;
    text-align: center;
    background: #EAECEE;
    font-size: 8pt;
    min-height: 14px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #1B4F72, stop:1 #2874A6);
    border-radius: 3px;
}

/* ── StatusBar ───────────────────────────────────────────────────────────────── */
QStatusBar {
    background: #1B4F72;
    color: white;
    font-size: 8pt;
}
QStatusBar::item { border: none; }

/* ── ToolTip ─────────────────────────────────────────────────────────────────── */
QToolTip {
    background: #1B4F72;
    color: white;
    border: none;
    font-size: 8pt;
    padding: 4px;
}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Sistema visual unificado de la suite (azul técnico + ámbar sobre slate).
# Sobrescribe la hoja anterior; los tokens de arriba se conservan porque
# otros archivos del módulo los importan. Si suite_shared no estuviera
# disponible, se mantiene el estilo previo como respaldo.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from suite_shared.styles import (make_main_style as _mk,
                                     HEADER_STYLE as _HDR)
    STYLESHEET = _mk()
except Exception:  # noqa: BLE001
    pass
