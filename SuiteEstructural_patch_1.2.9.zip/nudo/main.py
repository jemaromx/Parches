# -*- coding: utf-8 -*-
"""
Joint Design Pro -- Punto de entrada principal.

Uso:
    py main.py           -> lanza la aplicacion completa (requiere STAAD Pro)
    py main.py --demo    -> modo demo con datos ficticios (sin STAAD Pro)

Dependencias:
    pip install PySide6 matplotlib numpy reportlab pywin32
    pip install openpyxl pillow  (opcionales)
"""
import sys
from pathlib import Path

# ── suite_shared ──────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.splash import make_splash

log = setup_logging("nudo")
install_excepthook("nudo")

def run_demo():
    """Ejecuta el diseno en modo demo con datos ficticios."""
    log.info("Iniciando modo DEMO")

    from design.code_parameters   import CodeParameters
    from design.geometry_checker  import GeometryChecker
    from design.joint_forces      import JointForceCalculator
    from design.confinement       import ConfinementDesigner
    from design.capacity_design   import CapacityDesignChecker
    from design.lap_splice        import LapSpliceChecker
    from staad.extractor import SectionProps

    SEP = "=" * 60
    print(f"\n{SEP}")
    print("  JOINT DESIGN PRO -- MODO DEMO")
    print("  Diseno de Nudo Columna-Trabe")
    print("  NTC 2023 DEC  |  ACI 318-25")
    print(f"{SEP}\n")

    fc, fy = 250.0, 4200.0
    ductility = "Q4"
    code = CodeParameters(ductility, fc, fy)

    col_sec = SectionProps(b=40.0, h=40.0, Ag=1600.0)
    trabe_secs = [
        SectionProps(b=30.0, h=55.0, Ag=1650.0),
        SectionProps(b=30.0, h=55.0, Ag=1650.0),
    ]

    # 1. Geometria
    geo_chk = GeometryChecker()
    jg = geo_chk.check(col_sec, trabe_secs, n_trabes_at_node=2)
    ok_geo = "OK" if jg.ok_rel_heights else "NO CUMPLE (NTC par.8.3.1)"
    print(f"Tipo de nudo:    {jg.joint_type}")
    print(f"Aj (area nudo):  {jg.Aj:.0f} cm2")
    print(f"h_col/h_trabe:   {jg.h_col_over_h_trabe:.2f}  {ok_geo}")

    # 2. Fuerzas en nudo
    jf_calc = JointForceCalculator()
    jf = jf_calc.calculate(
        Mci=3_600_000, Mcs=2_800_000,
        Vcol=12_000, h_col=col_sec.h,
        Aj=jg.Aj, lc_id=1,
        code_params=code, joint_geometry=jg,
    )
    ok_ntc = "OK" if jf.ok_shear_NTC else "FALLA"
    ok_aci = "OK" if jf.ok_shear_ACI else "FALLA"
    print(f"\nFuerzas en el nudo (LC1):")
    print(f"  Vjh     = {jf.Vjh/1000:8.2f} ton")
    print(f"  vu      = {jf.vu:8.3f} kgf/cm2")
    print(f"  DCR NTC = {jf.DCR_NTC:.3f}  {ok_ntc}")
    print(f"  DCR ACI = {jf.DCR_ACI:.3f}  {ok_aci}")

    # 3. Confinamiento
    conf_dsgn = ConfinementDesigner()
    conf = conf_dsgn.design(col_sec, ln_cm=300.0, code_params=code)
    ok_ash = "OK" if conf.ok_Ash else "FALLA"
    print(f"\nConfinamiento:")
    print(f"  Ash req NTC  = {conf.Ash_req_NTC:.2f} cm2")
    print(f"  Ash req ACI  = {conf.Ash_req_ACI:.2f} cm2")
    print(f"  Estribo: d={conf.db_est_cm*10:.0f}mm | {conf.n_ramas} ramas | s={conf.s_prov_cm:.0f}cm")
    print(f"  Ash provista = {conf.Ash_prov:.2f} cm2  {ok_ash}")
    print(f"  lo           = {conf.lo_cm:.1f} cm")

    # 4. Diseno por capacidad
    cap_chk = CapacityDesignChecker()
    cap = cap_chk.check(
        col_sections=[col_sec, col_sec],
        trabe_sections=trabe_secs,
        As_col=[20.0, 20.0],
        As_trabe=[10.0, 10.0],
        code_params=code,
    )
    ok_cap = "OK" if cap.ok else "FALLA"
    print(f"\nDiseno por capacidad (Q={ductility[-1]}):")
    print(f"  Sum-Mnc        = {cap.sum_Mnc/1e6:.2f} ton*m")
    print(f"  Sum-Mnb        = {cap.sum_Mnb/1e6:.2f} ton*m")
    print(f"  Sum-Mnc/Sum-Mnb = {cap.ratio:.3f}  (req >= {cap.required_ratio:.2f})  {ok_cap}")

    # 5. Traslapes
    lap_chk = LapSpliceChecker()
    lap = lap_chk.check(db_long_cm=2.54, h_col_cm=40.0,
                        code_params=code, h_trabe_cm=55.0)
    ok_ldh = "OK" if lap.ok_Ldh_available else "Espacio insuficiente"
    print(f"\nLongitudes de desarrollo:")
    print(f"  Ld  = {lap.Ld_cm:.1f} cm")
    print(f"  Ldh = {lap.Ldh_cm:.1f} cm  {ok_ldh}")
    print(f"  Ls  = {lap.Ls_cm:.1f} cm")

    print(f"\n{SEP}")
    print("  DEMO completado. Ejecute 'py main.py' para la GUI completa.")
    print(f"{SEP}\n")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    """Lanza la aplicacion PySide6."""
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore    import QTimer
    from gui.styles        import STYLESHEET
    from config.settings   import APP_NAME, APP_VERSION

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("Ingenieria Estructural")
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)

    splash = make_splash(APP_NAME, "Diseño de Nudo Viga-Columna de Concreto Reforzado",
                         APP_VERSION, "NTC 2023 / ACI 318-25")
    splash.show()
    app.processEvents()

    from gui.main_window import MainWindow
    window = MainWindow()

    def _show():
        splash.finish(window)
        window.show()

    QTimer.singleShot(400, _show)
    sys.exit(app.exec())

if __name__ == "__main__":
    if "--demo" in sys.argv:
        run_demo()
    else:
        main()
