"""
Lector de datos de STAAD Pro 2025 vía openstaadpy para trabes.

Extrae en 3 secciones (x=0, L/2, L) para cada combinación de carga.
El módulo convierte automáticamente de las unidades del modelo (kN/kN·m)
a las unidades internas de diseño (ton/ton·m) usando _UNIT_F.

  Si el modelo está en kN  / kN·m  →  _UNIT_F = 1/9.81  ≈ 0.10197
  Si el modelo está en ton / ton·m →  _UNIT_F = 1.0  (sin conversión)

Vector de fuerzas STAAD: [Fx, Fy, Fz, Mx, My, Mz]
  Fx  axial
  Fy  cortante local-Y  → cortante en plano vertical para trabes horizontales
  Fz  cortante local-Z
  Mx  momento torsor
  My  momento local-Y
  Mz  momento local-Z  → flexión en plano vertical
"""
from __future__ import annotations
import logging

log = logging.getLogger(__name__)

try:
    from openstaadpy import os_analytical
    _AVAIL = True
except ImportError:
    _AVAIL = False
    log.warning("openstaadpy no disponible — modo sin STAAD.")

# ── Factor de conversión de unidades del modelo → ton / ton·m ────────────────
# Ajuste según las unidades del modelo activo en STAAD Pro:
#   Modelo en kN  / kN·m  →  _UNIT_F = 1.0 / 9.81   (≈ 0.10197)
#   Modelo en ton / ton·m →  _UNIT_F = 1.0             (sin conversión)
_UNIT_F: float = 1.0 / 9.81


class OpenSTAADReader:
    """Conexión con STAAD Pro 2025 y extracción de fuerzas para trabes."""

    def __init__(self):
        self._staad    = None
        self._ready    = False
        # Cachés
        self._sec_cache: dict   = {}   # {beam_id: {width, depth, length}}
        self._force_cache: dict = {}   # {(beam_id, cid): [f_ini, f_mid, f_fin]}

    # ── Conexión ──────────────────────────────────────────────────────────────

    def connect(self) -> tuple[bool, str]:
        if not _AVAIL:
            return False, "openstaadpy no está instalado."
        try:
            self._staad = os_analytical.connect()
            if not self._staad.Output.AreResultsAvailable():
                return False, "Conexión OK pero el modelo no tiene resultados de análisis."
            self._ready = True
            return True, "Conexión establecida con STAAD Pro 2025."
        except Exception as exc:
            return False, str(exc)

    @property
    def connected(self) -> bool:
        return self._ready

    # ── Secciones de la barra ─────────────────────────────────────────────────

    def get_section(self, beam_id: int) -> dict:
        """Propiedades geométricas de la sección.
        Retorna: {width [m], depth [m], length [m]}
        """
        if beam_id in self._sec_cache:
            return self._sec_cache[beam_id]
        if not self._ready:
            return {"width": 0.30, "depth": 0.50, "length": 5.0}

        try:
            geo  = self._staad.Geometry
            prop = self._staad.Property

            length = float(geo.GetBeamLength(beam_id))
            b_m, d_m, *_ = prop.GetBeamPropertyAll(beam_id)
            sec = {"width": float(b_m), "depth": float(d_m), "length": length}
        except Exception as exc:
            log.warning(f"Barra {beam_id} — error leyendo sección: {exc}")
            sec = {"width": 0.30, "depth": 0.50, "length": 5.0}

        self._sec_cache[beam_id] = sec
        return sec

    # ── Fuerzas en 3 secciones ────────────────────────────────────────────────

    def get_forces(self, beam_id: int, comb_id: int) -> list[dict]:
        """
        Fuerzas en Inicio (x=0), Mitad (x=L/2) y Fin (x=L).
        Cada elemento: {"Fx","Fy","Fz","Mx","My","Mz"}  [ton / ton·m]
        """
        key = (beam_id, comb_id)
        if key in self._force_cache:
            return self._force_cache[key]

        if not self._ready:
            zero = {"Fx":0.0,"Fy":0.0,"Fz":0.0,"Mx":0.0,"My":0.0,"Mz":0.0}
            return [zero.copy(), zero.copy(), zero.copy()]

        length = self.get_section(beam_id)["length"]
        out    = self._staad.Output

        def _parse(raw) -> dict:
            f = _UNIT_F   # conversión kN → ton  (o 1.0 si modelo en ton)
            return {
                "Fx": float(raw[0]) * f,
                "Fy": float(raw[1]) * f,
                "Fz": float(raw[2]) * f,
                "Mx": float(raw[3]) * f,   # kN·m → ton·m
                "My": float(raw[4]) * f,
                "Mz": float(raw[5]) * f,
            }

        result = []
        for i, xf in enumerate([0.0, 0.5, 1.0]):
            try:
                if i == 0:
                    raw = out.GetMemberEndForces(beam_id, 0, comb_id, 0)
                elif i == 2:
                    raw = out.GetMemberEndForces(beam_id, 1, comb_id, 0)
                else:
                    raw = out.GetIntermediateMemberForcesAtDistance(
                        beam_id, xf * length, comb_id)
                fp = _parse(raw)
                # Nodo FIN (nodo j): GetMemberEndForces entrega la ACCIÓN DE
                # EXTREMO, cuyo momento flexionante tiene signo OPUESTO al del
                # diagrama de momentos interno (convención de inicio y mitad).
                # Se invierte para que + = flexión positiva (sagging) de forma
                # consistente en toda la barra y con las barras contiguas.
                if i == 2:
                    fp["Mz"] = -fp["Mz"]
                    fp["My"] = -fp["My"]
                result.append(fp)
            except Exception as exc:
                log.warning(f"Barra {beam_id}, comb {comb_id}, sec {i}: {exc}")
                result.append({"Fx":0.0,"Fy":0.0,"Fz":0.0,
                               "Mx":0.0,"My":0.0,"Mz":0.0})

        self._force_cache[key] = result
        return result

    # ── Pre-fetch y volcado de caché ──────────────────────────────────────────

    def dump_cache(self) -> tuple[dict, dict]:
        """
        Retorna copias planas de los cachés (datos Python puros, sin COM).

        Llamar DESPUÉS de pre_fetch() en el hilo principal y pasar el
        resultado al DesignWorker para evitar accesos COM desde QThread.
        Los objetos COM de Windows son STA y no pueden cruzar hilos.

        Returns
        -------
        sec_data   : {beam_id: {width, depth, length}}
        force_data : {(beam_id, comb_id): [f_ini, f_mid, f_fin]}
        """
        return dict(self._sec_cache), dict(self._force_cache)

    def pre_fetch(self, beam_ids: list[int], comb_ids: list[int]):
        """Extrae todos los datos en el hilo principal antes de lanzar el worker."""
        total = len(beam_ids) * len(comb_ids)
        done  = 0
        for bid in beam_ids:
            self.get_section(bid)
            for cid in comb_ids:
                self.get_forces(bid, cid)
                done += 1
        log.info(f"pre_fetch: {done}/{total} combinaciones extraídas.")

    def get_load_cases(self) -> list[int]:
        """Lista de casos de carga disponibles (primarios + combinaciones)."""
        if not self._ready:
            return []
        try:
            n_prim = int(self._staad.Load.GetPrimaryLoadCaseCount())
            n_comb = int(self._staad.Load.GetLoadCombinationCaseCount())
            return list(range(1, n_prim + n_comb + 1))
        except Exception:
            return []

    # ── Trabes seleccionadas en el modelo ─────────────────────────────────────

    def get_selected_beams(self) -> list[int]:
        """
        IDs de las barras seleccionadas en STAAD Pro.

        Prueba varios nombres de método que existen en distintas versiones del
        wrapper openstaadpy / COM de OpenSTAAD.  Al primer intento también vuelca
        en el log la lista completa de métodos disponibles en OSGeometry para
        facilitar el diagnóstico si ningún candidato funciona.
        """
        if not self._ready:
            return []

        geo = self._staad.Geometry

        # ── Diagnóstico único: muestra qué métodos expone OSGeometry ──────────
        if not getattr(self, '_geo_diag_done', False):
            self._geo_diag_done = True
            try:
                metodos = sorted(m for m in dir(geo) if not m.startswith('_'))
                log.info("OSGeometry — métodos disponibles: %s", metodos)
            except Exception:
                pass
            try:
                metodos_st = sorted(m for m in dir(self._staad)
                                    if not m.startswith('_'))
                log.info("StaadWrapper — atributos raíz: %s", metodos_st)
            except Exception:
                pass

        # ── Candidatos en orden de probabilidad ──────────────────────────────
        _candidates = [
            # openstaadpy moderno
            ("Geometry", "GetSelectedBeamList"),
            ("Geometry", "GetSelectedBeams"),
            ("Geometry", "GetSelectedMemberList"),
            ("Geometry", "GetSelectedMembers"),
            # Algunos wrappers ponen el método en el objeto raíz
            (None, "GetSelectedBeamList"),
            (None, "GetSelectedBeams"),
            (None, "GetSelectedMemberList"),
            (None, "GetSelectedMembers"),
        ]

        for sub, name in _candidates:
            try:
                obj = getattr(self._staad, sub) if sub else self._staad
                fn  = getattr(obj, name, None)
                if fn is None:
                    continue
                raw = fn()
                ids = [int(b) for b in raw if b]
                log.info("get_selected_beams vía '%s.%s': %d barra(s)",
                         sub or "staad", name, len(ids))
                return ids
            except Exception as exc:
                log.debug("get_selected_beams/%s.%s: %s", sub, name, exc)

        log.warning("get_selected_beams: ningún método de selección funcionó. "
                    "Revise el log INFO para ver los métodos disponibles.")
        return []

    def _calc_direction(self, beam_id: int) -> str:
        """
        Infiere la dirección de la barra comparando desplazamiento en X vs Z.

        Convenio:
          |ΔX| >= |ΔZ|  →  "X"   (trabe corre en dirección X del modelo)
          |ΔX|  < |ΔZ|  →  "Y"   (trabe corre en dirección Y/Z del modelo)

        Nota: STAAD usa ejes globales X-Y-Z. Para losas planas horizontales
        las trabes en planta se proyectan sobre X y Z.
        """
        try:
            geo = self._staad.Geometry
            sn  = int(geo.GetMemberStartNode(beam_id))
            en  = int(geo.GetMemberEndNode(beam_id))
            sc  = geo.GetNodeCoordinates(sn)
            ec  = geo.GetNodeCoordinates(en)
            dx  = abs(float(ec[0]) - float(sc[0]))
            dz  = abs(float(ec[2]) - float(sc[2]))
            return "X" if dx >= dz else "Y"
        except Exception as exc:
            log.warning(f"_calc_direction barra {beam_id}: {exc} — asumiendo X")
            return "X"

    def build_members_from_staad(self, params: dict) -> list[dict]:
        """
        Construye la lista de miembros desde las barras seleccionadas en STAAD Pro.

        Lee la sección transversal (b, h) directamente del modelo y deriva
        la dirección de la barra a partir de las coordenadas de sus nodos.

        Parameters
        ----------
        params : dict
            Parámetros del proyecto (rec_flex, rec_comp se toman como default).

        Returns
        -------
        list[dict]  —  cada dict: {id, dir, b [cm], h [cm], rec_flex, rec_comp}
        """
        beam_ids = self.get_selected_beams()
        if not beam_ids:
            log.warning("build_members_from_staad: no hay barras seleccionadas.")
            return []

        members = []
        for bid in beam_ids:
            sec  = self.get_section(bid)
            b_cm = round(sec["width"] * 100, 1)
            h_cm = round(sec["depth"] * 100, 1)
            members.append({
                "id":       bid,
                "dir":      self._calc_direction(bid),
                "b":        b_cm,
                "h":        h_cm,
                "rec_flex": params.get("rec_flex", 6.0),
                "rec_comp": params.get("rec_comp", 4.0),
            })
        log.info(f"build_members_from_staad: {len(members)} barra(s) cargadas.")
        return members

    def build_members_for_ids(self, beam_ids: list[int], params: dict) -> list[dict]:
        """
        Construye la lista de miembros para los IDs dados explícitamente.

        Se usa como respaldo cuando la detección automática de selección no
        funciona y el usuario escribe los IDs a mano.
        """
        members = []
        for bid in beam_ids:
            try:
                sec  = self.get_section(bid)
                b_cm = round(sec["width"] * 100, 1)
                h_cm = round(sec["depth"] * 100, 1)
                members.append({
                    "id":       bid,
                    "dir":      self._calc_direction(bid),
                    "b":        b_cm,
                    "h":        h_cm,
                    "rec_flex": params.get("rec_flex", 6.0),
                    "rec_comp": params.get("rec_comp", 4.0),
                })
            except Exception as exc:
                log.warning(f"build_members_for_ids: barra {bid}: {exc}")
        log.info(f"build_members_for_ids: {len(members)} barra(s) cargadas.")
        return members
