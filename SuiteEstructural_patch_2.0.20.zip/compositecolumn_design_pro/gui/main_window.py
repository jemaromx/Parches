﻿# gui/main_window.py
"""
Ventana principal — Composite Column Design Pro.

Estructura:
  ┌──────────────────── HEADER (60px) ─────────────────────┐
  │ Nombre  Subtítulo  Versión                              │
  ├────────────────────────────────────────────────────────┤
  │ LEFT (scroll, 280-430px)  │  RIGHT (tabs, ≥400px)      │
  │  • STAAD Pro              │  • Envolvente               │
  │  • Miembros               │  • Por Combinación          │
  │  • Proyecto               │  • Interacción 3D           │
  │  • Tipo de columna        │  • Memoria de cálculo       │
  │  • Concreto               │                             │
  │  • Acero estructural      │                             │
  │  • Refuerzo               │                             │
  │  • Perfil / Sección       │                             │
  │  • Cargas STAAD / LC      │                             │
  │  • Normativa              │                             │
  │  • [STRETCH]              │                             │
  │  • DISEÑAR ▶              │                             │
  ├────────────────────────────────────────────────────────┤
  │ Progress bar (5px)                                     │
  │ Status bar                                             │
  └────────────────────────────────────────────────────────┘
"""
from __future__ import annotations
import os, sys, logging, copy, math
from typing import List, Optional, Dict

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QScrollArea, QTabWidget, QGroupBox,
    QLabel, QPushButton, QLineEdit, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QTextEdit, QProgressBar, QStatusBar, QFrame,
    QFileDialog, QMessageBox, QSizePolicy, QApplication, QDialog,
)
from PySide6.QtCore import Qt, QThread, Signal, QObject, Slot
from PySide6.QtGui import QFont, QColor

from config.settings import (
    APP_NAME, APP_VERSION, APP_SUBTITLE, APP_CODE,
    COLORS, STEEL_MATERIALS, REBAR_MATERIALS,
    COLUMN_TYPE_ENCASED, COLUMN_TYPE_FILLED,
    REBAR_DIAMETERS, STUD_DIAMETERS_IN,
)
from gui.styles import QSS
from gui.interaction_plot import InteractionPlot3D, SectionView

log = logging.getLogger(__name__)


# ── Worker thread ─────────────────────────────────────────────────────────────

class DesignWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, params: dict, staad_cache: dict):
        super().__init__()
        self._params = params
        self._cache  = staad_cache

    def run(self):
        try:
            results = _run_design(self._params, self._cache, self.progress.emit)
            self.finished.emit(results)
        except Exception as exc:
            import traceback
            self.error.emit(f"{exc}\n{traceback.format_exc()}")


# ── Tabla con copia ───────────────────────────────────────────────────────────

class CopyableTable(QTableWidget):
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            items = self.selectedItems()
            if not items:
                return
            rows = sorted(set(i.row() for i in items))
            cols = sorted(set(i.column() for i in items))
            text = "\n".join(
                "\t".join(
                    (self.item(r, c).text() if self.item(r, c) else "")
                    for c in cols
                )
                for r in rows
            )
            QApplication.clipboard().setText(text)
        else:
            super().keyPressEvent(event)


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1380, 840)
        self.setMinimumSize(960, 580)
        self.setStyleSheet(QSS)

        self._reader  = None   # OpenSTAADReader
        self._results: List[dict] = []
        self._staad_cache: dict = {}
        self._thread: Optional[QThread] = None

        self._build_ui()
        self._status("Listo — conecte a STAAD Pro o ingrese datos manualmente.")

    # ── Construcción de UI ────────────────────────────────────────────────────



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "compositecolumn_design_pro")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(self._make_left_panel())
        splitter.addWidget(self._make_right_panel())
        splitter.setSizes([340, 900])
        root.addWidget(splitter, 1)

        self._pbar = QProgressBar()
        self._pbar.setFixedHeight(5)
        self._pbar.setTextVisible(False)
        self._pbar.setRange(0, 100)
        self._pbar.hide()
        root.addWidget(self._pbar)

        self._sb = QStatusBar()
        badge = QLabel(f"  {APP_CODE}  ")
        badge.setStyleSheet(
            "background:#1B4F72;color:white;font-size:8pt;padding:2px 6px;border-radius:3px;"
        )
        self._sb.addPermanentWidget(badge)
        self.setStatusBar(self._sb)

    def _make_header(self) -> QFrame:
        frame = QFrame()
        frame.setFixedHeight(60)
        frame.setStyleSheet(f"background-color:{COLORS['primary']};")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 6, 16, 6)

        title = QLabel(APP_NAME)
        title.setObjectName("lbl_header_title")
        title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        title.setStyleSheet("color:white;")

        sub = QLabel(APP_SUBTITLE)
        sub.setObjectName("lbl_header_sub")
        sub.setStyleSheet("color:#AED6F1;font-size:9pt;")

        ver = QLabel(f"v{APP_VERSION}")
        ver.setObjectName("lbl_header_ver")
        ver.setStyleSheet("color:rgba(255,255,255,0.65);font-size:8pt;")

        lay.addWidget(title)
        lay.addWidget(sub)
        lay.addStretch()
        lay.addWidget(ver)
        return frame

    # ── Panel izquierdo ───────────────────────────────────────────────────────

    def _make_left_panel(self) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setMinimumWidth(270)
        scroll.setMaximumWidth(440)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        inner = QWidget()
        inner.setMinimumWidth(255)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        lay.addWidget(self._grp_staad())
        lay.addWidget(self._grp_column_type())
        lay.addWidget(self._grp_concrete())
        lay.addWidget(self._grp_steel_profile())
        lay.addWidget(self._grp_rebar())
        lay.addWidget(self._grp_geometry())
        lay.addWidget(self._grp_lc())
        lay.addWidget(self._grp_code())
        lay.addStretch()
        lay.addWidget(self._make_run_btn())

        scroll.setWidget(inner)
        return scroll

    # ── Grupos del panel izquierdo ────────────────────────────────────────────

    def _grp_staad(self) -> QGroupBox:
        grp = QGroupBox("STAAD Pro 2024/2025")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._lbl_conn = QLabel("✗ Sin conexión")
        self._lbl_conn.setObjectName("lbl_disconnected")

        btn = QPushButton("Conectar a STAAD Pro")
        btn.setObjectName("btn_connect")
        btn.setToolTip("Conecta con el modelo abierto y ejecutado en STAAD Pro")
        btn.clicked.connect(self._connect_staad)

        self._le_members = QLineEdit()
        self._le_members.setPlaceholderText("IDs barras: 1 2 3  (vacío=todas)")
        self._le_members.setToolTip("IDs de los miembros a diseñar (separados por espacio)")

        btn_sel = QPushButton("Obtener selección STAAD")
        btn_sel.clicked.connect(self._get_selected)
        btn_sel.setToolTip("Importa la selección actual de STAAD Pro")

        lay.addWidget(self._lbl_conn)
        lay.addWidget(btn)
        lay.addWidget(QLabel("Barras a diseñar:"))
        lay.addWidget(self._le_members)
        lay.addWidget(btn_sel)
        return grp

    def _grp_column_type(self) -> QGroupBox:
        grp = QGroupBox("Tipo de columna compuesta")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_col_type = QComboBox()
        self._cb_col_type.addItems([
            "Concreto con perfil ahogado (SRC/Encased)",
            "Perfil de acero relleno de concreto (CFT/Filled)",
        ])
        self._cb_col_type.currentIndexChanged.connect(self._on_col_type_changed)
        self._cb_col_type.setToolTip(
            "SRC: Concreto con W, IR, Canal, HSS, Pipe ahogado\n"
            "CFT: HSS rect/circ, PTR o Pipe relleno de concreto"
        )
        lay.addWidget(self._cb_col_type)
        return grp

    def _grp_concrete(self) -> QGroupBox:
        grp = QGroupBox("Concreto")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._dsb_fc = QDoubleSpinBox()
        self._dsb_fc.setRange(100, 700)
        self._dsb_fc.setValue(250)
        self._dsb_fc.setSuffix(" kg/cm²")
        self._dsb_fc.setToolTip("Resistencia a compresión fc' (NTC DEA 10.1.1: 20–70 MPa)")

        self._dsb_Ec = QDoubleSpinBox()
        self._dsb_Ec.setRange(0, 5_000_000)
        self._dsb_Ec.setValue(0)
        self._dsb_Ec.setSuffix(" kg/cm²")
        self._dsb_Ec.setToolTip("Ec=0 → automático: NTC 14000√fc' / "
                                "US ACI 318-25 19.2.2.1 (4700√fc' MPa = 15008.6√fc' kg/cm²)")

        self._dsb_wc = QDoubleSpinBox()
        self._dsb_wc.setRange(1400, 2500)
        self._dsb_wc.setValue(2400)
        self._dsb_wc.setSuffix(" kg/m³")

        lay.addWidget(QLabel("fc' (kg/cm²):"))
        lay.addWidget(self._dsb_fc)
        lay.addWidget(QLabel("Ec (0=automático):"))
        lay.addWidget(self._dsb_Ec)
        lay.addWidget(QLabel("Peso unitario:"))
        lay.addWidget(self._dsb_wc)
        return grp

    def _grp_steel_profile(self) -> QGroupBox:
        grp = QGroupBox("Perfil de acero estructural")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_steel_mat = QComboBox()
        for m in STEEL_MATERIALS:
            self._cb_steel_mat.addItem(m["name"])
        self._cb_steel_mat.setToolTip("Material del perfil ahogado / tubo")

        self._dsb_fy_s = QDoubleSpinBox()
        self._dsb_fy_s.setRange(1000, 8000)
        self._dsb_fy_s.setValue(2530)
        self._dsb_fy_s.setSuffix(" kg/cm²")

        self._dsb_fu_s = QDoubleSpinBox()
        self._dsb_fu_s.setRange(1000, 8000)
        self._dsb_fu_s.setValue(4080)
        self._dsb_fu_s.setSuffix(" kg/cm²")

        self._cb_steel_mat.currentIndexChanged.connect(self._update_steel_props)

        # Selector de perfil
        self._cb_prof_type = QComboBox()
        self._cb_prof_type.addItems(["W / IR", "Canal CE", "HSS Rectangular (PTR)",
                                     "HSS Circular (OC)", "Pipe/OC Std",
                                     "3 Placas (armada)"])
        self._cb_prof_type.setToolTip("Tipo de perfil")

        self._cb_prof_name = QComboBox()
        self._cb_prof_name.setEditable(True)
        self._cb_prof_name.setToolTip("Nombre del perfil (ej. W14X120, HSS8X8X1/2)")
        self._cb_prof_type.currentIndexChanged.connect(self._populate_profiles)

        self._plates3_dims = None
        self._btn_3pl = QPushButton("Definir placas…")
        self._btn_3pl.setVisible(False)
        self._btn_3pl.clicked.connect(self._open_dialog_3pl)
        self._lbl_3pl = QLabel("(sin definir)")
        self._lbl_3pl.setStyleSheet("color:#2874A6; font-style:italic; font-size:8pt;")
        self._lbl_3pl.setVisible(False)

        self._populate_profiles(0)

        lay.addWidget(QLabel("Material acero:"))
        lay.addWidget(self._cb_steel_mat)
        lay.addWidget(QLabel("Fy (kg/cm²):"))
        lay.addWidget(self._dsb_fy_s)
        lay.addWidget(QLabel("Fu (kg/cm²):"))
        lay.addWidget(self._dsb_fu_s)
        lay.addWidget(QLabel("Tipo de perfil:"))
        lay.addWidget(self._cb_prof_type)
        lay.addWidget(QLabel("Perfil:"))
        lay.addWidget(self._cb_prof_name)
        lay.addWidget(self._btn_3pl)
        lay.addWidget(self._lbl_3pl)
        return grp

    def _grp_rebar(self) -> QGroupBox:
        grp = QGroupBox("Acero de refuerzo (solo SRC — cuantía automática)")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_rebar_mat = QComboBox()
        for m in REBAR_MATERIALS:
            self._cb_rebar_mat.addItem(m["name"])

        self._dsb_fy_r = QDoubleSpinBox()
        self._dsb_fy_r.setRange(1000, 8000)
        self._dsb_fy_r.setValue(4200)
        self._dsb_fy_r.setSuffix(" kg/cm²")

        self._cb_rebar_mat.currentIndexChanged.connect(self._update_rebar_props)

        # Cuantía mínima y máxima para la iteración
        self._dsb_p_min = QDoubleSpinBox()
        self._dsb_p_min.setRange(0.01, 0.06)
        self._dsb_p_min.setSingleStep(0.005)
        self._dsb_p_min.setValue(0.01)
        self._dsb_p_min.setSuffix("")
        self._dsb_p_min.setToolTip("Cuantía mínima de refuerzo (NTC DEC: 1%)")

        self._dsb_p_max = QDoubleSpinBox()
        self._dsb_p_max.setRange(0.01, 0.08)
        self._dsb_p_max.setSingleStep(0.005)
        self._dsb_p_max.setValue(0.06)
        self._dsb_p_max.setSuffix("")
        self._dsb_p_max.setToolTip("Cuantía máxima de refuerzo (NTC DEC: 6%)")

        lbl_auto = QLabel("(Cuantía y barras calculadas automáticamente)")
        lbl_auto.setStyleSheet("color:#7D6608;font-style:italic;font-size:8pt;")

        lay.addWidget(QLabel("Material refuerzo:"))
        lay.addWidget(self._cb_rebar_mat)
        lay.addWidget(QLabel("fyr (kg/cm²):"))
        lay.addWidget(self._dsb_fy_r)
        row_p = QHBoxLayout()
        row_p.addWidget(QLabel("ρ mín:"))
        row_p.addWidget(self._dsb_p_min)
        row_p.addWidget(QLabel("ρ máx:"))
        row_p.addWidget(self._dsb_p_max)
        lay.addLayout(row_p)
        lay.addWidget(lbl_auto)
        return grp

    def _grp_geometry(self) -> QGroupBox:
        grp = QGroupBox("Geometría de la sección")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        # Sección concreto (solo SRC)
        self._dsb_bc = QDoubleSpinBox()
        self._dsb_bc.setRange(10, 300)
        self._dsb_bc.setValue(50)
        self._dsb_bc.setSuffix(" cm")
        self._dsb_bc.setToolTip("Ancho sección concreto")

        self._dsb_hc = QDoubleSpinBox()
        self._dsb_hc.setRange(10, 300)
        self._dsb_hc.setValue(50)
        self._dsb_hc.setSuffix(" cm")
        self._dsb_hc.setToolTip("Alto sección concreto")

        self._dsb_cover = QDoubleSpinBox()
        self._dsb_cover.setRange(1, 20)
        self._dsb_cover.setValue(5)
        self._dsb_cover.setSuffix(" cm")
        self._dsb_cover.setToolTip("Recubrimiento libre. Valor por defecto: 5 cm.")

        self._dsb_ex = QDoubleSpinBox()
        self._dsb_ex.setRange(-50, 50)
        self._dsb_ex.setValue(0)
        self._dsb_ex.setSuffix(" cm")
        self._dsb_ex.setToolTip("Desfase X del centroide del perfil respecto al centro del concreto")

        self._dsb_ey = QDoubleSpinBox()
        self._dsb_ey.setRange(-50, 50)
        self._dsb_ey.setValue(0)
        self._dsb_ey.setSuffix(" cm")
        self._dsb_ey.setToolTip("Desfase Y del centroide del perfil")

        self._dsb_Kx = QDoubleSpinBox()
        self._dsb_Kx.setRange(0.1, 5.0)
        self._dsb_Kx.setValue(1.0)
        self._dsb_Kx.setSuffix("")
        self._dsb_Kx.setToolTip("Factor Kx — valor manual a utilizar en diseño")
        self._dsb_Kx.setEnabled(True)    # editable por defecto (Auto-K OFF)

        self._dsb_Ky = QDoubleSpinBox()
        self._dsb_Ky.setRange(0.1, 5.0)
        self._dsb_Ky.setValue(1.0)
        self._dsb_Ky.setToolTip("Factor Ky — valor manual a utilizar en diseño")
        self._dsb_Ky.setEnabled(True)    # editable por defecto (Auto-K OFF)


        # Conectores
        self._grp_conn_inner = QGroupBox("Conectores de cortante (SRC)")
        lay_c = QVBoxLayout(self._grp_conn_inner)

        # ── Pernos Nelson ──────────────────────────────────────────────────
        lay_c.addWidget(QLabel("── Pernos Nelson ──"))
        self._cb_stud_d = QComboBox()
        for d in STUD_DIAMETERS_IN:
            self._cb_stud_d.addItem(f"{d}\" ({d*2.54:.3f} cm)")
        self._cb_stud_d.setCurrentIndex(2)  # 3/4"

        self._dsb_stud_h = QDoubleSpinBox()
        self._dsb_stud_h.setRange(5, 30)
        self._dsb_stud_h.setValue(10)
        self._dsb_stud_h.setSuffix(" cm")

        lay_c.addWidget(QLabel("Diámetro perno:"))
        lay_c.addWidget(self._cb_stud_d)
        lay_c.addWidget(QLabel("Longitud perno:"))
        lay_c.addWidget(self._dsb_stud_h)

        # ── Canal CE ───────────────────────────────────────────────────────
        lay_c.addWidget(QLabel("── Alt. Canal CE ──"))
        from design.connectors import CE_SECTIONS as _CE
        self._cb_ce_key = QComboBox()
        for k in _CE:
            self._cb_ce_key.addItem(k)
        self._cb_ce_key.setCurrentIndex(1)   # C100×8.1 por defecto
        self._cb_ce_key.setToolTip("Sección de canal estándar CE (NTC DEA 10.2.8.4)")

        self._dsb_ce_lcc = QDoubleSpinBox()
        self._dsb_ce_lcc.setRange(5.0, 100.0)
        self._dsb_ce_lcc.setValue(20.0)
        self._dsb_ce_lcc.setSuffix(" cm")
        self._dsb_ce_lcc.setToolTip("Longitud del canal conector (lcc)")

        lay_c.addWidget(QLabel("Sección canal CE:"))
        lay_c.addWidget(self._cb_ce_key)
        lay_c.addWidget(QLabel("Longitud canal (lcc):"))
        lay_c.addWidget(self._dsb_ce_lcc)

        self._grp_conn_inner.setVisible(True)

        self._lbl_bc = QLabel("Ancho bc (cm):")
        self._lbl_hc = QLabel("Alto hc (cm):")

        lay.addWidget(self._lbl_bc)
        lay.addWidget(self._dsb_bc)
        lay.addWidget(self._lbl_hc)
        lay.addWidget(self._dsb_hc)
        lay.addWidget(QLabel("Recubrimiento:"))
        lay.addWidget(self._dsb_cover)
        lay.addWidget(QLabel("Desfase ex (cm):"))
        lay.addWidget(self._dsb_ex)
        lay.addWidget(QLabel("Desfase ey (cm):"))
        lay.addWidget(self._dsb_ey)
        # ── Longitud Efectiva — Factor K (igual que columnsteel) ────────────
        grp_k = QGroupBox("Longitud Efectiva — Factor K (AISC App.7)")
        vk = QVBoxLayout(grp_k)
        row_k = QHBoxLayout()
        row_k.addWidget(QLabel("Kx:"))
        row_k.addWidget(self._dsb_Kx)
        row_k.addWidget(QLabel("Ky:"))
        row_k.addWidget(self._dsb_Ky)
        vk.addLayout(row_k)
        self._btn_calc_k = QPushButton("Calcular K (AISC App.7)")
        self._btn_calc_k.setObjectName("btnGreen")
        self._btn_calc_k.setToolTip(
            "Calcula el factor de longitud efectiva K de cada columna con el "
            "ábaco de alineación (AISC 360-22 App.7, trabes encadenadas hasta "
            "columna) y muestra Kx, Ky, GA y GB por dirección.\n"
            "Requiere conexión activa a STAAD Pro. Corre en el hilo principal.")
        self._btn_calc_k.clicked.connect(self._on_calc_k)
        vk.addWidget(self._btn_calc_k)
        self._btn_k_lengths = QPushButton("Longitudes trabes (K)")
        self._btn_k_lengths.setToolTip(
            "Tabla de longitudes reales de trabes (encadenadas hasta "
            "columna) usadas en el cálculo de K.\nPermite corregirlas y "
            "recalcular. Disponible después de ejecutar el diseño.")
        self._btn_k_lengths.setEnabled(False)
        self._btn_k_lengths.clicked.connect(self._on_btn_k_lengths)
        vk.addWidget(self._btn_k_lengths)
        self._btn_col_len = QPushButton("Longitud de columnas…")
        self._btn_col_len.setToolTip(
            "Longitud REAL de la columna cuando está modelada con 2 o más "
            "barras.\nSuma los tramos verticales continuos hasta encontrar una "
            "trabe en Dir.X y/o Dir.Z (las diagonales se descomponen).\n"
            "La tabla permite modificar manualmente la longitud; el diseño usa "
            "KLx = Kx·L(Dir.X) y KLy = Ky·L(Dir.Z).")
        self._btn_col_len.clicked.connect(self._on_btn_col_len)
        vk.addWidget(self._btn_col_len)
        _lbl_marco = QLabel(
            "K manual: escriba Kx/Ky arriba.  K automática: presione "
            "'Calcular K (AISC App.7)' (ahí se indica el tipo de marco por "
            "dirección y el diseño usará ese K por columna).")
        _lbl_marco.setWordWrap(True)
        _lbl_marco.setStyleSheet("font-size:7.5pt; color:#666;")
        vk.addWidget(_lbl_marco)
        lay.addWidget(grp_k)

        # ── Efectos de 2° Orden (B1-B2 — AISC App.8 / DG6 2a ed / NTC DEA) ──
        grp_so = QGroupBox("Efectos de 2° Orden (B1-B2)")
        vso = QVBoxLayout(grp_so)
        self._chk_so = QCheckBox("Considerar efectos de 2° orden")
        self._chk_so.setChecked(False)
        self._chk_so.setToolTip(
            "Marque para que el script amplifique los momentos con el método "
            "B1-B2\n(AISC 360-22 App.8 / Design Guide 6 2a ed. / NTC DEA). "
            "Pe1 usa la EIeff\nde la columna compuesta (AISC I2-6/I2-12: "
            "C1=0.25+3ρ≤0.7 embebida,\nC3=0.45+3ρ≤0.9 rellena).\n\n"
            "DESMARQUE si los efectos de 2° orden ya fueron considerados en "
            "su\nmodelo matemático (análisis P-Δ / análisis directo en "
            "STAAD Pro).")
        _b2_tip = (
            "B2: amplificador de piso, INDICADO POR EL USUARIO por dirección\n"
            "(calcúlelo externamente con ΣPu, ΣH y Δoh de cada entrepiso —\n"
            "AISC 360-22 Ec. A-8-6 / NTC DEA 2023 Ec. 3.7.3.2.1).\n"
            "  • Dir. X → eje fuerte (Mux)\n"
            "  • Dir. Z → eje débil (Muy)\n"
            "Se aplica a Mlt en Mr = B1·Mnt + B2·Mlt (dir. no arriostrada).")
        self._dsb_B2x = QDoubleSpinBox()
        self._dsb_B2x.setRange(1.0, 3.0); self._dsb_B2x.setValue(1.0)
        self._dsb_B2x.setDecimals(2); self._dsb_B2x.setSingleStep(0.05)
        self._dsb_B2x.setMinimumWidth(90); self._dsb_B2x.setToolTip(_b2_tip)
        self._dsb_B2z = QDoubleSpinBox()
        self._dsb_B2z.setRange(1.0, 3.0); self._dsb_B2z.setValue(1.0)
        self._dsb_B2z.setDecimals(2); self._dsb_B2z.setSingleStep(0.05)
        self._dsb_B2z.setMinimumWidth(90); self._dsb_B2z.setToolTip(_b2_tip)
        vso.addWidget(self._chk_so)

        # Contenido que se DESPLIEGA/OCULTA al marcar el checkbox (igual que
        # columnsteel). Los checkboxes de arriostrado están en el grupo de
        # Longitud Efectiva (definen K y el tipo de amplificación).
        self._so_content = QWidget()
        vso_c = QVBoxLayout(self._so_content)
        vso_c.setContentsMargins(0, 4, 0, 0)
        vso_c.setSpacing(4)
        row_ds = QHBoxLayout()
        row_ds.addWidget(QLabel("B2 Dir. X (Mx):"))
        row_ds.addWidget(self._dsb_B2x)
        row_ds.addWidget(QLabel("  B2 Dir. Z (My):"))
        row_ds.addWidget(self._dsb_B2z)
        row_ds.addStretch()
        vso_c.addLayout(row_ds)
        # LC gravitacional
        row_g = QHBoxLayout()
        row_g.addWidget(QLabel("LC gravitacional (PP+CM+CVacc):"))
        self._spn_lc_grav = QSpinBox()
        self._spn_lc_grav.setRange(0, 9999); self._spn_lc_grav.setValue(0)
        self._spn_lc_grav.setMinimumWidth(70)
        self._spn_lc_grav.setToolTip(
            "Caso de carga GRAVITACIONAL para separar Mnt/Mlt:\n"
            "  Mr = B1·Mnt + B2·Mlt   [AISC A-8-1 / DG6]\n"
            "0 = no separar (conservador: B1 o δs sobre el momento total).")
        row_g.addWidget(self._spn_lc_grav); row_g.addStretch()
        vso_c.addLayout(row_g)
        vso.addWidget(self._so_content)

        # El checkbox DESPLIEGA/OCULTA el contenido (no solo lo habilita)
        self._chk_so.toggled.connect(self._so_content.setVisible)
        self._so_content.setVisible(self._chk_so.isChecked())
        lay.addWidget(grp_so)
        lay.addWidget(self._grp_conn_inner)
        return grp

    def _grp_lc(self) -> QGroupBox:
        grp = QGroupBox("Combinaciones de carga")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._sb_lc_ini = QSpinBox()
        self._sb_lc_ini.setRange(1, 9999)
        self._sb_lc_ini.setValue(1)
        self._sb_lc_fin = QSpinBox()
        self._sb_lc_fin.setRange(1, 9999)
        self._sb_lc_fin.setValue(100)

        row = QHBoxLayout()
        row.addWidget(QLabel("LC ini:"))
        row.addWidget(self._sb_lc_ini)
        row.addWidget(QLabel("fin:"))
        row.addWidget(self._sb_lc_fin)
        lay.addLayout(row)
        return grp

    def _grp_code(self) -> QGroupBox:
        grp = QGroupBox("Normativa")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)
        self._cb_code = QComboBox()
        self._cb_code.addItems(["NTC 2023 DEA/DEC", "ACI 318-25 / AISC 360-22"])
        self._cb_code.setToolTip("Normativa de diseño a aplicar")
        lay.addWidget(self._cb_code)
        return grp

    def _make_run_btn(self) -> QPushButton:
        btn = QPushButton("▶  DISEÑAR COLUMNAS COMPUESTAS")
        btn.setObjectName("btn_run")
        btn.setToolTip("Ejecuta el diseño para todas las barras y combinaciones seleccionadas")
        btn.clicked.connect(self._run_design)
        return btn

    # ── Panel derecho ─────────────────────────────────────────────────────────

    def _make_right_panel(self) -> QTabWidget:
        tabs = QTabWidget()
        tabs.setMinimumWidth(400)
        self._tabs = tabs

        # Tab 1: Envolvente
        self._tbl_env = CopyableTable()
        self._tbl_env.setAlternatingRowColors(True)
        self._tbl_env.horizontalHeader().setStretchLastSection(True)
        self._tbl_env.cellClicked.connect(self._on_env_clicked)
        tabs.addTab(self._tbl_env, "Envolvente")

        # Tab 2: Por combinación
        self._tbl_combo = CopyableTable()
        self._tbl_combo.setAlternatingRowColors(True)
        self._tbl_combo.horizontalHeader().setStretchLastSection(True)
        tabs.addTab(self._tbl_combo, "Por Combinación")

        # Tab 3: Interacción 3D
        wplot = QWidget()
        play = QVBoxLayout(wplot)
        play.setContentsMargins(4, 4, 4, 4)
        play.setSpacing(4)

        # Fila de controles
        row_ctrl = QHBoxLayout()
        row_ctrl.addWidget(QLabel("Miembro:"))
        self._cb_member_plot = QComboBox()
        self._cb_member_plot.currentIndexChanged.connect(self._update_plot)
        self._cb_member_plot.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        row_ctrl.addWidget(self._cb_member_plot)
        play.addLayout(row_ctrl)

        # Splitter horizontal: izquierda=diagrama, derecha=sección
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.setChildrenCollapsible(False)

        # --- Lado izquierdo: diagrama interacción ---
        wleft = QWidget()
        lleft = QVBoxLayout(wleft)
        lleft.setContentsMargins(0, 0, 0, 0)
        lleft.setSpacing(2)
        self._plot3d = InteractionPlot3D()
        lleft.addWidget(self._plot3d)
        hsplit.addWidget(wleft)

        # --- Lado derecho: sección transversal con dimensiones ---
        wright = QWidget()
        wright.setMinimumWidth(260)
        wright.setMaximumWidth(380)
        lright = QVBoxLayout(wright)
        lright.setContentsMargins(4, 4, 4, 4)
        lbl_sec = QLabel("Sección transversal")
        lbl_sec.setAlignment(Qt.AlignCenter)
        lbl_sec.setStyleSheet("font-weight:bold;color:#1B4F72;font-size:9pt;")
        lright.addWidget(lbl_sec)
        self._sec_view = SectionView()
        self._sec_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lright.addWidget(self._sec_view, 1)
        hsplit.addWidget(wright)

        hsplit.setSizes([700, 300])
        play.addWidget(hsplit, 1)
        tabs.addTab(wplot, "Interacción 3D")

        # Tab 3b: Esfuerzo-Deformación
        wss = QWidget()
        sslay = QVBoxLayout(wss)
        sslay.setContentsMargins(4, 4, 4, 4)
        row_ss = QHBoxLayout()
        row_ss.addWidget(QLabel("Miembro:"))
        self._cb_member_ss = QComboBox()
        row_ss.addWidget(self._cb_member_ss)
        row_ss.addWidget(QLabel("Combinación:"))
        self._cb_lc_ss = QComboBox()
        row_ss.addWidget(self._cb_lc_ss)
        row_ss.addStretch()
        sslay.addLayout(row_ss)
        from gui.stress_strain_plot import StrainStressWidget
        self._ss_widget = StrainStressWidget()
        sslay.addWidget(self._ss_widget, 1)
        self._cb_member_ss.currentIndexChanged.connect(self._on_ss_member_changed)
        self._cb_lc_ss.currentIndexChanged.connect(self._update_ss_plot)
        tabs.addTab(wss, "Esfuerzo-Deformación")

        # Tab 4: Memoria de cálculo
        wmem = QWidget()
        mlay = QVBoxLayout(wmem)
        mlay.setContentsMargins(4, 4, 4, 4)
        hm = QHBoxLayout()
        hm.addWidget(QLabel("Miembro:"))
        self._cb_member_memo = QComboBox()
        self._cb_member_memo.currentIndexChanged.connect(self._update_memo)
        hm.addWidget(self._cb_member_memo)
        hm.addStretch()
        btn_mem = QPushButton("📄 Exportar Word")
        btn_mem.setObjectName("btn_memory")
        btn_mem.clicked.connect(self._export_word)
        hm.addWidget(btn_mem)
        btn_dxf = QPushButton("📐 Exportar DXF")
        btn_dxf.clicked.connect(self._export_dxf)
        hm.addWidget(btn_dxf)
        mlay.addLayout(hm)
        self._txt_memo = QTextEdit()
        self._txt_memo.setReadOnly(True)
        mlay.addWidget(self._txt_memo)
        tabs.addTab(wmem, "Memoria de Cálculo")

        return tabs

    # ── Slots UI ──────────────────────────────────────────────────────────────

    def _on_col_type_changed(self, idx):
        is_enc = idx == 0
        self._lbl_bc.setVisible(is_enc)
        self._dsb_bc.setVisible(is_enc)
        self._lbl_hc.setVisible(is_enc)
        self._dsb_hc.setVisible(is_enc)
        self._grp_conn_inner.setVisible(is_enc)

    def _update_steel_props(self, idx):
        mat = STEEL_MATERIALS[idx]
        self._dsb_fy_s.setValue(mat["fy"])
        self._dsb_fu_s.setValue(mat["fu"])

    def _update_rebar_props(self, idx):
        mat = REBAR_MATERIALS[idx]
        self._dsb_fy_r.setValue(mat["fy"])

    def _populate_profiles(self, idx):
        from design.steel_db import list_sections
        is_3pl = (self._cb_prof_type.currentText().startswith("3 Placas"))
        self._btn_3pl.setVisible(is_3pl)
        self._lbl_3pl.setVisible(is_3pl)
        self._cb_prof_name.setVisible(not is_3pl)
        if is_3pl:
            self._cb_prof_name.clear()
            return
        types = ["W", "CHANNEL", "HSS_RECT", "HSS_CIRC", "HSS_CIRC"]
        t = types[idx] if idx < len(types) else "W"
        names = list_sections(t)
        self._cb_prof_name.clear()
        self._cb_prof_name.addItems(names)

    def _open_dialog_3pl(self):
        from gui.dialog_3pl import Dialog3PL
        dlg = Dialog3PL(self, initial=self._plates3_dims)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._plates3_dims = dlg.get_dimensions()
            d = self._plates3_dims
            self._lbl_3pl.setText(
                f"bf_t={d['bf_top']:.0f}×{d['tf_top']:.1f} | "
                f"bf_b={d['bf_bot']:.0f}×{d['tf_bot']:.1f} | "
                f"alma {d['hw']:.0f}×{d['tw']:.1f}")

    def _connect_staad(self):
        from fileio.openstaad_reader import OpenSTAADReader
        self._reader = OpenSTAADReader()
        ok, msg = self._reader.connect()
        if ok:
            self._lbl_conn.setText(f"✔ {msg}")
            self._lbl_conn.setObjectName("lbl_connected")
            lc_ids = self._reader.get_load_cases()
            if lc_ids:
                self._sb_lc_ini.setValue(lc_ids[0])
                self._sb_lc_fin.setValue(lc_ids[-1])
        else:
            self._lbl_conn.setText(f"✗ {msg}")
            self._lbl_conn.setObjectName("lbl_disconnected")
        self._lbl_conn.style().unpolish(self._lbl_conn)
        self._lbl_conn.style().polish(self._lbl_conn)
        self._status(msg)

    def _get_selected(self):
        if self._reader and self._reader.connected:
            ids = self._reader.get_selected_members()
            if ids:
                self._le_members.setText(" ".join(str(i) for i in ids))
                self._status(f"{len(ids)} barras importadas de STAAD.")
            else:
                self._status("Sin barras seleccionadas en STAAD.")
        else:
            self._status("Conecte a STAAD Pro primero.")

    # ── Diseño ────────────────────────────────────────────────────────────────

    def _run_design(self):
        params = self._collect_params()
        if params is None:
            return

        # ── Factor K: se usa el pre-calculado con el botón "Calcular K"
        # (que ya mostró el diálogo de tipo de marco). No se vuelve a
        # preguntar aquí. El mismo tipo de marco alimenta el 2° orden:
        # contraventeado = no sway (K1≤1 y B1; sway → K1=1 y B2).
        if params.get("auto_k"):
            sx, sz = getattr(self, "_k_sway_comp", (True, True))
            params["k_sway_dirx"] = sx
            params["k_sway_dirz"] = sz
            params["k_overrides"] = dict(getattr(self, "_k_overrides_comp", {}))
            params["arr_x"] = not sx
            params["arr_y"] = not sz

        # Pre-fetch STAAD en hilo principal
        cache = {}
        if self._reader and self._reader.connected:
            self._status("Pre-cargando datos de STAAD Pro…")
            QApplication.processEvents()
            member_ids = params["member_ids"]
            lc_ids     = list(params["lc_ids"])
            if params.get("second_order") and params.get("lc_grav"):
                _lg = params["lc_grav"]
                if _lg not in lc_ids:
                    lc_ids = lc_ids + [_lg]
            self._reader.pre_fetch(member_ids, lc_ids)
            if params.get("auto_k"):
                ok, msg = self._reader.build_connectivity()
                self._status(msg)
            cache["reader"] = self._reader

        self._pbar.show()
        self._pbar.setValue(0)

        self._design_cache = cache
        self._thread  = QThread()
        self._worker  = DesignWorker(params, cache)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._thread.start()

    def _on_btn_k_lengths(self):
        _kb = (getattr(self, "_k_beams", None)
               or getattr(self, "_design_cache", {}).get("k_beams", {}))
        if not _kb:
            QMessageBox.information(
                self, "Longitudes de trabes",
                "Ejecute primero el diseño con 'Calcular K automáticamente'.")
            return
        self._offer_k_lengths_review(_kb)

    def _on_calc_k(self, _checked=False, reuse_sway=False):
        """Botón independiente: calcula K de cada columna en el HILO PRINCIPAL
        (los objetos COM de STAAD son afines al hilo que los creó; por eso el
        cálculo dentro del worker fallaba y caía al método estándar). Muestra
        una tabla con ID, Kx, Ky y GA/GB por dirección, y habilita la revisión
        de longitudes."""
        if not (self._reader and self._reader.connected):
            QMessageBox.warning(
                self, "Calcular K",
                "Conecte a STAAD Pro antes de calcular el factor K.")
            return
        raw = self._le_members.text().strip()
        if raw:
            try:
                member_ids = [int(x) for x in raw.split()]
            except ValueError:
                QMessageBox.warning(self, "Calcular K", "IDs de barras inválidos.")
                return
        else:
            member_ids = self._reader.get_member_ids()
        if not member_ids:
            QMessageBox.warning(self, "Calcular K", "Sin columnas para calcular.")
            return
        # Diálogo de tipo de marco por dirección (Dir X / Dir Z). Se omite al
        # recalcular con longitudes revisadas (reusa la elección previa).
        if not (reuse_sway and getattr(self, "_k_sway_comp", None) is not None):
            if not self._ask_k_sway():
                return
        sx, sz = getattr(self, "_k_sway_comp", (True, True))
        self._status("Construyendo conectividad del modelo…")
        QApplication.processEvents()
        try:
            ok, msg = self._reader.build_connectivity()
        except Exception as exc:
            QMessageBox.critical(self, "Calcular K",
                                 f"Error construyendo conectividad: {exc}")
            return
        if not ok:
            QMessageBox.critical(self, "Calcular K", msg)
            return
        from design.k_chain import compute_k_factors_chained
        self._k_results = {}
        self._k_beams = {}
        overrides = dict(getattr(self, "_k_overrides_comp", {}))
        n = len(member_ids)
        for i, mid in enumerate(member_ids):
            self._status(f"Calculando K — columna {mid} ({i+1}/{n})…")
            QApplication.processEvents()
            try:
                res = compute_k_factors_chained(
                    self._reader, mid,
                    sway_y=sz,   # eje débil (Ky) ↔ Dir Z
                    sway_z=sx,   # eje fuerte (Kz) ↔ Dir X
                    length_overrides=overrides,
                    # L revisada a mano en «Longitud de columnas…» (K-1)
                    col_len_overrides=dict(getattr(self, "_col_len", {})))
            except Exception as exc:
                log.warning("Calcular K col %d: %s", mid, exc)
                continue
            if not res.get("ok"):
                # Sin conectividad/coordenadas no se inventa un K: el diseño
                # de esta barra usa el K manual.
                log.warning("Calcular K col %d: %s", mid, res.get("msg"))
                continue
            self._k_results[mid] = _k_detail_de(res, sway_x=sx, sway_y=sz)
            for bid, info in res.get("beams_K", {}).items():
                self._k_beams[bid] = info
        if not self._k_results:
            QMessageBox.warning(
                self, "Calcular K",
                "No se pudo calcular K para ninguna columna. Verifique la "
                "conexión y que las columnas tengan trabes conectadas.")
            return
        # Poblar spinbox con la 1ª columna (referencia); el diseño usa el K
        # pre-calculado por columna cuando existe (_k_results).
        self._btn_k_lengths.setEnabled(bool(self._k_beams))
        _first = next(iter(self._k_results.values()))
        self._dsb_Kx.setValue(_first["Kx"])
        self._dsb_Ky.setValue(_first["Ky"])
        self._status(f"K calculado para {len(self._k_results)} columna(s).")
        self._show_k_results_table()

    def _show_k_results_table(self):
        """Tabla: ID de columna, Kx, Ky y GA/GB por dirección. Incluye botón
        para revisar/editar las longitudes usadas en GA y GB."""
        from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                       QLabel, QTableWidget, QTableWidgetItem,
                                       QDialogButtonBox, QPushButton)
        from PySide6.QtCore import Qt as _Qt
        dlg = QDialog(self)
        dlg.setWindowTitle("Factor de Longitud Efectiva K — AISC 360-22 App.7")
        dlg.setMinimumSize(640, 460)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "K por columna (ábaco de alineación, trabes encadenadas hasta "
            "columna).\nDir. X = eje fuerte (Kx);  Dir. Z = eje débil (Ky).  "
            "GA = nodo inicial, GB = nodo final.")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        rows = sorted(self._k_results.items())
        t = QTableWidget(len(rows), 7)
        t.setHorizontalHeaderLabels(
            ["Columna", "Kx", "GA (X)", "GB (X)", "Ky", "GA (Z)", "GB (Z)"])
        for i, (mid, d) in enumerate(rows):
            vals = [str(mid), f"{d['Kx']:.3f}", f"{d['GA_x']:.2f}",
                    f"{d['GB_x']:.2f}", f"{d['Ky']:.3f}", f"{d['GA_y']:.2f}",
                    f"{d['GB_y']:.2f}"]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                it.setTextAlignment(_Qt.AlignCenter)
                it.setFlags(it.flags() & ~_Qt.ItemIsEditable)
                t.setItem(i, c, it)
        t.resizeColumnsToContents()
        t.setAlternatingRowColors(True)
        v.addWidget(t)
        row_b = QHBoxLayout()
        btn_len = QPushButton("Revisar longitudes (GA/GB)…")
        btn_len.setToolTip(
            "Tabla editable de longitudes de trabes usadas en el cálculo de "
            "GA y GB; permite corregirlas y recalcular el factor K.")
        def _rev():
            dlg.accept()
            self._on_btn_k_lengths()
        btn_len.clicked.connect(_rev)
        row_b.addWidget(btn_len); row_b.addStretch()
        v.addLayout(row_b)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(dlg.reject)
        bb.clicked.connect(lambda *_: dlg.accept())
        v.addWidget(bb)
        dlg.exec()

    def _ask_k_sway(self) -> bool:
        """Dialogo: marco contraventeado / no contraventeado por direccion
        (AISC 360-22 App.7). Regresa False si el usuario cancela."""
        from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                       QGroupBox, QRadioButton, QButtonGroup,
                                       QDialogButtonBox)
        dlg = QDialog(self)
        dlg.setWindowTitle("Auto K — AISC 360-22 Apéndice 7")
        dlg.setMinimumWidth(420)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Tipo de estructura por dirección (para el ábaco de alineación).\n"
            "El K se calcula con la longitud REAL de trabes encadenadas\n"
            "hasta encontrar columna (volados excluidos).")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        prev_x, prev_z = getattr(self, "_k_sway_comp", (True, True))
        grupos = []
        for titulo, prev in (("Dirección X  (pandeo eje fuerte — Kx)", prev_x),
                             ("Dirección Z  (pandeo eje débil — Ky)", prev_z)):
            g = QGroupBox(titulo)
            gl = QVBoxLayout(g)
            rb_s = QRadioButton("Marco  (con desplazamiento lateral — sway)")
            rb_b = QRadioButton("Contraventeado  (sin desplazamiento — braced)")
            (rb_s if prev else rb_b).setChecked(True)
            bg = QButtonGroup(dlg); bg.addButton(rb_s); bg.addButton(rb_b)
            gl.addWidget(rb_s); gl.addWidget(rb_b)
            v.addWidget(g)
            grupos.append(rb_s)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return False
        self._k_sway_comp = (grupos[0].isChecked(), grupos[1].isChecked())
        return True

    def _offer_k_lengths_review(self, beams: dict):
        """Tabla editable de longitudes de trabes usadas en el calculo de K;
        [Recalcular K] vuelve a correr el diseño con las longitudes revisadas."""
        from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                       QTableWidget, QTableWidgetItem,
                                       QDialogButtonBox)
        from PySide6.QtCore import Qt as _Qt
        dlg = QDialog(self)
        dlg.setWindowTitle("Longitudes de trabes — cálculo de K")
        dlg.setMinimumSize(560, 420)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Longitud REAL (columna a columna) usada por cada trabe en el "
            "cálculo de K.\nEdite la columna 'L (m)' si detecta un valor "
            "incorrecto y presione [Recalcular K]\n(se vuelve a ejecutar el "
            "diseño con las longitudes revisadas). Las trabes en VOLADO se "
            "excluyen.")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        fin_lbl = {"columna": "en columna", "libre": "VOLADO (excluida)",
                   "quiebre": "quiebre/no colineal"}
        overrides = getattr(self, "_k_overrides_comp", {})
        orden = sorted(beams.items())
        tblL = QTableWidget(len(orden), 4)
        tblL.setHorizontalHeaderLabels(
            ["Trabe", "Perfil", "L (m)", "Terminación"])
        for i, (bid, (nom, L, fin)) in enumerate(orden):
            it0 = QTableWidgetItem(str(bid))
            it1 = QTableWidgetItem(str(nom))
            for it in (it0, it1):
                it.setFlags(it.flags() & ~_Qt.ItemIsEditable)
            it2 = QTableWidgetItem(f"{overrides.get(bid, L):.3f}")
            it3 = QTableWidgetItem(fin_lbl.get(fin, fin))
            it3.setFlags(it3.flags() & ~_Qt.ItemIsEditable)
            for c, it in enumerate((it0, it1, it2, it3)):
                it.setTextAlignment(_Qt.AlignCenter)
                tblL.setItem(i, c, it)
        tblL.resizeColumnsToContents()
        v.addWidget(tblL)
        bb = QDialogButtonBox()
        bb.addButton("Recalcular K", QDialogButtonBox.AcceptRole)
        bb.addButton("Aceptar valores", QDialogButtonBox.RejectRole)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new_ov = dict(overrides)
        cambio = False
        for i, (bid, (nom, L, fin)) in enumerate(orden):
            try:
                L_new = float(tblL.item(i, 2).text().replace(",", "."))
            except (ValueError, AttributeError):
                continue
            if L_new > 0 and abs(L_new - L) > 1e-4:
                new_ov[bid] = L_new
                cambio = True
        if cambio:
            self._k_overrides_comp = new_ov
            self._on_calc_k(reuse_sway=True)   # recalcular K con longitudes

    # ── Longitud REAL de columnas partidas en varias barras ───────────────────
    def _on_btn_col_len(self):
        """Tabla con la longitud real de cada columna (suma de los tramos
        continuos hasta la trabe que restringe cada dirección). El usuario
        puede modificarla manualmente; el diseño usa KLx = Kx·L(Dir.X) y
        KLy = Ky·L(Dir.Z)."""
        if not (self._reader and getattr(self._reader, "connected", False)):
            QMessageBox.information(
                self, "Longitud de columnas",
                "Conecte a STAAD Pro para leer la geometría del modelo.")
            return
        raw = self._le_members.text().strip()
        if raw:
            try:
                member_ids = [int(x) for x in raw.split()]
            except ValueError:
                QMessageBox.warning(self, "Longitud de columnas",
                                    "IDs de barras inválidos.")
                return
        else:
            member_ids = self._reader.get_member_ids()
        if not member_ids:
            QMessageBox.warning(self, "Longitud de columnas",
                                "Sin columnas para revisar.")
            return

        self._status("Revisando la longitud real de las columnas…")
        QApplication.processEvents()
        try:
            ok, msg = self._reader.build_connectivity()
            if not ok:
                QMessageBox.critical(self, "Longitud de columnas", msg)
                return
            from design.column_chain import FIN_TXT, longitudes_columnas
            datos = longitudes_columnas(
                self._reader, member_ids,
                overrides=dict(getattr(self, "_col_len", {})))
        except Exception as exc:
            QMessageBox.critical(self, "Longitud de columnas",
                                 f"No se pudo calcular:\n{exc}")
            return

        from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                       QTableWidget, QTableWidgetItem,
                                       QDialogButtonBox)
        dlg = QDialog(self)
        dlg.setWindowTitle("Longitud real de columnas (barras encadenadas)")
        dlg.setMinimumSize(760, 460)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Cuando una columna está modelada con 2 o más barras, la longitud "
            "de pandeo es la del tramo CONTINUO, no la del segmento. Se suman "
            "los tramos verticales colineales hasta encontrar una trabe que "
            "restrinja cada dirección (las diagonales se descomponen: aportan "
            "ux² al marco X y uz² al marco Z).\n"
            "Edite 'L Dir.X' o 'L Dir.Z' si conoce el valor correcto y presione "
            "[Aceptar]. El diseño usará KLx = Kx·L(Dir.X) y KLy = Ky·L(Dir.Z).")
        lbl.setWordWrap(True)
        v.addWidget(lbl)

        cols = ["Columna", "L segmento (m)", "Barras Dir.X", "L Dir.X (m)",
                "Termina X", "Barras Dir.Z", "L Dir.Z (m)", "Termina Z"]
        orden = sorted(datos)
        tblC = QTableWidget(len(orden), len(cols))
        tblC.setHorizontalHeaderLabels(cols)
        for i, mid in enumerate(orden):
            d = datos[mid]
            fx = " / ".join(FIN_TXT.get(f, f) for f in d["fin_x"])
            fz = " / ".join(FIN_TXT.get(f, f) for f in d["fin_z"])
            vals = [str(mid), f"{d['L_seg']:.3f}", str(d["n_segs_x"]),
                    f"{d['Lx']:.3f}", fx, str(d["n_segs_z"]),
                    f"{d['Lz']:.3f}", fz]
            for c, txt in enumerate(vals):
                it = QTableWidgetItem(txt)
                it.setTextAlignment(Qt.AlignCenter)
                if c not in (3, 6):          # solo las L son editables
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                tblC.setItem(i, c, it)
        tblC.resizeColumnsToContents()
        v.addWidget(tblC)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        finales = {}
        for i, mid in enumerate(orden):
            d = datos[mid]

            def _leer(col, calc):
                try:
                    return float(tblC.item(i, col).text().replace(",", "."))
                except (ValueError, AttributeError):
                    return calc

            Lx, Lz = _leer(3, d["Lx"]), _leer(6, d["Lz"])
            if Lx > 0 and Lz > 0:
                finales[mid] = (Lx, Lz)
        self._col_len = finales
        self._status(f"Longitud real registrada para {len(finales)} columna(s). "
                     "Se usará en el próximo diseño.")

    def _collect_params(self) -> Optional[dict]:
        col_type = (COLUMN_TYPE_ENCASED
                    if self._cb_col_type.currentIndex() == 0
                    else COLUMN_TYPE_FILLED)

        # IDs de miembros
        raw = self._le_members.text().strip()
        if raw:
            try:
                member_ids = [int(x) for x in raw.split()]
            except ValueError:
                QMessageBox.warning(self, "Error", "IDs de barras inválidos.")
                return None
        else:
            if self._reader and self._reader.connected:
                member_ids = self._reader.get_member_ids()
            else:
                QMessageBox.warning(self, "Sin miembros",
                                    "Conecte a STAAD Pro o indique IDs de barras.")
                return None

        lc_ini = self._sb_lc_ini.value()
        lc_fin = self._sb_lc_fin.value()
        if self._reader and self._reader.connected:
            known = self._reader.get_load_cases()
            if known:
                # Filtrar por rango indicado
                lc_ids = [lc for lc in known if lc_ini <= lc <= lc_fin]
                if not lc_ids:
                    # Rango no encontrado en el catálogo → usar enteros directos
                    lc_ids = list(range(lc_ini, lc_fin + 1))
            else:
                # STAAD Load API no enumeró combinaciones → usar el rango directamente
                lc_ids = list(range(lc_ini, lc_fin + 1))
        else:
            lc_ids = list(range(lc_ini, lc_fin + 1))
        if not lc_ids:
            lc_ids = [lc_ini]

        # Perfil
        prof_name = self._cb_prof_name.currentText().strip()
        from design.steel_db import get_section, detect_section_type, plates3_section
        if self._cb_prof_type.currentText().startswith("3 Placas"):
            if not self._plates3_dims:
                QMessageBox.warning(self, "Sección 3 placas",
                                    "Defina las dimensiones de las placas.")
                return
            d3 = self._plates3_dims
            prof_data = plates3_section(d3["bf_top"], d3["tf_top"],
                                        d3["bf_bot"], d3["tf_bot"],
                                        d3["hw"], d3["tw"])
            prof_name = "3PL armada"
        else:
            prof_data = get_section(prof_name)
        if prof_data is None:
            QMessageBox.warning(self, "Perfil no encontrado",
                                f"El perfil '{prof_name}' no está en la base de datos.\n"
                                "Verifique el nombre (ej. W14X120, HSS8X8X1/2).")
            return None

        # Diámetro de perno
        stud_d_idx = self._cb_stud_d.currentIndex()
        stud_d_in  = STUD_DIAMETERS_IN[stud_d_idx]

        return {
            "column_type":  col_type,
            "member_ids":   member_ids,
            "lc_ids":       lc_ids,
            "fc":           self._dsb_fc.value(),
            "Ec":           self._dsb_Ec.value(),
            "wc":           self._dsb_wc.value(),
            "fy_s":         self._dsb_fy_s.value(),
            "fu_s":         self._dsb_fu_s.value(),
            "fy_r":         self._dsb_fy_r.value(),
            "p_min":        self._dsb_p_min.value(),
            "p_max":        self._dsb_p_max.value(),
            "bc":           self._dsb_bc.value(),
            "hc":           self._dsb_hc.value(),
            "cover":        self._dsb_cover.value(),
            "ex":           self._dsb_ex.value(),
            "ey":           self._dsb_ey.value(),
            "Kx":           self._dsb_Kx.value(),
            "Ky":           self._dsb_Ky.value(),
            "auto_k":       bool(getattr(self, "_k_results", None)),
            "second_order": self._chk_so.isChecked(),
            "lc_grav":      self._spn_lc_grav.value(),
            "arr_x":        False,   # se define en _run_design desde el
            "arr_y":        False,   #   diálogo de tipo de marco (Auto-K)
            "k_precomputed": {m: (d["Kx"], d["Ky"])
                              for m, d in getattr(self, "_k_results", {}).items()},
            # Columna física del K automático (barras, nudos A/B, G y la L
            # que acompaña a cada K) para KL y la memoria (K-1).
            "k_detail_pre": {m: dict(d) for m, d
                             in getattr(self, "_k_results", {}).items()},
            # Longitud real por dirección revisada en "Longitud de columnas…"
            "col_len":      dict(getattr(self, "_col_len", {})),
            "delta_s_x":    self._dsb_B2x.value(),   # B2 Dir. X (eje fuerte, Mux)
            "delta_s_y":    self._dsb_B2z.value(),   # B2 Dir. Z (eje débil, Muy)
            "delta_s":      max(self._dsb_B2x.value(),
                                self._dsb_B2z.value()),   # compat
            "stud_d_cm":    stud_d_in * 2.54,
            "stud_h_cm":    self._dsb_stud_h.value(),
            "ce_key":       self._cb_ce_key.currentText(),
            "ce_lcc_cm":    self._dsb_ce_lcc.value(),
            "prof_name":    prof_name,
            "prof_data":    prof_data,
            "code":         self._cb_code.currentText(),
        }

    def _on_progress(self, pct: int, msg: str):
        self._pbar.setValue(pct)
        self._status(msg)
        QApplication.processEvents()

    def _on_finished(self, results: list):
        self._thread.quit()
        self._pbar.hide()
        self._results = results
        self._populate_env_table(results)
        self._populate_combo_table(results)
        self._populate_member_selectors(results)
        if results:
            self._update_plot(0)
            self._update_memo(0)
            # Si se pre-calculó K, actualizar spinboxes con el K de referencia
            if getattr(self, "_k_results", None) and results[0].get("Kx") is not None:
                self._dsb_Kx.setValue(results[0]["Kx"])
                self._dsb_Ky.setValue(results[0]["Ky"])
            # Auto-populate esfuerzo-deformación
            self._on_ss_member_changed(0)
            self._update_ss_plot()
            # Tabla de longitudes de trabes usadas en Auto-K (editable)
            _kb = (getattr(self, "_k_beams", None)
                   or getattr(self, "_design_cache", {}).get("k_beams", {}))
            self._btn_k_lengths.setEnabled(bool(_kb))
        self._status(f"Diseño completado — {len(results)} miembros procesados.")

    def _on_error(self, msg: str):
        self._thread.quit()
        self._pbar.hide()
        self._status(f"Error: {msg[:100]}")
        QMessageBox.critical(self, "Error en diseño", msg)

    # ── Tablas de resultados ──────────────────────────────────────────────────

    def _populate_env_table(self, results: list):
        cols = ["Miembro", "Tipo", "Perfil", "φPn (ton)", "Pu crít (ton)",
                "Mux crít (t·m)", "Muy crít (t·m)", "LC crít",
                "PM", "V", "T", "Máx", "Estado"]
        tbl = self._tbl_env
        tbl.clear()
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setRowCount(len(results))

        for row, r in enumerate(results):
            env = r.get("envelope")
            if env is None:
                continue
            vals = [
                str(r.get("member_id", "")),
                r.get("column_type_label", ""),
                r.get("profile_name", ""),
                f"{r.get('phi_Pn', 0):.2f}",
                f"{env.Pu:.3f}",
                f"{env.Mux:.3f}",
                f"{env.Muy:.3f}",
                getattr(env, "label", str(env.lc)),
                f"{env.PR_comp:.4f}",
                f"{env.PR_shear:.4f}",
                f"{env.PR_tors:.4f}",
                f"{env.PR_max:.4f}",
                env.status,
            ]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                if col >= 8:
                    try:
                        ratio = float(val)
                        color = (QColor(COLORS["ok_cell"])   if ratio <= 0.85
                                 else QColor(COLORS["warn_cell"]) if ratio <= 1.0
                                 else QColor(COLORS["fail_cell"]))
                        item.setBackground(color)
                    except ValueError:
                        if val == "OK":
                            item.setBackground(QColor(COLORS["ok_cell"]))
                        elif val == "NG":
                            item.setBackground(QColor(COLORS["fail_cell"]))
                tbl.setItem(row, col, item)

        tbl.resizeColumnsToContents()
        tbl.horizontalHeader().setStretchLastSection(True)

    def _populate_combo_table(self, results: list):
        cols = ["Miembro", "LC", "Pu (ton)", "Mux (t·m)", "Muy (t·m)",
                "Vux (ton)", "Vuy (ton)", "Tu (t·m)",
                "PM", "V", "T", "Máx", "Estado"]
        tbl = self._tbl_combo
        tbl.clear()
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)

        rows_data = []
        for r in results:
            mid = r.get("member_id", "")
            # Separador por miembro
            rows_data.append(("sep", mid, r.get("column_type_label", "")))
            for dr in r.get("all_results", []):
                rows_data.append(("data", mid, dr))

        tbl.setRowCount(len(rows_data))
        for row, entry in enumerate(rows_data):
            if entry[0] == "sep":
                item = QTableWidgetItem(f"── Miembro {entry[1]} — {entry[2]} ──")
                item.setBackground(QColor(COLORS["separator"]))
                item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                tbl.setItem(row, 0, item)
                tbl.setSpan(row, 0, 1, len(cols))
                continue
            _, mid, dr = entry
            vals = [str(mid), getattr(dr, "label", str(dr.lc)),
                    f"{dr.Pu:.3f}", f"{dr.Mux:.3f}", f"{dr.Muy:.3f}",
                    "—", "—", "—",
                    f"{dr.PR_comp:.4f}", f"{dr.PR_shear:.4f}",
                    f"{dr.PR_tors:.4f}", f"{dr.PR_max:.4f}", dr.status]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                if col >= 8:
                    try:
                        ratio = float(val)
                        color = (QColor(COLORS["ok_cell"])   if ratio <= 0.85
                                 else QColor(COLORS["warn_cell"]) if ratio <= 1.0
                                 else QColor(COLORS["fail_cell"]))
                        item.setBackground(color)
                    except ValueError:
                        if val == "OK":
                            item.setBackground(QColor(COLORS["ok_cell"]))
                        elif val == "NG":
                            item.setBackground(QColor(COLORS["fail_cell"]))
                tbl.setItem(row, col, item)

        tbl.resizeColumnsToContents()

    def _populate_member_selectors(self, results: list):
        self._cb_member_plot.clear()
        self._cb_member_memo.clear()
        self._cb_member_ss.clear()
        for r in results:
            mid = r.get("member_id", "")
            label = f"Miembro {mid} — {r.get('profile_name','')}"
            self._cb_member_plot.addItem(label)
            self._cb_member_memo.addItem(label)
            self._cb_member_ss.addItem(label)

    def _on_ss_member_changed(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        self._cb_lc_ss.blockSignals(True)
        self._cb_lc_ss.clear()
        for dr in r.get("all_results", []):
            self._cb_lc_ss.addItem(f"{dr.label} — Pu={dr.Pu:.2f}t")
        self._cb_lc_ss.blockSignals(False)
        # Auto-mostrar la combinación con mayor ratio
        all_r = r.get("all_results", [])
        if all_r:
            worst = max(range(len(all_r)), key=lambda i: all_r[i].PR_max)
            self._cb_lc_ss.setCurrentIndex(worst)
        # setCurrentIndex no dispara currentIndexChanged porque las señales
        # de _cb_lc_ss están bloqueadas arriba — refrescar explícitamente.
        self._update_ss_plot()

    def _update_ss_plot(self):
        idx_m = self._cb_member_ss.currentIndex()
        idx_lc = self._cb_lc_ss.currentIndex()
        if not self._results or idx_m >= len(self._results):
            return
        r = self._results[idx_m]
        ss_data = r.get("ss_diagrams", [])
        if ss_data and idx_lc < len(ss_data):
            self._ss_widget.set_data(ss_data[idx_lc])
        elif r.get("all_results") and idx_lc < len(r["all_results"]):
            self._status("Diagrama esfuerzo-deformación no disponible para esta combinación.")

    def _on_env_clicked(self, row, col):
        if row < len(self._results):
            self._cb_member_plot.setCurrentIndex(row)
            self._cb_member_memo.setCurrentIndex(row)
            self._tabs.setCurrentIndex(2)

    def _update_plot(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        self._plot3d._member_id = r.get("member_id", 0)
        surf = r.get("surface")
        surf_nom = r.get("surface_nominal")
        if surf:
            self._plot3d.set_surface(*surf, nominal=surf_nom)
        demands = r.get("demands", [])
        self._plot3d.set_demands(demands)
        # Sección view
        sec_view_data = r.get("section_view_data", {})
        self._sec_view.set_section(sec_view_data)

    def _update_memo(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        env = r.get("envelope")
        memo = env.memo if env else r.get("memo", "(sin memoria)")
        # Conectores
        conn_memo = r.get("connectors_memo", "")
        self._txt_memo.setPlainText(memo + ("\n\n" + conn_memo if conn_memo else ""))

    def _export_dxf(self):
        """Exporta ratios a DXF — mismo formato que columnsteel_design_pro.

        Si el archivo elegido existe: reduce líneas y actualiza etiquetas
        (id → 'id / ratio (combo)', rojo si ratio > 1, texto 0.3).
        Si no existe: genera un DXF nuevo con una columna por miembro.
        """
        import os as _os
        from PySide6.QtWidgets import QFileDialog, QInputDialog
        if not self._results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute el diseño primero.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Seleccionar / crear DXF de ratios", "",
            "DXF Files (*.dxf);;All Files (*)")
        if not path:
            return
        pct, ok = QInputDialog.getDouble(
            self, "Reducción de líneas",
            "Porcentaje de reducción de líneas (0-99):",
            20.0, 0.0, 99.0, 1)
        if not ok:
            pct = 20.0
        from fileio.dxf_exporter import export_dxf_single, modify_existing_dxf
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Actualizando DXF de ratios…"):
            if _os.path.exists(path):
                okd, out = modify_existing_dxf(path, self._results,
                                               reduction_pct=pct)
            else:
                okd = export_dxf_single(path, self._results,
                                        reduction_pct=pct)
                out = path
        if okd:
            QMessageBox.information(self, "DXF", f"DXF generado:\n{out}")
        else:
            QMessageBox.warning(self, "DXF",
                                f"No fue posible generar el DXF:\n{out}")

    def _export_word(self):
        if not self._results:
            QMessageBox.information(self, "Sin resultados", "Ejecute el diseño primero.")
            return
        from fileio.word_exporter import export_word, _DOCX_OK
        if not _DOCX_OK:
            QMessageBox.warning(self, "python-docx no instalado",
                                "Instale: pip install python-docx")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar memoria de cálculo",
            os.path.expanduser("~\\Documents\\Memoria_Columnas.docx"),
            "Word (*.docx)",
        )
        if not path:
            return
        data = []
        for r in self._results:
            env = r.get("envelope")
            # Renderizar figuras para este miembro
            figures = _render_member_figures(r)
            data.append({
                "member_id":    r.get("member_id", ""),
                "column_type":  r.get("column_type_label", ""),
                "section_info": r.get("section_info", ""),
                "design_result": env,
                "memo": env.memo if env else "",
                "figures": figures,
            })
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Generando memoria Word…"):
            ok, msg = export_word(data, path, "Proyecto",
                               "N.A.", self._cb_code.currentText())
        if ok:
            QMessageBox.information(self, "Exportado", msg)
        else:
            QMessageBox.critical(self, "Error", msg)

    # ── Utilidades ────────────────────────────────────────────────────────────

    def _status(self, msg: str):
        self._sb.showMessage(msg)


# ── Renderizado de figuras para Word ────────────────────────────────────────────

def _render_member_figures(r: dict) -> list:
    """
    Renderiza los diagramas de un miembro como PNG (bytes) para embeber en Word.
    Devuelve lista de (caption, png_bytes).
    """
    import io as _io
    figures = []

    try:
        import matplotlib
        matplotlib.use("Agg")   # off-screen backend
        import matplotlib.pyplot as plt
        import numpy as np

        surf = r.get("surface")
        surf_nom = r.get("surface_nominal")
        demands  = r.get("demands", [])   # [(Pu, Mux, Muy, label), ...]
        mid = r.get("member_id", "")

        # ── Diagrama de interacción 3D ───────────────────────────────────────
        if surf is not None:
            P_arr, My_arr, Mz_arr = surf
            fig3d = plt.figure(figsize=(10, 7))
            ax3d  = fig3d.add_subplot(111, projection="3d")
            ax3d.set_title(f"Superficie P-Mx-My (φ) — Miembro {mid}", fontsize=10)
            ax3d.set_xlabel("Mx (ton·m)"); ax3d.set_ylabel("My (ton·m)")
            ax3d.set_zlabel("P (ton)")
            # Superficie de diseño (φ)
            try:
                ax3d.plot_surface(My_arr, Mz_arr, P_arr,
                                  alpha=0.30, color="#2874A6", label="Diseño φ")
            except Exception:
                ax3d.scatter(My_arr.ravel(), Mz_arr.ravel(), P_arr.ravel(),
                             s=1, alpha=0.2, color="#2874A6")
            # Superficie nominal
            if surf_nom is not None:
                Pn, Myn, Mzn = surf_nom
                try:
                    ax3d.plot_surface(Myn, Mzn, Pn,
                                      alpha=0.12, color="#839192", label="Nominal")
                except Exception:
                    pass
            # Demandas
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax3d.scatter([Mux], [Muy], [Pu], s=30, color=clr, zorder=10)
            buf3d = _io.BytesIO()
            fig3d.tight_layout()
            fig3d.savefig(buf3d, format="png", dpi=120)
            plt.close(fig3d)
            figures.append(("Diagrama de interacción 3D P-Mx-My (φ y nominal)", buf3d.getvalue()))

        # ── Diagrama 2D P-Mx ────────────────────────────────────────────────
        if surf is not None:
            # La superficie guardada va en los ejes del módulo:
            # (P, Mx sobre hc, My sobre bc), SRC y CFT por igual.
            P_arr, My_arr, Mz_arr = surf
            j_x = _columna_pura(My_arr, Mz_arr)   # Mux puro
            j90 = _columna_pura(Mz_arr, My_arr)   # Muy puro
            fig2, (ax_pmx, ax_pmy) = plt.subplots(1, 2, figsize=(12, 5))
            fig2.suptitle(f"Diagramas de interacción 2D — Miembro {mid}", fontsize=10)
            # P-Mx: ángulo 0° (puro Mux)
            ax_pmx.set_title("P vs Mux (flexión sobre hc)", fontsize=9)
            ax_pmx.set_xlabel("Mux (ton·m)"); ax_pmx.set_ylabel("P (ton)")
            ax_pmx.plot(My_arr[:, j_x], P_arr[:, j_x], "b-", lw=1.5, label="φ diseño")
            if surf_nom:
                Pn, Myn, Mzn = surf_nom
                ax_pmx.plot(Myn[:, j_x], Pn[:, j_x], "k--", lw=1, alpha=0.6, label="Nominal")
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax_pmx.scatter([Mux], [Pu], s=20, color=clr)
            ax_pmx.axhline(0, color="gray", lw=0.5)
            ax_pmx.legend(fontsize=7)

            # P-My: la columna de Muy puro
            ax_pmy.set_title("P vs Muy (flexión sobre bc)", fontsize=9)
            ax_pmy.set_xlabel("Muy (ton·m)"); ax_pmy.set_ylabel("P (ton)")
            ax_pmy.plot(Mz_arr[:, j90], P_arr[:, j90], "g-", lw=1.5, label="φ diseño")
            if surf_nom:
                Pn, Myn, Mzn = surf_nom
                ax_pmy.plot(Mzn[:, j90], Pn[:, j90], "k--", lw=1, alpha=0.6, label="Nominal")
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax_pmy.scatter([Muy], [Pu], s=20, color=clr)
            ax_pmy.axhline(0, color="gray", lw=0.5)
            ax_pmy.legend(fontsize=7)

            buf2d = _io.BytesIO()
            fig2.tight_layout()
            fig2.savefig(buf2d, format="png", dpi=120)
            plt.close(fig2)
            figures.append(("Diagramas de interacción 2D P-Mux y P-Muy", buf2d.getvalue()))

        # ── Diagrama esfuerzo-deformación más desfavorable ─────────────────
        ss_diagrams = r.get("ss_diagrams", [])
        all_res     = r.get("all_results", [])
        if ss_diagrams and all_res:
            try:
                worst_idx = max(range(len(all_res)), key=lambda i: all_res[i].PR_max)
                if worst_idx < len(ss_diagrams):
                    ss = ss_diagrams[worst_idx]
                    fibers = ss.get("fibers", [])
                    if fibers:
                        fig_ss = _render_ss_figure(ss, mid)
                        if fig_ss is not None:
                            buf_ss = _io.BytesIO()
                            fig_ss.tight_layout()
                            fig_ss.savefig(buf_ss, format="png", dpi=120)
                            plt.close(fig_ss)
                            lbl_ss = ss.get("label", f"LC-{worst_idx}")
                            figures.append((
                                f"Diagrama esfuerzo-deformación más desfavorable ({lbl_ss})",
                                buf_ss.getvalue()
                            ))
            except Exception:
                pass

    except Exception:
        import traceback; traceback.print_exc()

    return figures


def _render_ss_figure(ss: dict, mid):
    """Renderiza la figura de esfuerzo-deformación para el dict ss dado."""
    import math as _math
    import matplotlib.pyplot as plt
    import numpy as np

    fibers  = ss.get("fibers", [])
    if not fibers:
        return None
    c       = ss.get("c", 0)
    theta   = ss.get("theta_deg", 0)
    label   = ss.get("label", "")

    conc_f  = [f for f in fibers if f["type"] == "concreto"]
    rebar_f = [f for f in fibers if f["type"] == "refuerzo"]
    steel_f = [f for f in fibers if f["type"] == "perfil"]

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(12, 4))
    fig.suptitle(f"Esfuerzo-Deformación — Miembro {mid} — {label}  c={c:.1f}cm  θ={theta:.1f}°",
                 fontsize=9)

    all_sigma = [f["sigma"] for f in fibers if f["sigma"] != 0]
    sigma_abs = max(abs(s) for s in all_sigma) if all_sigma else 1.0

    # subplot 1: ε vs Y
    ax1.set_title("ε vs Y", fontsize=8)
    ax1.set_xlabel("ε", fontsize=7); ax1.set_ylabel("Y (cm)", fontsize=7)
    if conc_f:  ax1.scatter([f["eps"] for f in conc_f], [f["y"] for f in conc_f], s=3, c="lightblue", alpha=0.5)
    if rebar_f: ax1.scatter([f["eps"] for f in rebar_f], [f["y"] for f in rebar_f], s=25, c="red", zorder=5)
    if steel_f: ax1.scatter([f["eps"] for f in steel_f], [f["y"] for f in steel_f], s=12, c="steelblue", alpha=0.7)
    ax1.axvline(0, color="black", lw=0.8)
    ax1.tick_params(labelsize=6)

    # subplot 2: σ mapa
    ax2.set_title("σ en sección", fontsize=8)
    ax2.set_xlabel("Z (cm)", fontsize=7); ax2.set_ylabel("Y (cm)", fontsize=7)
    ax2.set_aspect("equal")
    if conc_f:
        sp = ax2.scatter([f["z"] for f in conc_f], [f["y"] for f in conc_f],
                         c=[f["sigma"] for f in conc_f], cmap="Blues", s=15,
                         vmin=0, vmax=sigma_abs, alpha=0.7)
    if rebar_f:
        ax2.scatter([f["z"] for f in rebar_f], [f["y"] for f in rebar_f],
                    c=[f["sigma"] for f in rebar_f], cmap="RdBu_r", s=50,
                    vmin=-sigma_abs, vmax=sigma_abs, edgecolors="black", lw=0.5, zorder=6)
    if steel_f:
        ax2.scatter([f["z"] for f in steel_f], [f["y"] for f in steel_f],
                    c=[f["sigma"] for f in steel_f], cmap="RdYlGn", s=20,
                    vmin=-sigma_abs, vmax=sigma_abs, alpha=0.8)
    theta_rad = _math.radians(theta)
    lim = max((abs(f["y"]) for f in fibers), default=1)
    cos_t = _math.cos(theta_rad); sin_t = _math.sin(theta_rad)
    if abs(sin_t) > 0.01:
        zn = np.linspace(-lim, lim, 10)
        yn = -cos_t / sin_t * zn
        ax2.plot(zn, yn, "k--", lw=0.8)
    else:
        ax2.axhline(0, color="k", lw=0.8, ls="--")
    ax2.tick_params(labelsize=6)

    # subplot 3: fuerzas resultantes
    ax3.set_title("Fuerza resultante (kg)", fontsize=8)
    forces_vals = [
        sum(f["F"] for f in conc_f),
        sum(f["F"] for f in rebar_f),
        sum(f["F"] for f in steel_f),
    ]
    bars = ax3.barh(["Concreto", "Refuerzo", "Perfil"], forces_vals,
                    color=["#2E86C1", "#E74C3C", "#1E8449"], alpha=0.8)
    ax3.axvline(0, color="black", lw=0.8)
    ax3.set_xlabel("F (kg)", fontsize=7)
    ax3.tick_params(labelsize=6)
    fabs = max((abs(v) for v in forces_vals), default=1)
    for bar, val in zip(bars, forces_vals):
        ax3.text(val + fabs * 0.02, bar.get_y() + bar.get_height() / 2,
                 f"{val:,.0f}", va="center", fontsize=6)

    return fig


# ── Motor de diseño (corre en worker thread) ──────────────────────────────────

def _run_design(params: dict, cache: dict, progress_cb) -> list:
    """
    Lógica principal de diseño para todas las barras.

    Convención de ejes STAAD → sección (medida el 03-oct-2026 contra
    «Cto.Control.std»: Iz = ZD·YD³/12 es la inercia mayor de una W, y
    dMz/dx = −Fy, dMy/dx = Fz a lo largo de la barra):
      · hc = dimensión en y local STAAD (YD, el peralte; el alma del perfil)
      · bc = dimensión en z local STAAD (ZD)
      · Fy (v[1]) → reader["Vuy"] = Vux sección, paralelo a hc
      · Fz (v[2]) → reader["Vuz"] = Vuy sección, paralelo a bc
      · Mz (v[5]) gira alrededor de z, flexiona SOBRE hc → reader["Muz"] = Mux
      · My (v[4]) gira alrededor de y, flexiona SOBRE bc → reader["Muy"] = Muy
      · Torsión = Mx (v[3]) → reader["Ttor"]
    Hasta el 03-oct-2026 Mux recibía My: el motor por ejes, EIeff/Pe (B1),
    K, CFT y la memoria leían el eje fuerte con el momento del débil. La
    superficie de fibras de SRC sí acertaba, porque su ángulo de demanda
    estaba cruzado en el mismo sentido; ahora las dos cosas van derechas.

    Cada nodo (inicial y final) de cada combinación genera un punto de demanda
    independiente en el diagrama de interacción.
    """
    import copy as _copy
    from design.composite_section import (
        ConcreteProps, SteelProps, RebarProps,
        EncasedSection, FilledSection,
    )
    from design.encased_column import EncasedColumnDesign, DesignForces
    from design.filled_column import FilledColumnDesign
    from design.fiber_model import (
        build_interaction_surface_3d, iterate_rebar,
        rebar_layout_4faces, _profile_fibers, strain_stress_diagram,
        check_demand_surface, check_demand_surface_detail,
    )
    from design.stirrup_design import design_stirrups, stirrup_memo as _stirrup_memo
    from design.connectors import (
        qn_stud, qn_channel, n_studs_required, n_channels_required,
        stud_layout, stud_layout_2d, connectors_memo,
    )

    col_type   = params["column_type"]
    member_ids = params["member_ids"]
    lc_ids     = params["lc_ids"]
    reader     = cache.get("reader")

    concrete  = ConcreteProps(params["fc"], params["Ec"], params["wc"],
                              code=params["code"])
    steel_mat = SteelProps(params["fy_s"], params["fu_s"])
    rebar_mat = RebarProps(params["fy_r"])
    prof_data = params["prof_data"]
    prof_name = params["prof_name"]
    code      = params["code"]

    results = []
    n_mem = len(member_ids)

    for i, mid in enumerate(member_ids):
        progress_cb(int(i / n_mem * 85), f"Diseñando miembro {mid} ({i+1}/{n_mem})…")

        # ── Longitud y K ────────────────────────────────────────────────
        L = params.get("L", 3.0)   # fallback 3.0 m cuando no hay STAAD
        if reader:
            try:
                Ls = reader.get_member_length(mid)
                if Ls > 0:
                    L = Ls
            except Exception:
                pass

        Kx, Ky = params["Kx"], params["Ky"]
        k_method = "Manual"
        k_detail = {}      # datos intermedios para el memo
        if params.get("auto_k") and reader:
            _pre = params.get("k_precomputed") or {}
            if mid in _pre:
                # K pre-calculado con el botón "Calcular K" (hilo principal,
                # sin el problema de afinidad COM del worker).
                Kx, Ky = _pre[mid]
                k_detail = dict((params.get("k_detail_pre") or {}).get(mid)
                                or {})
                k_method = "Automático (ábaco de alineación — pre-calculado)"
            else:
                try:
                    from design.k_chain import compute_k_pair_chained
                    _kb = cache.setdefault("k_beams", {})
                    _res = {}
                    _sx = params.get("k_sway_dirx", True)
                    _sz = params.get("k_sway_dirz", True)
                    compute_k_pair_chained(
                        reader, mid,
                        sway_y=_sz,
                        sway_z=_sx,
                        length_overrides=params.get("k_overrides") or {},
                        beams_out=_kb,
                        col_len_overrides=params.get("col_len") or {},
                        res_out=_res,
                    )
                    if not _res.get("ok"):
                        raise ValueError(_res.get("msg", "sin datos"))
                    k_detail = _k_detail_de(_res, sway_x=_sx, sway_y=_sz)
                    Kx, Ky = k_detail["Kx"], k_detail["Ky"]
                    k_method = "Automático (ábaco de alineación, columna física)"
                except Exception:
                    k_method = "Manual (fallo auto)"

        # Longitud por dirección. Con K automático, la de la columna FÍSICA
        # que acompaña a ese K (o la revisada a mano en «Longitud de
        # columnas…»): un K de la columna completa por la L de una barra no
        # es ninguna de las dos cosas (K-1). Sin K automático ni tabla
        # revisada, ambas direcciones usan la del segmento.
        _cl = (params.get("col_len") or {}).get(mid)
        if _cl:
            Lx_d, Ly_d = float(_cl[0]), float(_cl[1])
        elif k_detail.get("Lx", 0) > 0 and k_detail.get("Ly", 0) > 0:
            Lx_d, Ly_d = float(k_detail["Lx"]), float(k_detail["Ly"])
        else:
            Lx_d, Ly_d = L, L

        KLx = Kx * Lx_d
        KLy = Ky * Ly_d

        # ── Fuerzas STAAD por combinación (2 nodos) ──────────────────────
        if reader:
            forces_ini, forces_fin = reader.get_forces(mid, lc_ids)
        else:
            _zero = {"Pu": 0, "Vuy": 0, "Vuz": 0, "Ttor": 0, "Muy": 0, "Muz": 0}
            forces_ini = [dict(_zero) for _ in lc_ids]
            forces_fin = [dict(_zero) for _ in lc_ids]

        # ── Sección y motor ──────────────────────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            # Sección inicial con cuantía mínima
            As_initial = params["p_min"] * params["bc"] * params["hc"]
            sec = EncasedSection(
                bc=params["bc"], hc=params["hc"], cover=params["cover"],
                steel_profile=_copy.deepcopy(prof_data),
                ex=params["ex"], ey=params["ey"],
                concrete=_copy.deepcopy(concrete),
                steel=_copy.deepcopy(steel_mat),
                rebar=_copy.deepcopy(rebar_mat),
                n_bars=8,
                db=1.905,
                As_override=As_initial,
            )
            eng = EncasedColumnDesign(sec, code)
            section_label = "SRC (Encased)"
        else:
            sec = FilledSection(
                steel_profile=_copy.deepcopy(prof_data),
                concrete=_copy.deepcopy(concrete),
                steel=_copy.deepcopy(steel_mat),
            )
            eng = FilledColumnDesign(sec, code)
            section_label = "CFT (Filled)"

        phi_Pn = eng.phi_Pn(KLx, KLy)

        # ── Diseño por combinación — AMBOS NODOS como casos independientes ──
        # Convención: reader["Muz"] = Mz STAAD (v[5]) → Mux sección (sobre hc)
        #             reader["Muy"] = My STAAD (v[4]) → Muy sección (sobre bc)
        all_results = []
        so_max = None   # B1B2Result con la amplificación máxima (memoria)
        _g_ini = _g_fin = None
        if params.get("second_order") and params.get("lc_grav") and reader:
            try:
                _gi, _gf = reader.get_forces(mid, [params["lc_grav"]])
                _g_ini = _gi[0] if _gi else None
                _g_fin = _gf[0] if _gf else None
            except Exception:
                _g_ini = _g_fin = None
        for lc, fi, ff in zip(lc_ids, forces_ini, forces_fin):
            for node_label, f in (("ini", fi), ("fin", ff)):
                Pu  = f["Pu"]
                Mux = f["Muz"]    # Mz STAAD → flexión sobre hc (eje fuerte)
                Muy = f["Muy"]    # My STAAD → flexión sobre bc (eje débil)

                # ── 2° orden B1-B2 (AISC App.8 / DG6 2a ed) ──────────────
                if params.get("second_order", False):
                    from design.second_order_comp import amplify_b1b2
                    # K1 por dirección (NTC 3.7.2): K del análisis (≤1) si la
                    # dirección es contraventeada; 1.0 en otro caso.
                    _bx = params.get("arr_x", True)
                    _by = params.get("arr_y", True)
                    _K1x = min(Kx, 1.0) if _bx else 1.0
                    _K1y = min(Ky, 1.0) if _by else 1.0
                    _so = amplify_b1b2(
                        sec, Pu_ton=Pu, Mux_ton=Mux, Muy_ton=Muy,
                        L_m=L, K1x=_K1x, K1y=_K1y,
                        Mx_ini=fi["Muz"], Mx_fin=ff["Muz"],
                        My_ini=fi["Muy"], My_fin=ff["Muy"],
                        norma=params.get("code", "NTC"),
                        braced_x=params.get("arr_x", True),
                        braced_y=params.get("arr_y", True),
                        delta_s=params.get("delta_s", 1.0),
                        delta_s_x=params.get("delta_s_x"),
                        delta_s_y=params.get("delta_s_y"),
                        Mnt_x=((_g_ini if node_label == "ini" else _g_fin)
                               or {}).get("Muz") if _g_ini else None,
                        Mnt_y=((_g_ini if node_label == "ini" else _g_fin)
                               or {}).get("Muy") if _g_ini else None,
                    )
                    Mux, Muy = _so.Mux_amp, _so.Muy_amp
                    if (so_max is None or
                            max(_so.B1x, _so.B1y, _so.B2x, _so.B2y) >
                            max(so_max.B1x, so_max.B1y,
                                so_max.B2x, so_max.B2y)):
                        so_max = _so
                Vux = f["Vuy"]    # Vy STAAD → paralelo a hc
                Vuy = f["Vuz"]    # Vz STAAD → paralelo a bc
                Tu  = f["Ttor"]

                forces = DesignForces(
                    Pu=Pu, Mux=Mux, Muy=Muy,
                    Vux=Vux, Vuy=Vuy, Tu=Tu,
                    lc=lc, label=f"LC{lc}-{node_label}",
                )
                dr = eng.design(forces, KLx, KLy)
                all_results.append(dr)

        # ── Envolvente H1-1 (temporal, antes de fibras) ──────────────────
        envelope = max(all_results, key=lambda x: x.PR_max)

        # ── χ (NTC DEA 10.3.2.1.b-c): reducción por pandeo del punto de
        # compresión pura de la superficie de fibras (gobierna la dirección
        # de mayor esbeltez). Se calcula una sola vez con la sección actual
        # y se reutiliza en las superficies preliminar, final y nominal.
        chi_enc = 1.0
        if col_type == COLUMN_TYPE_ENCASED:
            chi_enc_x, _ = sec.chi(KLx, "x")
            chi_enc_y, _ = sec.chi(KLy, "y")
            chi_enc = min(chi_enc_x, chi_enc_y)

        # ── PASO 1: Superficie preliminar con p_min para hallar combinación crítica real ──
        surf = None; surf_nominal = None
        rebar_result = None
        rebar_fibers = []
        if col_type == COLUMN_TYPE_ENCASED:
            try:
                progress_cb(
                    int(i / n_mem * 85) + 3,
                    f"Superficie preliminar miembro {mid}…",
                )
                As_prelim = params["p_min"] * params["bc"] * params["hc"]
                rf_prelim = rebar_layout_4faces(
                    params["bc"], params["hc"], params["cover"], As_prelim,
                )
                P_prelim, My_prelim, Mz_prelim = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rf_prelim, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=0.90, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=0.75,
                )
                # Encontrar verdadera combinación crítica (mayor ratio de fibras)
                Pu_crit = envelope.Pu; Mux_crit = envelope.Mux; Muy_crit = envelope.Muy
                max_fr  = 0.0
                for lc_t, fi_t, ff_t in zip(lc_ids, forces_ini, forces_fin):
                    for f_t in (fi_t, ff_t):
                        det_t = check_demand_surface_detail(
                            P_prelim, My_prelim, Mz_prelim,
                            f_t["Pu"], f_t["Muz"], f_t["Muy"],
                        )
                        if det_t["ratio"] > max_fr:
                            max_fr    = det_t["ratio"]
                            Pu_crit   = f_t["Pu"]
                            Mux_crit  = f_t["Muz"]   # Mz STAAD → sobre hc
                            Muy_crit  = f_t["Muy"]   # My STAAD → sobre bc
            except Exception:
                import traceback; traceback.print_exc()
                Pu_crit = envelope.Pu; Mux_crit = envelope.Mux; Muy_crit = envelope.Muy

            # ── PASO 2: Iterar cuantía con las fuerzas críticas reales ──────
            progress_cb(
                int(i / n_mem * 85) + 6,
                f"Iterando cuantía miembro {mid}…",
            )
            rebar_result = iterate_rebar(
                bc=params["bc"], hc=params["hc"], fc=params["fc"],
                steel_profile=prof_data, fy_s=params["fy_s"],
                fy_r=params["fy_r"], cover=params["cover"],
                # Ejes de las fibras: My_fib flexiona sobre bc (= Muy) y
                # Mz_fib sobre hc (= Mux).
                Pu_ton=Pu_crit, My_ton_m=Muy_crit, Mz_ton_m=Mux_crit,
                ex=params["ex"], ey=params["ey"],
                p_min=params["p_min"], p_max=params["p_max"],
            )
            rebar_fibers = rebar_result["rebar_fibers"]
            sec.As_override = rebar_result["As"]
            sec.n_bars      = len(rebar_fibers)

        # ── PASO 3: Superficie final con cuantía iterada ─────────────────
        try:
            progress_cb(
                int(i / n_mem * 85) + 10,
                f"Superficie final miembro {mid}…",
            )
            if not rebar_fibers and col_type == COLUMN_TYPE_ENCASED:
                As_fb = params["p_min"] * params["bc"] * params["hc"]
                rebar_fibers = rebar_layout_4faces(
                    params["bc"], params["hc"], params["cover"], As_fb,
                )

            if col_type == COLUMN_TYPE_ENCASED:
                P_arr, My_arr, Mz_arr = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=0.90, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=0.75,
                )
                surf = (P_arr, My_arr, Mz_arr)
                # Superficie nominal: sin FR (fr=1.00 y fr_axial=1.00), pero
                # SÍ con χ — el pandeo es un efecto físico, no un margen de
                # seguridad, y debe verse también en la curva nominal.
                P_n, My_n, Mz_n = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=1.00, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=1.00,
                )
                surf_nominal = (P_n, My_n, Mz_n)
            else:
                from design.interaction_surface import build_3d_surface
                surf = build_3d_surface(sec, KLx, KLy, n_angles=72, n_pts_per_curve=40)
                surf_nominal = surf
        except Exception as _exc:
            import traceback; traceback.print_exc()

        # ── Construir texto de K para insertar en el memo ────────────────
        k_memo_txt = _k_memo_text(L, Kx, Ky, KLx, KLy, k_method, k_detail,
                                  Lx=Lx_d, Ly=Ly_d, code=code)
        # Insertar en cada DesignResult (memo individual)
        all_results = [
            dr._replace(memo=_memo_ejes() + "\n\n" + k_memo_txt
                        + "\n\n" + dr.memo)
            for dr in all_results
        ]
        envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Recalcular ratios con la superficie de fibras (consistencia) ─
        # También actualiza el texto del memo para que no muestre H1-1 incorrecto.
        if surf is not None and col_type == COLUMN_TYPE_ENCASED:
            P_s, My_s, Mz_s = surf
            updated = []
            for dr in all_results:
                det = check_demand_surface_detail(
                    P_s, My_s, Mz_s, dr.Pu, dr.Mux, dr.Muy,
                )
                fiber_ratio = det["ratio"]
                max_r  = max(fiber_ratio, dr.PR_shear, dr.PR_tors)
                status = "OK" if max_r <= 1.0 else "NG"
                new_memo = _replace_interaction_memo(
                    dr.memo, fiber_ratio, dr.Pu, dr.Mux, dr.Muy,
                    det["M_cap"], det["M_demand"], det["theta_deg"], status,
                    code=code,
                )
                updated.append(dr._replace(
                    PR_comp=round(fiber_ratio, 4),
                    PR_max=round(max_r, 4),
                    status=status,
                    memo=new_memo,
                ))
            all_results = updated
            envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Diseño de estribos y agregar al memo de la envolvente ─────────
        stirrup_txt = ""
        if col_type == COLUMN_TYPE_ENCASED:
            env_for_stir = max(all_results, key=lambda x: x.PR_max)
            # Obtener las fuerzas de cortante/torsión de la envolvente
            env_forces_list = [
                (fi, ff)
                for lc, fi, ff in zip(lc_ids, forces_ini, forces_fin)
            ]
            # Peor Vuy, Vuz, Tu de todos los nodos y combinaciones
            # design_stirrups llama Vuy al cortante PARALELO A hc (Fy de
            # STAAD, d sobre hc, bw = bc) y Vuz al paralelo a bc (Fz). Hasta
            # el 03-oct-2026 se le pasaban cruzados.
            Vuy_max = max(
                (abs(f["Vuy"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            Vuz_max = max(
                (abs(f["Vuz"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            Tu_max  = max(
                (abs(f["Ttor"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            try:
                db_long_est = 1.905   # ø3/4" aprox. para longitud de barras
                if rebar_fibers:
                    import math as _m
                    As_1bar = (rebar_result["As"] / max(len(rebar_fibers), 1)
                               if rebar_result else 0)
                    db_long_est = max(
                        _m.sqrt(As_1bar / (_m.pi / 4)) if As_1bar > 0 else 1.905,
                        0.6,
                    )
                stir_res = design_stirrups(
                    fc=params["fc"], fy_r=params["fy_r"],
                    bc=params["bc"], hc=params["hc"],
                    cover=params["cover"], db_long=db_long_est,
                    Vuy=Vuy_max, Vuz=Vuz_max, Tu=Tu_max,
                    Pu=env_for_stir.Pu,
                    code=params.get("code", "NTC"),
                )
                stirrup_txt = _stirrup_memo(
                    stir_res, params["fc"], params["fy_r"],
                    params["bc"], params["hc"],
                    params["cover"], db_long_est, code=code,
                )
            except Exception as _se:
                stirrup_txt = f"\n[Error en diseño de estribos: {_se}]\n"

        # Agregar sección de estribos al memo de la envolvente
        if stirrup_txt:
            all_results = [
                dr._replace(memo=dr.memo + stirrup_txt) if dr.label == envelope.label
                else dr
                for dr in all_results
            ]
            envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Efectos de 2° orden (B1-B2) en la memoria de cálculo ──────────
        if so_max is not None:
            from design.second_order_comp import format_b1b2_memory
            _b12_txt = format_b1b2_memory(so_max)
            if _b12_txt:
                all_results = [
                    dr._replace(memo=dr.memo + "\n\n" + _b12_txt)
                    if dr.label == envelope.label else dr
                    for dr in all_results
                ]
                envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Demandas (puntos en el diagrama) — incluye ratio para colorear ─
        # dr.Pu usa convención negativo=compresión (DesignForces); las
        # superficies graficadas (build_interaction_surface_3d / build_3d_surface)
        # usan positivo=compresión → se invierte el signo solo para el punto
        # graficado (dr.Pu en sí no se modifica en otras tablas/labels).
        demands = [(-dr.Pu, dr.Mux, dr.Muy, dr.label, dr.PR_max) for dr in all_results]

        # ── Diagramas esfuerzo-deformación por combinación ───────────────
        ss_diagrams = []
        if col_type == COLUMN_TYPE_ENCASED and rebar_fibers:
            steel_fibers_ss = _profile_fibers(prof_data, 16)
            for dr in all_results:
                try:
                    ss = strain_stress_diagram(
                        bc=params["bc"], hc=params["hc"], fc=params["fc"],
                        rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                        steel_fibers=steel_fibers_ss, fy_s=params["fy_s"],  # ← fix
                        ex=params["ex"], ey=params["ey"],
                        Pu_ton=dr.Pu, My_ton_m=dr.Muy, Mz_ton_m=dr.Mux,
                    )
                    ss["label"] = dr.label
                    ss_diagrams.append(ss)
                except Exception as _e:
                    ss_diagrams.append({"label": dr.label, "fibers": [], "error": str(_e)})

        # ── Conectores de cortante (solo SRC) ────────────────────────────
        conn_memo_txt = ""
        n_conn = 0
        layout_2d = {}
        if col_type == COLUMN_TYPE_ENCASED:
            try:
                qn = qn_stud(
                    params["stud_d_cm"], params["stud_h_cm"],
                    params["fc"], concrete.Ec, 4_220.0,
                )
                n_conn = n_studs_required(
                    params["fy_s"], sec.Aa, params["fc"], sec.Ac, qn,
                )
                layout_2d = stud_layout_2d(
                    n_conn, L,
                    params["bc"], params["hc"],
                    params["stud_d_cm"],
                )
                conn_memo_txt = connectors_memo(
                    "SRC Encased",
                    n_conn, params["stud_d_cm"], params["stud_h_cm"],
                    qn, L,
                    params["fc"], concrete.Ec,
                    params["fy_s"], sec.Aa, sec.Ac,
                    ce_key=params.get("ce_key", "C100×8.1 (4\")"),
                    ce_lcc_cm=params.get("ce_lcc_cm", 20.0),
                    code=code,
                )
                # Distribución 2D pernos Nelson
                if layout_2d:
                    conn_memo_txt += "\n\nDISTRIBUCIÓN ÓPTIMA DE PERNOS NELSON (2D):\n"
                    for axis, lay_d in layout_2d.items():
                        conn_memo_txt += (
                            f"  Dir. {axis}: "
                            f"{lay_d['n_rows']} fila(s) × {lay_d['n_per_row']} pernos  "
                            f"s_long={lay_d['s_long_cm']:.1f} cm  "
                            f"s_transv={lay_d['s_transv_cm']:.1f} cm  "
                            f"{'Válido' if lay_d['valid'] else 'REVISAR'}\n"
                        )
            except Exception:
                pass

        # ── Vista de sección ─────────────────────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            n_bars_result = len(rebar_fibers) if rebar_fibers else 8
            As_result     = rebar_result["As"] if rebar_result else 0
            _prof_with_name = dict(prof_data)
            _prof_with_name.setdefault("name", prof_name)
            sec_view = {
                "column_type":    "encased",
                "bc":             params["bc"],
                "hc":             params["hc"],
                "cover":          params["cover"],
                "n_bars":         n_bars_result,
                "As_total":       As_result,
                "rebar_fibers":   rebar_fibers,   # [(y, z, A), ...]
                "ex":             params["ex"],
                "ey":             params["ey"],
                "prof_data":      _prof_with_name,
                "cover_ratio":    params["cover"] / params["hc"],
                "steel_w_ratio":  prof_data.get("bf", 20) / params["bc"],
                "steel_h_ratio":  prof_data.get("d",  30) / params["hc"],
            }
            rebar_info = (
                # El acero COLOCADO, no el pedido: `rebar_layout_4faces`
                # redondea a varilla comercial y la sección que se dibuja
                # al lado ya muestra las varillas de verdad.
                f"ρ={rebar_result['p_pct_colocado']:.2f}%  "
                f"As={rebar_result['As_colocado']:.2f} cm²"
                f"  ({rebar_result['status']})"
            ) if rebar_result else "—"
        else:
            D = prof_data.get("bf", prof_data.get("d", 20))
            t = prof_data.get("tf", prof_data.get("tw", 0.5))
            H_d = prof_data.get("d", D)
            sec_view = {
                "column_type":  "filled",
                "profile_type": prof_data.get("type", "HSS_RECT"),
                "prof_data":    prof_data,
                "b_ratio":      D / max(D, H_d),
                "t_ratio":      t / max(D, H_d),
                "inner_ratio":  (D / 2 - t) / (D / 2) if D > 0 else 0.85,
            }
            rebar_info = "—"

        # ── Texto de información de sección ──────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            sec_info = (
                f"Concreto: {params['bc']:.0f}×{params['hc']:.0f} cm  "
                f"fc'={params['fc']:.0f} kg/cm²\n"
                f"Perfil: {prof_name}  Fy={params['fy_s']:.0f} kg/cm²\n"
                f"Refuerzo (auto): {rebar_info}  fyr={params['fy_r']:.0f} kg/cm²\n"
                f"KLx={KLx:.2f} m  KLy={KLy:.2f} m\n"
                f"Conectores: {n_conn} pernos Nelson\n"
                f"Límites: {sec.valid_limits() or ['OK']}"
            )
        else:
            sec_info = (
                f"Perfil relleno: {prof_name}\n"
                f"fc'={params['fc']:.0f} kg/cm²  Fy={params['fy_s']:.0f} kg/cm²\n"
                f"KLx={KLx:.2f} m  KLy={KLy:.2f} m\n"
                f"Clasificación: {sec.section_class()}\n"
                f"Límites: {sec.valid_limits() or ['OK']}"
            )

        results.append({
            "member_id":         mid,
            "column_type_label": section_label,
            "profile_name":      prof_name,
            "L":  L, "Kx": Kx, "Ky": Ky, "KLx": KLx, "KLy": KLy,
            "second_order":      so_max,
            "k_method":          k_method,
            "section_info":      sec_info,
            "phi_Pn":            phi_Pn,
            "all_results":       all_results,
            "envelope":          envelope,
            "surface":           _surf_en_ejes_del_modulo(surf, col_type),
            "surface_nominal":   _surf_en_ejes_del_modulo(surf_nominal,
                                                          col_type),
            "demands":           demands,
            "section_view_data": sec_view,
            "connectors_memo":   conn_memo_txt,
            "ss_diagrams":       ss_diagrams,
            "rebar_result":      rebar_result,
            "memo":              envelope.memo,
        })

    progress_cb(100, "Diseño completado.")
    return results


# ── Helpers para el cálculo de K ─────────────────────────────────────────────

def _k_detail_de(res: dict, sway_x: bool = True,
                 sway_y: bool = True) -> dict:
    """Datos del K automático de la columna FÍSICA para el diseño y la memoria.

    `res` es el resultado de `design.k_chain.compute_k_factors_chained`, en
    sus ejes: Ky (eje débil) con la cadena de la dirección Z de la sección y
    Kz (eje fuerte) con la de la dirección X. En este módulo Kx = Kz de
    k_chain (Dir. X, sobre hc) y Ky = Ky (Dir. Z, sobre bc). Lx/Ly son las
    longitudes de la columna física que acompañan a cada K (KLx = Kx·Lx).
    Es el MISMO cálculo de G que la cadena (K-4): hasta el 21-oct-2026 aquí
    se rehacía G con todo lo que llegaba al nudo, columnas incluidas.
    """
    nz = res.get("nodos_z") or (None, None)
    ny = res.get("nodos_y") or (None, None)
    return {
        "Kx":   float(res.get("Kz", 1.0)),
        "Ky":   float(res.get("Ky", 1.0)),
        "GA_x": float(res.get("GA_x", 0.0)),
        "GB_x": float(res.get("GB_x", 0.0)),
        "GA_y": float(res.get("GA_y", 0.0)),
        "GB_y": float(res.get("GB_y", 0.0)),
        "Lx":   float(res.get("L_z", 0.0) or 0.0),
        "Ly":   float(res.get("L_y", 0.0) or 0.0),
        "segs_x": list(res.get("segs_z") or []),
        "segs_y": list(res.get("segs_y") or []),
        "nodos_x": tuple(nz), "nodos_y": tuple(ny),
        "n_start": nz[0], "n_end": nz[1],
        "sway": bool(sway_x), "sway_x": bool(sway_x),
        "sway_y": bool(sway_y),
        "ok":   bool(res.get("ok", False)),
    }


def _columna_pura(M_a, M_b) -> int:
    """La columna (ángulo) de la superficie donde el momento es puramente
    M_a positivo: la que más M_a junta con menos M_b.

    No se supone qué ángulo es cuál: la superficie de CFT tiene Mux puro en
    la columna 0 y la de SRC, por cómo barre las fibras, en π/2. Mirarlo en
    los datos sirve para las dos.
    """
    import numpy as np
    return int(np.argmax(np.sum(M_a, axis=0) - np.sum(np.abs(M_b), axis=0)))


def _surf_en_ejes_del_modulo(surf, col_type):
    """La superficie de SRC en los ejes del módulo: (P, Mx sobre hc, My sobre bc).

    `build_interaction_surface_3d` devuelve (P, My_fib, Mz_fib) en los ejes de
    las fibras —My_fib = Σ F·z flexiona sobre bc, Mz_fib = Σ F·y sobre hc—,
    mientras que la de CFT (`build_3d_surface`) ya sale como (P, Mx, My).
    Las revisiones usan la de fibras tal cual; lo que se GUARDA para las
    gráficas y la memoria va en un solo orden para los dos tipos.
    """
    if surf is None or col_type != COLUMN_TYPE_ENCASED:
        return surf
    P_arr, My_fib, Mz_fib = surf
    return (P_arr, Mz_fib, My_fib)


def _memo_ejes() -> str:
    """Convención de ejes STAAD → sección, para la memoria de cada barra."""
    SEP = "=" * 72
    return "\n".join([
        SEP,
        "CONVENCION DE EJES (STAAD -> seccion)",
        SEP,
        "  Ejes locales de la barra en STAAD (con su angulo beta): x a lo largo",
        "  del eje, y en el peralte (YD), z en el ancho (ZD).",
        "    hc = dimension en y local (YD, el alma del perfil)",
        "    bc = dimension en z local (ZD)",
        "    Mux = Mz de STAAD: gira alrededor de z, flexiona SOBRE hc",
        "          (eje fuerte del perfil; Ix = Iz = ZD*YD^3/12)",
        "    Muy = My de STAAD: gira alrededor de y, flexiona SOBRE bc",
        "    Vux = Fy (paralelo a hc)     Vuy = Fz (paralelo a bc)     Tu = Mx",
        "  Momento y cortante van en pareja: dMz/dx = -Fy y dMy/dx = Fz.",
        "  En el nodo final STAAD entrega la ACCION de extremo (los seis",
        "  componentes con signo contrario al diagrama interno); se invierten",
        "  My y Mz para que los dos extremos queden en la convencion del",
        "  diagrama, que es la que decide la curvatura del Cm.",
        "  Referencia: STAAD.Pro, sistema de coordenadas locales de miembros;",
        "  comprobado contra el modelo (GetBeamPropertyAll, GetMemberEndForces,",
        "  GetIntermediateMemberForcesAtDistance), 03-oct-2026.",
    ])


def _k_memo_text(L: float, Kx: float, Ky: float,
                 KLx: float, KLy: float,
                 k_method: str, k_detail: dict,
                 Lx: float | None = None, Ly: float | None = None,
                 code: str = "NTC") -> str:
    """Genera el texto de la sección 'FACTOR DE LONGITUD EFECTIVA' para la memoria.

    Lx/Ly son las longitudes de la columna FÍSICA por dirección (la cadena de
    barras hasta la trabe que restringe esa dirección, o la revisada a mano).
    Si no se indican, se usa L en ambas. Con K automático la memoria dice
    qué barras forman la columna, sus extremos A/B y su longitud (K-1).
    """
    import math
    Lx = L if Lx is None else Lx
    Ly = L if Ly is None else Ly
    # Con la NTC el ábaco es un préstamo marcado de AISC 360-22 App. 7.
    from design.norma import es_ntc
    _ap7 = ("tomado de AISC 360-22 App. 7" if es_ntc(code)
            else "AISC 360-22 App. 7")
    SEP = "=" * 72
    lines = [
        SEP,
        "FACTOR DE LONGITUD EFECTIVA K",
        f"  Método: {k_method}",
        f"  Longitud del segmento (STAAD)  L = {L:.3f} m",
    ]
    if abs(Lx - L) > 1e-4 or abs(Ly - L) > 1e-4:
        lines += [
            "  Columna modelada con varias barras — longitud de la columna",
            "  física, hasta la trabe que restringe cada dirección:",
            f"    L (Dir.X) = {Lx:.3f} m      L (Dir.Z) = {Ly:.3f} m",
        ]
    lines.append("")

    def _f(v):
        return f"{v:.3f}" if isinstance(v, (int, float)) else str(v)

    def _k_txt(GA, GB, sway):
        if not isinstance(GA, (int, float)) or not isinstance(GB, (int, float)):
            return None
        if sway:
            num = 1.6*GA*GB + 4*(GA+GB) + 7.5
            den = GA + GB + 7.5
            K = max(math.sqrt(num/den), 1.0) if den > 0 else 1.0
            return (f"√[(1.6·{GA:.3f}·{GB:.3f} + 4·({GA:.3f}+{GB:.3f}) + 7.5)"
                    f" / ({GA:.3f}+{GB:.3f}+7.5)] = √[{num:.3f} / {den:.3f}]"
                    f" = {K:.4f}")
        # Marco sin deriva: la MISMA aproximación racional que usa el cálculo
        # (`design.k_chain._compute_K_local`), acotada a 0.5 ≤ K ≤ 1.0. Hasta
        # el 21-oct-2026 la memoria imprimía otra fórmula,
        # √[(GA+1)(GB+1)/((GA+2)(GB+2))], que no es la del motor.
        num = 3*GA*GB + 1.4*(GA+GB) + 0.64
        den = 3*GA*GB + 2.0*(GA+GB) + 1.28
        K = min(max(num/den, 0.5), 1.0)
        return (f"[3·{GA:.3f}·{GB:.3f} + 1.4·({GA:.3f}+{GB:.3f}) + 0.64]"
                f" / [3·{GA:.3f}·{GB:.3f} + 2·({GA:.3f}+{GB:.3f}) + 1.28]"
                f" = {num:.3f} / {den:.3f} = {K:.4f}")

    if k_detail:
        sway_x = k_detail.get("sway_x", k_detail.get("sway", True))
        sway_y = k_detail.get("sway_y", k_detail.get("sway", True))
        lines += [
            f"  Factores de alineación ({_ap7}):",
            "    G = Σ(EI/L)_columnas / Σ(EI/L)_vigas  en cada extremo de la",
            "    columna física",
            "  Una columna partida en varias barras es UNA columna: los extremos",
            "  A y B y la longitud son los de su cadena en cada dirección (se",
            "  corta donde llega una trabe que restringe ESA dirección) y todas",
            "  sus barras reciben el mismo K. Las columnas que llegan al nudo",
            "  suman con la L de su propia columna física.",
            "  Inercia de cada trabe en el plano del marco:",
            "    I = Iz·cos²β + Iy·sin²β  (β de la trabe), repartida por",
            "    dirección con w = (u·e)², e = eje de la sección girado su β.",
            "  Una trabe con w < 0.10 no restringe esa dirección; sin trabes",
            "  G = 10; tope G = 10.",
            "",
        ]
        if sway_x or sway_y:
            lines += [
                f"  Marco con deriva libre (sway) — {_ap7}, Ec. (C-A-7-5):",
                "    K = √[(1.6·GA·GB + 4·(GA+GB) + 7.5) / (GA+GB+7.5)]",
            ]
        if not (sway_x and sway_y):
            lines += [
                f"  Marco sin deriva (braced) — aproximación del ábaco ({_ap7}):",
                "    K = [3·GA·GB + 1.4·(GA+GB) + 0.64] / [3·GA·GB + 2·(GA+GB) + 1.28]",
                "    con 0.5 ≤ K ≤ 1.0  (Dumonteil, 1992)",
            ]
        lines.append("")
        bloques = (
            ("X", "Kx", "flexión sobre hc, eje fuerte", "x",
             k_detail.get("GA_x", "—"), k_detail.get("GB_x", "—"), Lx, sway_x),
            ("Z", "Ky", "flexión sobre bc, eje débil", "y",
             k_detail.get("GA_y", "—"), k_detail.get("GB_y", "—"), Ly, sway_y),
        )
        for d, kn, desc, s, GA, GB, Ld, sway in bloques:
            lines.append(f"  Dirección {d} ({kn}, {desc}):")
            segs = k_detail.get(f"segs_{s}")
            nodos = k_detail.get(f"nodos_{s}") or (
                k_detail.get("n_start", "—"), k_detail.get("n_end", "—"))
            if segs:
                lines.append(
                    f"    Columna física: barras "
                    f"{' + '.join(str(b) for b in segs)} "
                    f"({len(segs)} barra(s))")
            lines.append(
                f"    Extremo A = nudo {nodos[0]}   extremo B = nudo "
                f"{nodos[1]}   L = {Ld:.3f} m")
            lines.append(f"    GA = {_f(GA)}   GB = {_f(GB)}   "
                         f"({'sway' if sway else 'braced'})")
            kt = _k_txt(GA, GB, sway)
            if kt:
                lines.append(f"    {kn} = {kt}")
            lines.append("")
    else:
        lines += [
            "  (Datos de conectividad no disponibles — se aplicó valor manual)",
        ]

    lines += [
        "",
        f"  Resultados:",
        f"    Kx = {Kx:.4f}   →   KLx = {Kx:.4f} × {Lx:.3f} = {KLx:.3f} m",
        f"    Ky = {Ky:.4f}   →   KLy = {Ky:.4f} × {Ly:.3f} = {KLy:.3f} m",
        SEP,
    ]
    return "\n".join(lines)


def _replace_interaction_memo(
    memo: str,
    fiber_ratio: float,
    Pu: float, Mux: float, Muy: float,
    M_cap: float, M_demand: float,
    theta_deg: float,
    status: str,
    code: str = "NTC",
) -> str:
    """
    Reemplaza la sección 'INTERACCIÓN FLEXOCOMPRESIÓN' del memo (generada con
    el método simplificado H1-1) por el resultado correcto del modelo de fibras 3D.
    """
    import math as _math
    from design.norma import es_ntc as _es_ntc
    tick = "✔ OK" if fiber_ratio <= 1.0 else "✘ NO CUMPLE"
    if M_demand < 1e-6:
        # Carga pura
        ratio_txt = (
            f"  Carga axial pura (|Mux|≈|Muy|≈0)\n"
            f"  Relación P = |Pu|/φPn_fibras = {fiber_ratio:.4f}   {tick}"
        )
    elif M_cap > 0:
        ratio_txt = (
            f"  θ demanda  = atan2(|Mux|,|Muy|) = atan2({abs(Mux):.3f},{abs(Muy):.3f})"
            f" = {theta_deg:.1f}°\n"
            f"  M_demanda  = √(Mux²+Muy²) = √({Mux**2:.3f}+{Muy**2:.3f})"
            f" = {M_demand:.4f} ton·m\n"
            f"  M_capacidad (superficie, P={Pu:.2f}t, θ={theta_deg:.1f}°)"
            f" = {M_cap:.4f} ton·m\n"
            f"  Relación PM = M_demanda / M_capacidad"
            f" = {M_demand:.4f} / {M_cap:.4f} = {fiber_ratio:.4f}   {tick}"
        )
    else:
        ratio_txt = (
            f"  Relación PM (fibras) = {fiber_ratio:.4f}   {tick}"
        )

    new_section = "\n".join([
        "INTERACCIÓN FLEXOCOMPRESIÓN — MODELO DE FIBRAS 3D",
        ("  (NTC DEA 2023 10.1.3.1.c y 10.3.5 / bloque equivalente de NTC DEC 2023)"
         if _es_ntc(code) else
         "  (AISC 360-22 I1.2b — compatibilidad de deformaciones / ACI 318-25 22.2)"),
        "  Método: compatibilidad de deformaciones, bloque de Whitney",
        "  Superficie: 72 ángulos × 40 profundidades de eje neutro",
        "  Contribuciones: concreto (C=0.85·fc'·β₁·c·b) + refuerzo 4 caras + perfil (fibras)",
        "",
        f"  Pu  = {Pu:+.3f} ton",
        f"  Mux = {Mux:+.3f} ton·m  (Mz STAAD → flexión sobre hc)",
        f"  Muy = {Muy:+.3f} ton·m  (My STAAD → flexión sobre bc)",
        "",
        ratio_txt,
    ])

    # Buscar y reemplazar el bloque INTERACCIÓN ... hasta CORTANTE
    start = "INTERACCIÓN FLEXOCOMPRESIÓN"
    end   = "\nCORTANTE"
    i0 = memo.find(start)
    if i0 == -1:
        updated = memo + "\n\n" + new_section
    else:
        i1 = memo.find(end, i0)
        if i1 == -1:
            updated = memo[:i0] + new_section
        else:
            updated = memo[:i0] + new_section + memo[i1:]

    # Actualizar también la línea RESULTADO GLOBAL al final del memo
    import re as _re
    def _fix_global(m):
        # fiber_ratio ya incluye solo PM; max_r viene del llamador → usamos fiber_ratio y PR_shear/PR_tors
        # Si el patrón encuentra el número, lo sustituimos por el ratio real
        return m.group(0)   # placeholder — sustituimos abajo con replace explícito

    # Reemplazar cualquier "RESULTADO GLOBAL: ratio_max = X.XXXX → ..."
    pat = _re.compile(
        r"RESULTADO GLOBAL: ratio_max\s*=\s*[\d.]+\s*→\s*[^\n]+",
        _re.IGNORECASE,
    )
    global_status = "OK" if fiber_ratio <= 1.0 else "NO CUMPLE"
    replacement   = f"RESULTADO GLOBAL: ratio_max = {fiber_ratio:.4f}   →  {global_status}"
    updated       = pat.sub(replacement, updated)

    return updated
