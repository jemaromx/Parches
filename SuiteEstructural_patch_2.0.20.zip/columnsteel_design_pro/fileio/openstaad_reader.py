# fileio/openstaad_reader.py
"""
Lector STAAD Pro para columnas y contravientos de acero.

Obtiene, en orden de prioridad:
  1. Nombre de perfil  → lookup en steel_db (propiedades completas)
  2. GetBeamPropertyAll → propiedades basicas; Zx/Zy/Cw estimados

Fuerzas en extremos (ini y fin) para cada combinacion de carga.
Unidades STAAD: kN / kN*m  →  internas: ton / ton*m  (/ 9.80665)

APIs utilizadas (openstaadpy / win32com.client):
  Geometry.GetBeamList()
  Geometry.GetBeamLength(beam)                        -> float (m)
  Geometry.GetMemberIncidence(beam, arr_int32[2])     -> llena arr con (n_ini, n_fin)
  Geometry.GetNoOfBeamsConnectedAtNode(node)          -> int
  Geometry.GetBeamsConnectedAtNode(node, arr_int32[n])-> llena arr con IDs de barras
  Property.GetBeamSectionName(beam)                   -> str  e.g. "W14X120"
  Property.GetBeamPropertyAll(beam)                   -> (ZD,YD,Ax,Ay,Az,IX=J,IY,IZ,tf,tw)
  #   raw[5] = IX  = J  (constante de torsion de St. Venant)
  #   raw[6] = IY       (inercia eje debil   Y)
  #   raw[7] = IZ       (inercia eje fuerte  Z)
  Output.AreResultsAvailable()                        -> bool
  Output.GetMemberEndForces(beam,end,lc,local)        -> [Fx,Fy,Fz,Mx,My,Mz] kN/kN*m
  Load.GetLoadCaseCount() / GetLoadCombinationCaseCount()
"""
from __future__ import annotations
import logging, re, math
from typing import Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger(__name__)

try:
    import openstaadpy          # noqa: F401
    _AVAIL = True
except Exception:
    _AVAIL = False

_KN = 1.0 / 9.80665            # kN -> ton  (OpenSTAAD siempre devuelve kN)

_ZERO = {
    "Pu": 0.0, "Vuy": 0.0, "Vuz": 0.0,
    "Ttor": 0.0, "Muy": 0.0, "Muz": 0.0,
}


class OpenSTAADReader:
    """Lee datos de seccion y fuerzas de columnas/contravientos de acero."""

    def __init__(self):
        self._staad   = None
        self._geo     = None
        self._out     = None
        self._prop    = None
        self._load    = None

        self._member_ids: List[int] = []
        self._load_cases: List[int] = []

        # Cache pre-cargado en hilo principal (COM thread-affinity)
        self._sec_cache:  Dict[int, dict] = {}
        self._fi_cache:   Dict[Tuple[int,int], dict] = {}   # (mid, lc) -> ini
        self._ff_cache:   Dict[Tuple[int,int], dict] = {}   # (mid, lc) -> fin
        self._prefetched  = False

        # Cache de conectividad: nodo -> lista de miembros que tocan ese nodo
        # Poblado por build_connectivity() y reutilizado en compute_k_factors_aisc
        self._node_map:    Dict[int, List[int]] = {}   # {nodo: [mid1, mid2, ...]}
        self._mem_nodes:   Dict[int, Tuple[int,int]] = {}  # {mid: (n_start, n_end)}
        # Cache ligero de rigidez: {mid: (Iy_cm4, Ix_cm4, L_m)}
        self._stiff_cache: Dict[int, Tuple[float,float,float]] = {}
        # Nombre de perfil de cada miembro (para reporte detallado)
        self._section_names: Dict[int, str] = {}

    # ── Conexion ──────────────────────────────────────────────────────────────

    def connect(self) -> Tuple[bool, str]:
        if not _AVAIL:
            return False, "openstaadpy no esta instalado."
        try:
            from openstaadpy import os_analytical
            self._staad = os_analytical.connect()
            self._geo   = self._staad.Geometry
            self._out   = self._staad.Output
            self._prop  = self._staad.Property
            try:
                self._load = self._staad.Load
            except Exception:
                self._load = None
        except Exception as exc:
            return False, f"No se pudo conectar a STAAD Pro: {exc}"

        try:
            if not self._out.AreResultsAvailable():
                return False, "El modelo no tiene resultados. Analice primero."
        except Exception:
            pass

        try:
            self._member_ids = [int(x) for x in self._geo.GetBeamList()]
        except Exception as exc:
            return False, f"Error leyendo lista de miembros: {exc}"

        self._load_cases = self._fetch_load_cases()
        n_mem = len(self._member_ids)
        n_lc  = len(self._load_cases)
        rng   = (f" ({self._load_cases[0]}-{self._load_cases[-1]})"
                 if n_lc else "")
        return True, f"{n_mem} miembros, {n_lc} combinaciones{rng}"

    @property
    def connected(self) -> bool:
        return self._staad is not None and self._geo is not None

    # ── Pre-carga (hilo principal, antes del QThread) ─────────────────────────

    def pre_fetch(self, member_ids: List[int], lc_ids: List[int]) -> None:
        """
        Extrae todos los datos COM en el hilo principal.
        Despues de llamar esto, get_section / get_forces leen solo de cache.
        """
        self._sec_cache = {}
        self._fi_cache  = {}
        self._ff_cache  = {}
        self._prefetched = False

        for mid in member_ids:
            self._sec_cache[mid] = self._read_section(mid)
            for lc in lc_ids:
                self._fi_cache[(mid, lc)] = self._end_forces(mid, 0, lc)
                self._ff_cache[(mid, lc)] = self._end_forces(mid, 1, lc)

        self._prefetched = True
        log.info("pre_fetch: %d miembros x %d combos", len(member_ids), len(lc_ids))

    def build_connectivity(self, progress_cb=None) -> Tuple[bool, str]:
        """
        Construye el mapa de conectividad (nodo→miembros) y el cache de
        rigideces (Iy, Ix, L) para TODOS los miembros del modelo.

        Debe llamarse desde el hilo principal (COM thread-affinity) antes
        de invocar compute_k_factors_aisc().

        progress_cb : callable(pct: int, msg: str) | None
        Retorna (ok, mensaje).
        """
        self._node_map      = {}
        self._mem_nodes     = {}
        self._stiff_cache   = {}
        self._section_names = {}

        total = len(self._member_ids)
        if total == 0:
            return False, "Sin miembros en el modelo."

        errors     = 0
        err_nodes  = 0   # miembros sin nodos leídos
        err_stiff  = 0   # miembros sin propiedades de rigidez

        # Log del método de incidencias que funciona (detectado en primer miembro)
        _inc_method_logged = False

        for i, mid in enumerate(self._member_ids):

            # ── 1. Incidencias (nodos extremos) con GetMemberIncidence ────────
            sn, en = self._get_member_nodes(mid)
            if sn is None:
                err_nodes += 1
                log.debug("build_connectivity: sin incidencias para mid=%d", mid)
            else:
                self._mem_nodes[mid] = (sn, en)
                self._node_map.setdefault(sn, []).append(mid)
                self._node_map.setdefault(en, []).append(mid)
                if not _inc_method_logged:
                    log.info("build_connectivity: incidencias OK para mid=%d "
                             "(sn=%d, en=%d)", mid, sn, en)
                    _inc_method_logged = True

            # ── 2. Nombre del perfil (para reporte) ───────────────────────────
            try:
                name = str(self._prop.GetBeamSectionName(mid)).strip()
                self._section_names[mid] = name if name else f"MBR-{mid}"
            except Exception:
                self._section_names[mid] = f"MBR-{mid}"

            # ── 3. Propiedades de rigidez ─────────────────────────────────────
            # GetBeamPropertyAll devuelve: (ZD, YD, Ax, Ay, Az, IX=J, IY, IZ, tf, tw)
            # Orden real confirmado con STAAD Pro 2024/2025:
            #   raw[5] = IX = J  (constante de torsion de St. Venant)
            #   raw[6] = IY      (inercia eje debil   — controla Ky)
            #   raw[7] = IZ      (inercia eje fuerte  — controla Kz)
            try:
                raw = self._prop.GetBeamPropertyAll(mid)
                L   = float(self._geo.GetBeamLength(mid))
                if raw and len(raw) >= 8:
                    Iy_m4 = float(raw[6])   # IY eje debil
                    Iz_m4 = float(raw[7])   # IZ eje fuerte
                    Iy_cm4 = Iy_m4 * 1e8
                    Iz_cm4 = Iz_m4 * 1e8
                    self._stiff_cache[mid] = (
                        max(Iy_cm4, 1.0),   # cm4 eje débil  (posicion 0)
                        max(Iz_cm4, 1.0),   # cm4 eje fuerte (posicion 1)
                        max(L, 0.001),      # m
                    )
                else:
                    err_stiff += 1
                    log.debug("build_connectivity: GetBeamPropertyAll incompleto mid=%d", mid)
            except Exception as exc:
                err_stiff += 1
                log.debug("build_connectivity: sin rigidez mid=%d -> %s", mid, exc)

            if progress_cb and i % 50 == 0:
                pct = int(i / total * 100)
                progress_cb(pct, f"Conectividad: {i+1}/{total} miembros...")

        errors = err_nodes + err_stiff

        n_nodes     = len(self._node_map)
        n_mem_nodes = len(self._mem_nodes)
        n_stiff     = len(self._stiff_cache)

        # Diagnóstico de miembros sin nodos (ayuda a depurar problemas de API)
        sin_nodos = [m for m in self._member_ids if m not in self._mem_nodes]
        if sin_nodos:
            log.warning(
                "build_connectivity: %d miembros sin incidencias (nodos no leidos): %s",
                len(sin_nodos),
                sin_nodos[:20],   # mostrar máximo 20 IDs
            )

        msg = (
            f"Conectividad lista: {total} miembros totales, "
            f"{n_mem_nodes} con nodos leidos, "
            f"{n_nodes} nodos unicos, "
            f"{n_stiff} perfiles con propiedades."
        )
        if sin_nodos:
            msg += (f" ATENCION: {len(sin_nodos)} miembros sin nodos "
                    f"({sin_nodos[:5]}{'...' if len(sin_nodos)>5 else ''}). "
                    f"Se usara K=1.0 para esos miembros. "
                    f"Verifique el archivo columnsteel.log para diagnostico.")
        if err_stiff:
            msg += f" {err_stiff} miembros sin propiedades de rigidez."

        log.info(msg)
        if progress_cb:
            progress_cb(100, msg)
        return True, msg

    # ── API publica ────────────────────────────────────────────────────────────

    def get_member_ids(self) -> List[int]:
        return sorted(self._member_ids)

    def get_load_cases(self) -> List[int]:
        return list(self._load_cases)

    def get_section(self, mid: int) -> dict:
        """
        Propiedades de la seccion de acero.
        Retorna dict con: profile_name, A, d, bf, tf, tw, Ix, Iy,
                          Sx, Sy, Zx, Zy, rx, ry, J, Cw, h, ho,
                          length_m, kind_str
        """
        if self._prefetched and mid in self._sec_cache:
            return dict(self._sec_cache[mid])
        return self._read_section(mid)

    def get_forces(self, mid: int,
                   lc_ids: List[int]) -> Tuple[List[dict], List[dict]]:
        """
        Retorna (fuerzas_ini, fuerzas_fin) alineadas con lc_ids.
        Cada dict: {Pu, Vuy, Vuz, Ttor, Muy, Muz}  [ton / ton*m]
        """
        if self._prefetched:
            ini = [dict(self._fi_cache.get((mid, lc), _ZERO)) for lc in lc_ids]
            fin = [dict(self._ff_cache.get((mid, lc), _ZERO)) for lc in lc_ids]
            return ini, fin
        if not self.connected:
            empty = [dict(_ZERO) for _ in lc_ids]
            return empty, empty
        ini = [self._end_forces(mid, 0, lc) for lc in lc_ids]
        fin = [self._end_forces(mid, 1, lc) for lc in lc_ids]
        return ini, fin

    def get_selected_members(self) -> List[int]:
        if not self.connected:
            return []
        geo = self._geo
        candidates = [
            (geo,         "GetSelectedBeamList"),
            (geo,         "GetSelectedBeams"),
            (geo,         "GetSelectedMemberList"),
            (geo,         "GetSelectedMembers"),
            (self._staad, "GetSelectedBeamList"),
            (self._staad, "GetSelectedBeams"),
        ]
        for obj, name in candidates:
            fn = getattr(obj, name, None)
            if fn is None:
                continue
            try:
                ids = [int(x) for x in fn() if x]
                if ids:
                    log.info("get_selected_members via '%s': %d", name, len(ids))
                    return ids
            except Exception as exc:
                log.debug("get_selected_members/%s: %s", name, exc)
        log.warning("get_selected_members: ningun metodo funciono.")
        return []

    def get_member_length(self, mid: int) -> float:
        """Longitud en metros."""
        sec = self.get_section(mid)
        return sec.get("length_m", 0.0)

    def compute_k_factors_aisc(self, mid: int,
                               sway_y: bool = True,
                               sway_z: bool = True) -> dict:
        """Ky y Kz de la columna física a la que pertenece `mid`.

        Delega en `design.k_chain.compute_k_factors_chained`: hay UN solo
        cálculo de G en el módulo (K-4 de HALLAZGOS_K_COLUMNAS_2026-10-21.md).
        Hasta el 21-oct-2026 este método tenía el suyo, que sumaba como trabe
        todo lo que llegaba al nudo —columnas incluidas—, sin β ni reparto
        por dirección, y daba G bajo: K del lado inseguro. Requiere
        `build_connectivity()`.
        """
        from design.k_chain import compute_k_factors_chained
        return compute_k_factors_chained(self, mid, sway_y=sway_y,
                                         sway_z=sway_z)

    def compute_k_factors(self, mid: int,
                           sway_y: bool = True,
                           sway_z: bool = True) -> tuple:
        """
        Compatibilidad: llama a compute_k_factors_aisc y retorna (Ky, Kz).
        Use compute_k_factors_aisc() para obtener también los valores G.
        Calcula K_y y K_z automaticamente usando el nomograma de alineacion.

        Metodo (AISC Appendix 7 / NTC Art.3.6.3):
          G = Sum(EI/L)_columna / Sum(EI/L)_vigas en cada extremo del miembro.

        FIX de seguridad (evita cierre de STAAD Pro):
          - Toda la función corre en try/except amplio.
          - _node_G usa el caché pre-cargado (_sec_cache) para evitar
            llamadas COM masivas durante el cálculo; si no hay caché,
            usa GetBeamLength + GetBeamPropertyAll con protección individual.
          - Se abandona si se detectan más de MAX_MEMBERS miembros (modelo grande).
          - Nunca propaga excepciones; retorna (1.0, 1.0) en cualquier error.

        Limitación: sin info de orientación de miembros, todos los conectados
        al nodo contribuyen como vigas. Funciona para marcos 2D o cuando las
        vigas tienen menor rigidez.

        Es el mismo cálculo que `design.k_chain` (columna física, trabes por
        dirección con su inercia de marco): no hay un segundo cálculo de G.

        Returns: (Ky, Kz)
        """
        r = self.compute_k_factors_aisc(mid, sway_y=sway_y, sway_z=sway_z)
        return r["Ky"], r["Kz"]

    # ── Lectura de nodos extremos ─────────────────────────────────────────────

    def _get_member_nodes(self, mid: int) -> Tuple:
        """
        Obtiene (n_start, n_end) del miembro usando GetMemberIncidence.

        Firma correcta (Bentley openstaadpy):
            start, end = staad_obj.Geometry.GetMemberIncidence(member_id)
            → retorna directamente dos enteros, SIN pasar array

        Fallback a GetMemberStartNode / GetMemberEndNode si falla.
        Retorna (sn, en) como enteros, o (None, None) si todos fallan.
        """
        geo  = self._geo
        root = self._staad

        # ── Método 1: GetMemberIncidence — firma Bentley (retorna 2 valores) ──
        for obj, method in [
            (geo,  "GetMemberIncidence"),
            (root, "GetMemberIncidence"),
            (geo,  "GetMemberIncidences"),
            (root, "GetMemberIncidences"),
        ]:
            fn = getattr(obj, method, None)
            if fn is None:
                continue
            try:
                sn, en = fn(mid)          # desempaquetado directo
                sn, en = int(sn), int(en)
                if sn > 0 and en > 0:
                    return sn, en
            except Exception as exc:
                log.debug("_get_member_nodes mid=%d via %s: %s", mid, method, exc)

        # ── Método 2: GetMemberStartNode / GetMemberEndNode (fallback) ────────
        for obj, m_start, m_end in [
            (geo,  "GetMemberStartNode", "GetMemberEndNode"),
            (root, "GetMemberStartNode", "GetMemberEndNode"),
            (geo,  "GetBeamStartNode",   "GetBeamEndNode"),
        ]:
            fn_s = getattr(obj, m_start, None)
            fn_e = getattr(obj, m_end,   None)
            if fn_s is None or fn_e is None:
                continue
            try:
                sn = int(fn_s(mid)); en = int(fn_e(mid))
                if sn > 0 and en > 0:
                    return sn, en
            except Exception as exc:
                log.debug("_get_member_nodes mid=%d via %s/%s: %s",
                          mid, m_start, m_end, exc)

        log.warning("_get_member_nodes mid=%d: ningun metodo funciono", mid)
        return None, None

    # ── Lectura de seccion ─────────────────────────────────────────────────────

    def _read_section(self, mid: int) -> dict:
        """
        Intenta, en orden:
          1. GetBeamSectionName -> lookup en steel_db
          2. GetBeamPropertyAll -> propiedades basicas + estimacion
        """
        length_m = 0.0
        try:
            length_m = float(self._geo.GetBeamLength(mid))
        except Exception:
            pass

        # Intento 1: nombre del perfil → steel_db
        sp_db = self._try_from_db(mid)
        if sp_db is not None:
            sp_db["length_m"] = length_m
            return sp_db

        # Intento 2: GetBeamPropertyAll
        sp_raw = self._try_from_prop_all(mid)
        sp_raw["length_m"] = length_m
        return sp_raw

    def _try_from_db(self, mid: int) -> Optional[dict]:
        """Lee GetBeamSectionName y busca en steel_db."""
        name = ""
        try:
            name = str(self._prop.GetBeamSectionName(mid)).strip()
        except Exception:
            return None
        if not name:
            return None

        try:
            from design.steel_db import get_section, STEEL_SECTIONS
        except ImportError:
            return None

        # Normalizar: "W 14 120" -> "W14X120"
        key = _normalize_section_name(name)
        data = get_section(key)
        if data is None:
            # Buscar sin 'X' (e.g. "W14120")
            for k in STEEL_SECTIONS:
                if k.replace("X","") == key.replace("X",""):
                    data = STEEL_SECTIONS[k]
                    key  = k
                    break
        if data is None:
            log.debug("Perfil '%s' (norm '%s') no en steel_db", name, key)
            return None

        from design.section_types import SectionKind
        kind = _detect_kind(key)
        sp = _db_to_dict(data, key, kind)
        sp["profile_name"] = key
        sp["kind_str"]     = kind.value
        log.info("Perfil '%s' cargado de steel_db", key)
        return sp

    def _try_from_prop_all(self, mid: int) -> dict:
        """
        Usa GetBeamPropertyAll para propiedades basicas.
        Devuelve dict con todo lo necesario para el diseno.

        Orden real de GetBeamPropertyAll (confirmado STAAD Pro 2024/2025):
          raw[0] = ZD  = bf   (ancho / espesor en Z)
          raw[1] = YD  = d    (peralte / espesor en Y)
          raw[2] = AX         (area total)
          raw[3] = AY         (area cortante en Y)
          raw[4] = AZ         (area cortante en Z)
          raw[5] = IX  = J    (constante de torsion St. Venant)
          raw[6] = IY         (inercia eje debil   Y)
          raw[7] = IZ         (inercia eje fuerte  Z)
          raw[8] = tf  (espesor de patin o YD_TOP)
          raw[9] = tw  (espesor de alma  o ZD_TOP)
        Unidades del modelo: m, m^2, m^4
        """
        try:
            raw = self._prop.GetBeamPropertyAll(mid)
        except Exception:
            raw = None

        # Unidades del modelo (m, m^2, m^4) -> cm, cm^2, cm^4
        if raw is not None and len(raw) >= 9:
            b  = float(raw[0]) * 100.0    # cm  ZD = bf
            d  = float(raw[1]) * 100.0    # cm  YD = d
            Ax = float(raw[2]) * 1.0e4    # cm^2
            Ay = float(raw[3]) * 1.0e4
            Az = float(raw[4]) * 1.0e4
            J  = float(raw[5]) * 1.0e8    # cm^4 — IX = J (torsion)
            Iy = float(raw[6]) * 1.0e8    # cm^4 — IY eje debil
            Iz = float(raw[7]) * 1.0e8    # cm^4 — IZ eje fuerte
            tf = float(raw[8]) * 100.0
            tw = float(raw[9]) * 100.0 if len(raw) >= 10 else (d - 2*tf) * 0.05
        else:
            b = 20.0; d = 40.0; Ax = 80.0
            Iz = 40000.0; Iy = 2000.0; J = 20.0; tf = 1.5; tw = 1.0
            Ay = Az = Ax * 0.5

        if d <= 0:
            d = 40.0
        if b <= 0:
            b = max(d * 0.4, 10.0)
        if Ax <= 0:
            Ax = 2 * b * tf + (d - 2*tf) * tw

        h  = max(d - 2.0 * tf, 1.0)
        ho = d - tf
        Sx = Iz / (d / 2.0) if d > 0 else 1.0
        Sy = Iy / (b / 2.0) if b > 0 else 1.0
        rx = math.sqrt(Iz / Ax) if Ax > 0 else 1.0
        ry = math.sqrt(Iy / Ax) if Ax > 0 else 1.0
        # Estimaciones conservadoras
        Zx = Sx * 1.12
        Zy = Sy * 1.50
        Cw = Iy * ho**2 / 4.0 if ho > 0 else 0.0

        try:
            name = str(self._prop.GetBeamSectionName(mid)).strip()
        except Exception:
            name = f"SEC-{mid}"

        from design.section_types import SectionKind
        kind = _detect_kind(name)

        return {
            "profile_name": name,
            "kind_str": kind.value,
            "d": d,  "bf": b,  "tf": tf,  "tw": tw,
            "A": Ax, "Ix": Iz, "Iy": Iy,
            "Sx": Sx, "Sy": Sy, "Zx": Zx, "Zy": Zy,
            "rx": rx, "ry": ry,
            "J": J,   "Cw": Cw,
            "h": h,   "ho": ho,
        }

    # ── Fuerzas ────────────────────────────────────────────────────────────────

    def _end_forces(self, mid: int, end: int, lc: int) -> dict:
        try:
            v = self._out.GetMemberEndForces(mid, end, lc, 0)
            if v is None or len(v) < 6:
                return dict(_ZERO)
            # Convencion STAAD Pro (fuerzas locales en extremo de miembro):
            #   end=0 (nodo inicial): Fx > 0 indica COMPRESION en el miembro
            #   end=1 (nodo final):   Fx < 0 indica COMPRESION en el miembro
            # Convencion interna del motor de diseno: Pu < 0 = compresion
            # Por tanto al nodo inicial se niega Pu para unificar signos.
            sign_pu = -1.0 if end == 0 else 1.0
            # Nodo FIN (end=1): la acción de extremo trae el momento con signo
            # OPUESTO al del nodo inicial. Se invierte para unificar el signo
            # entre extremos (correcto para M1/M2 del Cm; la revisión usa |M|).
            _msgn = -1.0 if end == 1 else 1.0
            return {
                "Pu":   float(v[0]) * _KN * sign_pu,
                "Vuy":  float(v[1]) * _KN,
                "Vuz":  float(v[2]) * _KN,
                "Ttor": float(v[3]) * _KN,
                "Muy":  float(v[4]) * _KN * _msgn,
                "Muz":  float(v[5]) * _KN * _msgn,
            }
        except Exception as exc:
            log.debug("GetMemberEndForces(%d,end=%d,lc=%d): %s", mid, end, lc, exc)
            return dict(_ZERO)

    # ── Combinaciones ──────────────────────────────────────────────────────────

    def _fetch_load_cases(self) -> List[int]:
        lcs: List[int] = []
        if self._load is None:
            return lcs
        # Primarios
        for cnt in ("GetLoadCaseCount","GetNumberOfLoadCases",
                    "GetNoOfPrimaryLoadCases","GetPrimaryLoadCaseCount"):
            try:
                n = int(getattr(self._load, cnt)())
                for i in range(n):
                    for id_fn in ("GetLoadCaseID","GetPrimaryLoadCaseID",
                                  "GetLoadCaseNumber"):
                        try:
                            lcs.append(int(getattr(self._load, id_fn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        # Combinaciones
        for cnt in ("GetLoadCombinationCount","GetLoadComboCount",
                    "GetNoOfLoadCombinations","GetCombinationCaseCount",
                    "GetLoadCombinationCaseCount"):
            try:
                n = int(getattr(self._load, cnt)())
                for i in range(n):
                    for id_fn in ("GetLoadCombinationID","GetLoadComboID",
                                  "GetCombinationCaseID",
                                  "GetLoadCombinationNumber"):
                        try:
                            lcs.append(int(getattr(self._load, id_fn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        return sorted(set(lcs))


# ── Utilidades ────────────────────────────────────────────────────────────────

def _normalize_section_name(name: str) -> str:
    """
    Normaliza nombres de seccion de STAAD a formato AISC.
    Ejemplos:
      "W 14 120"  -> "W14X120"
      "W14X120"   -> "W14X120"
      "C 10 20"   -> "C10X20"
    """
    s = name.strip().upper()
    # Si ya tiene X, solo quitar espacios
    if "X" in s:
        return re.sub(r"\s+", "", s)
    # Separar letras de numeros con X
    # "W14 120" -> W14X120,  "W 14 120" -> W14X120
    s = re.sub(r"\s+", " ", s)
    parts = s.split()
    if len(parts) == 3:
        return f"{parts[0]}{parts[1]}X{parts[2]}"
    if len(parts) == 2:
        # "W14 120"
        m = re.match(r"([A-Z]+)(\d+)", parts[0])
        if m:
            return f"{m.group(1)}{m.group(2)}X{parts[1]}"
        return f"{parts[0]}X{parts[1]}"
    return re.sub(r"\s+", "", s)


def _detect_kind(label: str):
    from design.section_types import _detect_kind as _dk
    return _dk(label)


def _db_to_dict(data: dict, name: str, kind) -> dict:
    """Convierte un registro de steel_db en el dict que usa el reader."""
    d   = data.get("d",  0.0)
    bf  = data.get("bf", 0.0)
    tf  = data.get("tf", 0.0)
    tw  = data.get("tw", 0.0)
    h   = max(d - 2.0 * tf, 1.0)
    ho  = d - tf
    return {
        "A":  data.get("A",  0.0),
        "d":  d,  "bf": bf, "tf": tf, "tw": tw,
        "Ix": data.get("Ix", 0.0),
        "Iy": data.get("Iy", 0.0),
        "Sx": data.get("Sx", 0.0),
        "Sy": data.get("Sy", 0.0),
        "Zx": data.get("Zx", 0.0),
        "Zy": data.get("Zy", 0.0),
        "rx": data.get("rx", 0.0),
        "ry": data.get("ry", 0.0),
        "J":  data.get("J",  0.0),
        "Cw": data.get("Cw", 0.0),
        "h":  h,
        "ho": ho,
        "kind_str": kind.value,
    }
