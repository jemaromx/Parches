"""
Panel izquierdo de entrada de datos — BeamDesignPro.

Contiene todos los controles de configuración:
  • Materiales (fc, fy, fy_s)
  • Recubrimientos (rec_flex, rec_comp, rec_lateral)
  • Ductilidad (Q = 2 / 3 / 4)
  • Código de diseño (NTC 2023 / ACI 318-25)
  • Factor λ (concreto ligero)
  • Toggle de torsión
  • Trabes seleccionadas en STAAD Pro (reemplaza Excel)
  • Rango de combinaciones de carga
  • Combinaciones gravitacionales (solo Q=3 ó Q=4)
  • Botón de conexión STAAD Pro
  • Opciones DXF (modo A/B, flex/cortante)
  • Botón Diseñar
"""
from __future__ import annotations

import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QGroupBox, QLabel, QPushButton, QLineEdit,
    QDoubleSpinBox, QSpinBox, QComboBox, QCheckBox,
    QFileDialog, QRadioButton, QButtonGroup, QSizePolicy,
    QFrame, QScrollArea
)
from PySide6.QtCore import Qt, Signal, Slot
from PySide6.QtGui import QFont, QIcon


class InputPanel(QWidget):
    """Panel izquierdo con todos los parámetros de diseño."""

    # Señales
    sig_connect_staad  = Signal()
    sig_run_design     = Signal(object)  # dict de parámetros (object evita conversión QVariant)
    sig_refresh_beams  = Signal()       # solicita leer trabes desde STAAD

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    # ── Construcción de la UI ─────────────────────────────────────────────────

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Scroll area — desplazamiento vertical siempre disponible,
        # horizontal aparece automáticamente si el panel se estrecha.
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)

        container = QWidget()
        # Ancho mínimo fijo: es el ancho que debe tener el contenido para que
        # todos los campos sean visibles sin recortes.  Cuando el panel se
        # estrecha por debajo de este valor, aparece la barra horizontal.
        container.setMinimumWidth(256)
        lay = QVBoxLayout(container)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        # Orden de secciones según flujo de trabajo del usuario
        lay.addWidget(self._grp_staad())
        lay.addWidget(self._grp_trabes())
        lay.addWidget(self._grp_combinaciones())
        self.grp_gravedad = self._grp_gravedad()
        lay.addWidget(self.grp_gravedad)
        lay.addWidget(self._grp_materiales())
        lay.addWidget(self._grp_codigo())
        lay.addWidget(self._grp_dxf())
        lay.addStretch()
        lay.addWidget(self._btn_run_widget())

        scroll.setWidget(container)
        outer.addWidget(scroll)

        self.setMinimumWidth(245)
        self.setMaximumWidth(278)

    # ── Grupos individuales ───────────────────────────────────────────────────

    def _grp_gravedad(self) -> QGroupBox:
        grp = QGroupBox("Combinaciones Gravitacionales (Vpr)")
        grp.setToolTip(
            "Requeridas para calcular el cortante probable Vpr\n"
            "en diseño por capacidad (Q = 3 ó Q = 4).\n"
            "Indique el número de combinación en STAAD Pro.")
        form = QFormLayout(grp)
        form.setSpacing(6)

        self.spn_comb_CM = QSpinBox()
        self.spn_comb_CM.setRange(1, 9999)
        self.spn_comb_CM.setValue(1)
        self.spn_comb_CM.setToolTip(
            "Número de la combinación de SOLO carga muerta factorizada\n"
            "Ejemplo NTC: 1.4 CM")

        self.spn_comb_CMCV = QSpinBox()
        self.spn_comb_CMCV.setRange(1, 9999)
        self.spn_comb_CMCV.setValue(2)
        self.spn_comb_CMCV.setToolTip(
            "Número de la combinación de carga muerta + viva factorizadas\n"
            "Ejemplo NTC: 1.2 CM + 1.6 CV")

        form.addRow("1.4 CM:", self.spn_comb_CM)
        form.addRow("1.2 CM + 1.6 CV:", self.spn_comb_CMCV)

        grp.setVisible(False)
        return grp

    def _grp_materiales(self) -> QGroupBox:
        grp = QGroupBox("Materiales")
        form = QFormLayout(grp)
        form.setSpacing(6)

        # f'c
        self.spn_fc = QDoubleSpinBox()
        self.spn_fc.setRange(140, 700)
        self.spn_fc.setValue(250)
        self.spn_fc.setSuffix(" kg/cm²")
        self.spn_fc.setDecimals(0)

        # fy longitudinal
        self.spn_fy = QDoubleSpinBox()
        self.spn_fy.setRange(2000, 8000)
        self.spn_fy.setValue(4200)
        self.spn_fy.setSuffix(" kg/cm²")
        self.spn_fy.setDecimals(0)

        # fy estribos
        self.spn_fys = QDoubleSpinBox()
        self.spn_fys.setRange(2000, 4200)
        self.spn_fys.setValue(4200)
        self.spn_fys.setSuffix(" kg/cm²")
        self.spn_fys.setDecimals(0)
        self.spn_fys.setToolTip("Máx 4 200 kg/cm² (NTC DEC §5.5 / ACI 20.2.2)")

        # Recubrimientos
        self.spn_rec_flex = QDoubleSpinBox()
        self.spn_rec_flex.setRange(2, 15)
        self.spn_rec_flex.setValue(5)          # default 5 cm
        self.spn_rec_flex.setSuffix(" cm")
        self.spn_rec_flex.setDecimals(1)
        self.spn_rec_flex.setToolTip("Recubrimiento al centroide del acero en tracción")

        self.spn_rec_comp = QDoubleSpinBox()
        self.spn_rec_comp.setRange(2, 15)
        self.spn_rec_comp.setValue(5)          # default 5 cm
        self.spn_rec_comp.setSuffix(" cm")
        self.spn_rec_comp.setDecimals(1)
        self.spn_rec_comp.setToolTip("Recubrimiento al centroide del acero en compresión")

        self.spn_rec_lat = QDoubleSpinBox()
        self.spn_rec_lat.setRange(2.0, 15.0)
        self.spn_rec_lat.setValue(3.0)         # default 3 cm
        self.spn_rec_lat.setSuffix(" cm")
        self.spn_rec_lat.setDecimals(1)
        self.spn_rec_lat.setToolTip(
            "Recubrimiento lateral al centroide del estribo\n"
            "Se usa para calcular Aoh en el diseño por torsión\n"
            "(ancho interior: bi = b − 2·rec_lateral)")

        form.addRow("f'c:", self.spn_fc)
        form.addRow("fy long.:", self.spn_fy)
        form.addRow("fy estr.:", self.spn_fys)
        form.addRow("Rec. tracc.:", self.spn_rec_flex)
        form.addRow("Rec. comp.:", self.spn_rec_comp)
        form.addRow("Rec. lat.:", self.spn_rec_lat)
        return grp

    def _grp_codigo(self) -> QGroupBox:
        grp = QGroupBox("Código y Parámetros")
        form = QFormLayout(grp)
        form.setSpacing(6)

        # Código
        self.cmb_codigo = QComboBox()
        self.cmb_codigo.addItems(["NTC 2023", "ACI 318-25"])
        self.cmb_codigo.setToolTip("Código de diseño principal")

        # Q ductilidad
        self.cmb_Q = QComboBox()
        self.cmb_Q.addItems(["Q = 2  (Baja)", "Q = 3  (Media)", "Q = 4  (Alta)"])
        self.cmb_Q.setToolTip(
            "Factor de ductilidad de la estructura (NTC DEC 2024)\n"
            "Q=2 → Ductilidad baja   · FR_falla = 0.90\n"
            "Q=3 → Ductilidad media  · FR_falla = 0.75  · diseño por capacidad\n"
            "Q=4 → Ductilidad alta   · FR_falla = 0.75  · diseño por capacidad\n"
            "(Solo aplica NTC 2023)")

        # Lambda
        self.spn_lambda = QDoubleSpinBox()
        self.spn_lambda.setRange(0.75, 1.0)
        self.spn_lambda.setValue(1.0)
        self.spn_lambda.setSingleStep(0.05)
        self.spn_lambda.setDecimals(2)
        self.spn_lambda.setToolTip("Factor λ concreto ligero\n"
                                    "Concreto normal λ=1.0\n"
                                    "Concreto ligero λ=0.75")

        # Torsión
        self.chk_torsion = QCheckBox("Diseño por torsión")
        self.chk_torsion.setChecked(True)
        self.chk_torsion.setToolTip("Habilita el diseño por torsión (NTC DEC §5.8 / ACI §22.7)")

        # Diagramas 2D en memoria Word
        self.chk_diagramas_2d = QCheckBox("Diagramas 2D en memoria Word")
        self.chk_diagramas_2d.setChecked(True)
        self.chk_diagramas_2d.setToolTip(
            "Incluir diagramas de sección transversal con el refuerzo propuesto\n"
            "en la memoria de cálculo Word (Inicio / Mitad / Fin por barra).\n"
            "Requiere matplotlib instalado.")

        # Tipo de marco ACI (visible solo con ACI 318-25)
        self.cmb_frame_type = QComboBox()
        self.cmb_frame_type.addItems([
            "OMF  (Ordinario)",
            "IMF  (Ductilidad media)",
            "SMF  (Ductilidad alta / Especial)",
        ])
        self.cmb_frame_type.setToolTip(
            "Tipo de marco sismorresistente — ACI 318-25 §18\n"
            "OMF → Ordinary Moment Frame  (sin requisitos §18)\n"
            "IMF → Intermediate Moment Frame  §18.4\n"
            "     Confinamiento 2h; S ≤ mín(d/4, 300 mm)\n"
            "SMF → Special Moment Frame  §18.6\n"
            "     Confinamiento máx(2h, 450 mm); S ≤ mín(d/4, 150 mm)\n"
            "     Cortante Ve por capacidad (Mpr con 1.25fy)")
        self.cmb_frame_type.setVisible(False)

        form.addRow("Código:", self.cmb_codigo)
        form.addRow("Q (ductilidad):", self.cmb_Q)
        self._row_frame_type = ("Tipo de marco:", self.cmb_frame_type)
        form.addRow("Tipo de marco:", self.cmb_frame_type)
        form.addRow("λ (concreto):", self.spn_lambda)
        form.addRow("", self.chk_torsion)
        form.addRow("", self.chk_diagramas_2d)

        # Señales de visibilidad
        self.cmb_codigo.currentTextChanged.connect(self._on_codigo_changed)
        self.cmb_Q.currentIndexChanged.connect(self._on_Q_changed)
        self.cmb_frame_type.currentIndexChanged.connect(self._on_frame_type_changed)
        return grp

    def _grp_trabes(self) -> QGroupBox:
        grp = QGroupBox("Trabes a Diseñar")
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        # Contador de trabes cargadas desde STAAD
        self.lbl_beam_count = QLabel("Sin trabes cargadas")
        self.lbl_beam_count.setAlignment(Qt.AlignCenter)
        self.lbl_beam_count.setStyleSheet(
            "color: #7F8C8D; font-size: 8pt; padding: 4px;")
        lay.addWidget(self.lbl_beam_count)

        # Botón para leer la selección activa en STAAD Pro
        self.btn_refresh_beams = QPushButton("↻  Actualizar selección")
        self.btn_refresh_beams.setToolTip(
            "Lee las trabes actualmente seleccionadas en el modelo de STAAD Pro\n"
            "(requiere conexión activa con STAAD Pro)")
        self.btn_refresh_beams.clicked.connect(self.sig_refresh_beams)
        lay.addWidget(self.btn_refresh_beams)

        # Separador
        sep1 = QFrame()
        sep1.setFrameShape(QFrame.HLine)
        sep1.setStyleSheet("color: #AED6F1;")
        lay.addWidget(sep1)

        # IDs manuales (respaldo cuando la selección automática no funciona)
        lbl_manual = QLabel("IDs manuales (respaldo):")
        lbl_manual.setStyleSheet("font-size: 8pt;")
        lbl_manual.setToolTip(
            "Si 'Actualizar selección' no detecta las trabes automáticamente,\n"
            "escriba aquí los números de barra separados por coma.\n"
            "Ejemplos:  59, 87, 88, 90-94, 100")
        lay.addWidget(lbl_manual)

        self.txt_manual_ids = QLineEdit()
        self.txt_manual_ids.setPlaceholderText("Ej: 59, 87, 88, 90-94, 100")
        self.txt_manual_ids.setToolTip(
            "Números de barra separados por coma.\n"
            "Se admiten rangos: 90-94 equivale a 90, 91, 92, 93, 94.\n"
            "Presione '↻ Actualizar selección' después de editar.")
        lay.addWidget(self.txt_manual_ids)

        return grp

    def _grp_combinaciones(self) -> QGroupBox:
        grp  = QGroupBox("Combinaciones de Carga")
        form = QFormLayout(grp)
        form.setSpacing(6)

        self.spn_comb_ini = QSpinBox()
        self.spn_comb_ini.setRange(1, 9999)
        self.spn_comb_ini.setValue(1)
        self.spn_comb_ini.setToolTip("Número de la primera combinación de carga")

        self.spn_comb_fin = QSpinBox()
        self.spn_comb_fin.setRange(1, 9999)
        self.spn_comb_fin.setValue(10)
        self.spn_comb_fin.setToolTip("Número de la última combinación de carga")

        form.addRow("Desde:", self.spn_comb_ini)
        form.addRow("Hasta:", self.spn_comb_fin)
        return grp

    def _grp_staad(self) -> QGroupBox:
        grp = QGroupBox("STAAD Pro 2025")
        lay  = QVBoxLayout(grp)
        lay.setSpacing(6)

        self.lbl_staad_status = QLabel("Sin conexión")
        self.lbl_staad_status.setStyleSheet("color: #E74C3C; font-weight: bold;")
        self.lbl_staad_status.setAlignment(Qt.AlignCenter)

        self.btn_connect = QPushButton("Conectar a STAAD Pro")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.setToolTip("Establece conexión con STAAD Pro 2025 abierto\n"
                                     "(requiere ejecutar como Administrador)")
        self.btn_connect.clicked.connect(self.sig_connect_staad)

        lay.addWidget(self.lbl_staad_status)
        lay.addWidget(self.btn_connect)
        return grp

    def _grp_dxf(self) -> QGroupBox:
        grp = QGroupBox("Actualización DXF")
        lay  = QVBoxLayout(grp)
        lay.setSpacing(6)

        # ── Explicación breve ─────────────────────────────────────────────────
        nota = QLabel(
            "4 archivos DXF con textos 'N/N' junto a\n"
            "cada línea de trabe. El programa actualiza\n"
            "los textos y reduce las líneas.")
        nota.setStyleSheet("color: #5D6D7E; font-size: 7.5pt;")
        nota.setWordWrap(True)
        lay.addWidget(nota)

        sep0 = QFrame(); sep0.setFrameShape(QFrame.HLine)
        sep0.setStyleSheet("color: #AED6F1;"); lay.addWidget(sep0)

        # ── Modo A / B ────────────────────────────────────────────────────────
        lbl_modo = QLabel("Modo de etiquetado:")
        lbl_modo.setStyleSheet("font-weight: bold;")
        lay.addWidget(lbl_modo)

        self.rdo_modo_A = QRadioButton("A — Máximos")
        self.rdo_modo_B = QRadioButton("B — Por sección")
        self.rdo_modo_A.setChecked(True)
        self.rdo_modo_A.setToolTip(
            "Modo A — Un único valor máximo por barra\n"
            "Ej: '12 / 12 (18.40 / 14.60)'")
        self.rdo_modo_B.setToolTip(
            "Modo B — Tres valores por barra (inicio–mitad–fin)\n"
            "Ej: '12/12 (18.40 – 12.00 – 16.80 / 14.60 – 9.80 – 13.20)'")
        self._bg_modo = QButtonGroup(self)
        self._bg_modo.addButton(self.rdo_modo_A)
        self._bg_modo.addButton(self.rdo_modo_B)
        lay.addWidget(self.rdo_modo_A)
        lay.addWidget(self.rdo_modo_B)

        # ── Reducción de líneas ───────────────────────────────────────────────
        sep1 = QFrame(); sep1.setFrameShape(QFrame.HLine)
        sep1.setStyleSheet("color: #AED6F1;"); lay.addWidget(sep1)

        form_red = QFormLayout()
        form_red.setSpacing(4)
        self.spn_reduc = QDoubleSpinBox()
        self.spn_reduc.setRange(0.0, 90.0)
        self.spn_reduc.setValue(20.0)          # default 20 % de reducción
        self.spn_reduc.setSuffix("  %")
        self.spn_reduc.setDecimals(0)
        self.spn_reduc.setToolTip(
            "Porcentaje de REDUCCIÓN de longitud de cada línea.\n"
            "20 % → la línea queda al 80 % de su longitud original,\n"
            "reducida simétricamente desde el punto medio.")
        form_red.addRow("% Reducción de Línea:", self.spn_reduc)
        lay.addLayout(form_red)

        # ── Rutas de los 4 archivos DXF ───────────────────────────────────────
        sep2 = QFrame(); sep2.setFrameShape(QFrame.HLine)
        sep2.setStyleSheet("color: #AED6F1;"); lay.addWidget(sep2)

        lbl_arch = QLabel("Archivos DXF:")
        lbl_arch.setStyleSheet("font-weight: bold; font-size: 8pt;")
        lay.addWidget(lbl_arch)

        self._dxf_edits: dict[str, QLineEdit]  = {}
        self._dxf_chks:  dict[str, QCheckBox] = {}

        _dxf_defs = [
            ("As",  "As  — Flexión", "Áreas de acero longitudinal (flexión + torsión)"),
            ("Avs", "Avs — Cortante", "Cuantía de acero transversal por cortante"),
        ]
        for key, label, tooltip in _dxf_defs:
            row_w = QWidget()
            row_h = QHBoxLayout(row_w)
            row_h.setContentsMargins(0, 0, 0, 0)
            row_h.setSpacing(3)

            # Casilla de selección
            chk = QCheckBox(label + ":")
            chk.setChecked(True)
            chk.setFixedWidth(66)
            chk.setStyleSheet("font-size: 8pt;")
            chk.setToolTip(f"Marcar para actualizar este archivo\n({tooltip})")
            self._dxf_chks[key] = chk

            txt = QLineEdit()
            txt.setPlaceholderText("Ruta …")
            txt.setReadOnly(True)
            txt.setToolTip(tooltip)
            txt.setStyleSheet("font-size: 7.5pt;")

            btn = QPushButton("…")
            btn.setFixedWidth(24)
            btn.setToolTip(f"Seleccionar {key}.dxf")
            btn.clicked.connect(
                lambda checked, k=key, t=txt: self._browse_dxf(k, t))

            chk.toggled.connect(txt.setEnabled)
            chk.toggled.connect(btn.setEnabled)

            row_h.addWidget(chk)
            row_h.addWidget(txt, 1)
            row_h.addWidget(btn)
            lay.addWidget(row_w)
            self._dxf_edits[key] = txt

        return grp

    def _btn_run_widget(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 4, 0, 0)

        self.btn_run = QPushButton("▶  DISEÑAR")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.setToolTip("Iniciar el diseño de trabes")
        self.btn_run.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_run.clicked.connect(self._on_run)
        lay.addWidget(self.btn_run)
        return w

    # ── Slots internos ────────────────────────────────────────────────────────

    def _browse_dxf(self, key: str, txt_widget: QLineEdit):
        """Abre diálogo para seleccionar un archivo DXF existente."""
        last = txt_widget.text() or os.path.expanduser("~")
        path, _ = QFileDialog.getOpenFileName(
            self, f"Seleccionar {key}.dxf", last,
            "DXF Files (*.dxf);;All Files (*)")
        if path:
            txt_widget.setText(path)
            txt_widget.setToolTip(path)

    def _on_codigo_changed(self, text: str):
        """Cambia visibilidad de controles según código seleccionado."""
        es_ntc = text.startswith("NTC")
        self.cmb_Q.setEnabled(es_ntc)
        self.cmb_frame_type.setVisible(not es_ntc)
        self._update_gravedad_visibility()

    def _on_Q_changed(self, _index: int = 0):
        """Muestra panel gravitacional para Q=3 ó Q=4 (NTC)."""
        self._update_gravedad_visibility()

    def _on_frame_type_changed(self, _index: int = 0):
        """Muestra panel gravitacional solo para SMF (ACI)."""
        self._update_gravedad_visibility()

    def _update_gravedad_visibility(self):
        """Lógica centralizada: muestra el panel gravitacional cuando se necesita Vg."""
        es_ntc = self.cmb_codigo.currentText().startswith("NTC")
        if es_ntc:
            self.grp_gravedad.setVisible(self._q_value() >= 3)
        else:
            # ACI: solo SMF necesita Vg para cálculo de Ve
            self.grp_gravedad.setVisible(self._frame_type_value() == "SMF")

    def _q_value(self) -> int:
        """Retorna el valor entero de Q según la selección del combo."""
        return [2, 3, 4][self.cmb_Q.currentIndex()]

    def _frame_type_value(self) -> str:
        """Retorna 'OMF', 'IMF' o 'SMF' según el combo de tipo de marco."""
        return ["OMF", "IMF", "SMF"][self.cmb_frame_type.currentIndex()]

    def _on_run(self):
        params = self.get_params()
        self.sig_run_design.emit(params)

    # ── API pública ───────────────────────────────────────────────────────────

    def get_params(self) -> dict:
        """Retorna un dict con todos los parámetros de la interfaz."""
        comb_ini = self.spn_comb_ini.value()
        comb_fin = self.spn_comb_fin.value()
        if comb_fin < comb_ini:
            comb_fin = comb_ini

        dxf_mode = "A" if self.rdo_modo_A.isChecked() else "B"

        return {
            # Materiales
            "fc":           self.spn_fc.value(),
            "fy":           self.spn_fy.value(),
            "fy_s":         min(self.spn_fys.value(), 4200.0),
            "rec_flex":     self.spn_rec_flex.value(),
            "rec_comp":     self.spn_rec_comp.value(),
            "rec_lateral":  self.spn_rec_lat.value(),
            # Código
            "codigo":       self.cmb_codigo.currentText(),
            "Q":            float(self._q_value()),
            "frame_type":   self._frame_type_value(),   # "OMF"|"IMF"|"SMF" (ACI)
            "lamda":        self.spn_lambda.value(),
            "diseno_torsion":  self.chk_torsion.isChecked(),
            "diagramas_2d":    self.chk_diagramas_2d.isChecked(),
            # Trabes — IDs manuales (respaldo si la selección automática falla)
            "manual_beam_ids": self.txt_manual_ids.text().strip(),
            # Combinaciones de diseño
            "comb_ids":     list(range(int(comb_ini), int(comb_fin) + 1)),
            # Combinaciones gravitacionales para Vpr (Q=3 ó Q=4)
            "comb_CM":      self.spn_comb_CM.value(),
            "comb_CMCV":    self.spn_comb_CMCV.value(),
            # DXF
            "dxf_mode":     dxf_mode,
            "dxf_reduc":    self.spn_reduc.value(),
            "dxf_paths": {
                key: edit.text()
                for key, edit in self._dxf_edits.items()
            },
            # Qué archivos DXF desea actualizar el usuario
            "dxf_activos": {
                key: chk.isChecked()
                for key, chk in self._dxf_chks.items()
            },
        }

    def set_staad_status(self, connected: bool, message: str = ""):
        """Actualiza la etiqueta de estado STAAD Pro."""
        if connected:
            self.lbl_staad_status.setText("✔  Conectado")
            self.lbl_staad_status.setStyleSheet("color: #1E8449; font-weight: bold;")
            self.btn_connect.setEnabled(False)
        else:
            txt = message or "Sin conexión"
            self.lbl_staad_status.setText(f"✗  {txt}")
            self.lbl_staad_status.setStyleSheet("color: #E74C3C; font-weight: bold;")
            self.btn_connect.setEnabled(True)

    def set_beam_count(self, n: int):
        """Actualiza el contador de trabes cargadas desde STAAD Pro."""
        if n == 0:
            self.lbl_beam_count.setText("Sin trabes cargadas")
            self.lbl_beam_count.setStyleSheet(
                "color: #7F8C8D; font-size: 8pt; padding: 4px;")
        else:
            self.lbl_beam_count.setText(f"✔  {n} trabe(s) cargada(s)")
            self.lbl_beam_count.setStyleSheet(
                "color: #1E8449; font-size: 8pt; font-weight: bold; padding: 4px;")

    def set_running(self, running: bool):
        """Bloquea/desbloquea controles durante el diseño."""
        self.btn_run.setEnabled(not running)
        self.btn_run.setText("⏳  Diseñando…" if running else "▶  DISEÑAR")

