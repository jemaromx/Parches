# ui/dialog_3pl.py — Diálogo de captura de dimensiones para sección armada
# de 3 placas (2 patines + alma), permitiendo patines asimétricos.
from __future__ import annotations
from PySide6.QtWidgets import (
    QDialog, QFormLayout, QVBoxLayout, QGroupBox, QDoubleSpinBox,
    QDialogButtonBox, QLabel
)


class Dialog3PL(QDialog):
    """
    Captura bf_top/tf_top, bf_bot/tf_bot, hw, tw para una sección armada
    de 3 placas. Permite patines de distinto ancho/espesor (asimétrica).
    """

    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Sección Armada — 3 Placas")
        v = QVBoxLayout(self)

        init = initial or {}

        grp_top = QGroupBox("Patín Superior")
        ft = QFormLayout(grp_top)
        self.dsb_bf_top = QDoubleSpinBox()
        self.dsb_bf_top.setRange(2, 200); self.dsb_bf_top.setSuffix(" cm")
        self.dsb_bf_top.setValue(init.get("bf_top", 20.0))
        self.dsb_tf_top = QDoubleSpinBox()
        self.dsb_tf_top.setRange(0.3, 10); self.dsb_tf_top.setDecimals(2); self.dsb_tf_top.setSuffix(" cm")
        self.dsb_tf_top.setValue(init.get("tf_top", 1.5))
        ft.addRow("Ancho bf:", self.dsb_bf_top)
        ft.addRow("Espesor tf:", self.dsb_tf_top)
        v.addWidget(grp_top)

        grp_bot = QGroupBox("Patín Inferior")
        fb = QFormLayout(grp_bot)
        self.dsb_bf_bot = QDoubleSpinBox()
        self.dsb_bf_bot.setRange(2, 200); self.dsb_bf_bot.setSuffix(" cm")
        self.dsb_bf_bot.setValue(init.get("bf_bot", 20.0))
        self.dsb_tf_bot = QDoubleSpinBox()
        self.dsb_tf_bot.setRange(0.3, 10); self.dsb_tf_bot.setDecimals(2); self.dsb_tf_bot.setSuffix(" cm")
        self.dsb_tf_bot.setValue(init.get("tf_bot", 1.5))
        fb.addRow("Ancho bf:", self.dsb_bf_bot)
        fb.addRow("Espesor tf:", self.dsb_tf_bot)
        v.addWidget(grp_bot)

        grp_web = QGroupBox("Alma")
        fw = QFormLayout(grp_web)
        self.dsb_hw = QDoubleSpinBox()
        self.dsb_hw.setRange(5, 400); self.dsb_hw.setSuffix(" cm")
        self.dsb_hw.setValue(init.get("hw", 30.0))
        self.dsb_tw = QDoubleSpinBox()
        self.dsb_tw.setRange(0.3, 10); self.dsb_tw.setDecimals(2); self.dsb_tw.setSuffix(" cm")
        self.dsb_tw.setValue(init.get("tw", 1.0))
        fw.addRow("Altura libre hw:", self.dsb_hw)
        fw.addRow("Espesor tw:", self.dsb_tw)
        v.addWidget(grp_web)

        lbl = QLabel("La altura total de la sección será tf_top + hw + tf_bot.")
        lbl.setStyleSheet("color: #2874A6; font-style: italic; font-size: 8pt;")
        v.addWidget(lbl)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)

    def get_dimensions(self) -> dict:
        return {
            "bf_top": self.dsb_bf_top.value(), "tf_top": self.dsb_tf_top.value(),
            "bf_bot": self.dsb_bf_bot.value(), "tf_bot": self.dsb_tf_bot.value(),
            "hw": self.dsb_hw.value(), "tw": self.dsb_tw.value(),
        }
