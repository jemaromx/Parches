﻿# gui/main_window.py
"""
Ventana principal — Composite Column Design Pro.

Estructura:
  ┌──────────────────── HEADER (60px) ─────────────────────┐
  │ Nombre  Subtítulo  Versión                              │
  ├────────────────────────────────────────────────────────┤
  │ LEFT (scroll, 280-430px)  │  RIGHT (tabs, ≥400px)      │
  │  • STAAD Pro              │  • Envolvente               │
  │  • Miembros               │  • Por Combinación          │
  │  • Proyecto               │  • Interacción 3D           │
  │  • Tipo de columna        │  • Memoria de cálculo       │
  │  • Concreto               │                             │
  │  • Acero estructural      │                             │
  │  • Refuerzo               │                             │
  │  • Perfil / Sección       │                             │
  │  • Cargas STAAD / LC      │                             │
  │  • Normativa              │                             │
  │  • [STRETCH]              │                             │
  │  • DISEÑAR ▶              │                             │
  ├────────────────────────────────────────────────────────┤
  │ Progress bar (5px)                                     │
  │ Status bar                                             │
  └────────────────────────────────────────────────────────┘
"""
from __future__ import annotations
import os, sys, logging, copy, math
from typing import List, Optional, Dict

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QScrollArea, QTabWidget, QGroupBox,
    QLabel, QPushButton, QLineEdit, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QTextEdit, QProgressBar, QStatusBar, QFrame,
    QFileDialog, QMessageBox, QSizePolicy, QApplication, QDialog,
)
from PySide6.QtCore import Qt, QThread, Signal, QObject, Slot
from PySide6.QtGui import QFont, QColor

from config.settings import (
    APP_NAME, APP_VERSION, APP_SUBTITLE, APP_CODE,
    COLORS, STEEL_MATERIALS, REBAR_MATERIALS,
    COLUMN_TYPE_ENCASED, COLUMN_TYPE_FILLED,
    REBAR_DIAMETERS, STUD_DIAMETERS_IN,
)
from gui.styles import QSS
from gui.interaction_plot import InteractionPlot3D, SectionView

log = logging.getLogger(__name__)


# ── Worker thread ─────────────────────────────────────────────────────────────

class DesignWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, params: dict, staad_cache: dict):
        super().__init__()
        self._params = params
        self._cache  = staad_cache

    def run(self):
        try:
            results = _run_design(self._params, self._cache, self.progress.emit)
            self.finished.emit(results)
        except Exception as exc:
            import traceback
            self.error.emit(f"{exc}\n{traceback.format_exc()}")


# ── Tabla con copia ───────────────────────────────────────────────────────────

class CopyableTable(QTableWidget):
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            items = self.selectedItems()
            if not items:
                return
            rows = sorted(set(i.row() for i in items))
            cols = sorted(set(i.column() for i in items))
            text = "\n".join(
                "\t".join(
                    (self.item(r, c).text() if self.item(r, c) else "")
                    for c in cols
                )
                for r in rows
            )
            QApplication.clipboard().setText(text)
        else:
            super().keyPressEvent(event)


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1380, 840)
        self.setMinimumSize(960, 580)
        self.setStyleSheet(QSS)

        self._reader  = None   # OpenSTAADReader
        self._results: List[dict] = []
        self._staad_cache: dict = {}
        self._thread: Optional[QThread] = None

        self._build_ui()
        self._status("Listo — conecte a STAAD Pro o ingrese datos manualmente.")

    # ── Construcción de UI ────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(self._make_left_panel())
        splitter.addWidget(self._make_right_panel())
        splitter.setSizes([340, 900])
        root.addWidget(splitter, 1)

        self._pbar = QProgressBar()
        self._pbar.setFixedHeight(5)
        self._pbar.setTextVisible(False)
        self._pbar.setRange(0, 100)
        self._pbar.hide()
        root.addWidget(self._pbar)

        self._sb = QStatusBar()
        badge = QLabel(f"  {APP_CODE}  ")
        badge.setStyleSheet(
            "background:#1B4F72;color:white;font-size:8pt;padding:2px 6px;border-radius:3px;"
        )
        self._sb.addPermanentWidget(badge)
        self.setStatusBar(self._sb)

    def _make_header(self) -> QFrame:
        frame = QFrame()
        frame.setFixedHeight(60)
        frame.setStyleSheet(f"background-color:{COLORS['primary']};")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 6, 16, 6)

        title = QLabel(APP_NAME)
        title.setObjectName("lbl_header_title")
        title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        title.setStyleSheet("color:white;")

        sub = QLabel(APP_SUBTITLE)
        sub.setObjectName("lbl_header_sub")
        sub.setStyleSheet("color:#AED6F1;font-size:9pt;")

        ver = QLabel(f"v{APP_VERSION}")
        ver.setObjectName("lbl_header_ver")
        ver.setStyleSheet("color:rgba(255,255,255,0.65);font-size:8pt;")

        lay.addWidget(title)
        lay.addWidget(sub)
        lay.addStretch()
        lay.addWidget(ver)
        return frame

    # ── Panel izquierdo ───────────────────────────────────────────────────────

    def _make_left_panel(self) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setMinimumWidth(270)
        scroll.setMaximumWidth(440)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        inner = QWidget()
        inner.setMinimumWidth(255)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        lay.addWidget(self._grp_staad())
        lay.addWidget(self._grp_column_type())
        lay.addWidget(self._grp_concrete())
        lay.addWidget(self._grp_steel_profile())
        lay.addWidget(self._grp_rebar())
        lay.addWidget(self._grp_geometry())
        lay.addWidget(self._grp_lc())
        lay.addWidget(self._grp_code())
        lay.addStretch()
        lay.addWidget(self._make_run_btn())

        scroll.setWidget(inner)
        return scroll

    # ── Grupos del panel izquierdo ────────────────────────────────────────────

    def _grp_staad(self) -> QGroupBox:
        grp = QGroupBox("STAAD Pro 2024/2025")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._lbl_conn = QLabel("✗ Sin conexión")
        self._lbl_conn.setObjectName("lbl_disconnected")

        btn = QPushButton("Conectar a STAAD Pro")
        btn.setObjectName("btn_connect")
        btn.setToolTip("Conecta con el modelo abierto y ejecutado en STAAD Pro")
        btn.clicked.connect(self._connect_staad)

        self._le_members = QLineEdit()
        self._le_members.setPlaceholderText("IDs barras: 1 2 3  (vacío=todas)")
        self._le_members.setToolTip("IDs de los miembros a diseñar (separados por espacio)")

        btn_sel = QPushButton("Obtener selección STAAD")
        btn_sel.clicked.connect(self._get_selected)
        btn_sel.setToolTip("Importa la selección actual de STAAD Pro")

        lay.addWidget(self._lbl_conn)
        lay.addWidget(btn)
        lay.addWidget(QLabel("Barras a diseñar:"))
        lay.addWidget(self._le_members)
        lay.addWidget(btn_sel)
        return grp

    def _grp_column_type(self) -> QGroupBox:
        grp = QGroupBox("Tipo de columna compuesta")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_col_type = QComboBox()
        self._cb_col_type.addItems([
            "Concreto con perfil ahogado (SRC/Encased)",
            "Perfil de acero relleno de concreto (CFT/Filled)",
        ])
        self._cb_col_type.currentIndexChanged.connect(self._on_col_type_changed)
        self._cb_col_type.setToolTip(
            "SRC: Concreto con W, IR, Canal, HSS, Pipe ahogado\n"
            "CFT: HSS rect/circ, PTR o Pipe relleno de concreto"
        )
        lay.addWidget(self._cb_col_type)
        return grp

    def _grp_concrete(self) -> QGroupBox:
        grp = QGroupBox("Concreto")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._dsb_fc = QDoubleSpinBox()
        self._dsb_fc.setRange(100, 700)
        self._dsb_fc.setValue(250)
        self._dsb_fc.setSuffix(" kg/cm²")
        self._dsb_fc.setToolTip("Resistencia a compresión fc' (NTC DEA 10.1.1: 20–70 MPa)")

        self._dsb_Ec = QDoubleSpinBox()
        self._dsb_Ec.setRange(0, 5_000_000)
        self._dsb_Ec.setValue(0)
        self._dsb_Ec.setSuffix(" kg/cm²")
        self._dsb_Ec.setToolTip("Ec=0 → calculado por NTC (14000√fc')")

        self._dsb_wc = QDoubleSpinBox()
        self._dsb_wc.setRange(1400, 2500)
        self._dsb_wc.setValue(2400)
        self._dsb_wc.setSuffix(" kg/m³")

        lay.addWidget(QLabel("fc' (kg/cm²):"))
        lay.addWidget(self._dsb_fc)
        lay.addWidget(QLabel("Ec (0=automático):"))
        lay.addWidget(self._dsb_Ec)
        lay.addWidget(QLabel("Peso unitario:"))
        lay.addWidget(self._dsb_wc)
        return grp

    def _grp_steel_profile(self) -> QGroupBox:
        grp = QGroupBox("Perfil de acero estructural")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_steel_mat = QComboBox()
        for m in STEEL_MATERIALS:
            self._cb_steel_mat.addItem(m["name"])
        self._cb_steel_mat.setToolTip("Material del perfil ahogado / tubo")

        self._dsb_fy_s = QDoubleSpinBox()
        self._dsb_fy_s.setRange(1000, 8000)
        self._dsb_fy_s.setValue(2530)
        self._dsb_fy_s.setSuffix(" kg/cm²")

        self._dsb_fu_s = QDoubleSpinBox()
        self._dsb_fu_s.setRange(1000, 8000)
        self._dsb_fu_s.setValue(4080)
        self._dsb_fu_s.setSuffix(" kg/cm²")

        self._cb_steel_mat.currentIndexChanged.connect(self._update_steel_props)

        # Selector de perfil
        self._cb_prof_type = QComboBox()
        self._cb_prof_type.addItems(["W / IR", "Canal CE", "HSS Rectangular (PTR)",
                                     "HSS Circular (OC)", "Pipe/OC Std",
                                     "3 Placas (armada)"])
        self._cb_prof_type.setToolTip("Tipo de perfil")

        self._cb_prof_name = QComboBox()
        self._cb_prof_name.setEditable(True)
        self._cb_prof_name.setToolTip("Nombre del perfil (ej. W14X120, HSS8X8X1/2)")
        self._cb_prof_type.currentIndexChanged.connect(self._populate_profiles)

        self._plates3_dims = None
        self._btn_3pl = QPushButton("Definir placas…")
        self._btn_3pl.setVisible(False)
        self._btn_3pl.clicked.connect(self._open_dialog_3pl)
        self._lbl_3pl = QLabel("(sin definir)")
        self._lbl_3pl.setStyleSheet("color:#2874A6; font-style:italic; font-size:8pt;")
        self._lbl_3pl.setVisible(False)

        self._populate_profiles(0)

        lay.addWidget(QLabel("Material acero:"))
        lay.addWidget(self._cb_steel_mat)
        lay.addWidget(QLabel("Fy (kg/cm²):"))
        lay.addWidget(self._dsb_fy_s)
        lay.addWidget(QLabel("Fu (kg/cm²):"))
        lay.addWidget(self._dsb_fu_s)
        lay.addWidget(QLabel("Tipo de perfil:"))
        lay.addWidget(self._cb_prof_type)
        lay.addWidget(QLabel("Perfil:"))
        lay.addWidget(self._cb_prof_name)
        lay.addWidget(self._btn_3pl)
        lay.addWidget(self._lbl_3pl)
        return grp

    def _grp_rebar(self) -> QGroupBox:
        grp = QGroupBox("Acero de refuerzo (solo SRC — cuantía automática)")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._cb_rebar_mat = QComboBox()
        for m in REBAR_MATERIALS:
            self._cb_rebar_mat.addItem(m["name"])

        self._dsb_fy_r = QDoubleSpinBox()
        self._dsb_fy_r.setRange(1000, 8000)
        self._dsb_fy_r.setValue(4200)
        self._dsb_fy_r.setSuffix(" kg/cm²")

        self._cb_rebar_mat.currentIndexChanged.connect(self._update_rebar_props)

        # Cuantía mínima y máxima para la iteración
        self._dsb_p_min = QDoubleSpinBox()
        self._dsb_p_min.setRange(0.01, 0.06)
        self._dsb_p_min.setSingleStep(0.005)
        self._dsb_p_min.setValue(0.01)
        self._dsb_p_min.setSuffix("")
        self._dsb_p_min.setToolTip("Cuantía mínima de refuerzo (NTC DEC: 1%)")

        self._dsb_p_max = QDoubleSpinBox()
        self._dsb_p_max.setRange(0.01, 0.08)
        self._dsb_p_max.setSingleStep(0.005)
        self._dsb_p_max.setValue(0.06)
        self._dsb_p_max.setSuffix("")
        self._dsb_p_max.setToolTip("Cuantía máxima de refuerzo (NTC DEC: 6%)")

        lbl_auto = QLabel("(Cuantía y barras calculadas automáticamente)")
        lbl_auto.setStyleSheet("color:#7D6608;font-style:italic;font-size:8pt;")

        lay.addWidget(QLabel("Material refuerzo:"))
        lay.addWidget(self._cb_rebar_mat)
        lay.addWidget(QLabel("fyr (kg/cm²):"))
        lay.addWidget(self._dsb_fy_r)
        row_p = QHBoxLayout()
        row_p.addWidget(QLabel("ρ mín:"))
        row_p.addWidget(self._dsb_p_min)
        row_p.addWidget(QLabel("ρ máx:"))
        row_p.addWidget(self._dsb_p_max)
        lay.addLayout(row_p)
        lay.addWidget(lbl_auto)
        return grp

    def _grp_geometry(self) -> QGroupBox:
        grp = QGroupBox("Geometría de la sección")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        # Sección concreto (solo SRC)
        self._dsb_bc = QDoubleSpinBox()
        self._dsb_bc.setRange(10, 300)
        self._dsb_bc.setValue(50)
        self._dsb_bc.setSuffix(" cm")
        self._dsb_bc.setToolTip("Ancho sección concreto")

        self._dsb_hc = QDoubleSpinBox()
        self._dsb_hc.setRange(10, 300)
        self._dsb_hc.setValue(50)
        self._dsb_hc.setSuffix(" cm")
        self._dsb_hc.setToolTip("Alto sección concreto")

        self._dsb_cover = QDoubleSpinBox()
        self._dsb_cover.setRange(1, 20)
        self._dsb_cover.setValue(5)
        self._dsb_cover.setSuffix(" cm")
        self._dsb_cover.setToolTip("Recubrimiento libre")

        self._dsb_ex = QDoubleSpinBox()
        self._dsb_ex.setRange(-50, 50)
        self._dsb_ex.setValue(0)
        self._dsb_ex.setSuffix(" cm")
        self._dsb_ex.setToolTip("Desfase X del centroide del perfil respecto al centro del concreto")

        self._dsb_ey = QDoubleSpinBox()
        self._dsb_ey.setRange(-50, 50)
        self._dsb_ey.setValue(0)
        self._dsb_ey.setSuffix(" cm")
        self._dsb_ey.setToolTip("Desfase Y del centroide del perfil")

        self._dsb_Kx = QDoubleSpinBox()
        self._dsb_Kx.setRange(0.1, 5.0)
        self._dsb_Kx.setValue(1.0)
        self._dsb_Kx.setSuffix("")
        self._dsb_Kx.setToolTip("Factor Kx — habilitado solo con K manual")
        self._dsb_Kx.setEnabled(False)   # deshabilitado por defecto (auto)

        self._dsb_Ky = QDoubleSpinBox()
        self._dsb_Ky.setRange(0.1, 5.0)
        self._dsb_Ky.setValue(1.0)
        self._dsb_Ky.setToolTip("Factor Ky — habilitado solo con K manual")
        self._dsb_Ky.setEnabled(False)   # deshabilitado por defecto (auto)

        self._chk_auto_k = QCheckBox("Calcular K automáticamente (STAAD)")
        self._chk_auto_k.setChecked(True)
        self._chk_auto_k.setToolTip(
            "Activado: calcula K con el ábaco de alineación AISC Ap.7 leyendo la\n"
            "rigidez EI/L de vigas conectadas a cada nodo desde STAAD Pro.\n"
            "Desactivado: usa los valores Kx y Ky ingresados manualmente."
        )
        self._chk_auto_k.stateChanged.connect(self._on_auto_k_changed)

        # Conectores
        self._grp_conn_inner = QGroupBox("Conectores de cortante (SRC)")
        lay_c = QVBoxLayout(self._grp_conn_inner)

        # ── Pernos Nelson ──────────────────────────────────────────────────
        lay_c.addWidget(QLabel("── Pernos Nelson ──"))
        self._cb_stud_d = QComboBox()
        for d in STUD_DIAMETERS_IN:
            self._cb_stud_d.addItem(f"{d}\" ({d*2.54:.3f} cm)")
        self._cb_stud_d.setCurrentIndex(2)  # 3/4"

        self._dsb_stud_h = QDoubleSpinBox()
        self._dsb_stud_h.setRange(5, 30)
        self._dsb_stud_h.setValue(10)
        self._dsb_stud_h.setSuffix(" cm")

        lay_c.addWidget(QLabel("Diámetro perno:"))
        lay_c.addWidget(self._cb_stud_d)
        lay_c.addWidget(QLabel("Longitud perno:"))
        lay_c.addWidget(self._dsb_stud_h)

        # ── Canal CE ───────────────────────────────────────────────────────
        lay_c.addWidget(QLabel("── Alt. Canal CE ──"))
        from design.connectors import CE_SECTIONS as _CE
        self._cb_ce_key = QComboBox()
        for k in _CE:
            self._cb_ce_key.addItem(k)
        self._cb_ce_key.setCurrentIndex(1)   # C100×8.1 por defecto
        self._cb_ce_key.setToolTip("Sección de canal estándar CE (NTC DEA 10.2.8.4)")

        self._dsb_ce_lcc = QDoubleSpinBox()
        self._dsb_ce_lcc.setRange(5.0, 100.0)
        self._dsb_ce_lcc.setValue(20.0)
        self._dsb_ce_lcc.setSuffix(" cm")
        self._dsb_ce_lcc.setToolTip("Longitud del canal conector (lcc)")

        lay_c.addWidget(QLabel("Sección canal CE:"))
        lay_c.addWidget(self._cb_ce_key)
        lay_c.addWidget(QLabel("Longitud canal (lcc):"))
        lay_c.addWidget(self._dsb_ce_lcc)

        self._grp_conn_inner.setVisible(True)

        self._lbl_bc = QLabel("Ancho bc (cm):")
        self._lbl_hc = QLabel("Alto hc (cm):")

        lay.addWidget(self._lbl_bc)
        lay.addWidget(self._dsb_bc)
        lay.addWidget(self._lbl_hc)
        lay.addWidget(self._dsb_hc)
        lay.addWidget(QLabel("Recubrimiento:"))
        lay.addWidget(self._dsb_cover)
        lay.addWidget(QLabel("Desfase ex (cm):"))
        lay.addWidget(self._dsb_ex)
        lay.addWidget(QLabel("Desfase ey (cm):"))
        lay.addWidget(self._dsb_ey)
        lay.addWidget(self._chk_auto_k)
        row_k = QHBoxLayout()
        row_k.addWidget(QLabel("Kx:"))
        row_k.addWidget(self._dsb_Kx)
        row_k.addWidget(QLabel("Ky:"))
        row_k.addWidget(self._dsb_Ky)
        lay.addLayout(row_k)
        lay.addWidget(self._grp_conn_inner)
        return grp

    def _grp_lc(self) -> QGroupBox:
        grp = QGroupBox("Combinaciones de carga")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        self._sb_lc_ini = QSpinBox()
        self._sb_lc_ini.setRange(1, 9999)
        self._sb_lc_ini.setValue(1)
        self._sb_lc_fin = QSpinBox()
        self._sb_lc_fin.setRange(1, 9999)
        self._sb_lc_fin.setValue(100)

        row = QHBoxLayout()
        row.addWidget(QLabel("LC ini:"))
        row.addWidget(self._sb_lc_ini)
        row.addWidget(QLabel("fin:"))
        row.addWidget(self._sb_lc_fin)
        lay.addLayout(row)
        return grp

    def _grp_code(self) -> QGroupBox:
        grp = QGroupBox("Normativa")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)
        self._cb_code = QComboBox()
        self._cb_code.addItems(["NTC 2023 DEA/DEC", "ACI 318-25 / AISC 360-22"])
        self._cb_code.setToolTip("Normativa de diseño a aplicar")
        lay.addWidget(self._cb_code)
        return grp

    def _make_run_btn(self) -> QPushButton:
        btn = QPushButton("▶  DISEÑAR COLUMNAS COMPUESTAS")
        btn.setObjectName("btn_run")
        btn.setToolTip("Ejecuta el diseño para todas las barras y combinaciones seleccionadas")
        btn.clicked.connect(self._run_design)
        return btn

    # ── Panel derecho ─────────────────────────────────────────────────────────

    def _make_right_panel(self) -> QTabWidget:
        tabs = QTabWidget()
        tabs.setMinimumWidth(400)
        self._tabs = tabs

        # Tab 1: Envolvente
        self._tbl_env = CopyableTable()
        self._tbl_env.setAlternatingRowColors(True)
        self._tbl_env.horizontalHeader().setStretchLastSection(True)
        self._tbl_env.cellClicked.connect(self._on_env_clicked)
        tabs.addTab(self._tbl_env, "Envolvente")

        # Tab 2: Por combinación
        self._tbl_combo = CopyableTable()
        self._tbl_combo.setAlternatingRowColors(True)
        self._tbl_combo.horizontalHeader().setStretchLastSection(True)
        tabs.addTab(self._tbl_combo, "Por Combinación")

        # Tab 3: Interacción 3D
        wplot = QWidget()
        play = QVBoxLayout(wplot)
        play.setContentsMargins(4, 4, 4, 4)
        play.setSpacing(4)

        # Fila de controles
        row_ctrl = QHBoxLayout()
        row_ctrl.addWidget(QLabel("Miembro:"))
        self._cb_member_plot = QComboBox()
        self._cb_member_plot.currentIndexChanged.connect(self._update_plot)
        self._cb_member_plot.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        row_ctrl.addWidget(self._cb_member_plot)
        play.addLayout(row_ctrl)

        # Splitter horizontal: izquierda=diagrama, derecha=sección
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.setChildrenCollapsible(False)

        # --- Lado izquierdo: diagrama interacción ---
        wleft = QWidget()
        lleft = QVBoxLayout(wleft)
        lleft.setContentsMargins(0, 0, 0, 0)
        lleft.setSpacing(2)
        self._plot3d = InteractionPlot3D()
        lleft.addWidget(self._plot3d)
        hsplit.addWidget(wleft)

        # --- Lado derecho: sección transversal con dimensiones ---
        wright = QWidget()
        wright.setMinimumWidth(260)
        wright.setMaximumWidth(380)
        lright = QVBoxLayout(wright)
        lright.setContentsMargins(4, 4, 4, 4)
        lbl_sec = QLabel("Sección transversal")
        lbl_sec.setAlignment(Qt.AlignCenter)
        lbl_sec.setStyleSheet("font-weight:bold;color:#1B4F72;font-size:9pt;")
        lright.addWidget(lbl_sec)
        self._sec_view = SectionView()
        self._sec_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lright.addWidget(self._sec_view, 1)
        hsplit.addWidget(wright)

        hsplit.setSizes([700, 300])
        play.addWidget(hsplit, 1)
        tabs.addTab(wplot, "Interacción 3D")

        # Tab 3b: Esfuerzo-Deformación
        wss = QWidget()
        sslay = QVBoxLayout(wss)
        sslay.setContentsMargins(4, 4, 4, 4)
        row_ss = QHBoxLayout()
        row_ss.addWidget(QLabel("Miembro:"))
        self._cb_member_ss = QComboBox()
        row_ss.addWidget(self._cb_member_ss)
        row_ss.addWidget(QLabel("Combinación:"))
        self._cb_lc_ss = QComboBox()
        row_ss.addWidget(self._cb_lc_ss)
        row_ss.addStretch()
        sslay.addLayout(row_ss)
        from gui.stress_strain_plot import StrainStressWidget
        self._ss_widget = StrainStressWidget()
        sslay.addWidget(self._ss_widget, 1)
        self._cb_member_ss.currentIndexChanged.connect(self._on_ss_member_changed)
        self._cb_lc_ss.currentIndexChanged.connect(self._update_ss_plot)
        tabs.addTab(wss, "Esfuerzo-Deformación")

        # Tab 4: Memoria de cálculo
        wmem = QWidget()
        mlay = QVBoxLayout(wmem)
        mlay.setContentsMargins(4, 4, 4, 4)
        hm = QHBoxLayout()
        hm.addWidget(QLabel("Miembro:"))
        self._cb_member_memo = QComboBox()
        self._cb_member_memo.currentIndexChanged.connect(self._update_memo)
        hm.addWidget(self._cb_member_memo)
        hm.addStretch()
        btn_mem = QPushButton("📄 Exportar Word")
        btn_mem.setObjectName("btn_memory")
        btn_mem.clicked.connect(self._export_word)
        hm.addWidget(btn_mem)
        btn_dxf = QPushButton("📐 Exportar DXF")
        btn_dxf.clicked.connect(self._export_dxf)
        hm.addWidget(btn_dxf)
        mlay.addLayout(hm)
        self._txt_memo = QTextEdit()
        self._txt_memo.setReadOnly(True)
        mlay.addWidget(self._txt_memo)
        tabs.addTab(wmem, "Memoria de Cálculo")

        return tabs

    # ── Slots UI ──────────────────────────────────────────────────────────────

    def _on_col_type_changed(self, idx):
        is_enc = idx == 0
        self._lbl_bc.setVisible(is_enc)
        self._dsb_bc.setVisible(is_enc)
        self._lbl_hc.setVisible(is_enc)
        self._dsb_hc.setVisible(is_enc)
        self._grp_conn_inner.setVisible(is_enc)

    def _update_steel_props(self, idx):
        mat = STEEL_MATERIALS[idx]
        self._dsb_fy_s.setValue(mat["fy"])
        self._dsb_fu_s.setValue(mat["fu"])

    def _update_rebar_props(self, idx):
        mat = REBAR_MATERIALS[idx]
        self._dsb_fy_r.setValue(mat["fy"])

    def _populate_profiles(self, idx):
        from design.steel_db import list_sections
        is_3pl = (self._cb_prof_type.currentText().startswith("3 Placas"))
        self._btn_3pl.setVisible(is_3pl)
        self._lbl_3pl.setVisible(is_3pl)
        self._cb_prof_name.setVisible(not is_3pl)
        if is_3pl:
            self._cb_prof_name.clear()
            return
        types = ["W", "CHANNEL", "HSS_RECT", "HSS_CIRC", "HSS_CIRC"]
        t = types[idx] if idx < len(types) else "W"
        names = list_sections(t)
        self._cb_prof_name.clear()
        self._cb_prof_name.addItems(names)

    def _open_dialog_3pl(self):
        from gui.dialog_3pl import Dialog3PL
        dlg = Dialog3PL(self, initial=self._plates3_dims)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._plates3_dims = dlg.get_dimensions()
            d = self._plates3_dims
            self._lbl_3pl.setText(
                f"bf_t={d['bf_top']:.0f}×{d['tf_top']:.1f} | "
                f"bf_b={d['bf_bot']:.0f}×{d['tf_bot']:.1f} | "
                f"alma {d['hw']:.0f}×{d['tw']:.1f}")

    def _on_auto_k_changed(self, state):
        manual = (state == 0)   # checkbox desmarcado → K manual
        self._dsb_Kx.setEnabled(manual)
        self._dsb_Ky.setEnabled(manual)
        if manual:
            self._dsb_Kx.setToolTip("Factor Kx — valor manual a utilizar en diseño")
            self._dsb_Ky.setToolTip("Factor Ky — valor manual a utilizar en diseño")
        else:
            self._dsb_Kx.setToolTip("Calculado automáticamente desde STAAD (solo referencia)")
            self._dsb_Ky.setToolTip("Calculado automáticamente desde STAAD (solo referencia)")

    def _connect_staad(self):
        from fileio.openstaad_reader import OpenSTAADReader
        self._reader = OpenSTAADReader()
        ok, msg = self._reader.connect()
        if ok:
            self._lbl_conn.setText(f"✔ {msg}")
            self._lbl_conn.setObjectName("lbl_connected")
            lc_ids = self._reader.get_load_cases()
            if lc_ids:
                self._sb_lc_ini.setValue(lc_ids[0])
                self._sb_lc_fin.setValue(lc_ids[-1])
        else:
            self._lbl_conn.setText(f"✗ {msg}")
            self._lbl_conn.setObjectName("lbl_disconnected")
        self._lbl_conn.style().unpolish(self._lbl_conn)
        self._lbl_conn.style().polish(self._lbl_conn)
        self._status(msg)

    def _get_selected(self):
        if self._reader and self._reader.connected:
            ids = self._reader.get_selected_members()
            if ids:
                self._le_members.setText(" ".join(str(i) for i in ids))
                self._status(f"{len(ids)} barras importadas de STAAD.")
            else:
                self._status("Sin barras seleccionadas en STAAD.")
        else:
            self._status("Conecte a STAAD Pro primero.")

    # ── Diseño ────────────────────────────────────────────────────────────────

    def _run_design(self):
        params = self._collect_params()
        if params is None:
            return

        # Pre-fetch STAAD en hilo principal
        cache = {}
        if self._reader and self._reader.connected:
            self._status("Pre-cargando datos de STAAD Pro…")
            QApplication.processEvents()
            member_ids = params["member_ids"]
            lc_ids     = params["lc_ids"]
            self._reader.pre_fetch(member_ids, lc_ids)
            if params.get("auto_k"):
                ok, msg = self._reader.build_connectivity()
                self._status(msg)
            cache["reader"] = self._reader

        self._pbar.show()
        self._pbar.setValue(0)

        self._thread  = QThread()
        self._worker  = DesignWorker(params, cache)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._thread.start()

    def _collect_params(self) -> Optional[dict]:
        col_type = (COLUMN_TYPE_ENCASED
                    if self._cb_col_type.currentIndex() == 0
                    else COLUMN_TYPE_FILLED)

        # IDs de miembros
        raw = self._le_members.text().strip()
        if raw:
            try:
                member_ids = [int(x) for x in raw.split()]
            except ValueError:
                QMessageBox.warning(self, "Error", "IDs de barras inválidos.")
                return None
        else:
            if self._reader and self._reader.connected:
                member_ids = self._reader.get_member_ids()
            else:
                QMessageBox.warning(self, "Sin miembros",
                                    "Conecte a STAAD Pro o indique IDs de barras.")
                return None

        lc_ini = self._sb_lc_ini.value()
        lc_fin = self._sb_lc_fin.value()
        if self._reader and self._reader.connected:
            known = self._reader.get_load_cases()
            if known:
                # Filtrar por rango indicado
                lc_ids = [lc for lc in known if lc_ini <= lc <= lc_fin]
                if not lc_ids:
                    # Rango no encontrado en el catálogo → usar enteros directos
                    lc_ids = list(range(lc_ini, lc_fin + 1))
            else:
                # STAAD Load API no enumeró combinaciones → usar el rango directamente
                lc_ids = list(range(lc_ini, lc_fin + 1))
        else:
            lc_ids = list(range(lc_ini, lc_fin + 1))
        if not lc_ids:
            lc_ids = [lc_ini]

        # Perfil
        prof_name = self._cb_prof_name.currentText().strip()
        from design.steel_db import get_section, detect_section_type, plates3_section
        if self._cb_prof_type.currentText().startswith("3 Placas"):
            if not self._plates3_dims:
                QMessageBox.warning(self, "Sección 3 placas",
                                    "Defina las dimensiones de las placas.")
                return
            d3 = self._plates3_dims
            prof_data = plates3_section(d3["bf_top"], d3["tf_top"],
                                        d3["bf_bot"], d3["tf_bot"],
                                        d3["hw"], d3["tw"])
            prof_name = "3PL armada"
        else:
            prof_data = get_section(prof_name)
        if prof_data is None:
            QMessageBox.warning(self, "Perfil no encontrado",
                                f"El perfil '{prof_name}' no está en la base de datos.\n"
                                "Verifique el nombre (ej. W14X120, HSS8X8X1/2).")
            return None

        # Diámetro de perno
        stud_d_idx = self._cb_stud_d.currentIndex()
        stud_d_in  = STUD_DIAMETERS_IN[stud_d_idx]

        return {
            "column_type":  col_type,
            "member_ids":   member_ids,
            "lc_ids":       lc_ids,
            "fc":           self._dsb_fc.value(),
            "Ec":           self._dsb_Ec.value(),
            "wc":           self._dsb_wc.value(),
            "fy_s":         self._dsb_fy_s.value(),
            "fu_s":         self._dsb_fu_s.value(),
            "fy_r":         self._dsb_fy_r.value(),
            "p_min":        self._dsb_p_min.value(),
            "p_max":        self._dsb_p_max.value(),
            "bc":           self._dsb_bc.value(),
            "hc":           self._dsb_hc.value(),
            "cover":        self._dsb_cover.value(),
            "ex":           self._dsb_ex.value(),
            "ey":           self._dsb_ey.value(),
            "Kx":           self._dsb_Kx.value(),
            "Ky":           self._dsb_Ky.value(),
            "auto_k":       self._chk_auto_k.isChecked(),
            "stud_d_cm":    stud_d_in * 2.54,
            "stud_h_cm":    self._dsb_stud_h.value(),
            "ce_key":       self._cb_ce_key.currentText(),
            "ce_lcc_cm":    self._dsb_ce_lcc.value(),
            "prof_name":    prof_name,
            "prof_data":    prof_data,
            "code":         self._cb_code.currentText(),
        }

    def _on_progress(self, pct: int, msg: str):
        self._pbar.setValue(pct)
        self._status(msg)
        QApplication.processEvents()

    def _on_finished(self, results: list):
        self._thread.quit()
        self._pbar.hide()
        self._results = results
        self._populate_env_table(results)
        self._populate_combo_table(results)
        self._populate_member_selectors(results)
        if results:
            self._update_plot(0)
            self._update_memo(0)
            # Si K era automático, actualizar spinboxes con el valor calculado
            if self._chk_auto_k.isChecked() and results[0].get("Kx") is not None:
                self._dsb_Kx.setValue(results[0]["Kx"])
                self._dsb_Ky.setValue(results[0]["Ky"])
            # Auto-populate esfuerzo-deformación
            self._on_ss_member_changed(0)
            self._update_ss_plot()
        self._status(f"Diseño completado — {len(results)} miembros procesados.")

    def _on_error(self, msg: str):
        self._thread.quit()
        self._pbar.hide()
        self._status(f"Error: {msg[:100]}")
        QMessageBox.critical(self, "Error en diseño", msg)

    # ── Tablas de resultados ──────────────────────────────────────────────────

    def _populate_env_table(self, results: list):
        cols = ["Miembro", "Tipo", "Perfil", "φPn (ton)", "Pu crít (ton)",
                "Mux crít (t·m)", "Muy crít (t·m)", "LC crít",
                "PM", "V", "T", "Máx", "Estado"]
        tbl = self._tbl_env
        tbl.clear()
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setRowCount(len(results))

        for row, r in enumerate(results):
            env = r.get("envelope")
            if env is None:
                continue
            vals = [
                str(r.get("member_id", "")),
                r.get("column_type_label", ""),
                r.get("profile_name", ""),
                f"{r.get('phi_Pn', 0):.2f}",
                f"{env.Pu:.3f}",
                f"{env.Mux:.3f}",
                f"{env.Muy:.3f}",
                getattr(env, "label", str(env.lc)),
                f"{env.PR_comp:.4f}",
                f"{env.PR_shear:.4f}",
                f"{env.PR_tors:.4f}",
                f"{env.PR_max:.4f}",
                env.status,
            ]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                if col >= 8:
                    try:
                        ratio = float(val)
                        color = (QColor(COLORS["ok_cell"])   if ratio <= 0.85
                                 else QColor(COLORS["warn_cell"]) if ratio <= 1.0
                                 else QColor(COLORS["fail_cell"]))
                        item.setBackground(color)
                    except ValueError:
                        if val == "OK":
                            item.setBackground(QColor(COLORS["ok_cell"]))
                        elif val == "NG":
                            item.setBackground(QColor(COLORS["fail_cell"]))
                tbl.setItem(row, col, item)

        tbl.resizeColumnsToContents()
        tbl.horizontalHeader().setStretchLastSection(True)

    def _populate_combo_table(self, results: list):
        cols = ["Miembro", "LC", "Pu (ton)", "Mux (t·m)", "Muy (t·m)",
                "Vux (ton)", "Vuy (ton)", "Tu (t·m)",
                "PM", "V", "T", "Máx", "Estado"]
        tbl = self._tbl_combo
        tbl.clear()
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)

        rows_data = []
        for r in results:
            mid = r.get("member_id", "")
            # Separador por miembro
            rows_data.append(("sep", mid, r.get("column_type_label", "")))
            for dr in r.get("all_results", []):
                rows_data.append(("data", mid, dr))

        tbl.setRowCount(len(rows_data))
        for row, entry in enumerate(rows_data):
            if entry[0] == "sep":
                item = QTableWidgetItem(f"── Miembro {entry[1]} — {entry[2]} ──")
                item.setBackground(QColor(COLORS["separator"]))
                item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                tbl.setItem(row, 0, item)
                tbl.setSpan(row, 0, 1, len(cols))
                continue
            _, mid, dr = entry
            vals = [str(mid), getattr(dr, "label", str(dr.lc)),
                    f"{dr.Pu:.3f}", f"{dr.Mux:.3f}", f"{dr.Muy:.3f}",
                    "—", "—", "—",
                    f"{dr.PR_comp:.4f}", f"{dr.PR_shear:.4f}",
                    f"{dr.PR_tors:.4f}", f"{dr.PR_max:.4f}", dr.status]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                if col >= 8:
                    try:
                        ratio = float(val)
                        color = (QColor(COLORS["ok_cell"])   if ratio <= 0.85
                                 else QColor(COLORS["warn_cell"]) if ratio <= 1.0
                                 else QColor(COLORS["fail_cell"]))
                        item.setBackground(color)
                    except ValueError:
                        if val == "OK":
                            item.setBackground(QColor(COLORS["ok_cell"]))
                        elif val == "NG":
                            item.setBackground(QColor(COLORS["fail_cell"]))
                tbl.setItem(row, col, item)

        tbl.resizeColumnsToContents()

    def _populate_member_selectors(self, results: list):
        self._cb_member_plot.clear()
        self._cb_member_memo.clear()
        self._cb_member_ss.clear()
        for r in results:
            mid = r.get("member_id", "")
            label = f"Miembro {mid} — {r.get('profile_name','')}"
            self._cb_member_plot.addItem(label)
            self._cb_member_memo.addItem(label)
            self._cb_member_ss.addItem(label)

    def _on_ss_member_changed(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        self._cb_lc_ss.blockSignals(True)
        self._cb_lc_ss.clear()
        for dr in r.get("all_results", []):
            self._cb_lc_ss.addItem(f"{dr.label} — Pu={dr.Pu:.2f}t")
        self._cb_lc_ss.blockSignals(False)
        # Auto-mostrar la combinación con mayor ratio
        all_r = r.get("all_results", [])
        if all_r:
            worst = max(range(len(all_r)), key=lambda i: all_r[i].PR_max)
            self._cb_lc_ss.setCurrentIndex(worst)
        # setCurrentIndex no dispara currentIndexChanged porque las señales
        # de _cb_lc_ss están bloqueadas arriba — refrescar explícitamente.
        self._update_ss_plot()

    def _update_ss_plot(self):
        idx_m = self._cb_member_ss.currentIndex()
        idx_lc = self._cb_lc_ss.currentIndex()
        if not self._results or idx_m >= len(self._results):
            return
        r = self._results[idx_m]
        ss_data = r.get("ss_diagrams", [])
        if ss_data and idx_lc < len(ss_data):
            self._ss_widget.set_data(ss_data[idx_lc])
        elif r.get("all_results") and idx_lc < len(r["all_results"]):
            self._status("Diagrama esfuerzo-deformación no disponible para esta combinación.")

    def _on_env_clicked(self, row, col):
        if row < len(self._results):
            self._cb_member_plot.setCurrentIndex(row)
            self._cb_member_memo.setCurrentIndex(row)
            self._tabs.setCurrentIndex(2)

    def _update_plot(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        self._plot3d._member_id = r.get("member_id", 0)
        surf = r.get("surface")
        surf_nom = r.get("surface_nominal")
        if surf:
            self._plot3d.set_surface(*surf, nominal=surf_nom)
        demands = r.get("demands", [])
        self._plot3d.set_demands(demands)
        # Sección view
        sec_view_data = r.get("section_view_data", {})
        self._sec_view.set_section(sec_view_data)

    def _update_memo(self, idx):
        if not self._results or idx >= len(self._results):
            return
        r = self._results[idx]
        env = r.get("envelope")
        memo = env.memo if env else r.get("memo", "(sin memoria)")
        # Conectores
        conn_memo = r.get("connectors_memo", "")
        self._txt_memo.setPlainText(memo + ("\n\n" + conn_memo if conn_memo else ""))

    def _export_dxf(self):
        """Exporta ratios a DXF — mismo formato que columnsteel_design_pro.

        Si el archivo elegido existe: reduce líneas y actualiza etiquetas
        (id → 'id / ratio (combo)', rojo si ratio > 1, texto 0.3).
        Si no existe: genera un DXF nuevo con una columna por miembro.
        """
        import os as _os
        from PySide6.QtWidgets import QFileDialog, QInputDialog
        if not self._results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute el diseño primero.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Seleccionar / crear DXF de ratios", "",
            "DXF Files (*.dxf);;All Files (*)")
        if not path:
            return
        pct, ok = QInputDialog.getDouble(
            self, "Reducción de líneas",
            "Porcentaje de reducción de líneas (0-99):",
            20.0, 0.0, 99.0, 1)
        if not ok:
            pct = 20.0
        from fileio.dxf_exporter import export_dxf_single, modify_existing_dxf
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Actualizando DXF de ratios…"):
            if _os.path.exists(path):
                okd, out = modify_existing_dxf(path, self._results,
                                               reduction_pct=pct)
            else:
                okd = export_dxf_single(path, self._results,
                                        reduction_pct=pct)
                out = path
        if okd:
            QMessageBox.information(self, "DXF", f"DXF generado:\n{out}")
        else:
            QMessageBox.warning(self, "DXF",
                                f"No fue posible generar el DXF:\n{out}")

    def _export_word(self):
        if not self._results:
            QMessageBox.information(self, "Sin resultados", "Ejecute el diseño primero.")
            return
        from fileio.word_exporter import export_word, _DOCX_OK
        if not _DOCX_OK:
            QMessageBox.warning(self, "python-docx no instalado",
                                "Instale: pip install python-docx")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar memoria de cálculo",
            os.path.expanduser("~\\Documents\\Memoria_Columnas.docx"),
            "Word (*.docx)",
        )
        if not path:
            return
        data = []
        for r in self._results:
            env = r.get("envelope")
            # Renderizar figuras para este miembro
            figures = _render_member_figures(r)
            data.append({
                "member_id":    r.get("member_id", ""),
                "column_type":  r.get("column_type_label", ""),
                "section_info": r.get("section_info", ""),
                "design_result": env,
                "memo": env.memo if env else "",
                "figures": figures,
            })
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Generando memoria Word…"):
            ok, msg = export_word(data, path, "Proyecto",
                               "N.A.", self._cb_code.currentText())
        if ok:
            QMessageBox.information(self, "Exportado", msg)
        else:
            QMessageBox.critical(self, "Error", msg)

    # ── Utilidades ────────────────────────────────────────────────────────────

    def _status(self, msg: str):
        self._sb.showMessage(msg)


# ── Renderizado de figuras para Word ────────────────────────────────────────────

def _render_member_figures(r: dict) -> list:
    """
    Renderiza los diagramas de un miembro como PNG (bytes) para embeber en Word.
    Devuelve lista de (caption, png_bytes).
    """
    import io as _io
    figures = []

    try:
        import matplotlib
        matplotlib.use("Agg")   # off-screen backend
        import matplotlib.pyplot as plt
        import numpy as np

        surf = r.get("surface")
        surf_nom = r.get("surface_nominal")
        demands  = r.get("demands", [])   # [(Pu, Mux, Muy, label), ...]
        mid = r.get("member_id", "")

        # ── Diagrama de interacción 3D ───────────────────────────────────────
        if surf is not None:
            P_arr, My_arr, Mz_arr = surf
            fig3d = plt.figure(figsize=(10, 7))
            ax3d  = fig3d.add_subplot(111, projection="3d")
            ax3d.set_title(f"Superficie P-Mx-My (φ) — Miembro {mid}", fontsize=10)
            ax3d.set_xlabel("Mx (ton·m)"); ax3d.set_ylabel("My (ton·m)")
            ax3d.set_zlabel("P (ton)")
            # Superficie de diseño (φ)
            try:
                ax3d.plot_surface(My_arr, Mz_arr, P_arr,
                                  alpha=0.30, color="#2874A6", label="Diseño φ")
            except Exception:
                ax3d.scatter(My_arr.ravel(), Mz_arr.ravel(), P_arr.ravel(),
                             s=1, alpha=0.2, color="#2874A6")
            # Superficie nominal
            if surf_nom is not None:
                Pn, Myn, Mzn = surf_nom
                try:
                    ax3d.plot_surface(Myn, Mzn, Pn,
                                      alpha=0.12, color="#839192", label="Nominal")
                except Exception:
                    pass
            # Demandas
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax3d.scatter([Mux], [Muy], [Pu], s=30, color=clr, zorder=10)
            buf3d = _io.BytesIO()
            fig3d.tight_layout()
            fig3d.savefig(buf3d, format="png", dpi=120)
            plt.close(fig3d)
            figures.append(("Diagrama de interacción 3D P-Mx-My (φ y nominal)", buf3d.getvalue()))

        # ── Diagrama 2D P-Mx ────────────────────────────────────────────────
        if surf is not None:
            P_arr, My_arr, Mz_arr = surf
            fig2, (ax_pmx, ax_pmy) = plt.subplots(1, 2, figsize=(12, 5))
            fig2.suptitle(f"Diagramas de interacción 2D — Miembro {mid}", fontsize=10)
            # P-Mx: ángulo 0° (puro Mux)
            ax_pmx.set_title("P vs Mux (θ=0°)", fontsize=9)
            ax_pmx.set_xlabel("Mux (ton·m)"); ax_pmx.set_ylabel("P (ton)")
            ax_pmx.plot(My_arr[:, 0], P_arr[:, 0], "b-", lw=1.5, label="φ diseño")
            if surf_nom:
                Pn, Myn, Mzn = surf_nom
                ax_pmx.plot(Myn[:, 0], Pn[:, 0], "k--", lw=1, alpha=0.6, label="Nominal")
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax_pmx.scatter([Mux], [Pu], s=20, color=clr)
            ax_pmx.axhline(0, color="gray", lw=0.5)
            ax_pmx.legend(fontsize=7)

            # P-My: ángulo 90°
            j90 = len(P_arr[0]) // 4   # 90° index aprox
            ax_pmy.set_title("P vs Muy (θ=90°)", fontsize=9)
            ax_pmy.set_xlabel("Muy (ton·m)"); ax_pmy.set_ylabel("P (ton)")
            ax_pmy.plot(Mz_arr[:, j90], P_arr[:, j90], "g-", lw=1.5, label="φ diseño")
            if surf_nom:
                Pn, Myn, Mzn = surf_nom
                ax_pmy.plot(Mzn[:, j90], Pn[:, j90], "k--", lw=1, alpha=0.6, label="Nominal")
            for Pu, Mux, Muy, lbl, ratio in demands:
                clr = "#E74C3C" if ratio > 1.0 else "#27AE60"
                ax_pmy.scatter([Muy], [Pu], s=20, color=clr)
            ax_pmy.axhline(0, color="gray", lw=0.5)
            ax_pmy.legend(fontsize=7)

            buf2d = _io.BytesIO()
            fig2.tight_layout()
            fig2.savefig(buf2d, format="png", dpi=120)
            plt.close(fig2)
            figures.append(("Diagramas de interacción 2D P-Mux y P-Muy", buf2d.getvalue()))

        # ── Diagrama esfuerzo-deformación más desfavorable ─────────────────
        ss_diagrams = r.get("ss_diagrams", [])
        all_res     = r.get("all_results", [])
        if ss_diagrams and all_res:
            try:
                worst_idx = max(range(len(all_res)), key=lambda i: all_res[i].PR_max)
                if worst_idx < len(ss_diagrams):
                    ss = ss_diagrams[worst_idx]
                    fibers = ss.get("fibers", [])
                    if fibers:
                        fig_ss = _render_ss_figure(ss, mid)
                        if fig_ss is not None:
                            buf_ss = _io.BytesIO()
                            fig_ss.tight_layout()
                            fig_ss.savefig(buf_ss, format="png", dpi=120)
                            plt.close(fig_ss)
                            lbl_ss = ss.get("label", f"LC-{worst_idx}")
                            figures.append((
                                f"Diagrama esfuerzo-deformación más desfavorable ({lbl_ss})",
                                buf_ss.getvalue()
                            ))
            except Exception:
                pass

    except Exception:
        import traceback; traceback.print_exc()

    return figures


def _render_ss_figure(ss: dict, mid):
    """Renderiza la figura de esfuerzo-deformación para el dict ss dado."""
    import math as _math
    import matplotlib.pyplot as plt
    import numpy as np

    fibers  = ss.get("fibers", [])
    if not fibers:
        return None
    c       = ss.get("c", 0)
    theta   = ss.get("theta_deg", 0)
    label   = ss.get("label", "")

    conc_f  = [f for f in fibers if f["type"] == "concreto"]
    rebar_f = [f for f in fibers if f["type"] == "refuerzo"]
    steel_f = [f for f in fibers if f["type"] == "perfil"]

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(12, 4))
    fig.suptitle(f"Esfuerzo-Deformación — Miembro {mid} — {label}  c={c:.1f}cm  θ={theta:.1f}°",
                 fontsize=9)

    all_sigma = [f["sigma"] for f in fibers if f["sigma"] != 0]
    sigma_abs = max(abs(s) for s in all_sigma) if all_sigma else 1.0

    # subplot 1: ε vs Y
    ax1.set_title("ε vs Y", fontsize=8)
    ax1.set_xlabel("ε", fontsize=7); ax1.set_ylabel("Y (cm)", fontsize=7)
    if conc_f:  ax1.scatter([f["eps"] for f in conc_f], [f["y"] for f in conc_f], s=3, c="lightblue", alpha=0.5)
    if rebar_f: ax1.scatter([f["eps"] for f in rebar_f], [f["y"] for f in rebar_f], s=25, c="red", zorder=5)
    if steel_f: ax1.scatter([f["eps"] for f in steel_f], [f["y"] for f in steel_f], s=12, c="steelblue", alpha=0.7)
    ax1.axvline(0, color="black", lw=0.8)
    ax1.tick_params(labelsize=6)

    # subplot 2: σ mapa
    ax2.set_title("σ en sección", fontsize=8)
    ax2.set_xlabel("Z (cm)", fontsize=7); ax2.set_ylabel("Y (cm)", fontsize=7)
    ax2.set_aspect("equal")
    if conc_f:
        sp = ax2.scatter([f["z"] for f in conc_f], [f["y"] for f in conc_f],
                         c=[f["sigma"] for f in conc_f], cmap="Blues", s=15,
                         vmin=0, vmax=sigma_abs, alpha=0.7)
    if rebar_f:
        ax2.scatter([f["z"] for f in rebar_f], [f["y"] for f in rebar_f],
                    c=[f["sigma"] for f in rebar_f], cmap="RdBu_r", s=50,
                    vmin=-sigma_abs, vmax=sigma_abs, edgecolors="black", lw=0.5, zorder=6)
    if steel_f:
        ax2.scatter([f["z"] for f in steel_f], [f["y"] for f in steel_f],
                    c=[f["sigma"] for f in steel_f], cmap="RdYlGn", s=20,
                    vmin=-sigma_abs, vmax=sigma_abs, alpha=0.8)
    theta_rad = _math.radians(theta)
    lim = max((abs(f["y"]) for f in fibers), default=1)
    cos_t = _math.cos(theta_rad); sin_t = _math.sin(theta_rad)
    if abs(sin_t) > 0.01:
        zn = np.linspace(-lim, lim, 10)
        yn = -cos_t / sin_t * zn
        ax2.plot(zn, yn, "k--", lw=0.8)
    else:
        ax2.axhline(0, color="k", lw=0.8, ls="--")
    ax2.tick_params(labelsize=6)

    # subplot 3: fuerzas resultantes
    ax3.set_title("Fuerza resultante (kg)", fontsize=8)
    forces_vals = [
        sum(f["F"] for f in conc_f),
        sum(f["F"] for f in rebar_f),
        sum(f["F"] for f in steel_f),
    ]
    bars = ax3.barh(["Concreto", "Refuerzo", "Perfil"], forces_vals,
                    color=["#2E86C1", "#E74C3C", "#1E8449"], alpha=0.8)
    ax3.axvline(0, color="black", lw=0.8)
    ax3.set_xlabel("F (kg)", fontsize=7)
    ax3.tick_params(labelsize=6)
    fabs = max((abs(v) for v in forces_vals), default=1)
    for bar, val in zip(bars, forces_vals):
        ax3.text(val + fabs * 0.02, bar.get_y() + bar.get_height() / 2,
                 f"{val:,.0f}", va="center", fontsize=6)

    return fig


# ── Motor de diseño (corre en worker thread) ──────────────────────────────────

def _run_design(params: dict, cache: dict, progress_cb) -> list:
    """
    Lógica principal de diseño para todas las barras.

    Convención de ejes STAAD → sección:
      · hc = dimensión en Y local STAAD
      · bc = dimensión en Z local STAAD
      · Vy (v[1]) = Vuy paralelo a Y/hc   → reader["Vuy"]
      · Vz (v[2]) = Vuz paralelo a Z/bc   → reader["Vuz"]
      · My (v[4]) = momento sobre Y, flexiona en hc  → reader["Muy"]  = Mux sección
      · Mz (v[5]) = momento sobre Z, flexiona en bc  → reader["Muz"]  = Muy sección
      · Torsión = Mx (v[3]) → reader["Ttor"]

    Cada nodo (inicial y final) de cada combinación genera un punto de demanda
    independiente en el diagrama de interacción.
    """
    import copy as _copy
    from design.composite_section import (
        ConcreteProps, SteelProps, RebarProps,
        EncasedSection, FilledSection,
    )
    from design.encased_column import EncasedColumnDesign, DesignForces
    from design.filled_column import FilledColumnDesign
    from design.fiber_model import (
        build_interaction_surface_3d, iterate_rebar,
        rebar_layout_4faces, _profile_fibers, strain_stress_diagram,
        check_demand_surface, check_demand_surface_detail,
    )
    from design.stirrup_design import design_stirrups, stirrup_memo as _stirrup_memo
    from design.connectors import (
        qn_stud, qn_channel, n_studs_required, n_channels_required,
        stud_layout, stud_layout_2d, connectors_memo,
    )

    col_type   = params["column_type"]
    member_ids = params["member_ids"]
    lc_ids     = params["lc_ids"]
    reader     = cache.get("reader")

    concrete  = ConcreteProps(params["fc"], params["Ec"], params["wc"])
    steel_mat = SteelProps(params["fy_s"], params["fu_s"])
    rebar_mat = RebarProps(params["fy_r"])
    prof_data = params["prof_data"]
    prof_name = params["prof_name"]
    code      = params["code"]

    results = []
    n_mem = len(member_ids)

    for i, mid in enumerate(member_ids):
        progress_cb(int(i / n_mem * 85), f"Diseñando miembro {mid} ({i+1}/{n_mem})…")

        # ── Longitud y K ────────────────────────────────────────────────
        L = params.get("L", 3.0)   # fallback 3.0 m cuando no hay STAAD
        if reader:
            try:
                Ls = reader.get_member_length(mid)
                if Ls > 0:
                    L = Ls
            except Exception:
                pass

        Kx, Ky = params["Kx"], params["Ky"]
        k_method = "Manual"
        k_detail = {}      # datos intermedios para el memo
        if params.get("auto_k") and reader:
            try:
                Ky_calc, Kx_calc = reader.compute_k_factors(mid)
                k_detail = _build_k_detail(reader, mid, L, Kx_calc, Ky_calc)
                Kx, Ky = Kx_calc, Ky_calc
                k_method = "Automático (AISC Ap.7)"
            except Exception:
                k_method = "Manual (fallo auto)"

        KLx = Kx * L
        KLy = Ky * L

        # ── Fuerzas STAAD por combinación (2 nodos) ──────────────────────
        if reader:
            forces_ini, forces_fin = reader.get_forces(mid, lc_ids)
        else:
            _zero = {"Pu": 0, "Vuy": 0, "Vuz": 0, "Ttor": 0, "Muy": 0, "Muz": 0}
            forces_ini = [dict(_zero) for _ in lc_ids]
            forces_fin = [dict(_zero) for _ in lc_ids]

        # ── Sección y motor ──────────────────────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            # Sección inicial con cuantía mínima
            As_initial = params["p_min"] * params["bc"] * params["hc"]
            sec = EncasedSection(
                bc=params["bc"], hc=params["hc"], cover=params["cover"],
                steel_profile=_copy.deepcopy(prof_data),
                ex=params["ex"], ey=params["ey"],
                concrete=_copy.deepcopy(concrete),
                steel=_copy.deepcopy(steel_mat),
                rebar=_copy.deepcopy(rebar_mat),
                n_bars=8,
                db=1.905,
                As_override=As_initial,
            )
            eng = EncasedColumnDesign(sec, code)
            section_label = "SRC (Encased)"
        else:
            sec = FilledSection(
                steel_profile=_copy.deepcopy(prof_data),
                concrete=_copy.deepcopy(concrete),
                steel=_copy.deepcopy(steel_mat),
            )
            eng = FilledColumnDesign(sec, code)
            section_label = "CFT (Filled)"

        phi_Pn = eng.phi_Pn(KLx, KLy)

        # ── Diseño por combinación — AMBOS NODOS como casos independientes ──
        # Convención: reader["Muy"] = My STAAD (v[4]) → Mux sección (flexión en hc)
        #             reader["Muz"] = Mz STAAD (v[5]) → Muy sección (flexión en bc)
        all_results = []
        for lc, fi, ff in zip(lc_ids, forces_ini, forces_fin):
            for node_label, f in (("ini", fi), ("fin", ff)):
                Pu  = f["Pu"]
                Mux = f["Muy"]    # My STAAD → flexión en hc (Y local)
                Muy = f["Muz"]    # Mz STAAD → flexión en bc (Z local)
                Vux = f["Vuy"]    # Vy STAAD → paralelo a hc
                Vuy = f["Vuz"]    # Vz STAAD → paralelo a bc
                Tu  = f["Ttor"]

                forces = DesignForces(
                    Pu=Pu, Mux=Mux, Muy=Muy,
                    Vux=Vux, Vuy=Vuy, Tu=Tu,
                    lc=lc, label=f"LC{lc}-{node_label}",
                )
                dr = eng.design(forces, KLx, KLy)
                all_results.append(dr)

        # ── Envolvente H1-1 (temporal, antes de fibras) ──────────────────
        envelope = max(all_results, key=lambda x: x.PR_max)

        # ── χ (NTC DEA 10.3.2.1.b-c): reducción por pandeo del punto de
        # compresión pura de la superficie de fibras (gobierna la dirección
        # de mayor esbeltez). Se calcula una sola vez con la sección actual
        # y se reutiliza en las superficies preliminar, final y nominal.
        chi_enc = 1.0
        if col_type == COLUMN_TYPE_ENCASED:
            chi_enc_x, _ = sec.chi(KLx, "x")
            chi_enc_y, _ = sec.chi(KLy, "y")
            chi_enc = min(chi_enc_x, chi_enc_y)

        # ── PASO 1: Superficie preliminar con p_min para hallar combinación crítica real ──
        surf = None; surf_nominal = None
        rebar_result = None
        rebar_fibers = []
        if col_type == COLUMN_TYPE_ENCASED:
            try:
                progress_cb(
                    int(i / n_mem * 85) + 3,
                    f"Superficie preliminar miembro {mid}…",
                )
                As_prelim = params["p_min"] * params["bc"] * params["hc"]
                rf_prelim = rebar_layout_4faces(
                    params["bc"], params["hc"], params["cover"], As_prelim,
                )
                P_prelim, My_prelim, Mz_prelim = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rf_prelim, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=0.90, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=0.75,
                )
                # Encontrar verdadera combinación crítica (mayor ratio de fibras)
                Pu_crit = envelope.Pu; Mux_crit = envelope.Mux; Muy_crit = envelope.Muy
                max_fr  = 0.0
                for lc_t, fi_t, ff_t in zip(lc_ids, forces_ini, forces_fin):
                    for f_t in (fi_t, ff_t):
                        det_t = check_demand_surface_detail(
                            P_prelim, My_prelim, Mz_prelim,
                            f_t["Pu"], f_t["Muy"], f_t["Muz"],
                        )
                        if det_t["ratio"] > max_fr:
                            max_fr    = det_t["ratio"]
                            Pu_crit   = f_t["Pu"]
                            Mux_crit  = f_t["Muy"]   # My STAAD → hc
                            Muy_crit  = f_t["Muz"]   # Mz STAAD → bc
            except Exception:
                import traceback; traceback.print_exc()
                Pu_crit = envelope.Pu; Mux_crit = envelope.Mux; Muy_crit = envelope.Muy

            # ── PASO 2: Iterar cuantía con las fuerzas críticas reales ──────
            progress_cb(
                int(i / n_mem * 85) + 6,
                f"Iterando cuantía miembro {mid}…",
            )
            rebar_result = iterate_rebar(
                bc=params["bc"], hc=params["hc"], fc=params["fc"],
                steel_profile=prof_data, fy_s=params["fy_s"],
                fy_r=params["fy_r"], cover=params["cover"],
                Pu_ton=Pu_crit, My_ton_m=Mux_crit, Mz_ton_m=Muy_crit,
                ex=params["ex"], ey=params["ey"],
                p_min=params["p_min"], p_max=params["p_max"],
            )
            rebar_fibers = rebar_result["rebar_fibers"]
            sec.As_override = rebar_result["As"]
            sec.n_bars      = len(rebar_fibers)

        # ── PASO 3: Superficie final con cuantía iterada ─────────────────
        try:
            progress_cb(
                int(i / n_mem * 85) + 10,
                f"Superficie final miembro {mid}…",
            )
            if not rebar_fibers and col_type == COLUMN_TYPE_ENCASED:
                As_fb = params["p_min"] * params["bc"] * params["hc"]
                rebar_fibers = rebar_layout_4faces(
                    params["bc"], params["hc"], params["cover"], As_fb,
                )

            if col_type == COLUMN_TYPE_ENCASED:
                P_arr, My_arr, Mz_arr = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=0.90, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=0.75,
                )
                surf = (P_arr, My_arr, Mz_arr)
                # Superficie nominal: sin FR (fr=1.00 y fr_axial=1.00), pero
                # SÍ con χ — el pandeo es un efecto físico, no un margen de
                # seguridad, y debe verse también en la curva nominal.
                P_n, My_n, Mz_n = build_interaction_surface_3d(
                    bc=params["bc"], hc=params["hc"], fc=params["fc"],
                    rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                    steel_profile=prof_data, fy_s=params["fy_s"],
                    ex=params["ex"], ey=params["ey"],
                    fr=1.00, n_angles=72, n_depths=40,
                    chi=chi_enc, fr_axial=1.00,
                )
                surf_nominal = (P_n, My_n, Mz_n)
            else:
                from design.interaction_surface import build_3d_surface
                surf = build_3d_surface(sec, KLx, KLy, n_angles=72, n_pts_per_curve=40)
                surf_nominal = surf
        except Exception as _exc:
            import traceback; traceback.print_exc()

        # ── Construir texto de K para insertar en el memo ────────────────
        k_memo_txt = _k_memo_text(L, Kx, Ky, KLx, KLy, k_method, k_detail)
        # Insertar en cada DesignResult (memo individual)
        all_results = [
            dr._replace(memo=k_memo_txt + "\n\n" + dr.memo)
            for dr in all_results
        ]
        envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Recalcular ratios con la superficie de fibras (consistencia) ─
        # También actualiza el texto del memo para que no muestre H1-1 incorrecto.
        if surf is not None and col_type == COLUMN_TYPE_ENCASED:
            P_s, My_s, Mz_s = surf
            updated = []
            for dr in all_results:
                det = check_demand_surface_detail(
                    P_s, My_s, Mz_s, dr.Pu, dr.Mux, dr.Muy,
                )
                fiber_ratio = det["ratio"]
                max_r  = max(fiber_ratio, dr.PR_shear, dr.PR_tors)
                status = "OK" if max_r <= 1.0 else "NG"
                new_memo = _replace_interaction_memo(
                    dr.memo, fiber_ratio, dr.Pu, dr.Mux, dr.Muy,
                    det["M_cap"], det["M_demand"], det["theta_deg"], status,
                )
                updated.append(dr._replace(
                    PR_comp=round(fiber_ratio, 4),
                    PR_max=round(max_r, 4),
                    status=status,
                    memo=new_memo,
                ))
            all_results = updated
            envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Diseño de estribos y agregar al memo de la envolvente ─────────
        stirrup_txt = ""
        if col_type == COLUMN_TYPE_ENCASED:
            env_for_stir = max(all_results, key=lambda x: x.PR_max)
            # Obtener las fuerzas de cortante/torsión de la envolvente
            env_forces_list = [
                (fi, ff)
                for lc, fi, ff in zip(lc_ids, forces_ini, forces_fin)
            ]
            # Peor Vuy, Vuz, Tu de todos los nodos y combinaciones
            Vuy_max = max(
                (abs(f["Vuz"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            Vuz_max = max(
                (abs(f["Vuy"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            Tu_max  = max(
                (abs(f["Ttor"]) for fi, ff in env_forces_list for f in (fi, ff)),
                default=0.0,
            )
            try:
                db_long_est = 1.905   # ø3/4" aprox. para longitud de barras
                if rebar_fibers:
                    import math as _m
                    As_1bar = (rebar_result["As"] / max(len(rebar_fibers), 1)
                               if rebar_result else 0)
                    db_long_est = max(
                        _m.sqrt(As_1bar / (_m.pi / 4)) if As_1bar > 0 else 1.905,
                        0.6,
                    )
                stir_res = design_stirrups(
                    fc=params["fc"], fy_r=params["fy_r"],
                    bc=params["bc"], hc=params["hc"],
                    cover=params["cover"], db_long=db_long_est,
                    Vuy=Vuy_max, Vuz=Vuz_max, Tu=Tu_max,
                    Pu=env_for_stir.Pu,
                )
                stirrup_txt = _stirrup_memo(
                    stir_res, params["fc"], params["fy_r"],
                    params["bc"], params["hc"],
                    params["cover"], db_long_est,
                )
            except Exception as _se:
                stirrup_txt = f"\n[Error en diseño de estribos: {_se}]\n"

        # Agregar sección de estribos al memo de la envolvente
        if stirrup_txt:
            all_results = [
                dr._replace(memo=dr.memo + stirrup_txt) if dr.label == envelope.label
                else dr
                for dr in all_results
            ]
            envelope = max(all_results, key=lambda x: x.PR_max)

        # ── Demandas (puntos en el diagrama) — incluye ratio para colorear ─
        # dr.Pu usa convención negativo=compresión (DesignForces); las
        # superficies graficadas (build_interaction_surface_3d / build_3d_surface)
        # usan positivo=compresión → se invierte el signo solo para el punto
        # graficado (dr.Pu en sí no se modifica en otras tablas/labels).
        demands = [(-dr.Pu, dr.Mux, dr.Muy, dr.label, dr.PR_max) for dr in all_results]

        # ── Diagramas esfuerzo-deformación por combinación ───────────────
        ss_diagrams = []
        if col_type == COLUMN_TYPE_ENCASED and rebar_fibers:
            steel_fibers_ss = _profile_fibers(prof_data, 16)
            for dr in all_results:
                try:
                    ss = strain_stress_diagram(
                        bc=params["bc"], hc=params["hc"], fc=params["fc"],
                        rebar_fibers=rebar_fibers, fy_r=params["fy_r"],
                        steel_fibers=steel_fibers_ss, fy_s=params["fy_s"],  # ← fix
                        ex=params["ex"], ey=params["ey"],
                        Pu_ton=dr.Pu, My_ton_m=dr.Mux, Mz_ton_m=dr.Muy,
                    )
                    ss["label"] = dr.label
                    ss_diagrams.append(ss)
                except Exception as _e:
                    ss_diagrams.append({"label": dr.label, "fibers": [], "error": str(_e)})

        # ── Conectores de cortante (solo SRC) ────────────────────────────
        conn_memo_txt = ""
        n_conn = 0
        layout_2d = {}
        if col_type == COLUMN_TYPE_ENCASED:
            try:
                qn = qn_stud(
                    params["stud_d_cm"], params["stud_h_cm"],
                    params["fc"], concrete.Ec, 4_220.0,
                )
                n_conn = n_studs_required(
                    params["fy_s"], sec.Aa, params["fc"], sec.Ac, qn,
                )
                layout_2d = stud_layout_2d(
                    n_conn, L,
                    params["bc"], params["hc"],
                    params["stud_d_cm"],
                )
                conn_memo_txt = connectors_memo(
                    "SRC Encased",
                    n_conn, params["stud_d_cm"], params["stud_h_cm"],
                    qn, L,
                    params["fc"], concrete.Ec,
                    params["fy_s"], sec.Aa, sec.Ac,
                    ce_key=params.get("ce_key", "C100×8.1 (4\")"),
                    ce_lcc_cm=params.get("ce_lcc_cm", 20.0),
                )
                # Distribución 2D pernos Nelson
                if layout_2d:
                    conn_memo_txt += "\n\nDISTRIBUCIÓN ÓPTIMA DE PERNOS NELSON (2D):\n"
                    for axis, lay_d in layout_2d.items():
                        conn_memo_txt += (
                            f"  Dir. {axis}: "
                            f"{lay_d['n_rows']} fila(s) × {lay_d['n_per_row']} pernos  "
                            f"s_long={lay_d['s_long_cm']:.1f} cm  "
                            f"s_transv={lay_d['s_transv_cm']:.1f} cm  "
                            f"{'Válido' if lay_d['valid'] else 'REVISAR'}\n"
                        )
            except Exception:
                pass

        # ── Vista de sección ─────────────────────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            n_bars_result = len(rebar_fibers) if rebar_fibers else 8
            As_result     = rebar_result["As"] if rebar_result else 0
            _prof_with_name = dict(prof_data)
            _prof_with_name.setdefault("name", prof_name)
            sec_view = {
                "column_type":    "encased",
                "bc":             params["bc"],
                "hc":             params["hc"],
                "cover":          params["cover"],
                "n_bars":         n_bars_result,
                "As_total":       As_result,
                "rebar_fibers":   rebar_fibers,   # [(y, z, A), ...]
                "ex":             params["ex"],
                "ey":             params["ey"],
                "prof_data":      _prof_with_name,
                "cover_ratio":    params["cover"] / params["hc"],
                "steel_w_ratio":  prof_data.get("bf", 20) / params["bc"],
                "steel_h_ratio":  prof_data.get("d",  30) / params["hc"],
            }
            rebar_info = (
                f"ρ={rebar_result['p_pct']:.2f}%  As={rebar_result['As']:.2f} cm²"
                f"  ({rebar_result['status']})"
            ) if rebar_result else "—"
        else:
            D = prof_data.get("bf", prof_data.get("d", 20))
            t = prof_data.get("tf", prof_data.get("tw", 0.5))
            H_d = prof_data.get("d", D)
            sec_view = {
                "column_type":  "filled",
                "profile_type": prof_data.get("type", "HSS_RECT"),
                "prof_data":    prof_data,
                "b_ratio":      D / max(D, H_d),
                "t_ratio":      t / max(D, H_d),
                "inner_ratio":  (D / 2 - t) / (D / 2) if D > 0 else 0.85,
            }
            rebar_info = "—"

        # ── Texto de información de sección ──────────────────────────────
        if col_type == COLUMN_TYPE_ENCASED:
            sec_info = (
                f"Concreto: {params['bc']:.0f}×{params['hc']:.0f} cm  "
                f"fc'={params['fc']:.0f} kg/cm²\n"
                f"Perfil: {prof_name}  Fy={params['fy_s']:.0f} kg/cm²\n"
                f"Refuerzo (auto): {rebar_info}  fyr={params['fy_r']:.0f} kg/cm²\n"
                f"KLx={KLx:.2f} m  KLy={KLy:.2f} m\n"
                f"Conectores: {n_conn} pernos Nelson\n"
                f"Límites: {sec.valid_limits() or ['OK']}"
            )
        else:
            sec_info = (
                f"Perfil relleno: {prof_name}\n"
                f"fc'={params['fc']:.0f} kg/cm²  Fy={params['fy_s']:.0f} kg/cm²\n"
                f"KLx={KLx:.2f} m  KLy={KLy:.2f} m\n"
                f"Clasificación: {sec.section_class()}\n"
                f"Límites: {sec.valid_limits() or ['OK']}"
            )

        results.append({
            "member_id":         mid,
            "column_type_label": section_label,
            "profile_name":      prof_name,
            "L":  L, "Kx": Kx, "Ky": Ky, "KLx": KLx, "KLy": KLy,
            "section_info":      sec_info,
            "phi_Pn":            phi_Pn,
            "all_results":       all_results,
            "envelope":          envelope,
            "surface":           surf,
            "surface_nominal":   surf_nominal,
            "demands":           demands,
            "section_view_data": sec_view,
            "connectors_memo":   conn_memo_txt,
            "ss_diagrams":       ss_diagrams,
            "rebar_result":      rebar_result,
            "memo":              envelope.memo,
        })

    progress_cb(100, "Diseño completado.")
    return results


# ── Helpers para el cálculo de K ─────────────────────────────────────────────

def _build_k_detail(reader, mid: int, L: float,
                    Kx: float, Ky: float) -> dict:
    """
    Reconstruye los factores G de alineación (GA, GB) para el miembro mid.
    Retorna dict con los datos intermedios para el memo.
    """
    try:
        if not reader._mem_nodes:
            return {}
        n_start, n_end = reader._mem_nodes.get(mid, (None, None))
        if n_start is None:
            return {}
        if mid not in reader._stiff_cache:
            return {}
        Iy_col, Ix_col, L_col = reader._stiff_cache[mid]
        EIy = Iy_col / L_col
        EIx = Ix_col / L_col

        def _G(node):
            beams = reader._get_connected_beams(node)
            beams = [m for m in beams if m != mid]
            sy = sx = 0.0
            for m in beams:
                if m not in reader._stiff_cache:
                    continue
                Iy_m, Ix_m, L_m = reader._stiff_cache[m]
                sy += Iy_m / L_m
                sx += Ix_m / L_m
            Gy = EIy / sy if sy > 0 else 10.0
            Gx = EIx / sx if sx > 0 else 10.0
            return min(Gy, 100.0), min(Gx, 100.0)

        GA_y, GA_x = _G(n_start)
        GB_y, GB_x = _G(n_end)
        return {
            "n_start": n_start, "n_end": n_end,
            "GA_y": GA_y, "GB_y": GB_y,
            "GA_x": GA_x, "GB_x": GB_x,
            "EIy": EIy, "EIx": EIx,
            "sway": True,
        }
    except Exception:
        return {}


def _k_memo_text(L: float, Kx: float, Ky: float,
                 KLx: float, KLy: float,
                 k_method: str, k_detail: dict) -> str:
    """Genera el texto de la sección 'FACTOR DE LONGITUD EFECTIVA' para la memoria."""
    SEP = "=" * 72
    lines = [
        SEP,
        "FACTOR DE LONGITUD EFECTIVA K",
        f"  Método: {k_method}",
        f"  Longitud libre  L  = {L:.3f} m",
        "",
    ]

    if k_detail:
        GA_y = k_detail.get("GA_y", "—")
        GB_y = k_detail.get("GB_y", "—")
        GA_x = k_detail.get("GA_x", "—")
        GB_x = k_detail.get("GB_x", "—")
        n_s  = k_detail.get("n_start", "—")
        n_e  = k_detail.get("n_end",   "—")
        sway = k_detail.get("sway", True)

        lines += [
            "  Factores de alineación (AISC Apéndice 7):",
            f"    G = Σ(EI/L)_columnas / Σ(EI/L)_vigas  por nodo",
            f"    Nodo inicial [{n_s}]:  GA_Y = {GA_y:.3f}   GA_Z = {GA_x:.3f}",
            f"    Nodo final   [{n_e}]:  GB_Y = {GB_y:.3f}   GB_Z = {GB_x:.3f}",
            "",
        ]
        if sway:
            lines += [
                "  Marco con deriva libre (sway) — AISC Ap.7 Ec. (C-A-7-5):",
                "    K = √[(1.6·GA·GB + 4·(GA+GB) + 7.5) / (GA+GB+7.5)]",
                "",
                "  Dirección Y (flexión en hc):",
                f"    GA = {GA_y:.3f}   GB = {GB_y:.3f}",
            ]
            if isinstance(GA_y, float):
                import math
                GA, GB = GA_y, GB_y
                num = 1.6*GA*GB + 4*(GA+GB) + 7.5
                den = GA + GB + 7.5
                Ky_calc = math.sqrt(num/den) if den > 0 else 1.0
                lines.append(f"    Ky = √[({1.6:.1f}·{GA:.3f}·{GB:.3f} + "
                             f"4·({GA:.3f}+{GB:.3f}) + 7.5) / "
                             f"({GA:.3f}+{GB:.3f}+7.5)]")
                lines.append(f"    Ky = √[{num:.3f} / {den:.3f}] = {Ky_calc:.4f}")
            lines.append("")
            lines += [
                "  Dirección Z (flexión en bc):",
                f"    GA = {GA_x:.3f}   GB = {GB_x:.3f}",
            ]
            if isinstance(GA_x, float):
                import math
                GA, GB = GA_x, GB_x
                num = 1.6*GA*GB + 4*(GA+GB) + 7.5
                den = GA + GB + 7.5
                Kx_calc = math.sqrt(num/den) if den > 0 else 1.0
                lines.append(f"    Kx = √[{num:.3f} / {den:.3f}] = {Kx_calc:.4f}")
        else:
            lines += [
                "  Marco sin deriva (braced) — AISC Ap.7 Ec. (C-A-7-2):",
                "    K = √[(GA+1)·(GB+1) / (GA+2)·(GB+2)]",
            ]
    else:
        lines += [
            "  (Datos de conectividad no disponibles — se aplicó valor manual)",
        ]

    lines += [
        "",
        f"  Resultados:",
        f"    Kx = {Kx:.4f}   →   KLx = {Kx:.4f} × {L:.3f} = {KLx:.3f} m",
        f"    Ky = {Ky:.4f}   →   KLy = {Ky:.4f} × {L:.3f} = {KLy:.3f} m",
        SEP,
    ]
    return "\n".join(lines)


def _replace_interaction_memo(
    memo: str,
    fiber_ratio: float,
    Pu: float, Mux: float, Muy: float,
    M_cap: float, M_demand: float,
    theta_deg: float,
    status: str,
) -> str:
    """
    Reemplaza la sección 'INTERACCIÓN FLEXOCOMPRESIÓN' del memo (generada con
    el método simplificado H1-1) por el resultado correcto del modelo de fibras 3D.
    """
    import math as _math
    tick = "✔ OK" if fiber_ratio <= 1.0 else "✘ NO CUMPLE"
    if M_demand < 1e-6:
        # Carga pura
        ratio_txt = (
            f"  Carga axial pura (|Mux|≈|Muy|≈0)\n"
            f"  Relación P = |Pu|/φPn_fibras = {fiber_ratio:.4f}   {tick}"
        )
    elif M_cap > 0:
        ratio_txt = (
            f"  θ demanda  = atan2(|Muy|,|Mux|) = atan2({abs(Muy):.3f},{abs(Mux):.3f})"
            f" = {theta_deg:.1f}°\n"
            f"  M_demanda  = √(Mux²+Muy²) = √({Mux**2:.3f}+{Muy**2:.3f})"
            f" = {M_demand:.4f} ton·m\n"
            f"  M_capacidad (superficie, P={Pu:.2f}t, θ={theta_deg:.1f}°)"
            f" = {M_cap:.4f} ton·m\n"
            f"  Relación PM = M_demanda / M_capacidad"
            f" = {M_demand:.4f} / {M_cap:.4f} = {fiber_ratio:.4f}   {tick}"
        )
    else:
        ratio_txt = (
            f"  Relación PM (fibras) = {fiber_ratio:.4f}   {tick}"
        )

    new_section = "\n".join([
        "INTERACCIÓN FLEXOCOMPRESIÓN — MODELO DE FIBRAS 3D",
        "  (NTC DEA 2024 Cap. 10 / AISC 360-22 Cap. I / ACI 318-25 Cap. 10)",
        "  Método: compatibilidad de deformaciones, bloque de Whitney",
        "  Superficie: 72 ángulos × 40 profundidades de eje neutro",
        "  Contribuciones: concreto (C=0.85·fc'·β₁·c·b) + refuerzo 4 caras + perfil (fibras)",
        "",
        f"  Pu  = {Pu:+.3f} ton",
        f"  Mux = {Mux:+.3f} ton·m  (My STAAD → flexión en hc)",
        f"  Muy = {Muy:+.3f} ton·m  (Mz STAAD → flexión en bc)",
        "",
        ratio_txt,
    ])

    # Buscar y reemplazar el bloque INTERACCIÓN ... hasta CORTANTE
    start = "INTERACCIÓN FLEXOCOMPRESIÓN"
    end   = "\nCORTANTE"
    i0 = memo.find(start)
    if i0 == -1:
        updated = memo + "\n\n" + new_section
    else:
        i1 = memo.find(end, i0)
        if i1 == -1:
            updated = memo[:i0] + new_section
        else:
            updated = memo[:i0] + new_section + memo[i1:]

    # Actualizar también la línea RESULTADO GLOBAL al final del memo
    import re as _re
    def _fix_global(m):
        # fiber_ratio ya incluye solo PM; max_r viene del llamador → usamos fiber_ratio y PR_shear/PR_tors
        # Si el patrón encuentra el número, lo sustituimos por el ratio real
        return m.group(0)   # placeholder — sustituimos abajo con replace explícito

    # Reemplazar cualquier "RESULTADO GLOBAL: ratio_max = X.XXXX → ..."
    pat = _re.compile(
        r"RESULTADO GLOBAL: ratio_max\s*=\s*[\d.]+\s*→\s*[^\n]+",
        _re.IGNORECASE,
    )
    global_status = "OK" if fiber_ratio <= 1.0 else "NO CUMPLE"
    replacement   = f"RESULTADO GLOBAL: ratio_max = {fiber_ratio:.4f}   →  {global_status}"
    updated       = pat.sub(replacement, updated)

    return updated
