# -*- coding: utf-8 -*-
"""Vista en planta del nudo de concreto (seccion horizontal a media altura columna)."""
from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from viz.styles_viz import (
    COL_CONCRETE, COL_CONC_EDGE, COL_STEEL_L, COL_STEEL_T,
    COL_CONFINEMENT, COL_BEAM, COL_DIM, COL_BG,
    FONT_TITLE, FONT_LABEL, FONT_DIM,
    apply_global_style, draw_dimension, DPI_EXPORT,
)


def draw_plan_view(envelope_result, extractor=None,
                   project: str = "", output_path: str = "") -> plt.Figure:
    """Genera vista en planta profesional del nudo.

    Devuelve una figura aunque envelope_result este parcialmente vacio.
    """
    apply_global_style()
    fig, ax = plt.subplots(figsize=(10, 9), dpi=DPI_EXPORT)
    ax.set_aspect("equal")
    ax.set_facecolor(COL_BG)

    jg     = getattr(envelope_result, "joint_geometry", None)
    col_id = getattr(envelope_result, "col_id", 0)
    node_id = getattr(envelope_result, "node_id", 0)

    # Dimensiones por defecto si no hay geometria
    b_col = (jg.b_col / 100.0) if jg else 0.40
    h_col = (jg.h_col / 100.0) if jg else 0.40

    x0, y0 = -b_col / 2, -h_col / 2

    # ── Columna ───────────────────────────────────────────────────────────────
    ax.add_patch(Rectangle(
        (x0, y0), b_col, h_col,
        facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
        linewidth=1.5, zorder=2,
    ))

    # Zona confinada
    rec = 0.04
    ax.add_patch(Rectangle(
        (x0 + rec, y0 + rec), b_col - 2*rec, h_col - 2*rec,
        facecolor="none", edgecolor=COL_CONFINEMENT,
        linestyle="--", linewidth=1.0, zorder=3,
    ))
    ax.fill_between(
        [x0 + rec, x0 + b_col - rec], y0 + rec, y0 + h_col - rec,
        alpha=0.08, color=COL_CONFINEMENT, zorder=2,
    )

    # ── Trabes ────────────────────────────────────────────────────────────────
    n_trabes = (jg.n_trabes_framing if jg else 2)
    trabe_dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)][:n_trabes]
    trabe_len  = 0.60

    for i, (dx, dy) in enumerate(trabe_dirs):
        bx = b_col / 2 * abs(dx) + h_col / 2 * abs(dy)
        sx, sy = dx * bx, dy * bx
        ex, ey = sx + dx * trabe_len, sy + dy * trabe_len
        bw_t = 0.30
        if abs(dx) > abs(dy):
            trx, try_ = min(sx, ex), -bw_t / 2
            tw, th = abs(ex - sx), bw_t
        else:
            trx, try_ = -bw_t / 2, min(sy, ey)
            tw, th = bw_t, abs(ey - sy)
        ax.add_patch(Rectangle(
            (trx, try_), tw, th,
            facecolor=COL_BEAM, edgecolor=COL_CONC_EDGE,
            alpha=0.35, linewidth=1.0, zorder=1,
        ))
        ax.text(sx + dx * trabe_len * 0.55, sy + dy * trabe_len * 0.55,
                f"T{i+1}", ha="center", va="center",
                fontdict=FONT_DIM, color="#0D47A1")

    # ── Acero longitudinal ────────────────────────────────────────────────────
    db = 0.025
    for bx, by in _column_bars(b_col, h_col, rec, db):
        ax.add_patch(plt.Circle(
            (x0 + bx, y0 + by), db / 2,
            facecolor=COL_STEEL_L, edgecolor="#0D0D0D",
            linewidth=0.5, zorder=5,
        ))

    # ── Estribo ───────────────────────────────────────────────────────────────
    r = rec
    ax.plot(
        [x0+r, x0+b_col-r, x0+b_col-r, x0+r, x0+r],
        [y0+r, y0+r, y0+h_col-r, y0+h_col-r, y0+r],
        color=COL_STEEL_T, linewidth=1.5, zorder=4,
    )

    # ── Ejes ──────────────────────────────────────────────────────────────────
    ax.axhline(0, color="#AAAAAA", linewidth=0.5, linestyle=":", zorder=1)
    ax.axvline(0, color="#AAAAAA", linewidth=0.5, linestyle=":", zorder=1)

    # ── Cotas ─────────────────────────────────────────────────────────────────
    draw_dimension(ax, x0, y0, x0 + b_col, y0,
                   f"b={b_col*100:.0f} cm", offset=0.15, axis="x")
    draw_dimension(ax, x0 + b_col, y0, x0 + b_col, y0 + h_col,
                   f"h={h_col*100:.0f} cm", offset=0.15, axis="y")

    # ── Leyenda ───────────────────────────────────────────────────────────────
    Aj_txt = f"{jg.Aj:.0f} cm2" if jg else "—"
    ax.legend(handles=[
        mpatches.Patch(facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
                       label=f"Concreto Aj={Aj_txt}"),
        mpatches.Patch(facecolor="none", edgecolor=COL_CONFINEMENT,
                       linestyle="--", label="Nucleo confinado"),
        mpatches.Patch(facecolor=COL_BEAM, alpha=0.5, label="Trabes"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=COL_STEEL_L,
               markersize=6, label="Acero longitudinal"),
        Line2D([0], [0], color=COL_STEEL_T, linewidth=2, label="Estribo"),
    ], loc="lower right", fontsize=7, framealpha=0.9)

    # ── Panel de resultados ───────────────────────────────────────────────────
    _results_panel(ax, envelope_result)

    # ── Titulo ────────────────────────────────────────────────────────────────
    jtype = (jg.joint_type.upper() if jg else "—")
    ax.set_title(
        f"PLANTA — NUDO  |  Columna {col_id}  |  Nodo {node_id}\n"
        f"Tipo: {jtype}  |  Ductilidad: {_duct_label(envelope_result)}",
        fontdict=FONT_TITLE, pad=10, color="#1B4F72",
    )
    ax.set_xlabel("X  [m]", fontdict=FONT_LABEL)
    ax.set_ylabel("Y  [m]", fontdict=FONT_LABEL)
    margin = max(b_col, h_col) * 1.8
    ax.set_xlim(-margin / 2, margin / 2)
    ax.set_ylim(-margin / 2, margin / 2)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if output_path:
        try:
            fig.savefig(output_path, dpi=DPI_EXPORT, bbox_inches="tight")
        except Exception:
            pass

    return fig


# ── Helpers ────────────────────────────────────────────────────────────────────

def _column_bars(b, h, rec, db):
    positions = []
    for x in [rec + db/2, b - rec - db/2]:
        for y in [rec + db/2, h - rec - db/2]:
            positions.append((x, y))
    if b > 0.40:
        positions += [(b/2, rec + db/2), (b/2, h - rec - db/2)]
    if h > 0.40:
        positions += [(rec + db/2, h/2), (b - rec - db/2, h/2)]
    return positions


def _duct_label(env) -> str:
    combos = getattr(env, "combos", [])
    if not combos:
        return "—"
    jf = getattr(combos[0], "joint_force", None)
    return getattr(jf, "ductility", "—") if jf else "—"


def _results_panel(ax, env):
    combos = getattr(env, "combos", [])
    if not combos:
        return
    worst = getattr(env, "worst_shear_ntc", 0)
    jf_all = [c.joint_force for c in combos if c.joint_force]
    if not jf_all:
        return
    # El indice worst puede apuntar a jf_all (que puede tener menos elementos que combos)
    idx = min(worst, len(jf_all) - 1)

    Vjh_max    = getattr(env, "Vjh_max",    0.0)
    vu_max     = getattr(env, "vu_max",     0.0)
    DCR_NTC    = getattr(env, "DCR_NTC_max",0.0)
    DCR_ACI    = getattr(env, "DCR_ACI_max",0.0)
    ok_ntc     = getattr(env, "ok_shear_NTC", True)
    ok_aci     = getattr(env, "ok_shear_ACI", True)

    lines = [
        f"Vjh max = {Vjh_max/1000:.2f} ton",
        f"vu  max = {vu_max:.2f} kgf/cm2",
        f"DCR NTC = {DCR_NTC:.3f}  {'OK' if ok_ntc else 'FALLA'}",
        f"DCR ACI = {DCR_ACI:.3f}  {'OK' if ok_aci else 'FALLA'}",
    ]
    color = "#D5F5E3" if ok_ntc and ok_aci else "#FADBD8"
    ax.text(-0.01, 0.99, "\n".join(lines), transform=ax.transAxes,
            va="top", ha="left", fontsize=7,
            bbox=dict(boxstyle="round,pad=0.4", facecolor=color,
                      edgecolor="#888", linewidth=0.8),
            family="monospace")
