"""
Pestaña "Dimensión final" (Mejora 2).

Muestra en tabla los ID's de las zapatas con su B, L y h propuestos por el
diseño y permite al usuario EDITAR la dimensión final (B, L) y el espesor (h).
El botón "Recalcular con dimensión fija" re-lanza el cálculo de presiones,
estabilidad, asentamientos y diseño para TODAS las combinaciones SIN volver a
dimensionar ni iterar el peralte: los resultados se muestran tal cual resulten,
aunque NO cumplan capacidad, estabilidad, flexión o cortante.
"""
from __future__ import annotations

from typing import List

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QColor

from config.settings import COLORS
from gui.table_utils import enable_excel_copy


class FinalDimsWidget(QWidget):
    """Tabla editable de dimensiones finales + recálculo con dimensión fija."""

    sig_recompute = Signal(object)  # {node_id: {"L","B","h"}} — object: claves int no convertibles

    _HEADERS = ["ID", "Zapata", "B (m)", "L (m)", "h (m)", "Estado"]
    _COL_ID, _COL_LBL, _COL_B, _COL_L, _COL_H, _COL_ST = range(6)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build(self) -> None:
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        info = QLabel(
            "Edite B, L y h (espesor) y pulse «Recalcular con dimensión fija». "
            "Se revisarán todas las combinaciones con la dimensión indicada, "
            "SIN re-dimensionar: los resultados se muestran tal cual, aunque no "
            "cumplan capacidad, asentamientos, estabilidad, flexión o cortante.")
        info.setWordWrap(True)
        info.setStyleSheet(f"color: {COLORS['text']}; font-size: 9pt; padding: 2px;")
        lay.addWidget(info)

        self._tbl = QTableWidget(0, len(self._HEADERS))
        self._tbl.setHorizontalHeaderLabels(self._HEADERS)
        self._tbl.verticalHeader().setVisible(False)
        self._tbl.setEditTriggers(
            QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked)
        self._tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        hh = self._tbl.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Stretch)
        hh.setSectionResizeMode(self._COL_ID, QHeaderView.ResizeToContents)
        enable_excel_copy(self._tbl)
        lay.addWidget(self._tbl, 1)

        bar = QHBoxLayout()
        self._btn = QPushButton("🔁  Recalcular con dimensión fija")
        self._btn.setEnabled(False)
        self._btn.clicked.connect(self._on_recompute)
        bar.addWidget(self._btn)
        self._btn_reset = QPushButton("↺  Restaurar diseño automático")
        self._btn_reset.setEnabled(False)
        self._btn_reset.clicked.connect(lambda: self.sig_recompute.emit({}))
        bar.addWidget(self._btn_reset)
        bar.addStretch()
        self._lbl_hint = QLabel("")
        self._lbl_hint.setStyleSheet("color: #566573; font-size: 8pt;")
        bar.addWidget(self._lbl_hint)
        lay.addLayout(bar)

    # ── Población desde resultados ──────────────────────────────────────────
    def load_results(self, results: List) -> None:
        """Llena la tabla con B, L, h actuales de cada zapata."""
        self._tbl.blockSignals(True)
        self._tbl.setRowCount(len(results))
        for r, nr in enumerate(results):
            self._set_ro(r, self._COL_ID,  str(nr.node_id))
            self._set_ro(r, self._COL_LBL, nr.node_label or f"Z{nr.node_id}")
            self._set_edit(r, self._COL_B, nr.B)
            self._set_edit(r, self._COL_L, nr.L)
            self._set_edit(r, self._COL_H, nr.d_total)
            self._set_status(r, results[r])
        self._tbl.blockSignals(False)
        has = len(results) > 0
        self._btn.setEnabled(has)
        self._btn_reset.setEnabled(has)

    def _set_ro(self, row: int, col: int, text: str) -> None:
        it = QTableWidgetItem(text)
        it.setFlags(it.flags() & ~Qt.ItemIsEditable)
        it.setTextAlignment(Qt.AlignCenter)
        self._tbl.setItem(row, col, it)

    def _set_edit(self, row: int, col: int, value: float) -> None:
        it = QTableWidgetItem(f"{value:.3f}")
        it.setTextAlignment(Qt.AlignCenter)
        self._tbl.setItem(row, col, it)

    def _set_status(self, row: int, nr) -> None:
        """Resumen OK/NO de la zapata según sus combinaciones (caso peor)."""
        ok = _node_ok(nr)
        if ok:
            texto, color = "✔ Cumple", "#1E8449"
        else:
            grapas = _grapas_solventan(nr)
            if grapas:
                texto, color = f"✔ Cumple con grapas {grapas}", "#B9770E"
            else:
                texto, color = "✗ No cumple", "#922B21"
        it = QTableWidgetItem(texto)
        it.setFlags(it.flags() & ~Qt.ItemIsEditable)
        it.setTextAlignment(Qt.AlignCenter)
        it.setForeground(QColor(color))
        f = QFont(); f.setBold(True); it.setFont(f)
        self._tbl.setItem(row, self._COL_ST, it)

    # ── Recálculo ────────────────────────────────────────────────────────────
    def _collect(self) -> dict:
        out = {}
        for r in range(self._tbl.rowCount()):
            try:
                nid = int(self._tbl.item(r, self._COL_ID).text())
                B = float(self._tbl.item(r, self._COL_B).text().replace(",", "."))
                L = float(self._tbl.item(r, self._COL_L).text().replace(",", "."))
                h = float(self._tbl.item(r, self._COL_H).text().replace(",", "."))
            except (ValueError, AttributeError):
                continue
            if B > 0 and L > 0 and h > 0:
                out[nid] = {"L": L, "B": B, "h": h}
        return out

    def _on_recompute(self) -> None:
        dims = self._collect()
        if dims:
            self._lbl_hint.setText(f"Recalculando {len(dims)} zapata(s) con dimensión fija…")
            self.sig_recompute.emit(dims)


def _grapas_solventan(nr) -> str:
    """
    Si la ÚNICA falla es el cortante de viga ancha y las grapas propuestas
    lo solventan en todas las combinaciones, regresa la propuesta más
    desfavorable (p.ej. "#4 @ 20 cm"); si no, cadena vacía.
    """
    peor = ""
    for cr in nr.combos:
        gr = cr.geo_serv or cr.geo_ult
        if gr is not None:
            if not (gr.ok_cap and gr.ok_volteo and gr.ok_desl
                    and gr.ok_ext and gr.ok_asent):
                return ""
        sr = cr.struc
        if sr is None:
            continue
        if not (sr.ok_pun and sr.ok_flex):
            return ""            # falla algo que las grapas no resuelven
        if not (sr.ok_cort_L and sr.ok_cort_B):
            if not (sr.grapas_req and sr.grapa_sel
                    and "aumente" not in sr.grapa_sel):
                return ""
            peor = sr.grapa_sel.split("(")[0].strip()
    return peor


def _node_ok(nr) -> bool:
    """True si todas las combinaciones cumplen (geo + estructural)."""
    for cr in nr.combos:
        gr = cr.geo_serv or cr.geo_ult
        if gr is not None:
            if not (gr.ok_cap and gr.ok_volteo and gr.ok_desl
                    and gr.ok_ext and gr.ok_asent):
                return False
        sr = cr.struc
        if sr is not None:
            if not (sr.ok_pun and sr.ok_cort_L and sr.ok_cort_B and sr.ok_flex):
                return False
    return True
