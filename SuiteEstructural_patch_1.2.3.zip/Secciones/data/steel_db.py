﻿# data/steel_db.py — catálogo interno de perfiles (W/M/S/HP/C/MC desde AISC
# Shapes Database v16.0) y secciones HSS/PIPE estimadas geométricamente.
import math

from ._steel_sections_gen import STEEL_SECTIONS


def normalize_name(n: str) -> str:
    return n.upper().strip().replace(" ", "")


def lookup(name: str) -> dict | None:
    return STEEL_SECTIONS.get(normalize_name(name))


def pipe_thickness_from_name(n):
    return None


def estimate_from_hss_round(D, t):
    Di = max(D - 2*t, 0)
    A  = math.pi*(D**2 - Di**2)/4
    Ix = math.pi*(D**4 - Di**4)/64
    Sx = Ix/(D/2) if D else 0
    Zx = (D**3 - Di**3)/6
    r  = math.sqrt(Ix/A) if A else 0
    return {"A":A,"d":D,"bf":D,"tf":t,"tw":t,
            "Ix":Ix,"Sx":Sx,"Zx":Zx,"Iy":Ix,"Sy":Sx,"Zy":Zx,
            "rx":r,"ry":r,"J":2*Ix,"Cw":0.0}

def estimate_from_hss_rect(H, B, t):
    Hi = max(H-2*t,0); Bi = max(B-2*t,0)
    A  = H*B - Hi*Bi
    Ix = (B*H**3 - Bi*Hi**3)/12
    Sx = Ix/(H/2) if H else 0
    Zx = B*H**2/4 - Bi*Hi**2/4
    Iy = (H*B**3 - Hi*Bi**3)/12
    Sy = Iy/(B/2) if B else 0
    Zy = H*B**2/4 - Hi*Bi**2/4
    rx = math.sqrt(Ix/A) if A else 0
    ry = math.sqrt(Iy/A) if A else 0
    Ae = Hi*Bi; p = 2*(Hi+Bi)
    J  = 4*Ae**2*t/p if p else 0
    return {"A":A,"d":H,"bf":B,"tf":t,"tw":t,
            "Ix":Ix,"Sx":Sx,"Zx":Zx,"Iy":Iy,"Sy":Sy,"Zy":Zy,
            "rx":rx,"ry":ry,"J":J,"Cw":0.0}

def estimate_from_dimensions(d, bf, tf, tw):
    h = d-2*tf; A = 2*bf*tf + h*tw
    Ix = (bf*d**3 - (bf-tw)*h**3)/12
    Sx = Ix/(d/2) if d else 0
    Zx = bf*tf*(d-tf) + tw*h**2/4
    Iy = 2*tf*bf**3/12 + h*tw**3/12
    Sy = Iy/(bf/2) if bf else 0
    Zy = bf**2*tf/2 + tw**2*h/4
    rx = math.sqrt(Ix/A) if A else 0
    ry = math.sqrt(Iy/A) if A else 0
    J  = (2*bf*tf**3 + h*tw**3)/3
    Cw = Iy*(d-tf)**2/4
    return {"A":A,"d":d,"bf":bf,"tf":tf,"tw":tw,
            "Ix":Ix,"Sx":Sx,"Zx":Zx,"Iy":Iy,"Sy":Sy,"Zy":Zy,
            "rx":rx,"ry":ry,"J":J,"Cw":Cw}

# ── HSS Rectangulares / PTR (H×B×t en cm) ────────────────────────────────────
_HSS_RECT_RAW = [
    # (H,  B,    t,     nombre)
    (5.08, 5.08, 0.318, "HSS2X2X1/8"),
    (5.08, 5.08, 0.476, "HSS2X2X3/16"),
    (7.62, 7.62, 0.318, "HSS3X3X1/8"),
    (7.62, 7.62, 0.476, "HSS3X3X3/16"),
    (7.62, 7.62, 0.635, "HSS3X3X1/4"),
    (10.16,10.16,0.318, "HSS4X4X1/8"),
    (10.16,10.16,0.476, "HSS4X4X3/16"),
    (10.16,10.16,0.635, "HSS4X4X1/4"),
    (10.16,10.16,0.953, "HSS4X4X3/8"),
    (12.70,12.70,0.476, "HSS5X5X3/16"),
    (12.70,12.70,0.635, "HSS5X5X1/4"),
    (12.70,12.70,0.953, "HSS5X5X3/8"),
    (12.70,12.70,1.270, "HSS5X5X1/2"),
    (15.24,15.24,0.476, "HSS6X6X3/16"),
    (15.24,15.24,0.635, "HSS6X6X1/4"),
    (15.24,15.24,0.953, "HSS6X6X3/8"),
    (15.24,15.24,1.270, "HSS6X6X1/2"),
    (20.32,10.16,0.635, "HSS8X4X1/4"),
    (20.32,10.16,0.953, "HSS8X4X3/8"),
    (20.32,15.24,0.635, "HSS8X6X1/4"),
    (20.32,15.24,0.953, "HSS8X6X3/8"),
    (20.32,20.32,0.635, "HSS8X8X1/4"),
    (20.32,20.32,0.953, "HSS8X8X3/8"),
    (20.32,20.32,1.270, "HSS8X8X1/2"),
    (25.40,12.70,0.953, "HSS10X5X3/8"),
    (25.40,15.24,0.635, "HSS10X6X1/4"),
    (25.40,15.24,0.953, "HSS10X6X3/8"),
    (25.40,20.32,0.953, "HSS10X8X3/8"),
    (25.40,25.40,0.635, "HSS10X10X1/4"),
    (25.40,25.40,0.953, "HSS10X10X3/8"),
    (25.40,25.40,1.270, "HSS10X10X1/2"),
    (30.48,15.24,0.953, "HSS12X6X3/8"),
    (30.48,20.32,0.953, "HSS12X8X3/8"),
    (30.48,25.40,0.953, "HSS12X10X3/8"),
    (30.48,30.48,0.635, "HSS12X12X1/4"),
    (30.48,30.48,0.953, "HSS12X12X3/8"),
    (30.48,30.48,1.270, "HSS12X12X1/2"),
    (35.56,35.56,0.953, "HSS14X14X3/8"),
    (35.56,35.56,1.270, "HSS14X14X1/2"),
    (40.64,40.64,0.953, "HSS16X16X3/8"),
    (40.64,40.64,1.270, "HSS16X16X1/2"),
]
HSS_RECT_DB: dict[str, dict] = {
    name: estimate_from_hss_rect(H, B, t)
    for H, B, t, name in _HSS_RECT_RAW
}

# ── HSS Circulares / PIPE / OC (D×t en cm) ───────────────────────────────────
_HSS_CIRC_RAW = [
    # (D_cm,  t_cm,  nombre)
    (3.340, 0.337, "PIPE1-1/4 STD"),
    (4.826, 0.368, "PIPE1-1/2 STD"),
    (6.033, 0.391, "PIPE2 STD"),
    (7.303, 0.516, "PIPE2-1/2 STD"),
    (8.890, 0.549, "PIPE3 STD"),
    (10.16, 0.602, "PIPE3-1/2 STD"),
    (11.43, 0.602, "PIPE4 STD"),
    (14.13, 0.655, "PIPE5 STD"),
    (16.83, 0.711, "PIPE6 STD"),
    (21.91, 0.818, "PIPE8 STD"),
    (27.31, 0.927, "PIPE10 STD"),
    (32.39, 0.953, "PIPE12 STD"),
    (4.826, 0.508, "PIPE1-1/2 XH"),
    (6.033, 0.554, "PIPE2 XH"),
    (8.890, 0.762, "PIPE3 XH"),
    (11.43, 0.856, "PIPE4 XH"),
    (16.83, 1.097, "PIPE6 XH"),
    (21.91, 1.270, "PIPE8 XH"),
    (27.31, 1.270, "PIPE10 XH"),
    (32.39, 1.270, "PIPE12 XH"),
]
HSS_CIRC_DB: dict[str, dict] = {
    name: estimate_from_hss_round(D, t)
    for D, t, name in _HSS_CIRC_RAW
}


def get_sections_by_type(section_type: str) -> list[str]:
    """Devuelve lista de nombres de secciones según tipo."""
    t = section_type.upper()
    if t in ("W", "IR"):
        return sorted(k for k in STEEL_SECTIONS if k.startswith("W") and not k.startswith("WT"))
    if t in ("C", "CE"):
        return sorted(k for k in STEEL_SECTIONS if k.startswith("C") or k.startswith("MC"))
    if t == "HP":
        return sorted(k for k in STEEL_SECTIONS if k.startswith("HP"))
    if t in ("HSS_RECT", "PTR", "OR_RECT"):
        return sorted(HSS_RECT_DB.keys())
    if t in ("HSS_CIRC", "PIPE", "OC"):
        return sorted(HSS_CIRC_DB.keys())
    return []


def get_props(name: str) -> dict | None:
    """Lookup de propiedades; busca W/C primero, luego HSS."""
    p = lookup(name)
    if p:
        return p
    if name in HSS_RECT_DB:
        return HSS_RECT_DB[name]
    if name in HSS_CIRC_DB:
        return HSS_CIRC_DB[name]
    return None


def cruz_props(bf_h: float, tf_h: float, hw: float, tw: float) -> dict:
    """
    Propiedades de sección en cruz (cruciforme):
    Placa horizontal: bf_h × tf_h  (total ancho, espesor)
    Placa vertical:   tw × hw      (alma total, incluyendo superposición)
    """
    A_h = bf_h * tf_h
    A_v = hw * tw - tf_h * tw   # descontar superposición
    A   = A_h + A_v
    d   = hw
    # Alma completa (centrada) + placa horizontal centrada, restando la
    # superposición central (tf_h × tw) ya contada en el término del alma.
    Ix = (tw*hw**3)/12 + (bf_h*tf_h**3)/12 - (tf_h*tw**3)/12
    Iy = (tf_h*bf_h**3)/12 + (tw**3*(hw-tf_h))/12
    Sx = Ix/(hw/2) if hw else 0
    Sy = Iy/(bf_h/2) if bf_h else 0
    Zx = bf_h*tf_h**2/4 + tw*(hw**2 - tf_h**2)/4
    Zy = bf_h**2*tf_h/4 + (hw-tf_h)*tw**2/4
    rx = math.sqrt(Ix/A) if A else 0
    ry = math.sqrt(Iy/A) if A else 0
    J  = (bf_h*tf_h**3 + (hw-tf_h)*tw**3)/3
    return {"shape":"cruz", "A":A,"d":hw,"bf":bf_h,"tf":tf_h,"tw":tw,
            "Ix":Ix,"Sx":Sx,"Zx":Zx,"Iy":Iy,"Sy":Sy,"Zy":Zy,
            "rx":rx,"ry":ry,"J":J,"Cw":0.0}


def plates3_props(bf_top: float, tf_top: float, bf_bot: float, tf_bot: float,
                   hw: float, tw: float) -> dict:
    """
    Propiedades de sección armada de 3 placas (2 patines + alma), tipo
    perfil I, permitiendo patines asimétricos (bf_top/tf_top distintos de
    bf_bot/tf_bot).

    hw : altura libre del alma entre patines (cm)
    tw : espesor del alma (cm)
    """
    d = tf_bot + hw + tf_top

    A_bot = bf_bot * tf_bot
    A_w   = hw * tw
    A_top = bf_top * tf_top
    A     = A_bot + A_w + A_top

    y_bot_c = tf_bot / 2
    y_w_c   = tf_bot + hw / 2
    y_top_c = tf_bot + hw + tf_top / 2
    ybar = (A_bot*y_bot_c + A_w*y_w_c + A_top*y_top_c) / A if A else 0.0

    Ix = (bf_bot*tf_bot**3/12 + A_bot*(y_bot_c - ybar)**2
          + tw*hw**3/12        + A_w*(y_w_c - ybar)**2
          + bf_top*tf_top**3/12 + A_top*(y_top_c - ybar)**2)
    Iy = (bf_bot**3*tf_bot/12 + tw**3*hw/12 + bf_top**3*tf_top/12)

    y_top_fiber = d - ybar
    y_bot_fiber = ybar
    Sx_top = Ix/y_top_fiber if y_top_fiber > 1e-9 else 0.0
    Sx_bot = Ix/y_bot_fiber if y_bot_fiber > 1e-9 else 0.0
    Sx = min(Sx_top, Sx_bot) if Sx_top and Sx_bot else max(Sx_top, Sx_bot)
    bf_max = max(bf_top, bf_bot)
    Sy = Iy/(bf_max/2) if bf_max else 0.0

    # Módulo plástico Zx: eje de igual área (PNA), luego suma de momentos
    # estáticos de cada mitad respecto al PNA.
    y_pna = _equal_area_axis_3pl(A_bot, A_w, A_top, tf_bot, hw, tf_top)
    Zx = _plastic_modulus_3pl(bf_bot, tf_bot, tw, hw, bf_top, tf_top, y_pna)
    Zy = bf_bot**2*tf_bot/4 + tw**2*hw/4 + bf_top**2*tf_top/4

    rx = math.sqrt(Ix/A) if A else 0.0
    ry = math.sqrt(Iy/A) if A else 0.0
    J  = (bf_bot*tf_bot**3 + hw*tw**3 + bf_top*tf_top**3) / 3
    Cw = 0.0

    return {"shape":"3pl", "bf_top":bf_top, "tf_top":tf_top,
            "bf_bot":bf_bot, "tf_bot":tf_bot, "hw":hw,
            "A":A, "d":d, "bf":bf_top, "tf":tf_top, "tw":tw,
            "Ix":Ix, "Sx":Sx, "Zx":Zx, "Iy":Iy, "Sy":Sy, "Zy":Zy,
            "rx":rx, "ry":ry, "J":J, "Cw":Cw,
            "bf_top":bf_top, "tf_top":tf_top, "bf_bot":bf_bot, "tf_bot":tf_bot}


def _equal_area_axis_3pl(A_bot, A_w, A_top, tf_bot, hw, tf_top):
    """Ubica el eje de igual área (PNA) desde la base, para Zx de 3 placas."""
    A_total = A_bot + A_w + A_top
    half = A_total / 2
    if A_bot >= half:
        return (half / A_bot) * tf_bot if A_bot else 0.0
    rem = half - A_bot
    if rem <= A_w:
        tw_eff = A_w / hw if hw else 0.0
        return tf_bot + (rem / tw_eff if tw_eff else 0.0)
    rem -= A_w
    tf_top_eff = A_top / tf_top if tf_top else 0.0
    return tf_bot + hw + (rem / tf_top_eff if tf_top_eff else 0.0)


def _plastic_modulus_3pl(bf_bot, tf_bot, tw, hw, bf_top, tf_top, y_pna):
    """Suma de A_i*|y_i - y_pna| para las 3 placas, partiendo la que
    contenga al eje de igual área (PNA)."""
    d = tf_bot + hw + tf_top

    def strip_moment(y0, y1, w):
        """Momento estático de una franja [y0,y1] de ancho w respecto a y_pna."""
        lo, hi = min(y0, y1), max(y0, y1)
        a = max(lo, min(hi, y_pna))   # corte en el PNA
        Z = 0.0
        if a - lo > 1e-9:
            Z += w*(a-lo)*abs((a+lo)/2 - y_pna)
        if hi - a > 1e-9:
            Z += w*(hi-a)*abs((hi+a)/2 - y_pna)
        return Z

    return (strip_moment(0, tf_bot, bf_bot)
            + strip_moment(tf_bot, tf_bot+hw, tw)
            + strip_moment(tf_bot+hw, d, bf_top))
