﻿# ui/tab_seccion_compuesta.py  — Tab "Sección Compuesta"
from __future__ import annotations
import math
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, QPushButton,
    QComboBox, QDoubleSpinBox, QSplitter, QScrollArea, QTabWidget,
    QTextEdit, QRadioButton, QStackedWidget, QFormLayout,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QApplication, QMessageBox, QFileDialog, QInputDialog, QCheckBox, QDialog
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QColor, QKeySequence
import matplotlib.patches as mpatches

from core.composite_section import (
    transformed_concrete_steel, transformed_steel_filled,
    Ec_NTC_DEC, Ec_NTC_DEA, Ec_ACI
)
from data.steel_db import (
    get_sections_by_type, get_props, cruz_props, plates3_props,
    estimate_from_hss_rect, estimate_from_hss_round,
)
from ui.widgets import MplCanvas, NavToolbar
from ui.dialog_3pl import Dialog3PL
from fileio.word_exporter import export_tab_memory
from fileio.staad_writer import (
    connect_to_staad, export_section_to_staad, props_from_transformed_section
)
from config.settings import COLORS, STEEL_MATERIALS

P   = COLORS["primary"]
SEP = "#D4E6F1"


# ── Tabla de resultados con Ctrl+C ────────────────────────────────────────────
class ResultTable(QTableWidget):
    def __init__(self, parent=None):
        super().__init__(0, 3, parent)
        self.setHorizontalHeaderLabels(["Propiedad", "Valor", "Unidad"])
        hh = self.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setFont(QFont("Segoe UI", 8))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self._copy()
        else:
            super().keyPressEvent(event)

    def _copy(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r0 = min(r.topRow()    for r in ranges)
        r1 = max(r.bottomRow() for r in ranges)
        lines = []
        for row in range(r0, r1 + 1):
            cells = [(self.item(row, c).text() if self.item(row, c) else "") for c in range(3)]
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))


class TabSeccionCompuesta(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._result: dict = {}
        self._build_ui()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        spl = QSplitter(Qt.Horizontal)
        spl.setCollapsible(0, False)
        spl.setCollapsible(1, False)

        # ── Panel izquierdo ────────────────────────────────────────────────────
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_w = QWidget()
        left_w.setFixedWidth(310)
        lv = QVBoxLayout(left_w)
        lv.setSpacing(6)
        lv.setContentsMargins(8, 8, 8, 8)

        # Tipo
        grp_tipo = QGroupBox("Tipo de Sección Compuesta")
        tv = QVBoxLayout(grp_tipo)
        tv.setContentsMargins(8, 16, 8, 8)
        self.rb_conc = QRadioButton("Concreto + Perfil de Acero Ahogado")
        self.rb_fill = QRadioButton("Perfil de Acero Relleno de Concreto")
        self.rb_conc.setChecked(True)
        tv.addWidget(self.rb_conc)
        tv.addWidget(self.rb_fill)
        lv.addWidget(grp_tipo)

        self.stack = QStackedWidget()
        lv.addWidget(self.stack)

        # ── Página 0: Concreto + perfil ahogado ───────────────────────────────
        pg0 = QWidget()
        p0v = QVBoxLayout(pg0)
        p0v.setSpacing(6)
        p0v.setContentsMargins(0, 0, 0, 0)

        grp_conc = QGroupBox("Sección de Concreto")
        c0f = QFormLayout(grp_conc)
        c0f.setContentsMargins(8, 16, 8, 8)
        c0f.setSpacing(4)
        self.cb_shape = QComboBox()
        self.cb_shape.addItems(["Rectangular", "Circular"])
        self.dsb_b = QDoubleSpinBox(); self.dsb_b.setRange(1, 500); self.dsb_b.setValue(40); self.dsb_b.setSuffix(" cm")
        self.dsb_h = QDoubleSpinBox(); self.dsb_h.setRange(1, 500); self.dsb_h.setValue(60); self.dsb_h.setSuffix(" cm")
        self.lbl_h = QLabel("h (peralte):")
        c0f.addRow("Forma:", self.cb_shape)
        c0f.addRow("b (ancho):", self.dsb_b)
        c0f.addRow(self.lbl_h, self.dsb_h)
        self.cb_shape.currentIndexChanged.connect(self._on_shape)
        p0v.addWidget(grp_conc)

        grp_mat_c = QGroupBox("Material — Concreto")
        mf = QFormLayout(grp_mat_c)
        mf.setContentsMargins(8, 16, 8, 8)
        mf.setSpacing(4)
        self.dsb_fc = QDoubleSpinBox(); self.dsb_fc.setRange(100, 700); self.dsb_fc.setValue(250); self.dsb_fc.setSuffix(" kg/cm²")
        self.dsb_wc = QDoubleSpinBox(); self.dsb_wc.setRange(1.5, 3.0); self.dsb_wc.setValue(2.4); self.dsb_wc.setSuffix(" t/m³")
        self.cb_Ec_code = QComboBox(); self.cb_Ec_code.addItems(["NTC DEC 2024", "NTC DEA 2023", "ACI 318-25", "Manual"])
        self.dsb_Ec_manual = QDoubleSpinBox()
        self.dsb_Ec_manual.setRange(50000, 600000); self.dsb_Ec_manual.setValue(200000)
        self.dsb_Ec_manual.setSuffix(" kg/cm²"); self.dsb_Ec_manual.setDecimals(0)
        self.dsb_Ec_manual.setEnabled(False)
        self.lbl_Ec_calc = QLabel("Ec calculado: —")
        self.lbl_Ec_calc.setStyleSheet("color: #2874A6; font-style: italic; font-size: 8pt;")
        mf.addRow("f'c:", self.dsb_fc)
        mf.addRow("γc:", self.dsb_wc)
        mf.addRow("Código Ec:", self.cb_Ec_code)
        mf.addRow("Ec manual:", self.dsb_Ec_manual)
        mf.addRow("", self.lbl_Ec_calc)
        self.cb_Ec_code.currentTextChanged.connect(self._on_Ec_code_changed)
        self.dsb_fc.valueChanged.connect(self._update_Ec_label)
        self.dsb_wc.valueChanged.connect(self._update_Ec_label)
        self.dsb_Ec_manual.valueChanged.connect(self._update_Ec_label)
        p0v.addWidget(grp_mat_c)

        grp_steel0 = QGroupBox("Perfil de Acero Ahogado")
        s0f = QFormLayout(grp_steel0)
        s0f.setContentsMargins(8, 16, 8, 8)
        s0f.setSpacing(4)
        self.cb_type0 = QComboBox(); self.cb_type0.addItems(["W / IR", "Canal CE", "Cruz", "3 Placas (armada)"])
        self.cb_prof0 = QComboBox()
        self.btn_3pl = QPushButton("Definir placas…")
        self.btn_3pl.clicked.connect(self._open_dialog_3pl)
        self.btn_3pl.setVisible(False)
        self.lbl_3pl = QLabel("(sin definir)")
        self.lbl_3pl.setStyleSheet("color: #2874A6; font-style: italic; font-size: 8pt;")
        self.lbl_3pl.setVisible(False)
        self.cb_mat0  = QComboBox(); self.cb_mat0.addItems(list(STEEL_MATERIALS.keys()))
        self.dsb_dx = QDoubleSpinBox(); self.dsb_dx.setRange(-200, 200); self.dsb_dx.setValue(0); self.dsb_dx.setSuffix(" cm")
        self.dsb_dy = QDoubleSpinBox(); self.dsb_dy.setRange(-200, 200); self.dsb_dy.setValue(0); self.dsb_dy.setSuffix(" cm")
        self._plates3_dims: dict | None = None
        s0f.addRow("Tipo:", self.cb_type0)
        s0f.addRow("Perfil:", self.cb_prof0)
        s0f.addRow("", self.btn_3pl)
        s0f.addRow("", self.lbl_3pl)
        s0f.addRow("Material:", self.cb_mat0)
        s0f.addRow("Desfase ΔX:", self.dsb_dx)
        s0f.addRow("Desfase ΔY:", self.dsb_dy)
        p0v.addWidget(grp_steel0)

        # Cruz: dimensiones
        self.grp_cruz = QGroupBox("Dimensiones Cruz Cruciforme")
        cruzf = QFormLayout(self.grp_cruz)
        cruzf.setContentsMargins(8, 16, 8, 8)
        cruzf.setSpacing(4)
        self.dsb_bf_h = QDoubleSpinBox(); self.dsb_bf_h.setRange(5, 100); self.dsb_bf_h.setValue(30); self.dsb_bf_h.setSuffix(" cm")
        self.dsb_tf_h = QDoubleSpinBox(); self.dsb_tf_h.setRange(0.5, 5);  self.dsb_tf_h.setValue(1.5); self.dsb_tf_h.setSuffix(" cm")
        self.dsb_hw   = QDoubleSpinBox(); self.dsb_hw.setRange(5, 200);  self.dsb_hw.setValue(30); self.dsb_hw.setSuffix(" cm")
        self.dsb_tw   = QDoubleSpinBox(); self.dsb_tw.setRange(0.5, 5);  self.dsb_tw.setValue(1.5); self.dsb_tw.setSuffix(" cm")
        cruzf.addRow("bf_h:", self.dsb_bf_h)
        cruzf.addRow("tf_h:", self.dsb_tf_h)
        cruzf.addRow("hw:", self.dsb_hw)
        cruzf.addRow("tw:", self.dsb_tw)
        self.grp_cruz.setVisible(False)
        p0v.addWidget(self.grp_cruz)

        self.cb_type0.currentIndexChanged.connect(self._refresh_profiles0)
        self._refresh_profiles0()
        self.stack.addWidget(pg0)

        # ── Página 1: Perfil relleno ──────────────────────────────────────────
        pg1 = QWidget()
        p1v = QVBoxLayout(pg1)
        p1v.setSpacing(6)
        p1v.setContentsMargins(0, 0, 0, 0)

        grp_steel1 = QGroupBox("Perfil de Acero")
        s1f = QFormLayout(grp_steel1)
        s1f.setContentsMargins(8, 16, 8, 8)
        s1f.setSpacing(4)
        self.cb_type1 = QComboBox(); self.cb_type1.addItems(["HSS Rectangular (PTR)", "HSS Circular (PIPE/OC)"])
        self.cb_prof1 = QComboBox()
        self.chk_manual1 = QCheckBox("Captura manual de dimensiones")
        self.chk_manual1.toggled.connect(self._on_manual1_toggled)
        self.cb_mat1  = QComboBox(); self.cb_mat1.addItems(list(STEEL_MATERIALS.keys()))
        s1f.addRow("Tipo:", self.cb_type1)
        s1f.addRow("Perfil:", self.cb_prof1)
        s1f.addRow("", self.chk_manual1)
        s1f.addRow("Material:", self.cb_mat1)
        p1v.addWidget(grp_steel1)

        # Captura manual HSS/Pipe
        self.grp_manual1 = QGroupBox("Dimensiones Manuales")
        gm1 = QFormLayout(self.grp_manual1)
        gm1.setContentsMargins(8, 16, 8, 8)
        gm1.setSpacing(4)
        self.dsb_H1 = QDoubleSpinBox(); self.dsb_H1.setRange(2, 200); self.dsb_H1.setValue(20); self.dsb_H1.setSuffix(" cm")
        self.dsb_B1 = QDoubleSpinBox(); self.dsb_B1.setRange(2, 200); self.dsb_B1.setValue(20); self.dsb_B1.setSuffix(" cm")
        self.dsb_t1 = QDoubleSpinBox(); self.dsb_t1.setRange(0.2, 10); self.dsb_t1.setDecimals(3); self.dsb_t1.setValue(0.635); self.dsb_t1.setSuffix(" cm")
        self.lbl_H1 = QLabel("H (altura):")
        self.lbl_B1 = QLabel("B (ancho):")
        gm1.addRow(self.lbl_H1, self.dsb_H1)
        gm1.addRow(self.lbl_B1, self.dsb_B1)
        gm1.addRow("t (espesor pared):", self.dsb_t1)
        self.grp_manual1.setVisible(False)
        p1v.addWidget(self.grp_manual1)

        grp_mat_c1 = QGroupBox("Concreto de Relleno")
        m1f = QFormLayout(grp_mat_c1)
        m1f.setContentsMargins(8, 16, 8, 8)
        m1f.setSpacing(4)
        self.dsb_fc1 = QDoubleSpinBox(); self.dsb_fc1.setRange(100, 700); self.dsb_fc1.setValue(250); self.dsb_fc1.setSuffix(" kg/cm²")
        self.dsb_wc1 = QDoubleSpinBox(); self.dsb_wc1.setRange(1.5, 3.0); self.dsb_wc1.setValue(2.4); self.dsb_wc1.setSuffix(" t/m³")
        self.cb_Ec_code1 = QComboBox(); self.cb_Ec_code1.addItems(["NTC DEC 2024", "NTC DEA 2023", "ACI 318-25", "Manual"])
        self.dsb_Ec_manual1 = QDoubleSpinBox()
        self.dsb_Ec_manual1.setRange(50000, 600000); self.dsb_Ec_manual1.setValue(200000)
        self.dsb_Ec_manual1.setSuffix(" kg/cm²"); self.dsb_Ec_manual1.setDecimals(0)
        self.dsb_Ec_manual1.setEnabled(False)
        self.lbl_Ec_calc1 = QLabel("Ec calculado: —")
        self.lbl_Ec_calc1.setStyleSheet("color: #2874A6; font-style: italic; font-size: 8pt;")
        m1f.addRow("f'c:", self.dsb_fc1)
        m1f.addRow("γc:", self.dsb_wc1)
        m1f.addRow("Código Ec:", self.cb_Ec_code1)
        m1f.addRow("Ec manual:", self.dsb_Ec_manual1)
        m1f.addRow("", self.lbl_Ec_calc1)
        self.cb_Ec_code1.currentTextChanged.connect(self._on_Ec_code1_changed)
        self.dsb_fc1.valueChanged.connect(self._update_Ec_label1)
        self.dsb_wc1.valueChanged.connect(self._update_Ec_label1)
        self.dsb_Ec_manual1.valueChanged.connect(self._update_Ec_label1)
        p1v.addWidget(grp_mat_c1)

        self.cb_type1.currentIndexChanged.connect(self._refresh_profiles1)
        self._refresh_profiles1()
        self.stack.addWidget(pg1)

        self.rb_conc.toggled.connect(lambda c: self.stack.setCurrentIndex(0) if c else None)
        self.rb_fill.toggled.connect(lambda c: self.stack.setCurrentIndex(1) if c else None)

        # Inicializar etiquetas Ec
        self._update_Ec_label()
        self._update_Ec_label1()

        btn_calc = QPushButton("⚙  Calcular Sección Compuesta")
        btn_calc.setObjectName("btn_run")
        btn_calc.clicked.connect(self._calculate)
        lv.addWidget(btn_calc)

        self.btn_export_word = QPushButton("📄  Exportar Word")
        self.btn_export_word.setEnabled(False)
        self.btn_export_word.clicked.connect(self._export_word)
        lv.addWidget(self.btn_export_word)

        self.btn_export_staad = QPushButton("📐  Exportar a STAAD")
        self.btn_export_staad.setEnabled(False)
        self.btn_export_staad.clicked.connect(self._export_staad)
        lv.addWidget(self.btn_export_staad)
        lv.addStretch()
        left_scroll.setWidget(left_w)

        # ── Panel derecho ──────────────────────────────────────────────────────
        right_tabs = QTabWidget()

        # Vista + Resultados lado a lado
        tab_vista = QWidget()
        tv_layout = QHBoxLayout(tab_vista)
        tv_layout.setContentsMargins(4, 4, 4, 4)

        inner_spl = QSplitter(Qt.Horizontal)
        inner_spl.setCollapsible(0, False)
        inner_spl.setCollapsible(1, False)

        canvas_w = QWidget()
        cv = QVBoxLayout(canvas_w)
        cv.setContentsMargins(0, 0, 0, 0)
        self.canvas = MplCanvas(figsize=(5, 5), dpi=90)
        self.toolbar = NavToolbar(self.canvas, canvas_w)
        cv.addWidget(self.toolbar)
        cv.addWidget(self.canvas)

        self.res_table = ResultTable()

        inner_spl.addWidget(canvas_w)
        inner_spl.addWidget(self.res_table)
        inner_spl.setStretchFactor(0, 1)
        inner_spl.setStretchFactor(1, 1)
        inner_spl.setSizes([480, 380])
        tv_layout.addWidget(inner_spl)
        right_tabs.addTab(tab_vista, "Vista de la Sección")

        # Memoria
        tab_mem = QWidget()
        mv = QVBoxLayout(tab_mem)
        mv.setContentsMargins(4, 4, 4, 4)
        self.mem_text = QTextEdit()
        self.mem_text.setReadOnly(True)
        self.mem_text.setFont(QFont("Consolas", 8))
        mv.addWidget(self.mem_text)
        right_tabs.addTab(tab_mem, "Memoria de Cálculo")

        spl.addWidget(left_scroll)
        spl.addWidget(right_tabs)
        spl.setStretchFactor(0, 0)
        spl.setStretchFactor(1, 1)
        spl.setSizes([310, 880])
        root.addWidget(spl)

    # ── Helpers ────────────────────────────────────────────────────────────────
    def _on_shape(self):
        is_circ = self.cb_shape.currentIndex() == 1
        self.lbl_h.setVisible(not is_circ)
        self.dsb_h.setVisible(not is_circ)

    # Página 0 — Ec
    def _on_Ec_code_changed(self, text: str):
        is_manual = text == "Manual"
        self.dsb_Ec_manual.setEnabled(is_manual)
        self._update_Ec_label()

    def _update_Ec_label(self):
        ec = self._get_Ec(self.dsb_fc.value(), self.dsb_wc.value(), self.cb_Ec_code)
        self.lbl_Ec_calc.setText(f"Ec = {ec:,.0f} kg/cm²")

    # Página 1 — Ec
    def _on_Ec_code1_changed(self, text: str):
        is_manual = text == "Manual"
        self.dsb_Ec_manual1.setEnabled(is_manual)
        self._update_Ec_label1()

    def _update_Ec_label1(self):
        ec = self._get_Ec(self.dsb_fc1.value(), self.dsb_wc1.value(), self.cb_Ec_code1)
        self.lbl_Ec_calc1.setText(f"Ec = {ec:,.0f} kg/cm²")

    def _get_Ec(self, fc: float, wc: float, combo: QComboBox) -> float:
        code = combo.currentText()
        if code == "Manual":
            # determinar cuál spinbox usar según el combo
            if combo is self.cb_Ec_code:
                return self.dsb_Ec_manual.value()
            else:
                return self.dsb_Ec_manual1.value()
        if "ACI" in code:
            return Ec_ACI(fc, wc)
        elif "DEA" in code:
            return Ec_NTC_DEA(fc)
        return Ec_NTC_DEC(fc, wc)

    def _refresh_profiles0(self):
        t = self.cb_type0.currentText()
        is_cruz = "Cruz" in t
        is_3pl  = "3 Placas" in t
        self.grp_cruz.setVisible(is_cruz)
        self.btn_3pl.setVisible(is_3pl)
        self.lbl_3pl.setVisible(is_3pl)
        self.cb_prof0.setVisible(not is_cruz and not is_3pl)
        self.cb_prof0.setEnabled(not is_cruz and not is_3pl)
        if is_cruz or is_3pl:
            self.cb_prof0.clear()
            return
        key = "W" if "W" in t else "C"
        profs = get_sections_by_type(key)
        self.cb_prof0.clear()
        self.cb_prof0.addItems(profs if profs else ["(sin datos)"])

    def _open_dialog_3pl(self):
        dlg = Dialog3PL(self, initial=self._plates3_dims)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._plates3_dims = dlg.get_dimensions()
            d = self._plates3_dims
            self.lbl_3pl.setText(
                f"bf_top={d['bf_top']:.1f} tf_top={d['tf_top']:.2f} | "
                f"bf_bot={d['bf_bot']:.1f} tf_bot={d['tf_bot']:.2f} | "
                f"hw={d['hw']:.1f} tw={d['tw']:.2f}"
            )

    def _refresh_profiles1(self):
        t = self.cb_type1.currentText()
        key = "HSS_RECT" if "Rectangular" in t else "HSS_CIRC"
        profs = get_sections_by_type(key)
        self.cb_prof1.clear()
        self.cb_prof1.addItems(profs if profs else ["(sin datos)"])
        is_circ = "Circular" in t
        self.lbl_H1.setText("D (diámetro):" if is_circ else "H (altura):")
        self.lbl_B1.setVisible(not is_circ)
        self.dsb_B1.setVisible(not is_circ)

    def _on_manual1_toggled(self, checked: bool):
        self.cb_prof1.setVisible(not checked)
        self.grp_manual1.setVisible(checked)

    def _get_steel_props1(self) -> dict | None:
        if self.chk_manual1.isChecked():
            if "Circular" in self.cb_type1.currentText():
                return estimate_from_hss_round(self.dsb_H1.value(), self.dsb_t1.value())
            return estimate_from_hss_rect(self.dsb_H1.value(), self.dsb_B1.value(), self.dsb_t1.value())
        name = self.cb_prof1.currentText()
        if not name or name == "(sin datos)":
            return None
        return get_props(name)

    def _get_steel_props(self) -> dict | None:
        t = self.cb_type0.currentText()
        if "Cruz" in t:
            return cruz_props(
                self.dsb_bf_h.value(), self.dsb_tf_h.value(),
                self.dsb_hw.value(), self.dsb_tw.value()
            )
        if "3 Placas" in t:
            if not self._plates3_dims:
                return None
            d = self._plates3_dims
            return plates3_props(d["bf_top"], d["tf_top"], d["bf_bot"],
                                  d["tf_bot"], d["hw"], d["tw"])
        name = self.cb_prof0.currentText()
        if not name or name == "(sin datos)":
            return None
        sp = get_props(name)
        if sp is not None:
            sp = dict(sp)
            sp["shape"] = "canal" if ("Canal" in t or "CE" in t) else "I"
        return sp

    # ── Cálculo ────────────────────────────────────────────────────────────────
    def _calculate(self):
        try:
            if self.rb_conc.isChecked():
                self._calc_conc_ahogado()
            else:
                self._calc_steel_filled()
            if self._result:
                self.btn_export_word.setEnabled(True)
                self.btn_export_staad.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self, "Error en cálculo", str(e))

    def _export_word(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar memoria de cálculo", "", "Word (*.docx)"
        )
        if not path:
            return
        result = export_tab_memory(self, path)
        if result.startswith("ERROR"):
            QMessageBox.critical(self, "Exportar Word", result)
        else:
            QMessageBox.information(self, "Exportar Word", f"Documento creado:\n{result}")

    def _export_staad(self):
        if not self._result:
            return
        name, ok = QInputDialog.getText(self, "Exportar a STAAD",
                                         "Nombre de la sección en STAAD:",
                                         text="SECC_COMP")
        if not ok or not name.strip():
            return
        unit, ok = QInputDialog.getItem(self, "Exportar a STAAD",
                                         "Unidad de longitud activa en el modelo STAAD:",
                                         ["m", "cm", "in", "ft"], 0, False)
        if not ok:
            return
        ok2, msg, staad = connect_to_staad()
        if not ok2:
            QMessageBox.critical(self, "Exportar a STAAD", msg)
            return
        props = props_from_transformed_section(self._result)
        ok3, msg2 = export_section_to_staad(staad, props, name.strip(), unit)
        if ok3:
            QMessageBox.information(self, "Exportar a STAAD", msg2)
        else:
            QMessageBox.critical(self, "Exportar a STAAD", msg2)

    def _calc_conc_ahogado(self):
        sp = self._get_steel_props()
        if sp is None:
            QMessageBox.warning(self, "Sin perfil", "Seleccione un perfil de acero válido.")
            return

        mat  = STEEL_MATERIALS[self.cb_mat0.currentText()]
        Es   = mat["E"]
        fc   = self.dsb_fc.value()
        wc   = self.dsb_wc.value()
        Ec   = self._get_Ec(fc, wc, self.cb_Ec_code)
        shape = "circ" if self.cb_shape.currentIndex() == 1 else "rect"
        d1   = self.dsb_b.value()
        d2   = self.dsb_h.value() if shape == "rect" else 0.0

        ec_code = self.cb_Ec_code.currentText()
        res = transformed_concrete_steel(shape, d1, d2, sp, fc, Es, Ec,
                                         self.dsb_dx.value(), self.dsb_dy.value())
        res.update({"fc": fc, "Ec": Ec, "Es": Es, "ec_code": ec_code,
                    "shape": shape, "d1": d1, "d2": d2,
                    "sp": sp, "mode": "conc_ahogado"})
        self._result = res
        self._draw(res)
        self._fill_results(res)
        self._fill_memory(res)

    def _calc_steel_filled(self):
        sp = self._get_steel_props1()
        if sp is None:
            QMessageBox.warning(self, "Sin perfil", "Seleccione un perfil de acero válido.")
            return

        mat  = STEEL_MATERIALS[self.cb_mat1.currentText()]
        Es   = mat["E"]
        fc   = self.dsb_fc1.value()
        wc   = self.dsb_wc1.value()
        Ec   = self._get_Ec(fc, wc, self.cb_Ec_code1)

        ec_code = self.cb_Ec_code1.currentText()
        res = transformed_steel_filled(sp, fc, Es, Ec)
        res.update({"fc": fc, "Ec": Ec, "Es": Es, "ec_code": ec_code,
                    "sp": sp, "mode": "steel_filled"})
        self._result = res
        self._draw(res)
        self._fill_results(res)
        self._fill_memory(res)

    # ── Dibujo ─────────────────────────────────────────────────────────────────
    def _draw(self, r: dict):
        ax = self.canvas.ax
        ax.cla()
        ax.set_aspect('equal')
        ax.set_facecolor("#F8F9FA")

        sp = r.get("sp", {})
        d  = sp.get("d",  40)
        bf = sp.get("bf", 20)
        tf = sp.get("tf", 1.2)
        tw = sp.get("tw", 0.8)
        hw = d - 2 * tf

        if r["mode"] == "conc_ahogado":
            shape = r["shape"]
            d1 = r["d1"]
            d2 = r.get("d2", d1)
            # Sección de concreto
            if shape == "rect":
                rect_c = mpatches.Rectangle((0, 0), d1, d2,
                                            color="#B3C6E7", alpha=0.7, label="Concreto")
                ax.add_patch(rect_c)
                # Borde izquierdo del perfil centrado en la sección de concreto
                cx0 = d1 / 2 - bf / 2
                cy0 = d2 / 2 - d / 2
            else:
                circ = mpatches.Circle((d1 / 2, d1 / 2), d1 / 2,
                                       color="#B3C6E7", alpha=0.7, label="Concreto")
                ax.add_patch(circ)
                cx0 = d1 / 2 - bf / 2
                cy0 = d1 / 2 - d / 2
            # Perfil embebido, dibujado según su forma real
            dx_u = self.dsb_dx.value()
            dy_u = self.dsb_dy.value()
            self._draw_embedded_profile(ax, sp, cx0 + dx_u, cy0 + dy_u)
        else:
            # Perfil hueco con relleno
            self._draw_hollow_steel(ax, bf, d, tf, tw, 0, 0)
            # Relleno
            Hi = max(d - 2 * tf, 0)
            Bi = max(bf - 2 * tw, 0)
            if Hi > 0 and Bi > 0:
                inner = mpatches.Rectangle((tw, tf), Bi, Hi,
                                           color="#B3C6E7", alpha=0.7, label="Concreto relleno")
                ax.add_patch(inner)

        # Centroide
        cx = r.get("xCG", 0)
        cy = r.get("yCG", 0)
        ax.plot(cx, cy, 'r+', ms=14, mew=2.2, zorder=9,
                label=f"CG ({cx:.2f}, {cy:.2f})")
        ax.legend(fontsize=7, loc='best')
        ax.grid(True, ls=':', alpha=0.35)
        ax.autoscale()
        ax.set_xlabel("X (cm)", fontsize=8)
        ax.set_ylabel("Y (cm)", fontsize=8)
        ax.set_title("Sección Compuesta — Transformada", fontsize=9,
                     color=P, fontweight='bold')
        ax.tick_params(labelsize=7)
        self.canvas.redraw()

    def _draw_embedded_profile(self, ax, sp, x0, y0):
        """Dibuja el perfil ahogado respetando su tipo (I/W, CE, cruz, 3 placas)."""
        import matplotlib.patches as mpp
        shape = sp.get("shape", "I")
        d  = sp.get("d", 40); bf = sp.get("bf", 20)
        tf = sp.get("tf", 1.2); tw = sp.get("tw", 0.8)
        hw = d - 2 * tf

        if shape == "cruz":
            # Placa vertical + placa horizontal centradas
            ax.add_patch(mpp.Rectangle((x0 + bf/2 - tw/2, y0), tw, d,
                                       color="#1565C0", alpha=0.9, label="Acero"))
            ax.add_patch(mpp.Rectangle((x0, y0 + d/2 - tf/2), bf, tf,
                                       color="#1565C0", alpha=0.9))
        elif shape == "3pl":
            bft = sp.get("bf_top", bf); tft = sp.get("tf_top", tf)
            bfb = sp.get("bf_bot", bf); tfb = sp.get("tf_bot", tf)
            hwe = sp.get("hw", hw)
            bmx = max(bft, bfb)
            # Patín inferior
            ax.add_patch(mpp.Rectangle((x0 + bmx/2 - bfb/2, y0), bfb, tfb,
                                       color="#1565C0", alpha=0.9, label="Acero"))
            # Alma
            ax.add_patch(mpp.Rectangle((x0 + bmx/2 - tw/2, y0 + tfb), tw, hwe,
                                       color="#1565C0", alpha=0.9))
            # Patín superior
            ax.add_patch(mpp.Rectangle((x0 + bmx/2 - bft/2, y0 + tfb + hwe),
                                       bft, tft, color="#1565C0", alpha=0.9))
        elif shape == "canal":
            # Canal CE: alma vertical izquierda + dos patines
            ax.add_patch(mpp.Rectangle((x0, y0), tw, d,
                                       color="#1565C0", alpha=0.9, label="Acero"))
            ax.add_patch(mpp.Rectangle((x0, y0), bf, tf,
                                       color="#1565C0", alpha=0.9))
            ax.add_patch(mpp.Rectangle((x0, y0 + d - tf), bf, tf,
                                       color="#1565C0", alpha=0.9))
        else:
            # W / IR → perfil I
            self._draw_I_profile(ax, bf, d, tf, tw, hw, x0, y0)

    def _draw_I_profile(self, ax, bf, d, tf, tw, hw, x0, y0):
        from matplotlib.patches import Polygon as MPoly
        pts = [
            (x0,         y0),
            (x0 + bf,    y0),
            (x0 + bf,    y0 + tf),
            (x0 + bf/2 + tw/2, y0 + tf),
            (x0 + bf/2 + tw/2, y0 + tf + hw),
            (x0 + bf,    y0 + tf + hw),
            (x0 + bf,    y0 + d),
            (x0,         y0 + d),
            (x0,         y0 + tf + hw),
            (x0 + bf/2 - tw/2, y0 + tf + hw),
            (x0 + bf/2 - tw/2, y0 + tf),
            (x0,         y0 + tf),
        ]
        poly = MPoly(pts, closed=True, color="#1565C0", alpha=0.85, label="Acero")
        ax.add_patch(poly)

    def _draw_hollow_steel(self, ax, bf, d, tf, tw, x0, y0):
        outer = mpatches.Rectangle((x0, y0), bf, d,
                                   color="#1565C0", alpha=0.9, label="Acero")
        inner = mpatches.Rectangle((x0 + tw, y0 + tf),
                                   max(bf - 2*tw, 0), max(d - 2*tf, 0),
                                   color="white")
        ax.add_patch(outer)
        ax.add_patch(inner)

    # ── Tabla de resultados ────────────────────────────────────────────────────
    def _fill_results(self, r: dict):
        tbl = self.res_table
        tbl.setRowCount(0)
        n = r.get("n", 1)

        def sep(label: str):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            it = QTableWidgetItem(f"  {label}")
            it.setBackground(QColor(SEP))
            it.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
            it.setForeground(QColor(P))
            it.setFlags(Qt.ItemIsEnabled)
            tbl.setItem(ri, 0, it)
            for c in (1, 2):
                it2 = QTableWidgetItem("")
                it2.setBackground(QColor(SEP))
                it2.setFlags(Qt.ItemIsEnabled)
                tbl.setItem(ri, c, it2)

        def row(prop: str, val: str, unit: str):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            for c, (txt, align) in enumerate([
                (prop, Qt.AlignLeft | Qt.AlignVCenter),
                (val,  Qt.AlignCenter),
                (unit, Qt.AlignCenter),
            ]):
                it = QTableWidgetItem(txt)
                it.setTextAlignment(align)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                tbl.setItem(ri, c, it)

        sep("RAZÓN MODULAR")
        row("n = Es / Ec",           f"{n:.2f}",                  "—")
        row("Es (acero)",            f"{r['Es']:.0f}",            "kg/cm²")
        row("Ec (concreto)",         f"{r['Ec']:.0f}",            "kg/cm²")
        row("f'c",                   f"{r['fc']:.0f}",            "kg/cm²")

        sep("ÁREAS")
        row("Área acero (As)",       f"{r['As']:.4f}",            "cm²")
        row("Área concreto (Ac)",    f"{r['Ac']:.4f}",            "cm²")
        row("Área transformada A_tr",f"{r['A_tr']:.4f}",          "cm²")

        sep("CENTROIDE")
        row("Cx (desde origen)",     f"{r['xCG']:.4f}",           "cm")
        row("Cy (desde origen)",     f"{r['yCG']:.4f}",           "cm")

        sep("MOMENTOS DE INERCIA TRANSFORMADOS")
        row("Itr,x  (eje horizontal)", f"{r['Itr_x']:.4f}",       "cm⁴")
        row("Itr,y  (eje vertical)",   f"{r['Itr_y']:.4f}",       "cm⁴")

        sep("MÓDULOS DE SECCIÓN")
        row("S_x,sup = Itr,x / c_top", f"{r['Sx_top']:.4f}",     "cm³")
        row("S_x,inf = Itr,x / c_bot", f"{r['Sx_bot']:.4f}",     "cm³")
        row("S_y,der = Itr,y / c_der", f"{r['Sy_der']:.4f}",     "cm³")
        row("S_y,izq = Itr,y / c_izq", f"{r['Sy_izq']:.4f}",     "cm³")

        sep("RADIOS DE GIRO")
        row("r_x = √(Itr,x / A_tr)", f"{r['rx']:.4f}",           "cm")
        row("r_y = √(Itr,y / A_tr)", f"{r['ry']:.4f}",           "cm")

        sep("ÁREAS DE CORTANTE EFECTIVAS")
        row("A_vy  (alma del perfil)",  f"{r['Avy']:.4f}",        "cm²")
        row("A_vx  (patines del perf.)",f"{r['Avx']:.4f}",        "cm²")

        tbl.resizeRowsToContents()

    # ── Memoria de cálculo ─────────────────────────────────────────────────────
    def _fill_memory(self, r: dict):
        sp   = r.get("sp", {})
        modo = "Concreto con perfil ahogado" if r["mode"] == "conc_ahogado" else "Perfil relleno de concreto"
        lines = [
            "═" * 62,
            "  SECCIÓN COMPUESTA — SECCIÓN TRANSFORMADA",
            f"  Modo: {modo}",
            f"  Perfil: {sp.get('name', '—')}",
            "═" * 62,
            "",
            "1. MATERIALES",
            f"   f'c         = {r['fc']:.0f} kg/cm²",
            f"   Código Ec   = {r.get('ec_code','—')}",
            f"   Ec          = {r['Ec']:.0f} kg/cm²",
            f"   Es          = {r['Es']:.0f} kg/cm²",
            f"   n = Es/Ec   = {r['n']:.4f}",
            "",
            "2. ÁREAS",
            f"   As          = {r['As']:.4f} cm²",
            f"   Ac          = {r['Ac']:.4f} cm²",
            f"   A_tr = Ac + (n-1)·As",
            f"   A_tr        = {r['A_tr']:.4f} cm²",
            "",
            "3. CENTROIDE TRANSFORMADO",
            f"   Cx          = {r['xCG']:.4f} cm",
            f"   Cy          = {r['yCG']:.4f} cm",
            "",
            "4. INERCIA TRANSFORMADA",
            "   Itr,x = Ic,x + Ac·(yc−yCG)² + (n-1)·[Is,x + As·(ys−yCG)²]",
            f"   Itr,x       = {r['Itr_x']:.4f} cm⁴",
            f"   Itr,y       = {r['Itr_y']:.4f} cm⁴",
            "",
            "5. MÓDULOS DE SECCIÓN",
            f"   Sx,sup      = {r['Sx_top']:.4f} cm³",
            f"   Sx,inf      = {r['Sx_bot']:.4f} cm³",
            f"   Sy,der      = {r['Sy_der']:.4f} cm³",
            f"   Sy,izq      = {r['Sy_izq']:.4f} cm³",
            "",
            "6. RADIOS DE GIRO",
            f"   rx          = {r['rx']:.4f} cm",
            f"   ry          = {r['ry']:.4f} cm",
            "═" * 62,
        ]
        self.mem_text.setPlainText("\n".join(lines))
