# -*- coding: utf-8 -*-
"""
Indicador de progreso para operaciones largas (memorias, gráficas, DXF).

Uso:
    from suite_shared.busy_progress import busy_progress
    with busy_progress(self, "Generando memoria de cálculo…"):
        exportar(...)

Muestra un diálogo modal con barra animada (indeterminada) para que la
aplicación no parezca congelada durante la exportación. El diálogo se
cierra automáticamente al terminar (o si ocurre una excepción).
"""
from __future__ import annotations

from contextlib import contextmanager


@contextmanager
def busy_progress(parent=None, texto: str = "Generando documento…",
                  titulo: str = "Procesando"):
    from PySide6.QtWidgets import QProgressDialog, QApplication
    from PySide6.QtCore import Qt

    dlg = QProgressDialog(texto, None, 0, 0, parent)
    dlg.setWindowTitle(titulo)
    dlg.setWindowModality(Qt.WindowModal)
    dlg.setCancelButton(None)             # sin botón cancelar
    dlg.setMinimumDuration(0)             # aparece de inmediato
    dlg.setMinimumWidth(360)
    dlg.show()
    QApplication.processEvents()
    try:
        yield dlg
    finally:
        dlg.close()
        QApplication.processEvents()
