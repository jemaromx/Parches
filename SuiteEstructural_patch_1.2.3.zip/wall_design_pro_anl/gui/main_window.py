﻿# -*- coding: utf-8 -*-
"""
Ventana principal — WallDesignPro.

Arquitectura:
  ┌─ Header (logo + título) ──────────────────────────────────────────┐
  ├─ Left Panel (340px) ───────┬─ Right Panel (QTabWidget) ───────────┤
  │  • Archivos (Excel + .anl) │  • Resultados                        │
  │  • Acciones (botones)      │  • Resumen                           │
  │  • Log de cálculo          │  • Cort. Res. Ent.                   │
  │                            │  • Gráficas                          │
  ├────────────────────────────┴──────────────────────────────────────┤
  │  Barra de progreso (fina)                                          │
  └─ StatusBar ────────────────────────────────────────────────────────┘

Modo de operación: únicamente Archivo .anl
"""
from __future__ import annotations

import logging
import math
import os
import sys
import traceback
from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import (
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavToolbar,
)

from PySide6.QtCore    import Qt, QThread, Signal
from PySide6.QtGui     import QColor, QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QSplitter, QLabel, QPushButton, QLineEdit, QComboBox,
    QFileDialog, QMessageBox, QProgressBar, QStatusBar,
    QFrame, QGroupBox, QTabWidget, QTextEdit, QScrollArea,
    QSizePolicy,
)

from config.settings import (
    APP_NAME, APP_VERSION, APP_SUBTITLE,
    COLORS, LOG_COLORS, CRIT_BG, SOURCE_DIR,
)
from gui.styles import MAIN_STYLE, HEADER_STYLE, LOG_STYLE

log = logging.getLogger(__name__)


# ── Widget de texto con colores ───────────────────────────────────────────────

class ColoredLog(QTextEdit):
    """QTextEdit de sólo lectura con soporte de colores por segmento."""

    FG = LOG_COLORS
    BG = CRIT_BG

    def __init__(self, parent=None, wrap: bool = False):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setStyleSheet(LOG_STYLE)
        font = QFont("Consolas", 8)
        self.setFont(font)
        self.setLineWrapMode(QTextEdit.WidgetWidth if wrap else QTextEdit.NoWrap)

    def put(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto sin salto de línea con color fg y fondo opcional bg."""
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(self.FG.get(fg, self.FG[""])))
        if bg in self.BG:
            fmt.setBackground(QColor(self.BG[bg]))
        if fg in ("hdr", "sec"):
            fmt.setFontWeight(QFont.Weight.Bold)
        cursor.setCharFormat(fmt)
        cursor.insertText(text)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()

    def putln(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto + salto de línea."""
        self.put(text + "\n", fg, bg)

    def clear_log(self):
        self.clear()

    def scroll_top(self):
        self.moveCursor(QTextCursor.Start)


# ── Hilo de diseño ────────────────────────────────────────────────────────────

class DesignWorker(QThread):
    """Ejecuta todo el cálculo de diseño en un hilo secundario."""

    sig_log      = Signal(str, str)    # (texto, tag)
    sig_progress = Signal(int, str)    # (pct, mensaje)
    sig_done     = Signal(object)      # dict con todos los resultados
    sig_error    = Signal(str)         # traceback completo

    def __init__(self, excel_path: str, anl_path: str, source_dir: str, parent=None):
        super().__init__(parent)
        self.excel_path = excel_path
        self.anl_path   = anl_path
        self.source_dir = source_dir

    def _log(self, text: str, tag: str = ""):
        self.sig_log.emit(text, tag)

    def run(self):  # noqa: C901
        try:
            sd = self.source_dir
            if sd not in sys.path:
                sys.path.insert(0, sd)

            from staad_anl_parser      import ANLParser
            from wall_models           import WallData, UserInputs
            from wall_geometry         import build_plate_data, determine_direction, build_wall_levels
            from wall_design_ntc2023   import (
                design_masonry_level, design_concrete_level,
                interaction_diagram_masonry, interaction_diagram_concrete,
            )
            from wall_excel_reader     import read_user_inputs

            # 1. Excel ──────────────────────────────────────────────────────
            self._log("Leyendo parámetros del Excel...", "sec")
            inputs = read_user_inputs(self.excel_path, anl_path=None)
            self._log(
                f"  {inputs.n_walls} muros  |  "
                f"{len(inputs.floor_levels)} niveles  |  "
                f"combos diseño: {inputs.first_design_combo}–{inputs.last_design_combo}"
            )

            # 2. Cargar ANL ─────────────────────────────────────────────────
            self._log(f"\nCargando archivo .anl...", "sec")
            parser = ANLParser(self.anl_path)
            parser.load()
            self._log(f"  {len(parser.lines):,} líneas leídas.", "dim")

            # 3. Resolver grupos → IDs de placas ────────────────────────────
            if inputs.wall_group_names:
                self._log("\n  Leyendo GROUP DEFINITION desde .anl...", "sec")
                group_map = parser.find_group_plates(
                    list(inputs.wall_group_names.values())
                )
                for wname, gname in inputs.wall_group_names.items():
                    pids = group_map.get(gname.upper(), [])
                    inputs.wall_plate_ids[wname] = pids
                    if pids:
                        self._log(f"    {wname:<10} (_{gname}): {len(pids)} placas", "dim")
                    else:
                        self._log(f"    [AVISO] Grupo '_{gname}' no encontrado", "warn")
                found = sum(len(v) for v in inputs.wall_plate_ids.values())
                if found == 0:
                    raise ValueError(
                        "No se encontraron placas en ningún grupo. "
                        "Verifique los nombres en la hoja MUROS del Excel."
                    )

            # 4. Espesores (ELEMENT PROPERTY) ───────────────────────────────
            all_pids = list({pid for pids in inputs.wall_plate_ids.values()
                             for pid in pids})
            self._log(f"\n  Leyendo espesores ({len(all_pids)} placas)...", "dim")
            element_prop: dict = {}
            try:
                element_prop = parser.find_element_property(all_pids)
                self._log(
                    f"  {len(element_prop)}/{len(all_pids)} placas con espesor.", "dim")
                for tv, cnt in sorted(
                    Counter(round(v['thick'], 6)
                            for v in element_prop.values()).items()
                ):
                    self._log(f"    t={tv:.4f} m  →  {cnt} placas", "dim")
            except Exception as exc:
                self._log(f"  [AVISO] Espesores no disponibles: {exc}", "warn")

            # 5. Asignaciones de material (CONSTANTS) ───────────────────────
            self._log("  Leyendo asignaciones de material...", "dim")
            mat_assign: dict = {}
            try:
                mat_assign = parser.find_material_assignments(all_pids)
                if mat_assign:
                    for mname, cnt in sorted(Counter(mat_assign.values()).items()):
                        excel_mat = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mname.strip().upper()),
                            None,
                        )
                        flag = "✓" if excel_mat else "?"
                        tag  = "ok"  if excel_mat else "warn"
                        self._log(
                            f"    {flag} MATERIAL {mname:<14}  {cnt:>4} placas  "
                            + (f"→ Excel: {excel_mat.name}"
                               if excel_mat else "→ NO encontrado en Excel"),
                            tag,
                        )
                else:
                    self._log(
                        "  [AVISO] Sin asignaciones CONSTANTS. "
                        "Usando correlación por módulo E.", "warn")
            except Exception as exc:
                self._log(f"  [AVISO] Material no disponible: {exc}", "warn")

            # 6. Combinaciones ──────────────────────────────────────────────
            design_combos  = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            service_combos = list(range(
                inputs.first_service_combo, inputs.last_service_combo + 1))
            pp_combo   = inputs.pp_cm_cvacc_combo
            all_combos = sorted(set(design_combos + service_combos + [pp_combo]))

            walls_out    : List[WallData]            = []
            results_all  : Dict[str, Dict[str, list]] = {}
            diagrams_all : Dict[str, Dict[str, list]] = {}
            total_walls  = max(len(inputs.wall_plate_ids), 1)

            # 7. Procesar cada muro ─────────────────────────────────────────
            for wi, (wall_name, plate_ids) in enumerate(
                    inputs.wall_plate_ids.items()):

                self.sig_progress.emit(
                    int(wi / total_walls * 90),
                    f"Muro {wall_name}  ({wi+1}/{total_walls})",
                )
                self._log(
                    f"\n{'='*55}\nMuro: {wall_name}  ({len(plate_ids)} placas)",
                    "sec")

                if not plate_ids:
                    self._log("  Sin placas asignadas. Saltando.", "warn")
                    continue

                # Espesor
                thickness_excel = inputs.wall_thickness.get(wall_name, 0.15)
                if element_prop:
                    wt = [
                        element_prop[pid]["thick"]
                        for pid in plate_ids
                        if pid in element_prop
                        and element_prop[pid]["thick"] > 0
                    ]
                    if wt:
                        thickness = sum(wt) / len(wt)
                        self._log(
                            f"  Espesor (ELEMENT PROPERTY): {thickness:.4f} m  "
                            f"(Excel: {thickness_excel:.4f} m)", "dim")
                    else:
                        thickness = thickness_excel
                        self._log(
                            f"  Espesor (Excel fallback): {thickness:.4f} m", "warn")
                else:
                    thickness = thickness_excel
                    self._log(
                        f"  Espesor (Excel): {thickness:.4f} m", "dim")

                # Material
                mat = None
                if mat_assign and inputs.materials:
                    wm = [mat_assign[pid] for pid in plate_ids
                          if pid in mat_assign]
                    if wm:
                        mc = Counter(wm).most_common(1)[0][0]
                        mat = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mc.strip().upper()),
                            None,
                        )
                        if mat:
                            self._log(
                                f"  Material (CONSTANTS): {mat.name} ✓", "dim")
                        else:
                            self._log(
                                f"  [AVISO] Material STAAD '{mc}' "
                                "no en Excel.", "warn")

                if mat is None:
                    mat_name = inputs.wall_material.get(wall_name, "")
                    mat = next(
                        (m for m in inputs.materials
                         if m.name == mat_name), None)
                    if mat:
                        self._log(
                            f"  Material (Excel, por nombre): {mat.name}", "dim")
                    elif inputs.materials:
                        mat = inputs.materials[0]
                        self._log(
                            f"  [AVISO] Usando primer material: {mat.name}", "warn")

                if mat is None:
                    self._log(
                        f"  [ERROR] Sin material para {wall_name}. Saltando.", "err")
                    continue

                position = inputs.wall_positions.get(wall_name, 1)

                # PlateData
                combined: dict = {
                    pid: {'thick': element_prop[pid]['thick']}
                    for pid in plate_ids
                    if pid in element_prop
                } if element_prop else {}

                self._log("  Extrayendo geometría y esfuerzos...", "dim")
                plates = build_plate_data(
                    parser, plate_ids, all_combos, thickness,
                    combined or None,
                    material_assignments=mat_assign,
                )
                if not plates:
                    self._log("  [ERROR] No se obtuvieron placas.", "err")
                    continue

                direction = determine_direction(plates)
                self._log(
                    f"  {len(plates)} placas procesadas.  "
                    f"Dirección: {direction}  "
                    f"t_prom: {thickness:.4f} m", "dim")

                # RelTan
                sdx = sum(p.x_max - p.x_min for p in plates)
                sdz = sum(p.z_max - p.z_min for p in plates)
                den = math.sqrt(sdx**2 + sdz**2)
                if den > 1e-9:
                    rt1, rt2 = sdx / den, sdz / den
                else:
                    rt1 = 1.0 if direction == "X" else 0.0
                    rt2 = 1.0 if direction == "Z" else 0.0
                reltan = {"reltan1": rt1, "reltan2": rt2}
                inputs.wall_reltan[wall_name] = reltan
                self._log(
                    f"  reltan: {rt1:.4f} (Dir X) / {rt2:.4f} (Dir Z)", "dim")

                # Niveles
                Ht = inputs.floor_levels[0] - inputs.floor_levels[-1]
                levels = build_wall_levels(
                    plates=plates,
                    floor_levels=inputs.floor_levels,
                    direction=direction,
                    thickness=thickness,
                    all_design_combos=design_combos,
                    pp_combo=pp_combo,
                    story_shears=inputs.story_shears,
                    wall_name=wall_name,
                    reltan=reltan,
                    materials=inputs.materials,
                    service_combos=service_combos,
                )
                self._log(f"  {len(levels)} niveles construidos.", "dim")

                wall = WallData(
                    name=wall_name, position=position,
                    plate_ids=plate_ids, direction=direction,
                    levels=levels, material=mat, Ht=Ht, thickness=thickness,
                )
                walls_out.append(wall)

                # Diseñar niveles
                results_w: dict  = {}
                diagrams_w: dict = {}

                for lv in levels:
                    lv_mat   = lv.material if lv.material is not None else mat
                    mat_src  = "nivel" if lv.material is not None else "muro↓"
                    tipo_str = "Mamp." if lv_mat.tipo_material == 1 else "Conc."
                    E_lv     = [p.modulo_E for p in lv.plates if p.modulo_E > 0]
                    E_prom   = sum(E_lv) / len(E_lv) if E_lv else 0.0
                    e_tag    = "ok" if lv.material is not None else "warn"
                    self._log(
                        f"  Nivel {lv.nivel_name}: "
                        f"Lm={lv.lm:.2f}m  t={lv.thickness:.4f}m  "
                        f"Hi={lv.hi:.2f}m  E_prom={E_prom:,.0f}  "
                        f"Mat={lv_mat.name} [{tipo_str}] ({mat_src})",
                        e_tag)

                    if lv_mat.tipo_material == 1:
                        res_list = design_masonry_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, Q_duct=inputs.Q_duct,
                            position=position, service_combos=service_combos,
                        )
                        diag_pts = (
                            interaction_diagram_masonry(
                                fm=lv_mat.fm, fc=lv_mat.fc_castillos,
                                fy=lv_mat.fy_vert, Lm=lv.lm, t=lv.thickness,
                                As_castillo=max(
                                    max((r.Asc1 for r in res_list), default=4.0),
                                    4.0),
                                n_castillos=2,
                            ) if res_list else []
                        )
                    else:
                        res_list = design_concrete_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, position=position, Ht=wall.Ht,
                        )
                        if res_list:
                            asext_max = max((r.AsExt1 for r in res_list), default=4.0)
                            asv_max   = max((r.Asv   for r in res_list), default=0.0)
                            secc_tc   = res_list[0].SeccTC if res_list else 0.15 * lv.lm
                            diag_pts  = interaction_diagram_concrete(
                                fc=lv_mat.fc, fy=lv_mat.fy_vert,
                                Lm=lv.lm, t=lv.thickness, SeccTC=secc_tc,
                                AsExt=max(asext_max, 4.0),
                                Asv_total=max(asv_max * lv.lm, 8.0),
                            )
                        else:
                            diag_pts = []

                    n_ok = sum(
                        1 for r in res_list
                        if getattr(r, "cond_axial", "") in ("Si Pasa", "Tension")
                        and getattr(r, "cond_cortante", "") == "Si Pasa"
                    )
                    self._log(
                        f"    {len(res_list)} combos  |  {n_ok} OK",
                        "ok" if (n_ok == len(res_list) and res_list) else "warn")

                    results_w[lv.nivel_name]  = res_list
                    diagrams_w[lv.nivel_name] = diag_pts

                results_all[wall_name]  = results_w
                diagrams_all[wall_name] = diagrams_w

            self.sig_progress.emit(100, "Completado")
            self.sig_done.emit({
                "walls":    walls_out,
                "results":  results_all,
                "diagrams": diagrams_all,
                "inputs":   inputs,
            })

        except Exception:
            self.sig_error.emit(traceback.format_exc())


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._walls:    list = []
        self._results:  dict = {}
        self._diagrams: dict = {}
        self._inputs         = None
        self._shear_data     = {}
        self._plot_paths     = {}
        self._worker: Optional[DesignWorker] = None
        self._plot_canvas: Optional[FigureCanvas]  = None
        self._plot_toolbar: Optional[NavToolbar]   = None

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1360, 820)
        self.setStyleSheet(MAIN_STYLE)
        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_right_tabs())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([340, 1020])
        root.addWidget(splitter, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(5)
        root.addWidget(self.progress)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.lbl_badge = QLabel("  NTC 2023  ")
        self.lbl_badge.setStyleSheet(
            "background:#2874A6; color:white; padding:0 8px; border-radius:3px;")
        self.status.addPermanentWidget(self.lbl_badge)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    def _build_header(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(HEADER_STYLE)
        frame.setFixedHeight(60)
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)

        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet(
            "color:white; font-size:15pt; font-weight:bold;")
        lay.addWidget(lbl_title)

        lbl_sub = QLabel(APP_SUBTITLE)
        lbl_sub.setStyleSheet("color:#AED6F1; font-size:9pt;")
        lay.addWidget(lbl_sub)

        lay.addStretch()

        lbl_ver = QLabel(f"v{APP_VERSION}")
        lbl_ver.setStyleSheet("color:#AED6F1; font-size:8pt;")
        lay.addWidget(lbl_ver)
        return frame

    def _build_left_panel(self) -> QWidget:
        panel = QWidget()
        panel.setFixedWidth(340)
        vlay = QVBoxLayout(panel)
        vlay.setContentsMargins(8, 8, 8, 8)
        vlay.setSpacing(6)

        # ── Archivos ─────────────────────────────────────────────────────
        grp_files = QGroupBox("Archivos de entrada")
        glay = QGridLayout(grp_files)
        glay.setSpacing(6)

        glay.addWidget(QLabel("Plantilla Excel:"), 0, 0)
        self.edit_excel = QLineEdit()
        self.edit_excel.setPlaceholderText("*.xlsx")
        glay.addWidget(self.edit_excel, 0, 1)
        btn_excel = QPushButton("…")
        btn_excel.setFixedWidth(28)
        btn_excel.clicked.connect(self._browse_excel)
        glay.addWidget(btn_excel, 0, 2)

        glay.addWidget(QLabel("Archivo .anl:"), 1, 0)
        self.edit_anl = QLineEdit()
        self.edit_anl.setPlaceholderText("*.anl")
        glay.addWidget(self.edit_anl, 1, 1)
        btn_anl = QPushButton("…")
        btn_anl.setFixedWidth(28)
        btn_anl.clicked.connect(self._browse_anl)
        glay.addWidget(btn_anl, 1, 2)

        glay.setColumnStretch(1, 1)

        btn_preview = QPushButton("Previsualizar Excel")
        btn_preview.clicked.connect(self._preview_excel)
        glay.addWidget(btn_preview, 2, 0, 1, 3)

        vlay.addWidget(grp_files)

        # ── Acciones ─────────────────────────────────────────────────────
        grp_actions = QGroupBox("Acciones")
        alay = QVBoxLayout(grp_actions)
        alay.setSpacing(5)

        self.btn_run = QPushButton("▶   Calcular")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.clicked.connect(self._start_calculation)
        alay.addWidget(self.btn_run)

        btn_word = QPushButton("Resultados + Gráficas  (Word)")
        btn_word.setObjectName("btn_word")
        btn_word.clicked.connect(self._export_word)
        alay.addWidget(btn_word)

        btn_mem = QPushButton("Memoria de Cálculo  (Word)")
        btn_mem.setObjectName("btn_memory")
        btn_mem.clicked.connect(self._export_calc_memory)
        alay.addWidget(btn_mem)

        btn_plots = QPushButton("Guardar Gráficas  (PNG)")
        btn_plots.setObjectName("btn_plots")
        btn_plots.clicked.connect(self._save_plots)
        alay.addWidget(btn_plots)

        btn_clear = QPushButton("Limpiar")
        btn_clear.setObjectName("btn_clear")
        btn_clear.clicked.connect(self._clear_all)
        alay.addWidget(btn_clear)

        vlay.addWidget(grp_actions)

        # ── Log de cálculo ────────────────────────────────────────────────
        grp_log = QGroupBox("Log de cálculo")
        llay = QVBoxLayout(grp_log)
        llay.setContentsMargins(4, 4, 4, 4)

        self.log_widget = ColoredLog(wrap=True)
        llay.addWidget(self.log_widget)

        vlay.addWidget(grp_log, 1)
        return panel

    def _build_right_tabs(self) -> QTabWidget:
        self.tabs = QTabWidget()

        # Tab: Resultados
        self.tab_results = QWidget()
        self.tabs.addTab(self.tab_results, "  Resultados  ")
        self._init_tab_results()

        # Tab: Resumen
        self.tab_summary = QWidget()
        self.tabs.addTab(self.tab_summary, "  Resumen  ")
        self._init_tab_summary()

        # Tab: Cort. Res. Ent.
        self.tab_shear = QWidget()
        self.tabs.addTab(self.tab_shear, "  Cort. Res. Ent.  ")
        self._init_tab_shear()

        # Tab: Gráficas
        self.tab_plots = QWidget()
        self.tabs.addTab(self.tab_plots, "  Gráficas  ")
        self._init_tab_plots()

        return self.tabs

    # ── Pestañas ──────────────────────────────────────────────────────────────

    def _wall_selector_row(self, parent_lay: QHBoxLayout, combo_attr: str,
                           extra_btn_text: str = "", extra_slot=None):
        """Crea la barra de selección de muro + botón exportar opcional."""
        parent_lay.addWidget(QLabel("Muro:"))
        cb = QComboBox()
        cb.setFixedWidth(120)
        setattr(self, combo_attr, cb)
        parent_lay.addWidget(cb)
        parent_lay.addStretch()
        if extra_btn_text:
            btn = QPushButton(extra_btn_text)
            btn.setObjectName("btn_word")
            if extra_slot:
                btn.clicked.connect(extra_slot)
            parent_lay.addWidget(btn)

    def _init_tab_results(self):
        vlay = QVBoxLayout(self.tab_results)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        self._wall_selector_row(
            bar, "cb_res_wall",
            "Exportar Word", self._export_results_word)
        self.cb_res_wall.currentTextChanged.connect(
            lambda name: self._populate_results(name))
        vlay.addLayout(bar)

        self.res_log = ColoredLog()
        vlay.addWidget(self.res_log, 1)

    def _init_tab_summary(self):
        vlay = QVBoxLayout(self.tab_summary)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "Combinaciones críticas por nivel  "
            "(compresión · tensión · cortante · Mu · refuerzo)")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_summary_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.cb_sum_wall = QComboBox()
        self.cb_sum_wall.setFixedWidth(120)
        self.cb_sum_wall.currentTextChanged.connect(
            lambda name: self._populate_summary(name))
        # small row
        row = QHBoxLayout()
        row.addWidget(QLabel("Muro:"))
        row.addWidget(self.cb_sum_wall)
        row.addStretch()
        vlay.addLayout(row)

        self.sum_log = ColoredLog()
        vlay.addWidget(self.sum_log, 1)

    def _init_tab_shear(self):
        vlay = QVBoxLayout(self.tab_shear)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_shear_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.shear_log = ColoredLog()
        vlay.addWidget(self.shear_log, 1)

    def _init_tab_plots(self):
        vlay = QVBoxLayout(self.tab_plots)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Muro:"))
        self.cb_plot_wall = QComboBox()
        self.cb_plot_wall.setFixedWidth(110)
        self.cb_plot_wall.currentTextChanged.connect(self._on_plot_wall_change)
        ctrl.addWidget(self.cb_plot_wall)

        ctrl.addWidget(QLabel("Nivel:"))
        self.cb_plot_nivel = QComboBox()
        self.cb_plot_nivel.setFixedWidth(100)
        ctrl.addWidget(self.cb_plot_nivel)

        ctrl.addWidget(QLabel("Gráfica:"))
        self.cb_plot_type = QComboBox()
        self.cb_plot_type.addItems([
            "Interacción", "Envolvente Momentos", "Envolvente Cortantes"])
        self.cb_plot_type.setFixedWidth(180)
        ctrl.addWidget(self.cb_plot_type)

        btn_show = QPushButton("Mostrar")
        btn_show.clicked.connect(self._show_plot)
        ctrl.addWidget(btn_show)
        ctrl.addStretch()

        vlay.addLayout(ctrl)

        self.plot_container = QWidget()
        self.plot_layout    = QVBoxLayout(self.plot_container)
        self.plot_layout.setContentsMargins(0, 0, 0, 0)
        placeholder = QLabel("Ejecute el cálculo y seleccione muro + tipo de gráfica.")
        placeholder.setAlignment(Qt.AlignCenter)
        placeholder.setStyleSheet("color:#607D8B; font-size:11pt;")
        self.plot_layout.addWidget(placeholder)
        self.plot_placeholder = placeholder
        vlay.addWidget(self.plot_container, 1)

    # ── Navegación / Slots de UI ──────────────────────────────────────────────

    def _browse_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccione la plantilla Excel",
            "", "Excel (*.xlsx *.xlsm *.xls);;Todos (*.*)")
        if path:
            self.edit_excel.setText(path)

    def _browse_anl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccione el archivo de análisis STAAD Pro",
            "", "STAAD output (*.anl *.out *.ANL *.OUT);;Todos (*.*)")
        if path:
            self.edit_anl.setText(path)

    def _preview_excel(self):
        excel_path = self.edit_excel.text().strip()
        if not excel_path or not os.path.isfile(excel_path):
            QMessageBox.warning(self, "Aviso",
                                "Seleccione primero el archivo Excel.")
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_excel_reader import read_user_inputs
            inp = read_user_inputs(excel_path, anl_path=None)
            w = self.log_widget
            w.clear_log()
            w.putln("═══ RESUMEN EXCEL ═══", "sec")
            w.putln(f"  Combos diseño : {inp.first_design_combo}–{inp.last_design_combo}  "
                    f"(PP: {inp.pp_cm_cvacc_combo})")
            w.putln(f"  Factor Q       : {inp.Q_duct}")
            w.putln(f"  Niveles ({len(inp.floor_levels)}): {inp.floor_levels}")
            w.putln(f"\nMateriales ({len(inp.materials)}):", "sec")
            for m in inp.materials:
                tipo = "Mamp." if m.tipo_material == 1 else "Conc."
                w.putln(f"  {m.name:<14} [{tipo}]  "
                        f"E={m.modulo_E:,.0f}  vm={m.vm}  fm={m.fm}  fc={m.fc}", "ok")
            w.putln(f"\nMuros ({inp.n_walls}):", "sec")
            for nm in inp.wall_plate_ids:
                mat  = inp.wall_material.get(nm, "")
                pos  = inp.wall_positions.get(nm, 1)
                pids = inp.wall_plate_ids[nm]
                grp  = inp.wall_group_names.get(nm, "")
                extra = f"  Grupo=_{grp}" if grp else f"  {len(pids)} placas"
                w.putln(f"  {nm:<8} Pos={pos}  Mat={mat:<14}{extra}", "ok")
            w.putln(f"\nCortantes ({len(inp.story_shears)} niveles):", "sec")
            for niv, sh in inp.story_shears.items():
                w.putln(f"  {niv:<20} Vx={sh['Vx']:.1f} t   Vz={sh['Vz']:.1f} t")
        except Exception:
            self.log_widget.putln(f"Error al leer Excel:\n{traceback.format_exc()}",
                                  "err")

    # ── Cálculo ───────────────────────────────────────────────────────────────

    def _start_calculation(self):
        excel = self.edit_excel.text().strip()
        anl   = self.edit_anl.text().strip()

        if not excel or not os.path.isfile(excel):
            QMessageBox.critical(self, "Error",
                                 "Seleccione el archivo Excel de diseño (.xlsx).")
            return
        if not anl or not os.path.isfile(anl):
            QMessageBox.critical(self, "Error",
                                 "Seleccione el archivo de análisis STAAD Pro (.anl).")
            return

        self.btn_run.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.log_widget.clear_log()
        self.status.showMessage("  Calculando…")
        self.tabs.setCurrentWidget(self.tab_results)

        self._worker = DesignWorker(excel, anl, SOURCE_DIR, self)
        self._worker.sig_log.connect(self._on_log)
        self._worker.sig_progress.connect(self._on_progress)
        self._worker.sig_done.connect(self._on_done)
        self._worker.sig_error.connect(self._on_error)
        self._worker.finished.connect(lambda: self.btn_run.setEnabled(True))
        self._worker.start()

    def _on_log(self, text: str, tag: str):
        self.log_widget.putln(text, tag)

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self.status.showMessage(f"  {msg}")

    def _on_done(self, result: dict):
        self._walls    = result["walls"]
        self._results  = result["results"]
        self._diagrams = result["diagrams"]
        self._inputs   = result["inputs"]

        self.progress.setVisible(False)
        ts = datetime.now().strftime("%H:%M:%S")
        n  = len(self._walls)
        self.status.showMessage(
            f"  ✔  Diseño completado  ·  {n} muro(s)  ·  {ts}")
        self.log_widget.putln("\n✔  Cálculo completado exitosamente.", "ok")

        wall_names = [w.name for w in self._walls]

        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.blockSignals(True)
            cb.clear()
            cb.addItems(wall_names)
            cb.blockSignals(False)

        if wall_names:
            for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
                cb.setCurrentIndex(0)
            first = wall_names[0]
            self._populate_results(first)
            self._populate_summary(first)
            self._on_plot_wall_change(first)

        self._populate_shear()

    def _on_error(self, msg: str):
        self.progress.setVisible(False)
        self.status.showMessage("  ✗  Error en el cálculo.")
        self.log_widget.putln("\n✗  Error durante el cálculo:", "err")
        last = [l for l in msg.strip().splitlines() if l.strip()]
        if last:
            self.log_widget.putln(f"  {last[-1]}", "err")
        self.log_widget.putln("\nDetalle:", "dim")
        self.log_widget.putln(msg, "dim")

    # ── Poblar pestañas ───────────────────────────────────────────────────────

    def _populate_results(self, wall_name: str):
        self.res_log.clear_log()
        if not wall_name:
            return
        wall   = next((w for w in self._walls if w.name == wall_name), None)
        inputs = self._inputs
        if not wall or not inputs:
            return
        reltan       = inputs.wall_reltan.get(wall_name, {"reltan1": 0.0, "reltan2": 0.0})
        position_str = "Exterior" if wall.position == 1 else "Interior"
        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat = lv.material if lv.material is not None else wall.material
            if isinstance(res_list[0].__class__.__name__, str):
                pass  # won't happen
            try:
                from wall_models import DesignResultMasonry
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_masonry_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
                else:
                    self._write_concrete_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
            except ImportError:
                pass
        self.res_log.scroll_top()

    def _populate_summary(self, wall_name: str):
        self.sum_log.clear_log()
        if not wall_name:
            return
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            from wall_models import DesignResultMasonry
        except ImportError:
            return

        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat   = lv.material if lv.material is not None else wall.material
            tipo_str = "Mampostería" if (lv_mat and lv_mat.tipo_material == 1) else "Concreto"
            SEP = "=" * 120
            self.sum_log.putln(f"\n{SEP}", "hdr")
            self.sum_log.putln(
                f"  NIVEL: {lv.nivel_name}    Hi={lv.hi:.2f} m    "
                f"Lm={lv.lm:.2f} m    [{tipo_str}]    Muro: {wall.name}", "sec")
            self.sum_log.putln(f"{SEP}", "hdr")
            crit = get_critical_combos(res_list)
            if crit:
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_critical_block_masonry(self.sum_log, crit)
                else:
                    self._write_critical_block_concrete(self.sum_log, crit)
        self.sum_log.scroll_top()

    def _populate_shear(self):
        self.shear_log.clear_log()
        if not self._walls or not self._inputs:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_shear_check import compute_shear_resistente
            shear_data = compute_shear_resistente(
                self._walls, self._results, self._inputs)
            self._shear_data = shear_data
            self._render_shear(shear_data)
        except Exception:
            self.shear_log.putln(
                f"Error al calcular cortante:\n{traceback.format_exc()}", "err")

    def _render_shear(self, shear_data: dict):
        W = self.shear_log
        SEP = "=" * 155
        sep = "-" * 155
        _c = ["Muro","Material","t(m)","Lm(m)","A(m2)",
              "sCalc","3.33vm","si","0.5vm","0.3si","n*rh*fy",
              "Vr(t)","Rel.","Vres(t)"]
        _w = [10,12,6,7,7,8,8,8,7,7,9,8,6,9]
        HDR = "  " + " ".join(c.rjust(w) for c, w in zip(_c, _w))

        for direction in ('X', 'Z'):
            level_list = shear_data.get(direction, [])
            if not level_list:
                W.putln(f"\n  Dirección {direction}: sin muros contribuyentes.", "dim")
                continue
            W.putln(f"\n{SEP}", "hdr")
            W.putln(f"  DIRECCIÓN {direction}  —  Cortante Resistente por Entrepiso",
                    "sec")
            W.putln(f"  NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso", "dim")
            W.putln(f"{SEP}", "hdr")
            for lev in level_list:
                W.putln(
                    f"\n  NIVEL: {lev['nivel_name']}    "
                    f"V_entrepiso {direction} = {lev['story_shear']:.2f} ton", "sec")
                W.putln(f"{HDR}", "hdr")
                W.putln(f"{'─'*155}", "dim")
                for w in lev['walls']:
                    if w['tipo'] == 'Mamposteria':
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{w['sigcalc']:>8.4f} {w['sigma_lim']:>8.4f} "
                            f"{w['sigma_i']:>8.4f} "
                            f"{w['vm05']:>7.4f} {w['sig03']:>7.4f} "
                            f"{w['nph_fyh']:>9.4f} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                    else:
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{'—':>8} {'—':>8} {'—':>8} "
                            f"{'—':>7} {'—':>7} {'—':>9} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                W.putln(f"{'─'*155}", "dim")
                cumple   = lev['cumple']
                cond_str = "✓  CUMPLE" if cumple else "✗  NO CUMPLE"
                cond_tag = "ok" if cumple else "fail"
                W.put(
                    f"  {'Σ Vres':>20} = {lev['sum_vres']:>8.2f} ton    "
                    f"V_ent = {lev['story_shear']:>8.2f} ton    "
                    f"Ratio = {lev['ratio']:>6.3f}    "
                )
                W.putln(cond_str, cond_tag)
                W.putln(f"{sep}", "dim")

    # ── Resultados por nivel ──────────────────────────────────────────────────

    def _build_crit_map(self, res_list: list) -> dict:
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
        except ImportError:
            return {}
        if not crit:
            return {}
        crit_map: dict = {}
        for key, tag in [
            ("max_refs","crit_refs"), ("max_refv","crit_refv"),
            ("max_refc","crit_refc"), ("max_mu","crit_mu"),
            ("max_shear","crit_shear"), ("max_tens","crit_tens"),
            ("max_comp","crit_comp"),
        ]:
            r = crit.get(key)
            if r is not None:
                crit_map[r.combo] = tag
        return crit_map

    def _write_masonry_level(self, W: ColoredLog, wall, lv, res_list,
                             mat, position_str, reltan):
        r0 = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Ht_t = lv.hi / lv.thickness if lv.thickness > 0 else 0.0
        fiel1 = reltan.get("reltan1", 0.0)
        fiel2 = reltan.get("reltan2", 0.0)
        SEP = "=" * 165
        sep = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Mampostería   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Fiel: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   Hcr={lv.hi:.2f} m   "
            f"H/t={Ht_t:.2f}   H/L={HL:.4f}   "
            f"Asmin(Cast.)={r0.AsminCast:.2f} cm²   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        W.putln(
            f"  v'm={mat.vm:.2f} kg/cm²   f'm={mat.fm:.2f} kg/cm²   "
            f"f'c(Cast.)={mat.fc_castillos:.2f} kg/cm²   "
            f"fy(Vert.)={mat.fy_vert:.0f} kg/cm²   "
            f"fy(Hor.)={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            f"{'FrFlC':>6} {'Pres(t)':>9} {'AscCal':>7} {'C.P':>9} "
            f"{'Asc(cm2)':>9} {'Pt(t)':>8} {'Vres(t)':>8} "
            f"{'k0':>5} {'k1':>5} {'ns':>5} {'nEfic':>6} "
            f"{'AshH':>7} {'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            cp_fg = "ok" if r.cond_axial    in ("Si Pasa","Tension") else "fail"
            cv_fg = "ok" if r.cond_cortante == "Si Pasa"             else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                f"{r.Frflcomp:>6.2f} {r.Pr:>9.2f} {r.Asc1_calc:>7.2f} ",
                bg=bg)
            W.put(f"{r.cond_axial:>9} ", cp_fg, bg)
            W.put(
                f"{r.Asc1:>9.2f} {r.Pt_svc:>8.2f} {r.Vr:>8.2f} "
                f"{r.k0:>5.2f} {r.k11:>5.2f} {r.ns:>5.2f} {r.n:>6.2f} "
                f"{r.Ash:>7.2f} {r.Vras:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.putln(f"{r.cond_cortante:>9}", cv_fg, bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_masonry(W, crit)
        except ImportError:
            pass

    def _write_concrete_level(self, W: ColoredLog, wall, lv, res_list,
                              mat, position_str, reltan):
        r0   = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Lt   = lv.lm / lv.thickness if lv.thickness > 0 else 0.0
        L3   = lv.lm / 3.0
        fiel1= reltan.get("reltan1", 0.0)
        fiel2= reltan.get("reltan2", 0.0)
        SEP  = "=" * 165
        sep  = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Concreto   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Rel.: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   H/L={HL:.4f}   L/t={Lt:.2f}   "
            f"L/3={L3:.2f} m   Asmin(Ver.)={r0.Asvmin:.2f} cm²/m   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        W.putln(
            f"  Hi={lv.hi:.2f} m   An.Sec.Ext.={r0.SeccTC:.2f} m   "
            f"Vmax={r0.Vmax:.2f} ton   "
            f"f'c={mat.fc:.2f} kg/cm²   "
            f"fyVert.={mat.fy_vert:.0f} kg/cm²   "
            f"fyHor.={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            f"{'Pres(t)':>9} {'RefVCent':>9} {'C.P':>9} "
            f"{'AsExt1':>9} {'SecTC(m)':>9} "
            f"{'Vcr(t)':>8} {'Sep3(cm)':>9} {'Sep4(cm)':>9} "
            f"{'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            cp_fg = "ok" if r.cond_axial    in ("Si Pasa","Tension") else "fail"
            cv_fg = "ok" if r.cond_cortante == "Si Pasa"             else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                f"{r.Pres:>9.2f} {r.Asv:>9.2f} ",
                bg=bg)
            W.put(f"{r.cond_axial:>9} ", cp_fg, bg)
            W.put(
                f"{r.AsExt1:>9.2f} {r.SeccTC:>9.2f} "
                f"{r.Vcr:>8.2f} {r.Sep1:>9.2f} {r.Sep2:>9.2f} "
                f"{r.Vs:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.putln(f"{r.cond_cortante:>9}", cv_fg, bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_concrete(W, crit)
        except ImportError:
            pass

    def _write_critical_block_masonry(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   Asc1={r.Asc1:>7.2f} cm²   "
              f"Ash={r.Ash:>6.2f} cm²/m   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_axial}]", cp)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   Asc1={r.Asc1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        r = crit['max_mu']
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   Asc1={r.Asc1:>7.2f} cm²")
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Ash={r.Ash:>6.2f} cm²/m   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        W.putln(f"{sep}", "dim")

    def _write_critical_block_concrete(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r  = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   Asv={r.Asv:>7.2f} cm²/m   "
              f"VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_axial}]", cp)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   AsExt1={r.AsExt1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        r = crit['max_mu']
        req_ext = r.AsExt1 > r.Asvmin * r.SeccTC * 1.01
        mu_tag  = "warn" if req_ext else "dim"
        ext_str = (f"AsExt1={r.AsExt1:.2f} cm²"
                   if req_ext else "No se req. ref. de borde adicional")
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   SeccTC={r.SeccTC:.3f} m   "
                f"{ext_str}", mu_tag)
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vs={r.Vs:>7.2f} ton   ph={r.ph:.5f}   "
              f"Sep #3={r.Sep1:>6.1f} cm   Sep #4={r.Sep2:>6.1f} cm   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        W.putln(f"{sep}", "dim")

    # ── Gráficas ──────────────────────────────────────────────────────────────

    def _on_plot_wall_change(self, wall_name: str = ""):
        if not wall_name:
            wall_name = self.cb_plot_wall.currentText()
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if wall:
            niveles = [lv.nivel_name for lv in wall.levels]
            self.cb_plot_nivel.blockSignals(True)
            self.cb_plot_nivel.clear()
            self.cb_plot_nivel.addItems(niveles)
            self.cb_plot_nivel.blockSignals(False)
            if niveles:
                self.cb_plot_nivel.setCurrentIndex(0)

    def _show_plot(self):
        wall_name  = self.cb_plot_wall.currentText()
        nivel      = self.cb_plot_nivel.currentText()
        plot_type  = self.cb_plot_type.currentText()

        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            QMessageBox.warning(self, "Aviso", "Seleccione un muro válido.")
            return

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)

        try:
            from wall_design_plots import (
                plot_interaction_masonry, plot_interaction_concrete,
                plot_moment_envelope, plot_shear_envelope,
            )
            mat       = wall.material
            tipo      = mat.tipo_material if mat else 1
            results_w = self._results.get(wall_name, {})
            diag_w    = self._diagrams.get(wall_name, {})

            if plot_type == "Interacción":
                diag_pts = diag_w.get(nivel, [])
                demand   = [(r.Pu, r.Mu) for r in results_w.get(nivel, [])]
                fig = (plot_interaction_masonry(diag_pts, demand, nivel, wall_name)
                       if tipo == 1
                       else plot_interaction_concrete(diag_pts, demand, nivel, wall_name))
            elif plot_type == "Envolvente Momentos":
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_moment_envelope(
                    wall.levels, results_w, floor_levels, wall_name)
            else:
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_shear_envelope(
                    wall.levels, results_w, floor_levels, wall_name)

            self._embed_figure(fig)

        except Exception:
            self.log_widget.putln(
                f"Error al generar gráfica:\n{traceback.format_exc()}", "err")

    def _embed_figure(self, fig):
        # Limpiar contenedor
        if self._plot_canvas:
            self._plot_canvas.setParent(None)
            self._plot_canvas = None
        if self._plot_toolbar:
            self._plot_toolbar.setParent(None)
            self._plot_toolbar = None
        if self.plot_placeholder:
            self.plot_placeholder.setParent(None)
            self.plot_placeholder = None

        while self.plot_layout.count():
            item = self.plot_layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)

        canvas  = FigureCanvas(fig)
        toolbar = NavToolbar(canvas, self.plot_container)
        self.plot_layout.addWidget(toolbar)
        self.plot_layout.addWidget(canvas)
        canvas.draw()
        self._plot_canvas  = canvas
        self._plot_toolbar = toolbar

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _require_results(self) -> bool:
        if not self._walls:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return False
        return True

    def _export_word(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione la carpeta de salida")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            fname = os.path.join(
                output_dir,
                f"Diseno_Muros_{datetime.now():%Y%m%d_%H%M}.docx")
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall=self._plot_paths,
                output_path=fname, design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Word exportado: {os.path.basename(fname)}")
            QMessageBox.information(
                self, "Listo", f"Documento exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error exportando Word", str(exc))

    def _export_results_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resultados Word", "",
            "Word Documents (*.docx)",
            options=QFileDialog.DontConfirmOverwrite)
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall={}, output_path=fname,
                design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_summary_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resumen Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_summary_word
            export_summary_word(
                walls=self._walls, results_by_wall=self._results,
                output_path=fname)
            self.status.showMessage(f"  Resumen exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_shear_word(self):
        if not self._require_results() or not self._shear_data:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Cortante Resistente Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_shear_check_word
            export_shear_check_word(
                self._shear_data, self._inputs, fname)
            self.status.showMessage(f"  Cortante exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_calc_memory(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Memoria de Cálculo Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_calc_memory import export_calc_memory_word
            export_calc_memory_word(
                walls=self._walls, results_by_wall=self._results,
                inputs=self._inputs, output_path=fname)
            self.status.showMessage(
                f"  Memoria exportada: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Memoria exportada:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _save_plots(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione carpeta para gráficas")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_plots import save_all_plots
            for wall in self._walls:
                paths = save_all_plots(
                    wall=wall,
                    results_by_level=self._results.get(wall.name, {}),
                    output_dir=output_dir,
                    diagram_points_by_level=self._diagrams.get(wall.name, {}),
                )
                self._plot_paths[wall.name] = paths
                self.log_widget.putln(
                    f"  {wall.name}: {len(paths)} gráficas guardadas.", "ok")
            self.status.showMessage(f"  Gráficas guardadas en: {output_dir}")
            QMessageBox.information(
                self, "Listo", f"Gráficas guardadas en:\n{output_dir}")
        except Exception as exc:
            QMessageBox.critical(self, "Error guardando gráficas", str(exc))

    # ── Limpiar ───────────────────────────────────────────────────────────────

    def _clear_all(self):
        self._walls    = []
        self._results  = {}
        self._diagrams = {}
        self._inputs   = None
        self._shear_data  = {}
        self._plot_paths  = {}
        for w in (self.res_log, self.sum_log, self.shear_log, self.log_widget):
            w.clear_log()
        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.clear()
        self.progress.setVisible(False)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    # ── Cierre ────────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        if self._worker and self._worker.isRunning():
            resp = QMessageBox.question(
                self, "Cálculo en progreso",
                "El cálculo está en ejecución. ¿Desea cancelar y salir?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                event.ignore()
                return
            self._worker.terminate()
            self._worker.wait()
        event.accept()
