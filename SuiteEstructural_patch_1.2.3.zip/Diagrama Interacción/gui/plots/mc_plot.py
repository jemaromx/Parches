﻿"""Gráficas M-φ (momento-curvatura) y M-θ (momento-rotación)."""
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT
from matplotlib.figure import Figure
from PySide6.QtWidgets import QWidget, QVBoxLayout, QTabWidget, QLabel

from core.moment_curvature import MCResult, MRResult
from gui.styles import PLOT_STYLE


class MCCanvas(FigureCanvas):
    """Canvas para diagrama M-φ."""

    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(6, 4), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)

    def plot(self, result: MCResult):
        ax = self.ax
        ax.clear()
        ax.set_xlabel("Curvatura φ (1/cm)", fontsize=9)
        ax.set_ylabel("Momento M (ton·m)", fontsize=9)
        ax.set_title(f"Diagrama Momento-Curvatura — N = {result.N_ext:.2f} ton", fontsize=9)
        ax.grid(True, alpha=0.3)

        if not result.points:
            self.draw()
            return

        phis = result.phis
        Ms   = np.abs(result.Ms)

        ax.plot(phis, Ms, color="#3b82f6", lw=2.0, label="M-φ")
        ax.fill_between(phis, 0, Ms, alpha=0.08, color="#3b82f6")

        # Fluencia
        if result.phi_y > 0:
            ax.axvline(result.phi_y, color="#f59e0b", ls="--", lw=1.2,
                       label=f"φy = {result.phi_y:.2e}  My = {result.My_val:.2f} t·m")
            ax.plot(result.phi_y, result.My_val, "o", color="#f59e0b", ms=7)

        # Último
        if result.phi_u > 0:
            ax.axvline(result.phi_u, color="#ef4444", ls="--", lw=1.2,
                       label=f"φu = {result.phi_u:.2e}  Mu = {result.Mu_val:.2f} t·m")
            ax.plot(result.phi_u, result.Mu_val, "s", color="#ef4444", ms=7)

        if result.mu_phi > 0:
            ax.set_title(
                f"Diagrama M-φ — N = {result.N_ext:.2f} ton  |  μφ = {result.mu_phi:.1f}",
                fontsize=9,
            )

        ax.legend(fontsize=8)
        self.fig.tight_layout()
        self.draw()


class MRCanvas(FigureCanvas):
    """Canvas para diagrama M-θ."""

    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(6, 4), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)

    def plot(self, mr: MRResult, My: float):
        ax = self.ax
        ax.clear()
        ax.set_xlabel("Rotación θ (rad)", fontsize=9)
        ax.set_ylabel("Momento M (ton·m)", fontsize=9)
        ax.set_title("Diagrama Momento-Rotación (Haselton 2008)", fontsize=9)
        ax.grid(True, alpha=0.3)

        if mr.thetas is None or len(mr.thetas) == 0:
            self.draw()
            return

        ax.plot(mr.thetas, mr.moments, color="#10b981", lw=2.0, marker="o",
                ms=5, label="M-θ envolvente")
        ax.fill_between(mr.thetas, 0, mr.moments, alpha=0.08, color="#10b981")

        ax.axvline(mr.theta_y, color="#f59e0b", ls="--", lw=1.2,
                   label=f"θy = {mr.theta_y:.4f} rad")
        ax.axvline(mr.theta_cap, color="#ef4444", ls="--", lw=1.2,
                   label=f"θcap = {mr.theta_cap:.4f} rad")

        info = (f"EIeff = {mr.EI_eff:.2e} kg·cm²  |  "
                f"μθ = {mr.mu_theta:.1f}  |  λ = {mr.lambda_val:.0f}")
        ax.set_title(f"M-θ Haselton 2008 — {info}", fontsize=8)

        ax.legend(fontsize=8)
        self.fig.tight_layout()
        self.draw()


class MCWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        tabs = QTabWidget()

        # Tab M-φ
        w_mc = QWidget()
        lm = QVBoxLayout(w_mc)
        self.canvas_mc = MCCanvas()
        self.toolbar_mc = NavigationToolbar2QT(self.canvas_mc, w_mc)
        self.toolbar_mc.setStyleSheet("background:#F4F8FB; color:#334155;")
        lm.addWidget(self.toolbar_mc)
        lm.addWidget(self.canvas_mc)
        tabs.addTab(w_mc, "M-φ  Curvatura")

        # Tab M-θ
        w_mr = QWidget()
        lr = QVBoxLayout(w_mr)
        self.canvas_mr = MRCanvas()
        self.toolbar_mr = NavigationToolbar2QT(self.canvas_mr, w_mr)
        self.toolbar_mr.setStyleSheet("background:#F4F8FB; color:#334155;")
        lr.addWidget(self.toolbar_mr)
        lr.addWidget(self.canvas_mr)
        tabs.addTab(w_mr, "M-θ  Rotación")

        root.addWidget(tabs)

    def plot_mc(self, result: MCResult):
        self.canvas_mc.plot(result)

    def plot_mr(self, mr: MRResult, My: float = 0.0):
        self.canvas_mr.plot(mr, My)
