﻿"""
Gráfica 3D del diagrama de interacción P-Mx-My.

Muestra:
  • Superficie nominal como wireframe (curvas meridionales + anillos horizontales)
  • Superficie reducida (φ·Pn) como superficie sólida semitransparente
  • Puntos de demanda coloreados por estado (verde/rojo)
"""
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QCheckBox

from core.interaction_3d import InteractionResult
from gui.styles import PLOT_STYLE


class InteractionPlot3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(7, 6))
        self.ax = self.fig.add_subplot(111, projection="3d")
        super().__init__(self.fig)
        self.setParent(parent)
        self._result = None
        self._draw_empty()

    def _style_ax(self):
        ax = self.ax
        ax.set_xlabel("Mx (ton·m)", fontsize=9, labelpad=8)
        ax.set_ylabel("My (ton·m)", fontsize=9, labelpad=8)
        ax.set_zlabel("P (ton)", fontsize=9, labelpad=8)
        ax.set_facecolor("#FFFFFF")
        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False
        ax.xaxis.pane.set_edgecolor("#CBD5E1")
        ax.yaxis.pane.set_edgecolor("#CBD5E1")
        ax.zaxis.pane.set_edgecolor("#CBD5E1")
        ax.tick_params(colors="#334155", labelsize=8)
        ax.set_title("Diagrama de Interacción 3D — P-Mx-My",
                     color="#1B4F72", pad=10, fontsize=10)

    def _draw_empty(self):
        self.ax.clear()
        self._style_ax()
        self.draw()

    def plot_surface(self, result: InteractionResult,
                     show_nominal: bool = True,
                     show_reduced: bool = True,
                     Pu=None, Mxu=None, Myu=None, inside=None):
        self._result = result
        ax = self.ax
        ax.clear()
        self._style_ax()

        n_a, n_p = result.P_nom.shape

        # ── Superficie NOMINAL: wireframe (evita z-sort artifacts) ──
        if show_nominal:
            # Meridionales: curvas a cada ángulo (cada ~10°)
            step_a = max(1, n_a // 36)
            for i in range(0, n_a, step_a):
                ax.plot(result.Mx_nom[i, :], result.My_nom[i, :], result.P_nom[i, :],
                        color="#3b82f6", lw=0.7, alpha=0.55)
            # Anillos horizontales: curvas a cada punto P (cada ~6)
            step_p = max(1, n_p // 8)
            for j in range(0, n_p, step_p):
                ax.plot(result.Mx_nom[:, j], result.My_nom[:, j], result.P_nom[:, j],
                        color="#60a5fa", lw=0.5, alpha=0.35)

        # ── Superficie REDUCIDA: sólida con shade=False (sin artefactos de iluminación) ──
        if show_reduced:
            ax.plot_surface(
                result.Mx_red, result.My_red, result.P_red,
                alpha=0.45, color="#10b981",
                shade=False,
                edgecolor="none",
            )
            # Ribetes meridionales encima
            step_a_r = max(1, n_a // 24)
            for i in range(0, n_a, step_a_r):
                ax.plot(result.Mx_red[i, :], result.My_red[i, :], result.P_red[i, :],
                        color="#34d399", lw=0.9, alpha=0.8)

        # ── Línea de Pmax reducido ──
        theta = np.linspace(0, 2 * np.pi, 72)
        M_max = max(float(np.abs(result.Mx_red).max()),
                    float(np.abs(result.My_red).max()), 1.0)
        r_tick = M_max * 0.04
        ax.plot(r_tick * np.cos(theta), r_tick * np.sin(theta),
                np.full_like(theta, result.Pmax_red),
                color="#f59e0b", lw=1.5, ls="--", alpha=0.9)

        # ── Eje P (vertical) de referencia ──
        ax.plot([0, 0], [0, 0],
                [result.Pmax_red * 0.02, float(result.P_nom[:, 0].min()) * 0.3],
                color="#64748b", lw=1.0, ls=":")

        # ── Puntos de demanda ──
        if Pu is not None and len(Pu) > 0:
            colors = (["#22c55e" if ok else "#ef4444" for ok in inside]
                      if inside is not None else ["#fbbf24"] * len(Pu))
            ax.scatter(Mxu, Myu, Pu, c=colors, s=45, zorder=10, depthshade=False)
            for i, (p, mx, my) in enumerate(zip(Pu, Mxu, Myu)):
                ax.plot([mx, mx], [my, my], [0, p],
                        color=colors[i], lw=0.6, alpha=0.5)

        self.fig.tight_layout()
        self.draw()


class InteractionPlot3DWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        hctrl = QHBoxLayout()
        self.chk_nom = QCheckBox("Superficie nominal")
        self.chk_nom.setChecked(True)
        self.chk_red = QCheckBox("Superficie reducida (φ)")
        self.chk_red.setChecked(True)
        hctrl.addWidget(self.chk_nom)
        hctrl.addWidget(self.chk_red)
        hctrl.addStretch()
        root.addLayout(hctrl)

        self.canvas = InteractionPlot3DCanvas(self)
        self.toolbar = NavigationToolbar2QT(self.canvas, self)
        self.toolbar.setStyleSheet("background:#F4F8FB; color:#334155;")
        root.addWidget(self.toolbar)
        root.addWidget(self.canvas)

        self.chk_nom.toggled.connect(self._replot)
        self.chk_red.toggled.connect(self._replot)

        self._result = None
        self._demands = {}

    def set_result(self, result: InteractionResult,
                   Pu=None, Mxu=None, Myu=None, inside=None):
        self._result = result
        self._demands = dict(Pu=Pu, Mxu=Mxu, Myu=Myu, inside=inside)
        self._replot()

    def _replot(self):
        if self._result is None:
            return
        self.canvas.plot_surface(
            self._result,
            show_nominal=self.chk_nom.isChecked(),
            show_reduced=self.chk_red.isChecked(),
            **self._demands,
        )
