﻿"""Gráfica de curvas esfuerzo-deformación: concreto y acero."""
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT
from matplotlib.figure import Figure
from PySide6.QtWidgets import QWidget, QVBoxLayout

from core.materials import ConcreteModel, SteelModel
from gui.styles import PLOT_STYLE


class StressStrainCanvas(FigureCanvas):
    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(7, 4), tight_layout=True)
        self.ax_c = self.fig.add_subplot(121)
        self.ax_s = self.fig.add_subplot(122)
        super().__init__(self.fig)
        self.setParent(parent)
        self._draw_empty()

    def _draw_empty(self):
        for ax in [self.ax_c, self.ax_s]:
            ax.clear(); ax.grid(True, alpha=0.3)
        self.ax_c.set_title("Concreto σ-ε", fontsize=9)
        self.ax_s.set_title("Acero σ-ε", fontsize=9)
        self.draw()

    def plot(self, concrete: ConcreteModel, steel: SteelModel):
        self.ax_c.clear()
        self.ax_s.clear()

        # ── Concreto ──
        eps_c = np.linspace(0, concrete.eps_cu, 200)
        sig_c = np.vectorize(concrete.stress)(eps_c)
        self.ax_c.plot(eps_c * 1000, sig_c, color="#60a5fa", lw=2.0)
        self.ax_c.fill_between(eps_c * 1000, 0, sig_c, alpha=0.15, color="#60a5fa")
        self.ax_c.axvline(concrete.eps_0 * 1000, color="#f59e0b", ls="--", lw=1,
                          label=f"ε₀={concrete.eps_0*1000:.2f}‰")
        self.ax_c.axvline(concrete.eps_cu * 1000, color="#ef4444", ls="--", lw=1,
                          label=f"εcu={concrete.eps_cu*1000:.1f}‰")
        self.ax_c.set_xlabel("Deformación (‰)", fontsize=9)
        self.ax_c.set_ylabel("Esfuerzo (kg/cm²)", fontsize=9)
        self.ax_c.set_title(f"Concreto — f'c={concrete.fc:.0f} kg/cm²\n"
                            f"Ec={concrete.Ec:,.0f} kg/cm²", fontsize=8)
        self.ax_c.legend(fontsize=7)
        self.ax_c.grid(True, alpha=0.3)

        # ── Acero ──
        eps_s, sig_s = steel.points_curve(300)
        self.ax_s.plot(eps_s * 1000, sig_s / 1000, color="#f59e0b", lw=2.0)
        self.ax_s.fill_between(eps_s * 1000, 0, sig_s / 1000,
                               alpha=0.10, color="#f59e0b")
        self.ax_s.axhline( steel.fy  / 1000, color="#10b981", ls="--", lw=1,
                           label=f"fy={steel.fy:.0f} kg/cm²")
        self.ax_s.axhline(-steel.fy  / 1000, color="#10b981", ls="--", lw=1)
        self.ax_s.axhline( steel.fsu / 1000, color="#ef4444", ls="--", lw=1,
                           label=f"fsu={steel.fsu:.0f} kg/cm²")
        self.ax_s.set_xlabel("Deformación (‰)", fontsize=9)
        self.ax_s.set_ylabel("Esfuerzo (ton/cm²)", fontsize=9)
        self.ax_s.set_title(f"Acero — fy={steel.fy:.0f} kg/cm²\n"
                            f"Es={steel.Es/1e6:.2f}×10⁶ kg/cm²", fontsize=8)
        self.ax_s.legend(fontsize=7)
        self.ax_s.grid(True, alpha=0.3)

        self.fig.tight_layout()
        self.draw()


class StressStrainWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.canvas = StressStrainCanvas()
        tb = NavigationToolbar2QT(self.canvas, self)
        tb.setStyleSheet("background:#F4F8FB; color:#334155;")
        root.addWidget(tb)
        root.addWidget(self.canvas)

    def plot(self, concrete: ConcreteModel, steel: SteelModel):
        self.canvas.plot(concrete, steel)
