﻿"""Visualización 2D de la sección de concreto con refuerzo."""
import math
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.patches import Circle, Polygon, Rectangle
import matplotlib.patches as mpatches

from PySide6.QtWidgets import QWidget, QVBoxLayout

from core.section import SectionData
from gui.styles import PLOT_STYLE


class SectionViewCanvas(FigureCanvas):
    """Canvas Matplotlib para dibujar la sección de concreto."""

    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(5, 5), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self._draw_empty()

    def _draw_empty(self):
        self.ax.clear()
        self.ax.set_aspect("equal")
        self.ax.set_title("Vista de la sección", color="#1B4F72", pad=8)
        self.ax.set_xlabel("X (cm)", fontsize=9)
        self.ax.set_ylabel("Y (cm)", fontsize=9)
        self.ax.grid(True, alpha=0.3)
        self.draw()

    def plot_section(self, section: SectionData, angle_deg: float = 0.0):
        """Dibuja el contorno, huecos y varillas de la sección."""
        with matplotlib.rc_context(PLOT_STYLE):
            self.ax.clear()
            self.ax.set_aspect("equal")
            self.ax.set_xlabel("X (cm)", fontsize=9)
            self.ax.set_ylabel("Y (cm)", fontsize=9)
            self.ax.grid(True, alpha=0.3)

            # ── Contorno exterior ──
            if section.polygon_coords:
                poly_arr = np.array(section.polygon_coords + [section.polygon_coords[0]])
                self.ax.fill(poly_arr[:, 0], poly_arr[:, 1],
                             color="#475569", alpha=0.7, zorder=1)
                self.ax.plot(poly_arr[:, 0], poly_arr[:, 1],
                             color="#64748B", lw=1.5, zorder=2)

            # ── Huecos ──
            for hc in section.holes_coords:
                hole_arr = np.array(hc + [hc[0]])
                self.ax.fill(hole_arr[:, 0], hole_arr[:, 1],
                             color="#0f172a", alpha=1.0, zorder=3)
                self.ax.plot(hole_arr[:, 0], hole_arr[:, 1],
                             color="#f59e0b", lw=1.2, linestyle="--", zorder=4)

            # ── Varillas ──
            for bar in section.rebars:
                r = bar.db / 2 if bar.db > 0 else max(0.5, math.sqrt(bar.As / math.pi))
                circle = Circle((bar.x, bar.y), radius=r,
                                color="#ef4444", zorder=5, ec="#fca5a5", lw=0.8)
                self.ax.add_patch(circle)

            # ── Centroide ──
            self.ax.plot(section.centroid_x, section.centroid_y,
                         "+", color="#facc15", ms=12, mew=2, zorder=6)

            # ── Eje neutro (indicativo) ──
            if section.polygon_coords:
                pts = np.array(section.polygon_coords)
                margin = max(pts[:, 0].max() - pts[:, 0].min(),
                             pts[:, 1].max() - pts[:, 1].min()) * 0.6
                a = math.radians(angle_deg)
                dx = math.cos(a) * margin
                dy = math.sin(a) * margin
                cx, cy = section.centroid_x, section.centroid_y
                self.ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy],
                             color="#60a5fa", lw=1.2, ls=":", zorder=5,
                             label=f"EN α={angle_deg:.0f}°")

            # ── Información ──
            title = (f"Ag={section.Ag:.1f} cm²  |  "
                     f"Ast={section.Ast:.2f} cm²  |  ρ={section.rho*100:.2f}%")
            self.ax.set_title(title, color="#1B4F72", fontsize=9, pad=6)

            # ── Ejes de referencia ──
            for xv in [0]: self.ax.axvline(xv, color="#334155", lw=0.8, ls="-")
            for yv in [0]: self.ax.axhline(yv, color="#334155", lw=0.8, ls="-")

            self.fig.tight_layout()
            self.draw()


class SectionViewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.canvas = SectionViewCanvas(self)
        lay.addWidget(self.canvas)

    def plot_section(self, section: SectionData, angle_deg: float = 0.0):
        self.canvas.plot_section(section, angle_deg)
