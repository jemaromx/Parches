﻿"""
Cortes 2D del diagrama de interacción 3D:
  • P vs Mx   (My ≈ 0)
  • P vs My   (Mx ≈ 0)
  • Mx vs My  (a P constante / P de diseño)
"""
import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT
from matplotlib.figure import Figure
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
    QDoubleSpinBox, QCheckBox,
)

from core.interaction_3d import InteractionResult, get_pm_cut, get_constant_p_contour
from gui.styles import PLOT_STYLE


class PMCutCanvas(FigureCanvas):
    """Canvas para corte uniaxial P vs Mx o P vs My."""

    def __init__(self, axis: str, parent=None):
        self.axis = axis
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(6, 4.5), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self._draw_empty()

    def _style_ax(self):
        ax = self.ax
        ax.set_xlabel(f"{self.axis} (ton·m)", fontsize=9)
        ax.set_ylabel("P (ton)", fontsize=9)
        ax.set_title(f"Diagrama de interacción 2D — P vs {self.axis}", fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.axhline(0, color="#475569", lw=0.8)
        ax.axvline(0, color="#475569", lw=0.8)

    def _draw_empty(self):
        self.ax.clear()
        self._style_ax()
        self.draw()

    def plot(self, result: InteractionResult,
             show_nominal=True, show_reduced=True,
             Pu=None, Mxu=None, Myu=None, inside=None):
        ax = self.ax
        ax.clear()
        self._style_ax()

        if show_nominal:
            M_n, P_n = get_pm_cut(result, axis=self.axis, reduced=False)
            ax.plot(M_n, P_n, color="#3b82f6", lw=1.4, alpha=0.7, label="Nominal")

        if show_reduced:
            M_r, P_r = get_pm_cut(result, axis=self.axis, reduced=True)
            ax.plot(M_r, P_r, color="#10b981", lw=2.0, label="Reducida (φ)")
            ax.fill(M_r, P_r, color="#10b981", alpha=0.08)

        ax.axhline(result.Pmax_red, color="#f59e0b", ls="--", lw=1.0,
                   label=f"Pmax,red = {result.Pmax_red:.1f} ton")

        # Puntos de demanda proyectados en este plano 2D
        if Pu is not None and len(Pu) > 0:
            M_dem = Mxu if self.axis == "Mx" else Myu
            colors = (["#22c55e" if ok else "#ef4444" for ok in inside]
                      if inside is not None else ["#fbbf24"] * len(Pu))
            ax.scatter(M_dem, Pu, c=colors, s=35, zorder=10, linewidths=0.5,
                       edgecolors="#1e293b")

        ax.legend(fontsize=8)
        self.fig.tight_layout()
        self.draw()


class MxMyContourCanvas(FigureCanvas):
    """Canvas para corte horizontal Mx vs My a P constante."""

    def __init__(self, parent=None):
        with matplotlib.rc_context(PLOT_STYLE):
            self.fig = Figure(figsize=(6, 4.5), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self._draw_empty()

    def _style_ax(self):
        ax = self.ax
        ax.set_xlabel("Mx (ton·m)", fontsize=9)
        ax.set_ylabel("My (ton·m)", fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.axhline(0, color="#475569", lw=0.8)
        ax.axvline(0, color="#475569", lw=0.8)
        ax.set_aspect("equal", adjustable="datalim")

    def _draw_empty(self):
        self.ax.clear()
        self._style_ax()
        self.draw()

    def plot(self, result: InteractionResult, P_target: float,
             show_nominal=True, show_reduced=True,
             Pu=None, Mxu=None, Myu=None, inside=None):
        ax = self.ax
        ax.clear()
        self._style_ax()
        ax.set_title(f"Diagrama de interacción 2D — Mx vs My  (P = {P_target:.1f} ton)",
                     fontsize=9)

        if show_nominal:
            Mx_n, My_n = get_constant_p_contour(result, P_target, reduced=False)
            Mx_n = np.append(Mx_n, Mx_n[0])
            My_n = np.append(My_n, My_n[0])
            ax.plot(Mx_n, My_n, color="#3b82f6", lw=1.4, alpha=0.7, label="Nominal")

        if show_reduced:
            Mx_r, My_r = get_constant_p_contour(result, P_target, reduced=True)
            Mx_r = np.append(Mx_r, Mx_r[0])
            My_r = np.append(My_r, My_r[0])
            ax.plot(Mx_r, My_r, color="#10b981", lw=2.0, label="Reducida (φ)")
            ax.fill(Mx_r, My_r, color="#10b981", alpha=0.10)

        # Puntos de demanda en el plano Mx-My (independiente del nivel de P del corte)
        if Mxu is not None and len(Mxu) > 0:
            colors = (["#22c55e" if ok else "#ef4444" for ok in inside]
                      if inside is not None else ["#fbbf24"] * len(Mxu))
            ax.scatter(Mxu, Myu, c=colors, s=35, zorder=10, linewidths=0.5,
                       edgecolors="#1e293b")

        ax.legend(fontsize=8)
        self.fig.tight_layout()
        self.draw()


class InteractionPlot2DWidget(QWidget):
    """Widget con 3 pestañas: P-Mx, P-My, Mx-My (a P constante)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        hctrl = QHBoxLayout()
        self.chk_nom = QCheckBox("Nominal")
        self.chk_nom.setChecked(True)
        self.chk_red = QCheckBox("Reducida (φ)")
        self.chk_red.setChecked(True)
        hctrl.addWidget(self.chk_nom)
        hctrl.addWidget(self.chk_red)
        hctrl.addSpacing(20)
        hctrl.addWidget(QLabel("P de diseño para corte Mx-My (ton):"))
        self.spin_P = QDoubleSpinBox()
        self.spin_P.setRange(-1e6, 1e6)
        self.spin_P.setDecimals(2)
        self.spin_P.setSingleStep(5.0)
        hctrl.addWidget(self.spin_P)
        hctrl.addStretch()
        root.addLayout(hctrl)

        tabs = QTabWidget()

        w1 = QWidget()
        l1 = QVBoxLayout(w1)
        self.canvas_pmx = PMCutCanvas("Mx")
        self.toolbar_pmx = NavigationToolbar2QT(self.canvas_pmx, w1)
        self.toolbar_pmx.setStyleSheet("background:#F4F8FB; color:#334155;")
        l1.addWidget(self.toolbar_pmx)
        l1.addWidget(self.canvas_pmx)
        tabs.addTab(w1, "P vs Mx")

        w2 = QWidget()
        l2 = QVBoxLayout(w2)
        self.canvas_pmy = PMCutCanvas("My")
        self.toolbar_pmy = NavigationToolbar2QT(self.canvas_pmy, w2)
        self.toolbar_pmy.setStyleSheet("background:#F4F8FB; color:#334155;")
        l2.addWidget(self.toolbar_pmy)
        l2.addWidget(self.canvas_pmy)
        tabs.addTab(w2, "P vs My")

        w3 = QWidget()
        l3 = QVBoxLayout(w3)
        self.canvas_mxmy = MxMyContourCanvas()
        self.toolbar_mxmy = NavigationToolbar2QT(self.canvas_mxmy, w3)
        self.toolbar_mxmy.setStyleSheet("background:#F4F8FB; color:#334155;")
        l3.addWidget(self.toolbar_mxmy)
        l3.addWidget(self.canvas_mxmy)
        tabs.addTab(w3, "Mx vs My")

        root.addWidget(tabs)

        self.chk_nom.toggled.connect(self._replot)
        self.chk_red.toggled.connect(self._replot)
        self.spin_P.valueChanged.connect(self._replot)

        self._result  = None
        self._demands = {}

    def set_result(self, result: InteractionResult,
                   Pu=None, Mxu=None, Myu=None, inside=None):
        self._result  = result
        self._demands = dict(Pu=Pu, Mxu=Mxu, Myu=Myu, inside=inside)
        self.spin_P.blockSignals(True)
        self.spin_P.setValue(round(result.Pmax_red * 0.4, 2))
        self.spin_P.blockSignals(False)
        self._replot()

    def _replot(self):
        if self._result is None:
            return
        show_nom = self.chk_nom.isChecked()
        show_red = self.chk_red.isChecked()
        dem = self._demands
        self.canvas_pmx.plot(self._result, show_nom, show_red, **dem)
        self.canvas_pmy.plot(self._result, show_nom, show_red, **dem)
        self.canvas_mxmy.plot(self._result, self.spin_P.value(),
                              show_nom, show_red, **dem)
