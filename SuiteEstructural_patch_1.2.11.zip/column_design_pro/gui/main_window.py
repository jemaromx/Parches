﻿"""
Ventana principal — ColumnDesignPro.

Arquitectura:
  ┌─ Header (56px, azul oscuro) ──────────────────────────────────────────────┐
  ├─ Left Panel (300px, con scroll) ──┬─ Right QTabWidget (expandible) ───────┤
  │  • Fuente de datos (API / .anl)   │  • Resultados (tabla)                 │
  │  • Lista de columnas (Excel)      │  • Diagrama 3-D interacción           │
  │  • Materiales                     │                                        │
  │  • Recubrimientos                 │                                        │
  │  • Cuantías                       │                                        │
  │  • Combinaciones                  │                                        │
  │  • Código / tipo estribo          │                                        │
  │  • DXF (opcional)                 │                                        │
  │  • [▶ EJECUTAR DISEÑO]            │                                        │
  ├───────────────────────────────────┴────────────────────────────────────────┤
  │  Barra de progreso (5 px, oculta hasta cálculo)                            │
  └─ StatusBar ────────────────────────────────────────────────────────────────┘

Flujo:
  1. InputPanel recopila parámetros
  2. main_window hace pre_fetch STAAD en hilo principal (COM thread-affinity)
  3. DesignWorker (QObject + QThread) ejecuta diseño en segundo plano
  4. Resultados → ResultsWidget + InteractionPlotWidget
"""
from __future__ import annotations

import math
import os
import tempfile
import logging
from datetime import datetime

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QSplitter, QTabWidget, QLabel, QStatusBar,
    QProgressBar, QMessageBox, QFileDialog,
    QApplication, QFrame, QPushButton
)
from PySide6.QtCore import Qt, QThread, Signal, QObject
from PySide6.QtGui  import QFont

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE, COLORS
from gui.styles      import MAIN_STYLE, HEADER_STYLE
from gui.input_panel import InputPanel
from gui.results_widget   import ResultsWidget
from gui.interaction_plot import InteractionPlotWidget
from gui.summary_widget   import SummaryWidget

log = logging.getLogger(__name__)

try:
    from fileio.openstaad_reader import OpenSTAADReader
    _OPENSTAAD_AVAILABLE = True
except Exception:
    OpenSTAADReader = None          # type: ignore[assignment,misc]
    _OPENSTAAD_AVAILABLE = False


# ── Worker (hilo secundario) ──────────────────────────────────────────────────

class DesignWorker(QObject):
    """Ejecuta el diseño en un hilo secundario para no bloquear la UI."""

    progress = Signal(int, str)     # (porcentaje, mensaje)
    finished = Signal(list, object)  # (results, diagrams_data) — object: dict con numpy no convertible a QVariant
    error    = Signal(str)

    def __init__(self, params: dict, members: list, reader=None):
        super().__init__()
        self.params     = params
        self.members    = members
        self.anl_reader = reader
        self._running   = True

    def run(self):
        try:
            self._execute()
        except Exception:
            import traceback
            self.error.emit(f"Error en diseño:\n{traceback.format_exc()}")

    def stop(self):
        self._running = False

    def _execute(self):
        import logging as _lg
        _wlog = _lg.getLogger("design.worker")
        _wlog.info("Worker iniciado — %d columnas, lc %s-%s",
                   len(self.members),
                   self.params.get("lc_ini"), self.params.get("lc_fin"))
        from design.column_design import ColumnDesigner
        from design.interaction_surface import InteractionSurface

        p = self.params
        designer = ColumnDesigner(
            fc=p["fc"], fy=p["fy"],
            rec1=p["rec1"], rec2=p["rec2"],
            p_min=p["p_min"], p_max=p["p_max"],
            code=p["code"], col_type=p["col_type"],
            # Efectos de 2° orden
            segundo_orden = p.get("segundo_orden", False),
            Lu_m          = p.get("Lu_m",     3.0),
            k_factor      = p.get("k_factor", 1.0),
            beta_dns      = p.get("beta_dns", 0.60),
            arriostrado   = p.get("arriostrado", True),
            arriostrado_y = p.get("arriostrado_y", None),
            arriostrado_z = p.get("arriostrado_z", None),
            delta_s       = p.get("delta_s",  1.0),
            lambda_est    = p.get("lambda_est", 0.0),
            lambda_est_x  = p.get("lambda_est_x", 0.0),
            lambda_est_z  = p.get("lambda_est_z", 0.0),
            cm_mode       = p.get("cm_mode",   "auto"),
            cm_manual     = p.get("cm_manual", 0.85),
            lc_sostenida  = p.get("lc_sostenida", 0),
            k_per_col     = p.get("k_per_col", {}),
            # Diseño sísmico
            Q             = p.get("Q",            1),
            fy_transv     = p.get("fy_transv",    0.0),
            rebar_grade   = p.get("rebar_grade",  42),
            db_main_cm    = p.get("db_main_cm",   1.905),
            Hn_global_m   = p.get("Hn_global_m",  3.0),
        )

        lc_ids      = list(range(p["lc_ini"], p["lc_fin"] + 1))
        lc_sost     = int(p.get("lc_sostenida", 0) or 0)   # caso de carga sostenida
        all_results = []
        diagrams    = {}
        total       = len(self.members)

        for idx, member in enumerate(self.members):
            if not self._running:
                return
            mid  = member["id"]
            tipo = member.get("tipo", 1)
            pct  = int((idx / max(total, 1)) * 88)
            self.progress.emit(pct,
                f"Diseñando columna {mid} ({idx+1}/{total}) …")
            _wlog.info("Diseñando col %s (%d/%d), tipo=%d", mid, idx+1, total, tipo)

            props, forces_ini, forces_fin = self._get_member_data(mid, lc_ids)
            _wlog.info("  Col %s: B=%.2fm H=%.2fm, %d comb. cargadas",
                       mid, props.get('width',0), props.get('depth',0), len(forces_ini))

            # Carga axial sostenida (PP+CM+CVma) factorizada para β_dns automático
            Pu_sost = self._get_pu_sost(mid, lc_sost)

            if tipo == 1:
                results = designer.design_rectangular(
                    col_id=mid,
                    B_m=props["width"], H_m=props["depth"],
                    nodo_a=props.get("node_a", 0),
                    nodo_b=props.get("node_b", 0),
                    forces_ini=forces_ini,
                    forces_fin=forces_fin,
                    comb_ids=lc_ids,
                    Pu_sost_ton=Pu_sost,
                )
            else:
                results = designer.design_circular(
                    col_id=mid,
                    diam_m=props["depth"],
                    nodo_a=props.get("node_a", 0),
                    nodo_b=props.get("node_b", 0),
                    forces_ini=forces_ini,
                    forces_fin=forces_fin,
                    comb_ids=lc_ids,
                    Pu_sost_ton=Pu_sost,
                )

            all_results.extend(results)

            self.progress.emit(pct + 2,
                f"Generando diagrama col {mid} …")
            try:
                diagrams[mid] = self._gen_diagram(mid, tipo, props, results, p)
            except Exception:
                import traceback
                tb = traceback.format_exc()
                log.error("Error generando diagrama col %s:\n%s", mid, tb)
                diagrams[mid] = {
                    "nom_pts": None, "fac_pts": None,
                    "curves_nom": [], "curves_fac": [],
                    "demand": [], "As_max": 0.0, "section": None,
                    "_error": tb,
                }

        self.progress.emit(100, "Diseño completado.")
        self.finished.emit(all_results, diagrams)

    # ── Datos del miembro ─────────────────────────────────────────────────────

    def _get_member_data(self, mid: int, lc_ids: list) -> tuple:
        zero = {"Pu": 0.0, "Muy": 0.0, "Muz": 0.0,
                "Vuy": 0.0, "Vuz": 0.0, "Ttor": 0.0}
        default_props = {"width": 0.30, "depth": 0.50, "tipo": 1,
                         "node_a": 0, "node_b": 0}

        if self.anl_reader is not None:
            props = dict(self.anl_reader.get_section(mid))
            props.setdefault("node_a", 0)
            props.setdefault("node_b", 0)
            f_ini, f_fin = self.anl_reader.get_forces(mid, lc_ids)
            return props, f_ini, f_fin

        return default_props.copy(), [zero.copy() for _ in lc_ids], \
               [zero.copy() for _ in lc_ids]

    def _get_pu_sost(self, mid: int, lc_sost: int) -> float:
        """Carga axial sostenida factorizada (ton) del miembro `mid` en el
        caso de carga `lc_sost` (PP+CM+CVma). Devuelve 0.0 si no aplica —
        en ese caso el motor usa el respaldo β_dns = 0.60.

        Se toma la mayor |Pu| entre los dos extremos (la axial sostenida es
        prácticamente constante a lo largo de la columna)."""
        if not lc_sost or self.anl_reader is None:
            return 0.0
        try:
            fs_ini, fs_fin = self.anl_reader.get_forces(mid, [lc_sost])
            pu_i = abs(fs_ini[0].get("Pu", 0.0)) if fs_ini else 0.0
            pu_f = abs(fs_fin[0].get("Pu", 0.0)) if fs_fin else 0.0
            return max(pu_i, pu_f)
        except Exception:
            log.exception("No se pudo leer carga sostenida LC %s col %s",
                          lc_sost, mid)
            return 0.0

    # ── Diagrama de interacción ───────────────────────────────────────────────

    def _gen_diagram(self, mid, tipo, props, results, p):
        from design.interaction_surface import InteractionSurface

        As_max = max((r.As_total for r in results if r.cumple), default=20.0)
        Bc = props["width"] * 100
        Hc = props["depth"] * 100

        surf = InteractionSurface(
            fc=p["fc"], fy=p["fy"],
            rec1=p["rec1"], rec2=p["rec2"],
            As_total=As_max,
            code=p["code"], col_type=p["col_type"],
        )
        if tipo == 1:
            nom_pts, fac_pts, c_nom, c_fac = surf.generate_rectangular(
                Bc, Hc, n_angles=72, n_depths=60)
        else:
            nom_pts, fac_pts, c_nom, c_fac = surf.generate_circular(
                Bc, n_angles=72, n_depths=60)

        demand = [(r.Pr, r.Muz, r.Muy) for r in results]

        # ── Datos para la vista de sección (refuerzo propuesto) ──
        # Se usa la combinación crítica: la que requiere más acero ("As" máx.)
        cumplen = [r for r in results if r.cumple]
        governing = max(cumplen, key=lambda r: r.As_total, default=None)
        if governing is None and results:
            governing = max(results, key=lambda r: r.As_total)
        section = None
        if governing is not None:
            section = {
                "col_type": tipo,
                "Bc": Bc, "Hc": Hc,
                "n_var": governing.n_var,
                "var_num": getattr(governing, "var_num", 0),
                "d_var_cm": governing.d_var_cm,
                "rebar_xy": governing.rebar_xy,
                "As_total": governing.As_total,
                "rec1": governing.rec1_cm,
                "rec2": governing.rec2_cm,
                "comb_id": governing.comb_id,
            }

        return {
            "nom_pts":    nom_pts,
            "fac_pts":    fac_pts,
            "curves_nom": c_nom,
            "curves_fac": c_fac,
            "demand":     demand,
            "As_max":     As_max,
            "section":    section,
        }


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._reader      = None
        self._all_results = []
        self._diagrams    = {}
        self._worker      = None
        self._thread      = None
        self._params      = {}
        self._members     : list = []   # columnas cargadas (STAAD o manual)
        self._k_results   : dict = {}   # KFactorResult por col_id
        self._setup_window()
        self._build_ui()
        self._connect_signals()



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "column_design_pro")
        except Exception:
            pass
    def _setup_window(self):
        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1400, 820)
        self.setMinimumSize(920, 620)

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Header ────────────────────────────────────────────────────────────
        root.addWidget(self._build_header())

        # ── Splitter: InputPanel | Tabs ───────────────────────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)

        self.input_panel = InputPanel()
        self.input_panel.setMinimumWidth(270)
        self.input_panel.setMaximumWidth(360)
        splitter.addWidget(self.input_panel)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        splitter.addWidget(self.tabs)
        splitter.setSizes([300, 1100])

        root.addWidget(splitter, stretch=1)

        # ── Tabs de resultados ────────────────────────────────────────────────
        self._tab_results = ResultsWidget()
        self._tab_diagram = InteractionPlotWidget()
        self._tab_summary = SummaryWidget()
        self.tabs.addTab(self._tab_results, "  Resultados")
        self.tabs.addTab(self._tab_summary, "  Resumen")
        self.tabs.addTab(self._tab_diagram, "  Diagrama 3-D")

        # ── Barra de progreso (fina, oculta hasta el cálculo) ─────────────────
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setFixedHeight(5)
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        # ── Status bar ────────────────────────────────────────────────────────
        self._build_statusbar()

    def _build_header(self) -> QFrame:
        frame = QFrame()
        frame.setFixedHeight(60)
        frame.setStyleSheet(HEADER_STYLE)

        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)

        # Título + subtítulo
        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet(
            "color: white; font-size: 14pt; font-weight: bold;")
        lay.addWidget(lbl_title)

        lbl_sub = QLabel("Diseño de Columnas de Concreto")
        lbl_sub.setStyleSheet("color: #AED6F1; font-size: 9pt;")
        lay.addWidget(lbl_sub)

        lay.addStretch()

        # Botón exportar memoria (en el header)
        btn_mem = QPushButton("Memoria Completa (Word)")
        btn_mem.setObjectName("btn_memory")
        btn_mem.setToolTip("Exportar toda la memoria de cálculo a Word (.docx)")
        btn_mem.clicked.connect(self._export_full_memory)
        lay.addWidget(btn_mem)

        self.btn_joint_json = QPushButton("Exportar a Nudos (JSON)")
        self.btn_joint_json.setObjectName("btn_joint")
        self.btn_joint_json.setToolTip(
            "Exporta areas de acero de columnas a JSON\n"
            "para importarlas en Joint Design Pro."
        )
        self.btn_joint_json.setStyleSheet(
            "background:#1E8449; color:white; border-radius:4px; "
            "padding:5px 10px; font-weight:bold; font-size:8pt;"
        )
        self.btn_joint_json.setEnabled(False)
        self.btn_joint_json.clicked.connect(self._on_export_joint_json)
        lay.addWidget(self.btn_joint_json)

        lbl_ver = QLabel(f"v{APP_VERSION}")
        lbl_ver.setStyleSheet(
            "color: #AED6F1; font-size: 8pt; margin-left: 10px;")
        lay.addWidget(lbl_ver)

        return frame

    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)

        self.lbl_status = QLabel(f"  {APP_NAME} v{APP_VERSION}  |  Listo")
        self.lbl_status.setStyleSheet("color: white;")
        sb.addWidget(self.lbl_status, 1)

        # Badge de código (ACI / NTC)
        self.lbl_code_badge = QLabel()
        self.lbl_code_badge.setStyleSheet(
            "background: #2874A6; color: white;"
            " padding: 0 10px; border-radius: 3px; font-size: 8pt;")
        sb.addPermanentWidget(self.lbl_code_badge)

    # ── Señales ───────────────────────────────────────────────────────────────

    def _connect_signals(self):
        self.input_panel.anl_loaded.connect(self._load_anl)
        self.input_panel.staad_connected.connect(self._connect_staad)
        self.input_panel.run_requested.connect(self._run_design)
        self.input_panel.refresh_columns.connect(self._on_refresh_columns)
        self.input_panel.calc_k_requested.connect(self._on_calc_k_factors)
        self._tab_results.export_word_requested.connect(
            self._export_word_results)
        self._tab_results.export_excel_requested.connect(
            self._export_excel_results)

    # ── Carga de datos ────────────────────────────────────────────────────────

    def _load_anl(self, path: str):
        from fileio.anl_reader import ANLReader
        reader = ANLReader(path)
        ok, msg = reader.load()
        if ok:
            self._reader = reader
            lcs        = reader.get_load_cases()
            member_ids = reader.get_member_ids()
            info = (f"{len(member_ids)} secciones  |  "
                    f"{len(lcs)} combinaciones")
            if lcs:
                info += f"  ({lcs[0]}–{lcs[-1]})"
                self.input_panel.set_load_case_range(lcs[0], lcs[-1])
            self.input_panel.set_anl_info(info)

            # Pre-cargar todos los miembros del ANL como lista de columnas.
            # El usuario puede filtrar usando IDs manuales + Actualizar selección.
            members = []
            for mid in member_ids:
                try:
                    sec  = reader.get_section(mid)
                    tipo = sec.get("tipo", 1)
                except Exception:
                    tipo = 1
                members.append({"id": mid, "tipo": tipo})
            self._members = members
            self.input_panel.set_column_count(len(members))

            self._set_status(
                f"  ✓  ANL cargado — {len(member_ids)} miembro(s) — {msg}")
        else:
            QMessageBox.warning(self, "Error ANL", msg)
            self._set_status(f"  ✗  {msg}")

    def _connect_staad(self):
        if not _OPENSTAAD_AVAILABLE:
            QMessageBox.warning(
                self, "OpenSTAAD no disponible",
                "openstaadpy no está instalado.\n"
                "Use el modo 'Archivo .anl' o instale openstaadpy.")
            return

        self._set_status("  Conectando a STAAD Pro …")
        self.input_panel.set_api_info("Conectando …")
        QApplication.processEvents()

        reader = OpenSTAADReader()
        ok, msg = reader.connect()
        if ok:
            self._reader = reader
            lcs = reader.get_load_cases()
            if lcs:
                self.input_panel.set_load_case_range(lcs[0], lcs[-1])
            self.input_panel.set_api_info(f"✓  {msg}")
            self._set_status(f"  ✓  STAAD Pro conectado — {msg}")
            # Auto-leer columnas seleccionadas al conectar
            self._on_refresh_columns()
        else:
            log.warning("Conexion a STAAD Pro fallida: %s", msg[:200])
            self.input_panel.set_api_info("✗  Sin conexion — ver instrucciones")
            # Mostrar mensaje con instrucciones detalladas
            box = QMessageBox(self)
            box.setWindowTitle("No se pudo conectar a STAAD Pro")
            box.setIcon(QMessageBox.Warning)
            # Texto corto + detalle expandible
            if "PASOS REQUERIDOS" in msg:
                short = "STAAD Pro no esta disponible.\nRevise los pasos requeridos (click 'Detalles')."
                box.setText(short)
                box.setDetailedText(msg)
            else:
                box.setText(msg)
            box.exec()
            self._set_status("  ✗  STAAD Pro no disponible — abra el modelo y analice primero")

    # ── Carga de columnas desde STAAD / manual ────────────────────────────────

    @staticmethod
    def _parse_manual_ids(text: str) -> list:
        """
        Convierte texto de IDs a lista de enteros.

        Acepta:
          "1, 3, 5"      → [1, 3, 5]
          "5-10"         → [5, 6, 7, 8, 9, 10]
          "1; 3; 5-10"   → [1, 3, 5, 6, 7, 8, 9, 10]
        """
        ids: set = set()
        for token in text.replace(";", ",").split(","):
            token = token.strip()
            if not token:
                continue
            if "-" in token:
                parts = token.split("-", 1)
                try:
                    a, b = int(parts[0].strip()), int(parts[1].strip())
                    ids.update(range(min(a, b), max(a, b) + 1))
                except ValueError:
                    pass
            else:
                try:
                    ids.add(int(token))
                except ValueError:
                    pass
        return sorted(ids)

    def _build_members_for_ids(self, ids: list) -> list:
        """
        Construye lista de miembros para IDs explícitos usando el reader activo.

        Funciona tanto con OpenSTAADReader como con ANLReader (ambos exponen
        get_section()).  Determina tipo=1 (rectangular) o tipo=2 (circular)
        a partir de la sección leída.
        """
        if (_OPENSTAAD_AVAILABLE
                and OpenSTAADReader is not None
                and isinstance(self._reader, OpenSTAADReader)):
            # OpenSTAAD: usa el método dedicado que también popula el cache
            return self._reader.build_members_for_ids(ids)

        # ANL u otro reader: tipo siempre 1 (sección se relee en el worker)
        members = []
        for mid in ids:
            tipo = 1
            if self._reader is not None:
                try:
                    sec  = self._reader.get_section(mid)
                    tipo = sec.get("tipo", 1)
                except Exception:
                    pass
            members.append({"id": mid, "tipo": tipo})
        return members

    def _on_refresh_columns(self):
        """
        Lee las columnas a diseñar desde STAAD Pro, con respaldo manual.

        1) Intenta detección automática de la selección activa en STAAD Pro.
        2) Si devuelve 0 miembros y hay IDs manuales, los usa como respaldo.
        """
        params = self.input_panel.get_params()
        members = []

        # ── 1) Detección automática (solo con OpenSTAAD API) ──────────────────
        if (_OPENSTAAD_AVAILABLE
                and OpenSTAADReader is not None
                and isinstance(self._reader, OpenSTAADReader)):
            self._set_status("  Leyendo columnas seleccionadas en STAAD Pro…")
            QApplication.processEvents()
            try:
                members = self._reader.build_members_from_staad()
            except Exception as exc:
                log.exception("Error leyendo columnas seleccionadas")

        # ── 2) Respaldo: IDs manuales ─────────────────────────────────────────
        if not members:
            manual_text = params.get("manual_col_ids", "")
            if manual_text.strip():
                manual_ids = self._parse_manual_ids(manual_text)
                if manual_ids:
                    self._set_status(
                        f"  Selección automática vacía — "
                        f"cargando {len(manual_ids)} ID(s) manuales…")
                    QApplication.processEvents()
                    try:
                        members = self._build_members_for_ids(manual_ids)
                    except Exception as exc:
                        log.exception("Error cargando IDs manuales de columnas")
                        QMessageBox.critical(
                            self, "Error al leer columnas (manual)", str(exc))
                        return

        self._members = members
        n = len(members)
        self.input_panel.set_column_count(n)

        # Sincronizar tabla de K con los miembros cargados
        if members:
            mem_with_lu = []
            for m in members:
                cid = m.get("id", 0) if isinstance(m, dict) else m
                Lu  = 3.0
                if (self._reader is not None and hasattr(self._reader, "get_beam_length")):
                    try:
                        L = self._reader.get_beam_length(cid)
                        if L > 0.01:
                            Lu = L
                    except Exception:
                        pass
                mem_with_lu.append({"id": cid, "Lu_m": Lu})
            self.input_panel.update_k_table(mem_with_lu)

        if n == 0:
            self._set_status(
                "  Sin columnas — seleccione en STAAD Pro o escriba IDs en "
                "'IDs manuales' y presione '↻ Actualizar selección'")
        else:
            tipos = {}
            for m in members:
                t = m.get("tipo", 1)
                tipos[t] = tipos.get(t, 0) + 1
            resumen = (f"Rect:{tipos.get(1,0)}  "
                       f"Circ:{tipos.get(2,0)}")
            self._set_status(
                f"  {n} columna(s) cargada(s)  ·  {resumen}")

    # ── Cálculo del factor K desde STAAD ─────────────────────────────────────

    def _on_calc_k_factors(self):
        """
        Calcula los factores de longitud efectiva Ky y Kz para cada columna
        consultando STAAD Pro (propiedades de trabes en nodos extremo).

        Requiere:
          • Conexión activa vía OpenSTAAD API.
          • Columnas cargadas en self._members.
        """
        if not (_OPENSTAAD_AVAILABLE
                and OpenSTAADReader is not None
                and isinstance(self._reader, OpenSTAADReader)):
            QMessageBox.information(
                self, "Calcular K",
                "El cálculo automático de K requiere conexión activa con\n"
                "STAAD Pro (modo API OpenSTAAD).\n\n"
                "Si usa modo 'Archivo .anl', ingrese los valores K manualmente\n"
                "en la tabla de la sección 'Efectos de 2° Orden'.")
            return

        if not self._members:
            QMessageBox.warning(
                self, "Calcular K",
                "No hay columnas cargadas.\n"
                "Use '↻ Actualizar selección' primero.")
            return

        params = self.input_panel.get_params()
        braced   = params.get("arriostrado", True)
        braced_y = params.get("arriostrado_y", braced)
        braced_z = params.get("arriostrado_z", braced)
        code   = params.get("code", "NTC")

        self._set_status("  Calculando factores K desde STAAD Pro…")
        QApplication.processEvents()

        self._k_beams = getattr(self, "_k_beams", {})
        self._k_beams.clear()
        self._k_braced_code = (braced, code)
        k_dict     = {}
        k_results  = {}   # guardar KFactorResult para la memoria de cálculo
        errores    = []

        for m in self._members:
            cid  = m.get("id", 0) if isinstance(m, dict) else m
            tipo = m.get("tipo", 1) if isinstance(m, dict) else 1
            try:
                # Nodos extremo de la columna
                node_a, node_b = self._reader.get_beam_incidence(cid)

                # Sección transversal
                sec  = self._reader.get_section(cid)
                Bc_m = sec.get("width", 0.30)
                Hc_m = sec.get("depth", 0.50)

                # Calcular K — con longitud REAL de trabes encadenadas
                # (segmentos colineales sumados hasta encontrar columna;
                # volados excluidos). design/k_chain_concrete.py
                from design.k_chain_concrete import compute_k_factors_chained
                k_res = compute_k_factors_chained(
                    self._reader,
                    col_id = cid,
                    node_a = node_a,
                    node_b = node_b,
                    Bc_m   = Bc_m,
                    Hc_m   = Hc_m,
                    braced = braced,
                    braced_y = braced_y,
                    braced_z = braced_z,
                    code   = code,
                    length_overrides = getattr(self, "_k_overrides", {}),
                    beams_out = self._k_beams,
                )
                k_dict[cid]    = {"ky": k_res.Ky, "kz": k_res.Kz,
                                   "Lu_m": k_res.Lc_m}
                k_results[cid] = k_res

            except Exception as exc:
                log.exception("Error calculando K para col %d", cid)
                errores.append(f"Col {cid}: {exc}")
                k_dict[cid] = {"ky": 1.0, "kz": 1.0, "Lu_m": 3.0}

        # Actualizar tabla
        self.input_panel.set_k_values(k_dict)

        # Guardar resultados K para la memoria de cálculo
        self._k_results = k_results

        # Resumen
        if errores:
            QMessageBox.warning(
                self, "Calcular K — advertencias",
                "El cálculo terminó con errores en algunas columnas:\n\n"
                + "\n".join(errores[:10])
                + ("\n…" if len(errores) > 10 else ""))

        n_ok = len(k_dict) - len(errores)
        self._set_status(
            f"  ✓  Factor K calculado — {n_ok}/{len(self._members)} columna(s)"
            + (f"  ({len(errores)} error(es))" if errores else ""))

        # Tabla de longitudes de trabes usada en K (editable + recalcular)
        if self._k_beams:
            self._offer_k_lengths_review()

    def _offer_k_lengths_review(self):
        """Tabla editable con la longitud REAL usada por cada trabe en el
        cálculo de K. Si el usuario corrige alguna, se recalculan los K."""
        from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                       QTableWidget, QTableWidgetItem,
                                       QDialogButtonBox)
        from PySide6.QtCore import Qt as _Qt
        beams = dict(self._k_beams)
        dlg = QDialog(self)
        dlg.setWindowTitle("Longitudes de trabes — cálculo de K")
        dlg.setMinimumSize(520, 400)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Longitud REAL (columna a columna) usada por cada trabe en el "
            "cálculo del factor K.\nSi alguna longitud no es correcta, "
            "edítela y presione [Recalcular K]. Las trabes en VOLADO se "
            "excluyen del cálculo.")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        fin_lbl = {"columna": "en columna", "libre": "VOLADO (excluida)",
                   "quiebre": "quiebre/no colineal"}
        overrides = getattr(self, "_k_overrides", {})
        tblL = QTableWidget(len(beams), 3)
        tblL.setHorizontalHeaderLabels(["Trabe", "L (m)", "Terminación"])
        orden = sorted(beams.items())
        for i, (bid, (L, fin)) in enumerate(orden):
            it0 = QTableWidgetItem(str(bid))
            it0.setFlags(it0.flags() & ~_Qt.ItemIsEditable)
            it1 = QTableWidgetItem(f"{overrides.get(bid, L):.3f}")
            it2 = QTableWidgetItem(fin_lbl.get(fin, fin))
            it2.setFlags(it2.flags() & ~_Qt.ItemIsEditable)
            for c, it in enumerate((it0, it1, it2)):
                it.setTextAlignment(_Qt.AlignCenter)
                tblL.setItem(i, c, it)
        tblL.resizeColumnsToContents()
        v.addWidget(tblL)
        bb = QDialogButtonBox()
        bb.addButton("Recalcular K", QDialogButtonBox.AcceptRole)
        bb.addButton("Aceptar valores", QDialogButtonBox.RejectRole)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new_ov = dict(overrides)
        cambio = False
        for i, (bid, (L, fin)) in enumerate(orden):
            try:
                L_new = float(tblL.item(i, 1).text().replace(",", "."))
            except (ValueError, AttributeError):
                continue
            if L_new > 0 and abs(L_new - L) > 1e-4:
                new_ov[bid] = L_new
                cambio = True
        if cambio:
            self._k_overrides = new_ov
            self._on_calc_k_factors()

    # ── Ejecución del diseño ──────────────────────────────────────────────────

    def _run_design(self, params: dict):
        self._params = params
        log.info("Ejecutar diseño: code=%s fc=%s fy=%s lc=%s-%s cols=%d",
                 params.get("code"), params.get("fc"), params.get("fy"),
                 params.get("lc_ini"), params.get("lc_fin"), len(self._members))

        # ── Validar que hay columnas ──────────────────────────────────────────
        if not self._members:
            QMessageBox.warning(
                self, "Sin columnas",
                "No hay columnas cargadas para diseñar.\n\n"
                "Opciones:\n"
                "  • Conecte STAAD Pro vía API, seleccione\n"
                "    los miembros en el modelo y presione\n"
                "    '↻ Actualizar selección'\n"
                "  • O escriba los IDs en 'IDs manuales'\n"
                "    y presione '↻ Actualizar selección'")
            return

        # ── Validar fuente de datos de análisis ───────────────────────────────
        if self._reader is None:
            QMessageBox.warning(
                self, "Sin datos de análisis",
                "Conecte STAAD Pro vía API o cargue un archivo .anl.")
            return

        self._start_worker(params, self._members)

    def _start_worker(self, params: dict, members: list):
        if self._thread and self._thread.isRunning():
            self._worker.stop()
            self._thread.quit()
            self._thread.wait()

        self._tab_results.load_results([])
        self._tab_diagram.clear()
        self._tab_summary.load_results([])
        self.progress.setVisible(True)
        self.progress.setValue(0)

        # ── Pre-fetch COM en hilo principal ───────────────────────────────────
        if (_OPENSTAAD_AVAILABLE
                and OpenSTAADReader is not None
                and isinstance(self._reader, OpenSTAADReader)):
            lc_ids     = list(range(params["lc_ini"], params["lc_fin"] + 1))
            member_ids = [m["id"] for m in members]
            self._set_status(
                f"  Obteniendo fuerzas de STAAD Pro "
                f"({len(member_ids)} miembros × {len(lc_ids)} combinaciones) …")
            QApplication.processEvents()
            log.info("Pre-fetch: %d miembros, lc_ids=[%s..%s]",
                     len(member_ids), lc_ids[0] if lc_ids else "?",
                     lc_ids[-1] if lc_ids else "?")
            try:
                self._reader.pre_fetch(member_ids, lc_ids)
                log.info("Pre-fetch completado OK.")
            except Exception as exc:
                self.progress.setVisible(False)
                log.error("Error en pre_fetch STAAD Pro: %s", exc, exc_info=True)
                QMessageBox.warning(
                    self, "Error pre-fetch",
                    f"No se pudieron obtener los datos de STAAD Pro:\n{exc}\n\n"
                    f"Verifique que el rango de combinaciones coincida con su modelo.\n"
                    f"El error detallado quedó registrado en logs/column_design_pro.log")
                return

            # Advertencia si secciones usan fallback
            _fallback = [
                mid for mid in member_ids
                if (
                    abs(self._reader._section_cache.get(mid, {}).get("width",  -1) - 0.30) < 0.001
                    and
                    abs(self._reader._section_cache.get(mid, {}).get("depth",  -1) - 0.50) < 0.001
                )
            ]
            if _fallback:
                n_f = len(_fallback)
                preview = ", ".join(map(str, _fallback[:12]))
                if n_f > 12:
                    preview += " …"
                QMessageBox.warning(
                    self,
                    "Secciones no leídas desde STAAD Pro",
                    f"{n_f} de {len(member_ids)} miembro(s) usan la sección "
                    f"por defecto 30 × 50 cm porque la API Property de STAAD "
                    f"Pro no devolvió YD / ZD.\n\nMiembros afectados: {preview}")
                self._set_status(
                    f"  ⚠  {n_f} sección(es) usan fallback 30×50")

        # Actualizar badge de código
        self.lbl_code_badge.setText(f"  {params.get('code','?')}  ")

        # Inyectar resultados K en params para que el worker y el exportador los usen
        params["k_results"] = self._k_results

        self._thread = QThread()
        self._worker = DesignWorker(params, members, self._reader)
        self._worker.moveToThread(self._thread)

        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.finished.connect(
            lambda: self.progress.setVisible(False))

        self._set_status("  Calculando …")
        self._thread.start()

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self._set_status(f"  {msg}")
        QApplication.processEvents()

    def _on_finished(self, results: list, diagrams: dict):
        self.progress.setVisible(False)
        self._all_results = results
        self._diagrams    = diagrams
        passes = sum(1 for r in results if r.cumple)
        log.info("Diseño completado: %d resultados, %d cumplen", len(results), passes)

        self._tab_results.load_results(results)
        self._tab_summary.load_results(results)
        self.btn_joint_json.setEnabled(bool(results))

        failed = [cid for cid, d in diagrams.items() if d.get("_error")]
        if failed:
            errs = "\n\n".join(
                f"Col {cid}:\n{diagrams[cid]['_error']}"
                for cid in failed
            )
            QMessageBox.warning(
                self, "Error en diagrama de interacción",
                f"No se generaron diagramas para {len(failed)} columna(s):\n\n{errs}"
            )

        for col_id, data in diagrams.items():
            if data.get("nom_pts") is not None:
                self._tab_diagram.add_column(
                    col_id,
                    data["nom_pts"],
                    data["fac_pts"],
                    data.get("curves_nom", []),
                    data.get("curves_fac", []),
                    data["demand"],
                    data.get("section"),
                )

        dxf_path   = self._params.get("dxf_path", "")
        reduce_pct = self._params.get("reduce_pct", 0.0)
        export_dxf = self._params.get("export_dxf", True)
        if export_dxf and dxf_path and os.path.exists(dxf_path):
            self._process_dxf(dxf_path, reduce_pct)

        passes = sum(1 for r in results if r.cumple)
        ts = datetime.now().strftime("%H:%M:%S")
        self._set_status(
            f"  ✓  Diseño completado  ·  {len(results)} combinaciones"
            f"  |  {passes} cumplen  ·  {ts}")

    def _on_error(self, msg: str):
        self.progress.setVisible(False)
        self._set_status("  ✗  Error en el diseño")
        log.error("Error en el hilo de diseño: %s", msg)
        QMessageBox.critical(self, "Error en diseño", msg)

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _export_word_results(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar resultados a Word",
            "resultados_columnas.docx", "Word (*.docx)")
        if not path or not self._all_results:
            return
        diags = self._save_diagram_images()
        from fileio.word_exporter import WordExporter
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Exportando resultados a Word…"):
            ok = WordExporter().export_results_table(
            self._all_results, self._params, path)
        if ok:
            QMessageBox.information(self, "Exportado",
                                    f"Tabla guardada en:\n{path}")
        self._cleanup_diagram_images(diags)

    def _export_excel_results(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar resultados a Excel",
            "resultados_columnas.xlsx", "Excel (*.xlsx)")
        if path and self._tab_results.export_to_excel(path):
            QMessageBox.information(self, "Exportado",
                                    f"Excel guardado en:\n{path}")

    def _export_full_memory(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar memoria de cálculo",
            "memoria_columnas.docx", "Word (*.docx)")
        if not path or not self._all_results:
            return
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Generando memoria de cálculo…\n"
                                 "Renderizando diagramas de interacción…"):
            diags = self._save_diagram_images()
            from fileio.word_exporter import WordExporter
            WordExporter().export_full_calculations(
                self._all_results, self._params, diags, path)
        QMessageBox.information(self, "Exportado",
                                f"Memoria guardada en:\n{path}")
        self._cleanup_diagram_images(diags)

    def _save_diagram_images(self) -> dict:
        diags = {}
        for col_id in self._diagrams:
            tmp = tempfile.NamedTemporaryFile(
                suffix=".png", delete=False, prefix=f"col{col_id}_")
            tmp.close()
            self._tab_diagram._load_column(col_id)
            self._tab_diagram.save_figure(tmp.name, dpi=150)
            # Incluir datos de superficie para el diagrama 2-D en Word
            d = self._diagrams.get(col_id, {})
            diags[col_id] = {
                "fig_path":   tmp.name,
                "curves_fac": d.get("curves_fac", []),
                "curves_nom": d.get("curves_nom", []),
                "fac_pts":    d.get("fac_pts", None),
            }
        return diags

    # ── Exportar a Joint Design Pro ───────────────────────────────────────────

    def _on_export_joint_json(self):
        """Exporta areas de acero de columnas al formato JSON para joint_design_pro."""
        if not self._all_results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute primero el diseno de columnas.")
            return
        model_name = self._params.get("staad_file", "modelo.std")
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar JSON para Joint Design Pro",
            f"column_results_{os.path.splitext(os.path.basename(model_name))[0]}.json",
            "JSON (*.json)",
        )
        if not path:
            return
        try:
            from fileio.joint_exporter import export_column_results_json
            export_column_results_json(self._all_results, model_name, path)
            QMessageBox.information(
                self, "Exportado",
                f"Archivo JSON generado:\n{path}\n\n"
                "Importelo en Joint Design Pro desde la\n"
                "pestana 'Topologia y Acero'."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _cleanup_diagram_images(self, diags: dict):
        for d in diags.values():
            p = d.get("fig_path", "")
            if p and os.path.exists(p):
                try:
                    os.unlink(p)
                except Exception:
                    pass

    def _process_dxf(self, dxf_path: str, reduce_pct: float):
        from fileio.dxf_processor import DXFProcessor
        proc = DXFProcessor(dxf_path)
        ok, msg = proc.load()
        if not ok:
            self._set_status(f"  DXF: {msg}")
            return
        summary = self._tab_results.get_max_steel_per_column()
        members = [{"id": mid} for mid in summary]
        stats   = proc.update_beam_labels(members, summary)
        if reduce_pct != 0:
            n = proc.reduce_line_lengths(reduce_pct)
            self._set_status(
                f"  DXF: {stats['replaced']} etiquetas, {n} líneas modificadas.")
        else:
            self._set_status(
                f"  DXF: {stats['replaced']} etiquetas actualizadas.")
        out = dxf_path.replace(".dxf", "_actualizado.dxf")
        proc.save(out)

    # ── Helper ────────────────────────────────────────────────────────────────

    def _set_status(self, msg: str):
        self.lbl_status.setText(msg)

    def closeEvent(self, event):
        if self._thread and self._thread.isRunning():
            resp = QMessageBox.question(
                self, "Diseño en progreso",
                "El diseño está en ejecución. ¿Desea cancelar y salir?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                event.ignore()
                return
            self._worker.stop()
            self._thread.quit()
            self._thread.wait(2000)
        event.accept()
