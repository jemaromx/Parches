# -*- coding: utf-8 -*-
"""
Guardar / Abrir proyecto — gestor genérico para todos los módulos de la suite.

Un "proyecto" es un JSON (*.sdp) con el estado de TODOS los widgets de
captura de la ventana principal: QLineEdit, QTextEdit/QPlainTextEdit,
QSpinBox, QDoubleSpinBox, QComboBox, QCheckBox, QRadioButton, QGroupBox
"checables" y QTableWidget (incluidos combos/checks dentro de celdas).

Uso en cada módulo (al final del __init__ de la ventana principal):

    from suite_shared.project_io import instalar_gestor_proyecto
    instalar_gestor_proyecto(self, "wall_design_pro",
                             tablas_dinamicas={"tbl_mamp": self._add_mamp_row})

`tablas_dinamicas` (opcional) indica cómo agregar filas a tablas cuyo
renglón lleva widgets embebidos (combos, checks): al abrir un proyecto se
invoca esa función tantas veces como filas guardadas haya, de modo que los
widgets de celda existan antes de restaurar sus valores. Para tablas sin
widgets de celda se usa insertRow() genérico.

Los resultados calculados NO se guardan: al abrir un proyecto se recuperan
las entradas y se vuelve a ejecutar el diseño.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)

EXTENSION = "sdp"          # Suite de Diseño estructural — Proyecto
_FORMATO = 1


# ─────────────────────────────────────────────────────────────────────────────
# Identificación estable de widgets
# ─────────────────────────────────────────────────────────────────────────────

def _ruta_widget(w, raiz) -> str:
    """Ruta estable de un widget dentro de la ventana (clase:índice/…)."""
    partes = []
    actual = w
    while actual is not None and actual is not raiz:
        padre = actual.parent()
        if padre is None:
            partes.append(type(actual).__name__)
            break
        hermanos = [h for h in padre.children()
                    if type(h).__name__ == type(actual).__name__]
        idx = hermanos.index(actual) if actual in hermanos else 0
        nombre = actual.objectName()
        etiqueta = (f"{type(actual).__name__}#{nombre}" if nombre
                    else f"{type(actual).__name__}:{idx}")
        partes.append(etiqueta)
        actual = padre
    return "/".join(reversed(partes))


def _widgets_entrada(win):
    """Widgets de captura de la ventana, con ruta estable."""
    from PySide6.QtWidgets import (
        QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox,
        QComboBox, QCheckBox, QRadioButton, QTableWidget, QGroupBox)

    clases = (QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox,
              QComboBox, QCheckBox, QRadioButton, QTableWidget, QGroupBox)
    encontrados, vistos = [], set()
    for cls in clases:
        for w in win.findChildren(cls):
            if id(w) not in vistos and type(w) in clases:
                vistos.add(id(w))
                encontrados.append(w)
    resultado = {}
    for w in encontrados:
        # Ignorar widgets embebidos en celdas de tabla (se guardan con
        # la tabla) y los de solo lectura evidentes.
        padre = w.parent()
        dentro_tabla = False
        while padre is not None:
            if type(padre).__name__ == "QTableWidget":
                dentro_tabla = True
                break
            padre = padre.parent()
        if dentro_tabla and not isinstance(w, QTableWidget):
            continue
        if isinstance(w, QGroupBox) and not w.isCheckable():
            continue
        if isinstance(w, (QTextEdit, QPlainTextEdit)) and w.isReadOnly():
            continue
        if isinstance(w, QLineEdit) and w.isReadOnly():
            continue
        resultado[_ruta_widget(w, win)] = w
    return resultado


# ─────────────────────────────────────────────────────────────────────────────
# Serialización por tipo
# ─────────────────────────────────────────────────────────────────────────────

def _valor_de(w):
    from PySide6.QtWidgets import (
        QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox,
        QComboBox, QCheckBox, QRadioButton, QTableWidget, QGroupBox)

    if isinstance(w, QLineEdit):
        return {"t": "line", "v": w.text()}
    if isinstance(w, (QTextEdit, QPlainTextEdit)):
        return {"t": "text", "v": w.toPlainText()}
    if isinstance(w, QSpinBox):
        return {"t": "int", "v": w.value()}
    if isinstance(w, QDoubleSpinBox):
        return {"t": "float", "v": w.value()}
    if isinstance(w, QComboBox):
        return {"t": "combo", "v": w.currentIndex()}
    if isinstance(w, (QCheckBox, QRadioButton)):
        return {"t": "check", "v": w.isChecked()}
    if isinstance(w, QGroupBox):
        return {"t": "group", "v": w.isChecked()}
    if isinstance(w, QTableWidget):
        return _tabla_a_dict(w)
    return None


def _tabla_a_dict(tbl):
    from PySide6.QtWidgets import QComboBox, QCheckBox
    filas = tbl.rowCount()
    cols = tbl.columnCount()
    celdas = [[(tbl.item(r, c).text() if tbl.item(r, c) else None)
               for c in range(cols)] for r in range(filas)]
    widgets = {}
    for r in range(filas):
        for c in range(cols):
            cw = tbl.cellWidget(r, c)
            if cw is None:
                continue
            combo = cw if isinstance(cw, QComboBox) else \
                cw.findChild(QComboBox)
            check = cw if isinstance(cw, QCheckBox) else \
                cw.findChild(QCheckBox)
            if combo is not None:
                widgets[f"{r},{c}"] = {"t": "combo", "v": combo.currentIndex()}
            elif check is not None:
                widgets[f"{r},{c}"] = {"t": "check", "v": check.isChecked()}
    return {"t": "tabla", "filas": filas, "cols": cols,
            "celdas": celdas, "widgets": widgets}


def _aplicar_valor(w, dato, agregar_fila=None):
    from PySide6.QtWidgets import (
        QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox,
        QComboBox, QCheckBox, QRadioButton, QTableWidget, QGroupBox,
        QTableWidgetItem)

    t = dato.get("t")
    try:
        if t == "line" and isinstance(w, QLineEdit):
            w.setText(dato["v"])
        elif t == "text" and isinstance(w, (QTextEdit, QPlainTextEdit)):
            w.setPlainText(dato["v"])
        elif t == "int" and isinstance(w, QSpinBox):
            w.setValue(int(dato["v"]))
        elif t == "float" and isinstance(w, QDoubleSpinBox):
            w.setValue(float(dato["v"]))
        elif t == "combo" and isinstance(w, QComboBox):
            if 0 <= int(dato["v"]) < w.count():
                w.setCurrentIndex(int(dato["v"]))
        elif t == "check" and isinstance(w, (QCheckBox, QRadioButton)):
            w.setChecked(bool(dato["v"]))
        elif t == "group" and isinstance(w, QGroupBox):
            w.setChecked(bool(dato["v"]))
        elif t == "tabla" and isinstance(w, QTableWidget):
            _dict_a_tabla(w, dato, agregar_fila)
    except Exception as exc:                        # noqa: BLE001
        log.warning("No se pudo restaurar %s: %s", type(w).__name__, exc)


def _dict_a_tabla(tbl, dato, agregar_fila=None):
    from PySide6.QtWidgets import QComboBox, QCheckBox, QTableWidgetItem
    filas = int(dato.get("filas", 0))

    # Ajustar número de filas. Con agregar_fila los renglones nacen con sus
    # widgets de celda; sin él, insertRow simple.
    while tbl.rowCount() > filas:
        tbl.removeRow(tbl.rowCount() - 1)
    while tbl.rowCount() < filas:
        antes = tbl.rowCount()
        if agregar_fila is not None:
            agregar_fila()
        if tbl.rowCount() == antes:      # la función no agregó → genérico
            tbl.insertRow(tbl.rowCount())

    celdas = dato.get("celdas", [])
    for r in range(min(filas, len(celdas))):
        for c in range(min(tbl.columnCount(), len(celdas[r]))):
            if tbl.cellWidget(r, c) is not None:
                continue                  # esa celda la maneja su widget
            txt = celdas[r][c]
            if txt is None:
                continue
            item = tbl.item(r, c)
            if item is None:
                item = QTableWidgetItem()
                tbl.setItem(r, c, item)
            item.setText(txt)

    for clave, wd in dato.get("widgets", {}).items():
        r, c = (int(x) for x in clave.split(","))
        cw = tbl.cellWidget(r, c)
        if cw is None:
            continue
        combo = cw if isinstance(cw, QComboBox) else cw.findChild(QComboBox)
        check = cw if isinstance(cw, QCheckBox) else cw.findChild(QCheckBox)
        if wd["t"] == "combo" and combo is not None:
            if 0 <= int(wd["v"]) < combo.count():
                combo.setCurrentIndex(int(wd["v"]))
        elif wd["t"] == "check" and check is not None:
            check.setChecked(bool(wd["v"]))


# ─────────────────────────────────────────────────────────────────────────────
# Estado calculado (caché STAAD + resultados) — serializador genérico
# ─────────────────────────────────────────────────────────────────────────────
# Serializa grafos de objetos Python (dataclasses, dicts con llaves no-str,
# listas, primitivos) a JSON etiquetado, y los reconstruye como
# SimpleNamespace (duck-typing: el código de la UI solo lee atributos).

_MAX_PROFUNDIDAD = 14


def _ser(v, prof=0):
    if prof > _MAX_PROFUNDIDAD:
        return None
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (list, tuple, set)):
        return {"__l__": [_ser(x, prof + 1) for x in v]}
    # numpy: arrays con etiqueta (se reconstruyen como ndarray al abrir,
    # porque las gráficas indexan curve[:, 1]); escalares → número nativo
    if type(v).__module__ == "numpy":
        try:
            import numpy as _np
            if isinstance(v, _np.ndarray):
                return {"__np__": v.tolist()}
            return v.item() if hasattr(v, "item") else None
        except Exception:                           # noqa: BLE001
            return None
    if isinstance(v, dict):
        return {"__m__": [[_ser(k, prof + 1), _ser(x, prof + 1)]
                          for k, x in v.items()]}
    if isinstance(v, Path):
        return str(v)
    # Enum → valor con etiqueta
    import enum
    if isinstance(v, enum.Enum):
        return {"__e__": [type(v).__name__, v.name, _ser(v.value, prof + 1)]}
    if hasattr(v, "__dict__"):
        return {"__o__": type(v).__name__,
                "a": {k: _ser(x, prof + 1) for k, x in vars(v).items()
                      if not k.startswith("__")}}
    return None


def _clase_por_nombre(nombre: str):
    """Busca una clase ya importada con ese nombre (para reconstruir
    dataclasses reales y que los isinstance() del código sigan funcionando)."""
    import sys as _s
    for mod in list(_s.modules.values()):
        cls = getattr(mod, nombre, None)
        if isinstance(cls, type) and cls.__name__ == nombre:
            return cls
    return None


def _des(v):
    from types import SimpleNamespace
    if isinstance(v, dict):
        if "__np__" in v:
            try:
                import numpy as _np
                return _np.array(v["__np__"])
            except Exception:                       # noqa: BLE001
                return v["__np__"]
        if "__l__" in v:
            return [_des(x) for x in v["__l__"]]
        if "__m__" in v:
            return {(_hashable(_des(k))): _des(x) for k, x in v["__m__"]}
        if "__e__" in v:
            ns = SimpleNamespace(name=v["__e__"][1], value=_des(v["__e__"][2]))
            return ns
        if "__o__" in v:
            campos = {k: _des(x) for k, x in v["a"].items()}
            cls = _clase_por_nombre(v["__o__"])
            if cls is not None:
                try:
                    obj = object.__new__(cls)
                    for k, x in campos.items():
                        setattr(obj, k, x)
                    return obj
                except Exception:                   # noqa: BLE001
                    pass
            ns = SimpleNamespace(**campos)
            ns.__clase__ = v["__o__"]
            return ns
    return v


def _hashable(k):
    if isinstance(k, list):
        return tuple(k)
    if isinstance(k, dict):
        return str(k)
    return k


# ─────────────────────────────────────────────────────────────────────────────
# Registro por módulo: qué estado calculado se guarda y cómo se repuebla
# ─────────────────────────────────────────────────────────────────────────────

ESTADO_MODULOS: dict[str, tuple] = {
    "wall_design_pro":            ("_walls", "_results", "_diagrams", "_inputs"),
    "wall_design_pro_anl":        ("_walls", "_results", "_diagrams", "_inputs"),
    "beam_design_pro":            ("_results", "_params"),
    "column_design_pro":          ("_all_results", "_diagrams", "_params"),
    "footing_design_pro":         ("_results", "_params", "_elements"),
    "beamsteel_design_pro":       ("_results",),
    "columnsteel_design_pro":     ("_results",),
    "compositecolumn_design_pro": ("_results",),
    "nudo":                       ("_results", "_viz_cache"),
}


class _CacheExtractor:
    """Extractor de solo-lectura para las vistas de nudo, alimentado con la
    geometría capturada al guardar el proyecto (funciona sin STAAD)."""

    def __init__(self, cache: dict):
        self._coords = dict(cache.get("coords", {}))
        self._incid  = dict(cache.get("incid", {}))

    def get_node_coord(self, nid):
        c = self._coords.get(nid) or self._coords.get(int(nid))
        return tuple(c) if c else (0.0, 0.0, 0.0)

    def get_member_incidence(self, mid):
        i = self._incid.get(mid) or self._incid.get(int(mid))
        return tuple(i) if i else (0, 0)


def _snapshot_nudo(win) -> None:
    """Captura coords/incidencias de los nudos diseñados en win._viz_cache."""
    ext = getattr(win, "_extractor", None)
    res = getattr(win, "_results", []) or []
    if ext is None or isinstance(ext, _CacheExtractor):
        return
    coords, incid = {}, {}

    def _nodo(nid):
        if nid in coords or nid is None:
            return
        try:
            coords[nid] = tuple(ext.get_node_coord(nid))
        except Exception:                           # noqa: BLE001
            pass

    def _miembro(mid):
        if mid in incid or mid is None:
            return
        try:
            inc = tuple(ext.get_member_incidence(mid))
            incid[mid] = inc
            for n in inc:
                _nodo(n)
        except Exception:                           # noqa: BLE001
            pass

    for e in res:
        _nodo(getattr(e, "node_id", None))
        _miembro(getattr(e, "col_id", None))
        for tid in (getattr(e, "trabe_ids", []) or []):
            _miembro(tid)
    if coords or incid:
        win._viz_cache = {"coords": coords, "incid": incid}


PRE_GUARDAR = {"nudo": _snapshot_nudo}


def _preparar_clases(win, modulo: str) -> None:
    """Importa los módulos de modelos ANTES de deserializar, para que los
    objetos se reconstruyan con sus clases reales (isinstance funciona)."""
    import importlib
    import sys as _s
    try:
        if modulo in ("wall_design_pro", "wall_design_pro_anl"):
            mw = _s.modules.get(type(win).__module__)
            sd = getattr(mw, "SOURCE_DIR", None)
            if sd and str(sd) not in _s.path:
                _s.path.insert(0, str(sd))
            importlib.import_module("wall_models")
            importlib.import_module("wall_design_ntc2023")
    except Exception as exc:                        # noqa: BLE001
        log.debug("preparar clases (%s): %s", modulo, exc)


def _refrescar_resultados(win, modulo: str) -> bool:
    """Repuebla los widgets de resultados con el estado restaurado."""
    def llama(nombre, *args):
        try:
            getattr(win, nombre)(*args)
            return True
        except Exception as exc:                    # noqa: BLE001
            log.warning("refresco %s.%s: %s", modulo, nombre, exc)
            return False

    if modulo in ("wall_design_pro", "wall_design_pro_anl"):
        return llama("_on_done", {
            "walls":    getattr(win, "_walls", []),
            "results":  getattr(win, "_results", {}),
            "diagrams": getattr(win, "_diagrams", {}) or {},
            "inputs":   getattr(win, "_inputs", None),
        })
    if modulo == "beam_design_pro":
        return llama("_on_design_finished", getattr(win, "_results", []))
    if modulo == "column_design_pro":
        return llama("_on_finished", getattr(win, "_all_results", []),
                     getattr(win, "_diagrams", {}) or {})
    if modulo == "footing_design_pro":
        return llama("_on_finished", getattr(win, "_results", []))
    if modulo == "beamsteel_design_pro":
        return llama("_on_design_done", getattr(win, "_results", []))
    if modulo == "nudo":
        # Sin STAAD: usar el extractor de caché para las vistas gráficas
        try:
            vc = getattr(win, "_viz_cache", None)
            if getattr(win, "_extractor", None) is None and \
                    isinstance(vc, dict):
                win._extractor = _CacheExtractor(vc)
        except Exception as exc:                    # noqa: BLE001
            log.warning("extractor de caché: %s", exc)
        return llama("_on_design_finished", getattr(win, "_results", []))
    if modulo == "columnsteel_design_pro":
        res = getattr(win, "_results", [])
        ok = llama("_populate_combos_table", res)
        llama("_populate_summary_table", res)
        llama("_populate_diagram_selector", res)
        if res:
            llama("_redraw_diagram", 0)
        return ok
    if modulo == "compositecolumn_design_pro":
        res = getattr(win, "_results", [])
        ok = llama("_populate_env_table", res)
        llama("_populate_combo_table", res)
        llama("_populate_member_selectors", res)
        if res:
            llama("_update_plot", 0)
            llama("_update_memo", 0)
        return ok
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Guardar / Abrir
# ─────────────────────────────────────────────────────────────────────────────

def guardar_proyecto(win, modulo: str, ruta: str | Path,
                     estado: tuple = ()) -> None:
    datos = {}
    for clave, w in _widgets_entrada(win).items():
        v = _valor_de(w)
        if v is not None:
            datos[clave] = v
    doc = {"formato": _FORMATO, "modulo": modulo, "widgets": datos}
    # Capturas extra por módulo (p.ej. geometría para las vistas de nudo)
    hook = PRE_GUARDAR.get(modulo)
    if hook is not None:
        try:
            hook(win)
        except Exception as exc:                    # noqa: BLE001
            log.warning("Captura extra (%s): %s", modulo, exc)
    # Estado calculado: caché de STAAD y resultados de la última corrida,
    # para poder VER resultados al abrir sin reconectar ni recalcular.
    est = {}
    for attr in estado:
        if hasattr(win, attr):
            try:
                est[attr] = _ser(getattr(win, attr))
            except Exception as exc:                # noqa: BLE001
                log.warning("No se pudo serializar %s: %s", attr, exc)
    if est:
        doc["estado"] = est
    Path(ruta).write_text(json.dumps(doc, ensure_ascii=False, indent=1),
                          encoding="utf-8")


def _auto_tablas_dinamicas(win) -> dict:
    """Convención de la suite: método _add_X_row junto a atributo tbl_X."""
    import re
    tablas = {}
    for nombre in dir(win):
        m = re.fullmatch(r"_add_(\w+)_row", nombre)
        if not m:
            continue
        attr_tbl = f"tbl_{m.group(1)}"
        if hasattr(win, attr_tbl) and callable(getattr(win, nombre)):
            tablas[attr_tbl] = getattr(win, nombre)
    return tablas


def abrir_proyecto(win, modulo: str, ruta: str | Path,
                   tablas_dinamicas: dict | None = None,
                   refrescar: str = "") -> tuple[int, int, bool]:
    """
    Restaura el proyecto; regresa (aplicados, ignorados, con_resultados).

    Si el archivo trae estado calculado, se restauran los atributos y se
    invoca el método `refrescar` de la ventana para repoblar los widgets
    de resultados sin reconectar a STAAD ni recalcular.
    """
    doc = json.loads(Path(ruta).read_text(encoding="utf-8"))
    if doc.get("modulo") != modulo:
        raise ValueError(
            f"El proyecto es del módulo '{doc.get('modulo')}', "
            f"no de '{modulo}'.")
    if tablas_dinamicas is None:
        tablas_dinamicas = _auto_tablas_dinamicas(win)
    mapa = _widgets_entrada(win)
    aplicados = ignorados = 0
    for clave, dato in doc.get("widgets", {}).items():
        w = mapa.get(clave)
        if w is None:
            ignorados += 1
            continue
        nombre = w.objectName()
        agregar = tablas_dinamicas.get(nombre)
        # también aceptar la tabla por atributo de la ventana
        if agregar is None:
            for attr, fn in tablas_dinamicas.items():
                if getattr(win, attr, None) is w:
                    agregar = fn
                    break
        _aplicar_valor(w, dato, agregar_fila=agregar)
        aplicados += 1

    con_resultados = False
    est = doc.get("estado", {})
    if est:
        _preparar_clases(win, modulo)
        for attr, dato in est.items():
            try:
                setattr(win, attr, _des(dato))
            except Exception as exc:                # noqa: BLE001
                log.warning("No se pudo restaurar estado %s: %s", attr, exc)
        if refrescar and hasattr(win, refrescar):
            try:
                getattr(win, refrescar)()
                con_resultados = True
            except Exception as exc:                # noqa: BLE001
                log.warning("Repoblado de resultados falló: %s", exc)
        else:
            con_resultados = _refrescar_resultados(win, modulo)
    return aplicados, ignorados, con_resultados


_NOMBRES_MODULO = {
    "beam_design_pro": "Trabes de concreto",
    "column_design_pro": "Columnas de concreto",
    "footing_design_pro": "Zapatas",
    "wall_design_pro": "Muros de mampostería",
    "wall_design_pro_anl": "Muros de mampostería",
    "beamsteel_design_pro": "Trabes de acero",
    "columnsteel_design_pro": "Columnas de acero",
    "compositecolumn_design_pro": "Columnas compuestas",
    "nudo": "Nudos de concreto",
    "secciones": "Propiedades de sección",
    "diagrama_interaccion": "Diagramas de interacción P-M",
}

# Versiones de STAAD/OpenSTAAD con las que trabaja la suite (se anexa a la
# ventana "Normativa aplicada" de todos los módulos).
_STAAD_FOOTER = (
    "<br><br><b>Integración con STAAD Pro</b><br>"
    "· STAAD Pro CONNECT Edition 2024 y 2025.<br>"
    "· API OpenSTAAD (COM) de STAAD Pro 2024/2025.")

# Normativa aplicada POR MÓDULO (HTML).
_NORMATIVA_MODULO = {
    "beam_design_pro":
        "<b>Concreto reforzado — flexión, cortante y torsión</b><br>"
        "· NTC-2023 para Diseño y Construcción de Estructuras de Concreto "
        "(CDMX).<br>· ACI CODE-318-25.",
    "column_design_pro":
        "<b>Concreto reforzado — flexocompresión biaxial</b><br>"
        "· NTC-2023 de Concreto (CDMX); efectos de esbeltez/2.º orden "
        "§3.3.5.<br>· ACI 318-25; amplificación de momentos §6.6.4.",
    "footing_design_pro":
        "<b>Cimentaciones</b><br>"
        "· NTC-2023 para Diseño y Construcción de Cimentaciones (CDMX).<br>"
        "<b>Concreto</b><br>· NTC-2023 de Concreto (CDMX) · ACI 318-25.",
    "wall_design_pro":
        "<b>Mampostería</b><br>"
        "· NTC-2023 para Diseño y Construcción de Estructuras de Mampostería "
        "(CDMX).",
    "wall_design_pro_anl":
        "<b>Mampostería</b><br>"
        "· NTC-2023 para Diseño y Construcción de Estructuras de Mampostería "
        "(CDMX).",
    "beamsteel_design_pro":
        "<b>Acero estructural — trabes</b><br>"
        "· NTC-2023 DEA para Diseño y Construcción de Estructuras de Acero "
        "(CDMX).<br>· AISC 360-22.",
    "columnsteel_design_pro":
        "<b>Acero estructural — columnas y celosías</b><br>"
        "· NTC-2023 DEA de Acero (CDMX).<br>"
        "· AISC 360-22; longitud efectiva K (Apéndice 7) y efectos de "
        "2.º orden B1-B2 (Apéndice 8).",
    "compositecolumn_design_pro":
        "<b>Columnas compuestas (acero-concreto)</b><br>"
        "· AISC 360-22, Capítulo I; AISC Design Guide 6 (2.ª ed.).<br>"
        "· NTC-2023 DEA de Acero (CDMX).<br>· NTC-2023 de Concreto (CDMX).",
    "nudo":
        "<b>Conexiones viga-columna de concreto</b><br>"
        "· NTC-2023 de Concreto (CDMX), diseño de nudos.<br>"
        "· ACI 318-25 (Cap. 15) / ACI 352R.",
    "secciones":
        "<b>Propiedades de sección y revisión compuesta</b><br>"
        "· NTC-2023 de Concreto y NTC-2023 DEA de Acero (CDMX).<br>"
        "· Deflexiones admisibles NTC (L/240).",
    "diagrama_interaccion":
        "<b>Diagramas de interacción P-M</b><br>"
        "· NTC-2023 de Concreto (CDMX).<br>· ACI 318-25.",
}


def _instalar_menu_ayuda(win, barra_menus, modulo: str) -> None:
    """Agrega (o reutiliza) el menú «Ayuda» con «Acerca de…» y «Normativa
    aplicada». El módulo puede personalizar el texto con los atributos
    `win.ACERCA_HTML` y `win.NORMATIVA_HTML` (str HTML)."""
    from PySide6.QtGui import QAction
    from PySide6.QtWidgets import QMessageBox
    try:
        from suite_shared.version import SUITE_VERSION
    except Exception:                               # noqa: BLE001
        SUITE_VERSION = ""

    nombre = _NOMBRES_MODULO.get(modulo, modulo.replace("_", " ").title())

    def _acerca():
        html = getattr(win, "ACERCA_HTML", None) or (
            f"<h3>SuiteEstructural — {nombre}</h3>"
            f"<p>Versión {SUITE_VERSION}</p>"
            "<p>Suite de diseño estructural conforme a NTC-2023 (CDMX) y "
            "ACI 318-25 / AISC 360-22, con integración a STAAD Pro "
            "(2024 y 2025) vía OpenSTAAD.</p>")
        QMessageBox.about(win, "Acerca de…", html)

    def _normativa():
        html = getattr(win, "NORMATIVA_HTML", None) or _NORMATIVA_MODULO.get(
            modulo,
            "<b>Concreto</b><br>· NTC-2023 de Concreto (CDMX) · ACI 318-25."
            "<br><br><b>Acero</b><br>· NTC-2023 DEA (CDMX) · AISC 360-22.")
        QMessageBox.information(win, "Normativa aplicada", html + _STAAD_FOOTER)

    # Reutilizar menú Ayuda existente si lo hay.
    menu_ayuda = None
    for accion in barra_menus.actions():
        m = accion.menu()
        if m is not None and accion.text().replace("&", "").strip().lower() \
                in ("ayuda", "help"):
            menu_ayuda = m
            break
    if menu_ayuda is None:
        menu_ayuda = barra_menus.addMenu("A&yuda")

    a1 = QAction("Acerca de…", win); a1.triggered.connect(_acerca)
    a2 = QAction("Normativa aplicada", win); a2.triggered.connect(_normativa)
    menu_ayuda.addAction(a1)
    menu_ayuda.addAction(a2)


def instalar_gestor_proyecto(win, modulo: str,
                             tablas_dinamicas: dict | None = None,
                             estado: tuple = (),
                             refrescar: str = "") -> None:
    """
    Agrega a la ventana una **barra de menús** con el menú «Archivo» →
    «Abrir proyecto…» (Ctrl+O), «Guardar proyecto…» (Ctrl+S) y «Salir»
    (mismo patrón que el módulo de referencia "Muro de contención").
    Si el módulo ya tiene un menú «Archivo», reutiliza ese menú.

    estado    : nombres de atributos de la ventana con la caché de STAAD y
                los resultados de la última corrida (se guardan en el .sdp).
    refrescar : método de la ventana que repuebla los widgets de resultados
                a partir de esos atributos (se llama al abrir).
    """
    from PySide6.QtGui import QAction, QKeySequence
    from PySide6.QtWidgets import QFileDialog, QMessageBox

    # Regla de la suite para TODOS los diálogos de archivo del módulo:
    # Guardar → carpeta del modelo STAAD conectado; Abrir → C:\
    try:
        from suite_shared.dialogos import instalar_dialogos_suite
        instalar_dialogos_suite()
    except Exception:                               # noqa: BLE001
        pass

    if tablas_dinamicas is None:
        tablas_dinamicas = _auto_tablas_dinamicas(win)
    if not estado:
        estado = ESTADO_MODULOS.get(modulo, ())

    filtro = f"Proyecto Suite (*.{EXTENSION})"

    def _abrir():
        ruta, _ = QFileDialog.getOpenFileName(
            win, "Abrir proyecto", "", filtro)
        if not ruta:
            return
        try:
            ap, ig, con_res = abrir_proyecto(win, modulo, ruta,
                                             tablas_dinamicas, refrescar)
        except Exception as exc:                    # noqa: BLE001
            QMessageBox.critical(win, "Abrir proyecto",
                                 f"No se pudo abrir el proyecto:\n{exc}")
            return
        msg = f"Proyecto cargado ({ap} campos restaurados)."
        if ig:
            msg += (f"\n{ig} campos del archivo no se encontraron en esta "
                    "versión y se ignoraron.")
        if con_res:
            msg += ("\n\nSe restauraron también los RESULTADOS de la última "
                    "corrida guardada (no requiere STAAD para consultarlos). "
                    "Para actualizar con el modelo, vuelva a ejecutar el "
                    "diseño.")
        else:
            msg += "\n\nEjecute nuevamente el diseño para generar resultados."
        QMessageBox.information(win, "Abrir proyecto", msg)

    def _guardar():
        ruta, _ = QFileDialog.getSaveFileName(
            win, "Guardar proyecto", f"proyecto.{EXTENSION}", filtro)
        if not ruta:
            return
        if not ruta.lower().endswith(f".{EXTENSION}"):
            ruta += f".{EXTENSION}"
        try:
            guardar_proyecto(win, modulo, ruta, estado)
        except Exception as exc:                    # noqa: BLE001
            QMessageBox.critical(win, "Guardar proyecto",
                                 f"No se pudo guardar el proyecto:\n{exc}")
            return
        QMessageBox.information(win, "Guardar proyecto",
                                f"Proyecto guardado en:\n{ruta}")

    def _nuevo():
        """Proyecto nuevo: limpia la pantalla (campos y resultados) y la
        memoria (caché de STAAD y resultados guardados)."""
        # 1) Si el módulo trae su propio método de reinicio, se usa ese.
        for hook in ("nuevo_proyecto", "_nuevo_proyecto",
                     "reset_todo", "limpiar_todo", "_limpiar_todo"):
            fn = getattr(win, hook, None)
            if callable(fn):
                r = QMessageBox.question(
                    win, "Proyecto nuevo",
                    "¿Limpiar todo (campos, resultados y memoria)?\n"
                    "Esta acción no se puede deshacer.")
                if r == QMessageBox.StandardButton.Yes:
                    fn()
                return

        r = QMessageBox.question(
            win, "Proyecto nuevo",
            "¿Limpiar todo (campos, resultados y memoria)?\n"
            "Esta acción no se puede deshacer.")
        if r != QMessageBox.StandardButton.Yes:
            return

        from PySide6.QtWidgets import (QLineEdit, QComboBox, QCheckBox,
                                       QRadioButton, QPlainTextEdit, QTextEdit,
                                       QTableWidget, QAbstractSpinBox)
        # 2) Reiniciar los widgets de captura (con señales bloqueadas).
        for w in win.findChildren(QAbstractSpinBox):
            try:
                w.blockSignals(True)
                if hasattr(w, "setValue") and hasattr(w, "minimum"):
                    w.setValue(w.minimum())
            except Exception:                       # noqa: BLE001
                pass
            finally:
                try: w.blockSignals(False)
                except Exception: pass                # noqa: E701
        for w in win.findChildren(QLineEdit):
            try: w.blockSignals(True); w.clear()
            except Exception: pass                    # noqa: E701
            finally:
                try: w.blockSignals(False)
                except Exception: pass                # noqa: E701
        for w in win.findChildren(QComboBox):
            try:
                w.blockSignals(True)
                if w.count(): w.setCurrentIndex(0)
            except Exception: pass                    # noqa: E701
            finally:
                try: w.blockSignals(False)
                except Exception: pass                # noqa: E701
        for w in list(win.findChildren(QCheckBox)) + list(win.findChildren(QRadioButton)):
            try:
                if w.isCheckable() and not w.isChecked():
                    continue
                w.blockSignals(True)
                if w.isCheckable(): w.setChecked(False)
            except Exception: pass                    # noqa: E701
            finally:
                try: w.blockSignals(False)
                except Exception: pass                # noqa: E701
        # 3) Limpiar tablas y textos de resultados en pantalla.
        for w in win.findChildren(QTableWidget):
            try: w.setRowCount(0)
            except Exception: pass                    # noqa: E701
        for w in list(win.findChildren(QPlainTextEdit)) + list(win.findChildren(QTextEdit)):
            try: w.clear()
            except Exception: pass                    # noqa: E701
        # 4) Limpiar la MEMORIA: atributos de estado (resultados/caché) y la
        #    caché del lector STAAD si existe.
        for attr in estado:
            try: setattr(win, attr, None)
            except Exception: pass                    # noqa: E701
        for rn in ("_reader", "reader", "_staad_reader"):
            rd = getattr(win, rn, None)
            if rd is not None:
                for cn in ("_force_cache", "_section_cache", "_cache",
                           "force_cache", "_sec_cache"):
                    c = getattr(rd, cn, None)
                    if isinstance(c, dict):
                        try: c.clear()
                        except Exception: pass        # noqa: E701
        # 5) Repintar la vista de resultados vacía, si el módulo lo permite.
        if refrescar:
            fn = getattr(win, refrescar, None)
            if callable(fn):
                try: fn()
                except Exception: pass                # noqa: E701
        try:
            win.statusBar().showMessage("  Proyecto nuevo — pantalla y memoria limpias", 4000)
        except Exception:                             # noqa: BLE001
            pass

    acc_nuevo = QAction("Nuevo", win)
    acc_nuevo.setShortcut(QKeySequence.New)
    acc_nuevo.triggered.connect(_nuevo)
    acc_abrir = QAction("Abrir proyecto…", win)
    acc_abrir.setShortcut(QKeySequence.Open)
    acc_abrir.triggered.connect(_abrir)
    acc_guardar = QAction("Guardar proyecto…", win)
    acc_guardar.setShortcut(QKeySequence.Save)
    acc_guardar.triggered.connect(_guardar)

    # Barra de menús: menú «Archivo» con Abrir / Guardar / Salir
    # (mismo patrón que el módulo de referencia "Muro de contención").
    try:
        barra_menus = win.menuBar()
        # Reutilizar un menú "Archivo" existente si el módulo ya tiene uno,
        # para no duplicarlo.
        menu_archivo = None
        for accion in barra_menus.actions():
            m = accion.menu()
            if m is not None and accion.text().replace("&", "").strip().lower() \
                    in ("archivo", "file"):
                menu_archivo = m
                break
        if menu_archivo is None:
            menu_archivo = barra_menus.addMenu("&Archivo")
            _es_nuevo = True
        else:
            _es_nuevo = False
        # Insertar las acciones al inicio del menú Archivo.
        accs_previas = menu_archivo.actions()
        antes = accs_previas[0] if accs_previas else None
        menu_archivo.insertAction(antes, acc_nuevo)
        menu_archivo.insertAction(antes, acc_abrir)
        menu_archivo.insertAction(antes, acc_guardar)
        menu_archivo.insertSeparator(antes)
        # "Salir" solo si el menú es nuevo (evita duplicar uno existente).
        if _es_nuevo:
            menu_archivo.addSeparator()
            acc_salir = QAction("Salir", win)
            acc_salir.triggered.connect(win.close)
            menu_archivo.addAction(acc_salir)

        # ── Menú «Ayuda» (Acerca de… / Normativa aplicada) ──────────────────
        _instalar_menu_ayuda(win, barra_menus, modulo)
    except Exception:                               # noqa: BLE001
        # Respaldo: si la ventana no admite barra de menús, dejar las acciones
        # accesibles por atajo de teclado (Ctrl+O / Ctrl+S).
        win.addAction(acc_nuevo)
        win.addAction(acc_abrir)
        win.addAction(acc_guardar)
