"""Versiones centralizadas de la Suite de Diseño Estructural."""

SUITE_VERSION = "1.2.11"

MODULE_VERSIONS = {
    "beam_design_pro":           "1.0",
    "column_design_pro":         "1.0",
    "footing_design_pro":        "1.0",
    "wall_design_pro":           "1.0",
    "wall_design_pro_anl":       "1.0",
    "diagrama_interaccion":      "1.0",
    "compositecolumn_design_pro":"1.0",
    "nudo":                      "1.0",
    "secciones":                 "1.0",
    "beamsteel_design_pro":      "1.0",
    "columnsteel_design_pro":    "1.0",
}
