# fileio/openstaad_reader.py
"""
Lector STAAD Pro para columnas compuestas.

Obtiene geometría, propiedades de sección y fuerzas internas
de barras seleccionadas con el modelo abierto y ejecutado.

Fuerzas STAAD: kN / kN·m  →  internas: ton / ton·m  (/ 9.80665)

APIs utilizadas (openstaadpy / win32com.client):
  Geometry.GetBeamList()
  Geometry.GetBeamLength(beam)
  Geometry.GetMemberIncidence(beam)
  Geometry.GetNoOfBeamsConnectedAtNode(node)
  Geometry.GetBeamsConnectedAtNode(node, arr)
  Property.GetBeamSectionName(beam)
  Property.GetBeamPropertyAll(beam)
  Output.AreResultsAvailable()
  Output.GetMemberEndForces(beam, end, lc, local)
"""
from __future__ import annotations
import logging, re, math
from typing import Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger(__name__)

try:
    import openstaadpy
    _AVAIL = True
except Exception:
    _AVAIL = False

_KN = 1.0 / 9.80665    # kN → ton

_ZERO = {
    "Pu": 0.0, "Vuy": 0.0, "Vuz": 0.0,
    "Ttor": 0.0, "Muy": 0.0, "Muz": 0.0,
}


class OpenSTAADReader:
    """Lee datos de sección y fuerzas para columnas compuestas."""

    def __init__(self):
        self._staad  = None
        self._geo    = None
        self._out    = None
        self._prop   = None
        self._load   = None

        self._member_ids: List[int] = []
        self._load_cases: List[int] = []

        self._sec_cache: Dict[int, dict] = {}
        self._fi_cache:  Dict[Tuple[int,int], dict] = {}
        self._ff_cache:  Dict[Tuple[int,int], dict] = {}
        self._prefetched = False

        self._node_map:    Dict[int, List[int]] = {}
        self._mem_nodes:   Dict[int, Tuple[int,int]] = {}
        self._stiff_cache: Dict[int, Tuple[float,float,float]] = {}
        self._section_names: Dict[int, str] = {}

    # ── Conexión ──────────────────────────────────────────────────────────────

    def connect(self) -> Tuple[bool, str]:
        if not _AVAIL:
            return False, "openstaadpy no instalado. Ejecute: pip install openstaadpy"
        try:
            from openstaadpy import os_analytical
            self._staad = os_analytical.connect()
            self._geo   = self._staad.Geometry
            self._out   = self._staad.Output
            self._prop  = self._staad.Property
            try:
                self._load = self._staad.Load
            except Exception:
                self._load = None
        except Exception as exc:
            return False, f"No se pudo conectar a STAAD Pro: {exc}"

        try:
            if not self._out.AreResultsAvailable():
                return False, "El modelo no tiene resultados. Analice primero en STAAD Pro."
        except Exception:
            pass

        try:
            self._member_ids = [int(x) for x in self._geo.GetBeamList()]
        except Exception as exc:
            return False, f"Error leyendo lista de miembros: {exc}"

        self._load_cases = self._fetch_load_cases()
        n_mem = len(self._member_ids)
        n_lc  = len(self._load_cases)
        rng   = f" (LC {self._load_cases[0]}–{self._load_cases[-1]})" if n_lc else ""
        return True, f"✔ Conectado: {n_mem} miembros, {n_lc} combinaciones{rng}"

    @property
    def connected(self) -> bool:
        return self._staad is not None

    # ── Pre-carga (hilo principal — COM tiene thread-affinity) ────────────────

    def pre_fetch(self, member_ids: List[int], lc_ids: List[int]) -> None:
        self._sec_cache = {}
        self._fi_cache  = {}
        self._ff_cache  = {}
        self._prefetched = False

        for mid in member_ids:
            self._sec_cache[mid] = self._read_section(mid)
            for lc in lc_ids:
                self._fi_cache[(mid, lc)] = self._end_forces(mid, 0, lc)
                self._ff_cache[(mid, lc)] = self._end_forces(mid, 1, lc)

        self._prefetched = True
        log.info("pre_fetch: %d miembros × %d combos", len(member_ids), len(lc_ids))

    # ── API pública ───────────────────────────────────────────────────────────

    def get_member_ids(self) -> List[int]:
        return sorted(self._member_ids)

    def get_load_cases(self) -> List[int]:
        return list(self._load_cases)

    def get_section_name(self, mid: int) -> str:
        if self._prefetched and mid in self._sec_cache:
            return self._sec_cache[mid].get("section_name", f"MBR-{mid}")
        if not self.connected:
            return f"MBR-{mid}"
        try:
            return str(self._prop.GetBeamSectionName(mid)).strip()
        except Exception:
            return f"MBR-{mid}"

    def get_section(self, mid: int) -> dict:
        if self._prefetched and mid in self._sec_cache:
            return dict(self._sec_cache[mid])
        return self._read_section(mid)

    def get_forces(self, mid: int, lc_ids: List[int]) -> Tuple[List[dict], List[dict]]:
        if self._prefetched:
            ini = [dict(self._fi_cache.get((mid, lc), _ZERO)) for lc in lc_ids]
            fin = [dict(self._ff_cache.get((mid, lc), _ZERO)) for lc in lc_ids]
            return ini, fin
        if not self.connected:
            empty = [dict(_ZERO) for _ in lc_ids]
            return empty, empty
        ini = [self._end_forces(mid, 0, lc) for lc in lc_ids]
        fin = [self._end_forces(mid, 1, lc) for lc in lc_ids]
        return ini, fin

    def get_member_length(self, mid: int) -> float:
        sec = self.get_section(mid)
        return sec.get("length_m", 0.0)

    def get_selected_members(self) -> List[int]:
        if not self.connected:
            return []
        candidates = [
            (self._geo,   "GetSelectedBeamList"),
            (self._geo,   "GetSelectedBeams"),
            (self._geo,   "GetSelectedMemberList"),
            (self._staad, "GetSelectedBeamList"),
        ]
        for obj, name in candidates:
            fn = getattr(obj, name, None)
            if fn is None:
                continue
            try:
                ids = [int(x) for x in fn() if x]
                if ids:
                    log.info("get_selected_members via '%s': %d", name, len(ids))
                    return ids
            except Exception as exc:
                log.debug("get_selected_members/%s: %s", name, exc)
        log.warning("get_selected_members: ningún método funcionó.")
        return []

    def compute_k_factors(self, mid: int,
                           sway_y: bool = True,
                           sway_z: bool = True) -> Tuple[float, float]:
        """Retorna (Ky, Kz) usando el ábaco de alineación AISC Ap.7."""
        # Reutiliza el mismo algoritmo que columnsteel
        if not self._mem_nodes:
            self.build_connectivity()

        n_start, n_end = self._mem_nodes.get(mid, (None, None))
        if n_start is None:
            sn, en = self._get_member_nodes(mid)
            if sn is None:
                return 1.0, 1.0
            n_start, n_end = sn, en

        if mid not in self._stiff_cache:
            return 1.0, 1.0

        Iy_col, Ix_col, L_col = self._stiff_cache[mid]
        EIy = Iy_col / L_col
        EIx = Ix_col / L_col

        def _G(node):
            beams = self._get_connected_beams(node)
            beams = [m for m in beams if m != mid]
            sy = sx = 0.0
            for m in beams:
                if m not in self._stiff_cache:
                    continue
                Iy_m, Ix_m, L_m = self._stiff_cache[m]
                sy += Iy_m / L_m
                sx += Ix_m / L_m
            Gy = EIy / sy if sy > 0 else 10.0
            Gx = EIx / sx if sx > 0 else 10.0
            return min(Gy, 100.0), min(Gx, 100.0)

        GA_y, GA_x = _G(n_start)
        GB_y, GB_x = _G(n_end)

        Ky = _k_from_G(GA_y, GB_y, sway_y)
        Kz = _k_from_G(GA_x, GB_x, sway_z)
        return Ky, Kz

    def build_connectivity(self, progress_cb=None) -> Tuple[bool, str]:
        self._node_map = {}
        self._mem_nodes = {}
        self._stiff_cache = {}
        self._section_names = {}
        total = len(self._member_ids)
        if total == 0:
            return False, "Sin miembros."

        for i, mid in enumerate(self._member_ids):
            sn, en = self._get_member_nodes(mid)
            if sn is not None:
                self._mem_nodes[mid] = (sn, en)
                self._node_map.setdefault(sn, []).append(mid)
                self._node_map.setdefault(en, []).append(mid)
            try:
                nm = str(self._prop.GetBeamSectionName(mid)).strip()
                self._section_names[mid] = nm or f"MBR-{mid}"
            except Exception:
                self._section_names[mid] = f"MBR-{mid}"
            try:
                raw = self._prop.GetBeamPropertyAll(mid)
                L   = float(self._geo.GetBeamLength(mid))
                if raw and len(raw) >= 8:
                    self._stiff_cache[mid] = (
                        max(float(raw[6]) * 1e8, 1.0),
                        max(float(raw[7]) * 1e8, 1.0),
                        max(L, 0.001),
                    )
            except Exception:
                pass
            if progress_cb and i % 50 == 0:
                progress_cb(int(i / total * 100), f"Conectividad: {i+1}/{total}...")

        if progress_cb:
            progress_cb(100, "Conectividad lista.")
        return True, f"Conectividad: {len(self._mem_nodes)} miembros, {len(self._node_map)} nodos."

    # ── Lectura interna ───────────────────────────────────────────────────────

    def _read_section(self, mid: int) -> dict:
        length_m = 0.0
        try:
            length_m = float(self._geo.GetBeamLength(mid))
        except Exception:
            pass
        sec = {"length_m": length_m, "section_name": f"MBR-{mid}"}
        try:
            name = str(self._prop.GetBeamSectionName(mid)).strip()
            sec["section_name"] = name
        except Exception:
            pass
        try:
            raw = self._prop.GetBeamPropertyAll(mid)
            if raw and len(raw) >= 9:
                sec.update({
                    "d":  float(raw[1]) * 100,
                    "bf": float(raw[0]) * 100,
                    "tf": float(raw[8]) * 100,
                    "tw": float(raw[9]) * 100 if len(raw) >= 10 else 0.0,
                    "A":  float(raw[2]) * 1e4,
                    "Ix": float(raw[7]) * 1e8,
                    "Iy": float(raw[6]) * 1e8,
                    "J":  float(raw[5]) * 1e8,
                })
        except Exception:
            pass
        return sec

    def _end_forces(self, mid: int, end: int, lc: int) -> dict:
        try:
            v = self._out.GetMemberEndForces(mid, end, lc, 0)
            if v is None or len(v) < 6:
                return dict(_ZERO)
            sign_pu = -1.0 if end == 0 else 1.0
            # Nodo FIN (end=1): la acción de extremo trae el momento con signo
            # OPUESTO al del nodo inicial. Se invierte para unificar el signo
            # entre extremos (correcto para M1/M2 del Cm; la revisión usa |M|).
            _msgn = -1.0 if end == 1 else 1.0
            return {
                "Pu":   float(v[0]) * _KN * sign_pu,
                "Vuy":  float(v[1]) * _KN,
                "Vuz":  float(v[2]) * _KN,
                "Ttor": float(v[3]) * _KN,
                "Muy":  float(v[4]) * _KN * _msgn,
                "Muz":  float(v[5]) * _KN * _msgn,
            }
        except Exception as exc:
            log.debug("GetMemberEndForces(%d,%d,%d): %s", mid, end, lc, exc)
            return dict(_ZERO)

    def _fetch_load_cases(self) -> List[int]:
        lcs: List[int] = []
        if self._load is None:
            return lcs
        for cnt in ("GetLoadCaseCount", "GetNumberOfLoadCases",
                    "GetNoOfPrimaryLoadCases"):
            try:
                n = int(getattr(self._load, cnt)())
                for i in range(n):
                    for id_fn in ("GetLoadCaseID", "GetPrimaryLoadCaseID"):
                        try:
                            lcs.append(int(getattr(self._load, id_fn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        for cnt in ("GetLoadCombinationCount", "GetLoadCombinationCaseCount",
                    "GetNoOfLoadCombinations"):
            try:
                n = int(getattr(self._load, cnt)())
                for i in range(n):
                    for id_fn in ("GetLoadCombinationID", "GetCombinationCaseID"):
                        try:
                            lcs.append(int(getattr(self._load, id_fn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        return sorted(set(lcs))

    def _get_member_nodes(self, mid: int) -> Tuple:
        geo = self._geo
        for obj, method in [
            (geo,         "GetMemberIncidence"),
            (self._staad, "GetMemberIncidence"),
        ]:
            fn = getattr(obj, method, None)
            if fn is None:
                continue
            try:
                sn, en = fn(mid)
                sn, en = int(sn), int(en)
                if sn > 0 and en > 0:
                    return sn, en
            except Exception:
                pass
        return None, None

    def _get_connected_beams(self, node: int) -> List[int]:
        for obj in (self._geo, self._staad):
            fn_n = getattr(obj, "GetNoOfBeamsConnectedAtNode", None)
            fn_g = getattr(obj, "GetBeamsConnectedAtNode", None)
            if fn_n is None or fn_g is None:
                continue
            try:
                n = int(fn_n(node))
                if n <= 0:
                    return []
                arr = np.zeros(n, dtype=np.int32)
                fn_g(node, arr)
                return [int(m) for m in arr if int(m) > 0]
            except Exception:
                pass
        return self._node_map.get(node, [])


def _k_from_G(GA: float, GB: float, sway: bool) -> float:
    """Fórmula de Newmark para K a partir de factores G."""
    if sway:
        num = 1.6 * GA * GB + 4.0 * (GA + GB) + 7.5
        den = GA + GB + 7.5
        return max(1.0, math.sqrt(num / den)) if den > 0 else 1.0
    else:
        num = (GA + 1.0) * (GB + 1.0)
        den = (GA + 2.0) * (GB + 2.0)
        return min(1.0, math.sqrt(num / den)) if den > 0 else 1.0
