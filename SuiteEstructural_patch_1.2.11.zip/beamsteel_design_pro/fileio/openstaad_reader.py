# fileio/openstaad_reader.py
"""
Conexión a STAAD Pro 2024 / 2025 vía openstaadpy.
Patrón: from openstaadpy import os_analytical  →  os_analytical.connect()

API verificada contra openstaadpy v25.0.1.1 (STAAD Pro 2025).
Todos los métodos incluyen fallbacks para mantener compatibilidad con
versiones anteriores (STAAD Pro 2024 / openstaadpy v24.x).

Convención de vectores de fuerza STAAD (sistema local del miembro):
  [0] Fx  – axial          (+ tensión en STAAD → invertimos: N(+) = compresión)
  [1] Fy  – cortante Y
  [2] Fz  – cortante Z
  [3] Mx  – torsión
  [4] My  – momento Y (eje débil)
  [5] Mz  – momento Z (eje fuerte, flexión vertical)
"""

from __future__ import annotations
import logging
import math
from typing import Dict, List, Optional, Tuple

from design.section_types import (SectionProperties, SectionKind,
                                   _detect_kind, _detect_kind_from_geometry)
from design.designer      import MemberForces, SectionPoint
from design.steel_db      import (lookup, estimate_from_dimensions,
                                   estimate_from_hss_round, estimate_from_hss_rect,
                                   pipe_thickness_from_name)

log = logging.getLogger(__name__)

# ── Import openstaadpy ────────────────────────────────────────────────────────
try:
    from openstaadpy import os_analytical
    _AVAIL = True
except ImportError:
    _AVAIL = False
    log.warning("openstaadpy no disponible — modo sin STAAD.")

# ── Tabla de conversión de unidades de fuerza → toneladas ────────────────────
# Fuente: SetInputUnits() docs, openstaadpy 25.0.1
# IMPORTANTE: las claves deben estar en orden de mayor a menor longitud para
# evitar que "ton" matchee antes que "metricton" o "kilonewton".
_FORCE_UNIT_TO_TON: Dict[str, float] = {
    "meganewton":  1000.0 / 9.80665,   # MN → ton
    "kilopound":   0.4536,              # kip → ton
    "kilonewton":  1.0 / 9.80665,      # kN  → ton
    "decanewton":  10.0 / 9806.65,     # daN → ton
    "kilogram":    1e-3,
    "metricton":   1.0,
    "tonelada":    1.0,
    "newton":      1.0 / 9806.65,
    "pound":       4.536e-4,
    "kgf":         1e-3,
    "kip":         0.4536,
    "ton":         1.0,
    "kn":          1.0 / 9.80665,
    "mn":          1000.0 / 9.80665,
    "kg":          1e-3,
    "lb":          4.536e-4,
    "n":           1.0 / 9806.65,
    "t":           1.0,
}
_DEFAULT_UNIT_F = 1.0 / 9.80665   # kN → ton (unidad más común en STAAD)


def _unit_factor_from_string(unit_str: str) -> float:
    """
    Devuelve el factor de conversión unidad-de-fuerza → ton.
    Estrategia: exacto primero, luego busca clave más larga que esté
    contenida en el string normalizado (evita falsos matches cortos).
    """
    key = unit_str.lower().replace(" ", "").replace("_", "").replace("-", "")
    # 1. Coincidencia exacta
    if key in _FORCE_UNIT_TO_TON:
        return _FORCE_UNIT_TO_TON[key]
    # 2. Buscar la clave más larga que sea subcadena de key (o key de la clave)
    best_k, best_v, best_len = None, _DEFAULT_UNIT_F, 0
    for k, v in _FORCE_UNIT_TO_TON.items():
        if (k in key or key in k) and len(k) > best_len:
            best_k, best_v, best_len = k, v, len(k)
    if best_k:
        return best_v
    log.warning("Unidad de fuerza desconocida '%s' — usando kN por defecto.",
                unit_str)
    return _DEFAULT_UNIT_F


class OpenSTAADReader:
    """
    Interfaz robusta con STAAD Pro 2024 y 2025 a través de openstaadpy.
    Cada llamada al API usa la firma correcta de 2025 con fallback a 2024.
    """

    def __init__(self):
        self._staad:   object = None
        self._ready:   bool   = False
        self._unit_f:  float  = _DEFAULT_UNIT_F   # kN → ton por defecto
        self._version: str    = "desconocida"
        self._sec_cache:   Dict = {}
        self._force_cache: Dict = {}
        self._geo_diag_done = False

    # ══════════════════════════════════════════════════════════════════════════
    # Conexión
    # ══════════════════════════════════════════════════════════════════════════

    def set_unit_factor(self, factor: float) -> None:
        """
        Establece el factor de conversión fuerza-modelo → toneladas.
        Llamar ANTES de fetch_all() cuando se conoce la unidad del modelo.
        Valores comunes:
          kN  → ton : 1/9.80665 ≈ 0.10197  (por defecto, igual que beam_design_pro)
          ton → ton : 1.0
          kg  → ton : 1/1000 = 0.001
          N   → ton : 1/9806.65
          kip → ton : 0.4536
        """
        self._unit_f = factor
        log.info("Factor de unidad establecido manualmente: %.6f", factor)

    def connect(self) -> Tuple[bool, str]:
        if not _AVAIL:
            return False, "openstaadpy no esta instalado."
        try:
            self._staad = os_analytical.connect()
        except Exception as exc:
            return False, f"Error al conectar con STAAD Pro: {exc}"

        # Detectar versión (solo informativo)
        try:
            self._version = str(self._staad.GetApplicationVersion())
        except Exception:
            self._version = "desconocida"
        log.info("STAAD Pro version detectada: %s", self._version)

        # NOTA: NO se usa GetInputUnitForForce() para determinar el factor de
        # conversión porque ese método devuelve la unidad de las CARGAS de
        # entrada, no la unidad de los RESULTADOS de análisis.
        # El factor se establece desde la UI (set_unit_factor) o permanece en
        # el valor por defecto kN→ton (igual que beam_design_pro).
        log.info("Factor de conversion activo: %.6f (editar en UI si el "
                 "modelo no esta en kN)", self._unit_f)

        # Verificar resultados disponibles
        #  AreResultsAvailable() existe en 2025; en 2024 podría no existir.
        #  Si falla o no está, continuamos (se detectará al leer fuerzas).
        try:
            if not self._staad.Output.AreResultsAvailable():
                return False, ("Conexion OK, pero el modelo no tiene resultados "
                               "de analisis. Ejecute el analisis en STAAD Pro.")
        except AttributeError:
            log.info("AreResultsAvailable() no disponible (STAAD 2024) — "
                     "continuando sin verificacion de resultados.")
        except Exception as exc:
            log.warning("AreResultsAvailable() error: %s — continuando.", exc)

        self._ready = True
        return True, (f"Conectado a STAAD Pro {self._version}. "
                      f"Factor activo: {self._unit_f:.5f} (fuerza→ton). "
                      f"Ajustar si el modelo NO usa kN.")

    @property
    def connected(self) -> bool:
        return self._ready

    @property
    def staad_version(self) -> str:
        return self._version

    @property
    def unit_factor(self) -> float:
        """Factor de conversión unidad-modelo → toneladas."""
        return self._unit_f

    # ══════════════════════════════════════════════════════════════════════════
    # Barras seleccionadas
    # ══════════════════════════════════════════════════════════════════════════

    def get_selected_members(self) -> List[int]:
        """
        IDs de las barras seleccionadas en el modelo STAAD activo.
        Método correcto 2025: Geometry.GetSelectedBeams()
        Fallbacks para 2024 y versiones anteriores.
        """
        if not self._ready:
            return []

        geo = self._staad.Geometry

        # Diagnóstico único: listar todos los métodos disponibles en el log
        if not self._geo_diag_done:
            self._geo_diag_done = True
            try:
                log.info("Geometry métodos: %s",
                         sorted(m for m in dir(geo) if not m.startswith('_')))
                log.info("Raíz métodos: %s",
                         sorted(m for m in dir(self._staad) if not m.startswith('_')))
            except Exception:
                pass

        # Orden de candidatos: primero el nombre correcto de 2025
        _candidates = [
            ("Geometry", "GetSelectedBeams"),        # ← correcto 2025
            ("Geometry", "GetSelectedBeamList"),
            ("Geometry", "GetSelectedMemberList"),
            ("Geometry", "GetSelectedMembers"),
            (None,       "GetSelectedBeams"),
            (None,       "GetSelectedBeamList"),
            (None,       "GetSelectedMembers"),
        ]

        for sub, name in _candidates:
            try:
                obj = getattr(self._staad, sub) if sub else self._staad
                fn  = getattr(obj, name, None)
                if fn is None:
                    continue
                raw = fn()
                if raw is None:
                    continue
                ids = [int(b) for b in raw if b]
                if ids:
                    log.info("get_selected_members via '%s.%s': %d barra(s)",
                             sub or "staad", name, len(ids))
                    return ids
            except Exception as exc:
                log.debug("get_selected_members/%s.%s: %s", sub, name, exc)

        log.warning("Ningun metodo de seleccion de barras funciono.")
        return []

    # ══════════════════════════════════════════════════════════════════════════
    # Longitud de barra
    # ══════════════════════════════════════════════════════════════════════════

    def get_member_length(self, member_id: int) -> float:
        """
        Longitud del miembro en metros.
        Método correcto 2025: Geometry.GetBeamLength(member_id)
        Fallback: cálculo a partir de coordenadas de nodos.
        """
        geo = self._staad.Geometry

        # Método directo
        for fn_name in ("GetBeamLength", "GetMemberLength", "GetBarLength"):
            fn = getattr(geo, fn_name, None)
            if fn:
                try:
                    v = float(fn(member_id))
                    if v > 0:
                        return v
                except Exception:
                    pass

        # Fallback: calcular desde coordenadas de nodos
        try:
            inc = geo.GetMemberIncidence(member_id)
            sn, en = int(inc[0]), int(inc[1])
            sc = geo.GetNodeCoordinates(sn)
            ec = geo.GetNodeCoordinates(en)
            dx = float(ec[0]) - float(sc[0])
            dy = float(ec[1]) - float(sc[1])
            dz = float(ec[2]) - float(sc[2])
            length = math.sqrt(dx*dx + dy*dy + dz*dz)
            log.debug("Longitud M%d calculada de coordenadas: %.4f m",
                      member_id, length)
            return length
        except Exception as exc:
            log.warning("get_member_length(%d): %s", member_id, exc)
            return 0.0

    # ══════════════════════════════════════════════════════════════════════════
    # Propiedades de sección
    # ══════════════════════════════════════════════════════════════════════════

    def get_section_properties(self, member_id: int) -> Optional[SectionProperties]:
        """
        1. Intenta obtener el nombre del perfil de STAAD.
        2. Busca el perfil en la base de datos AISC (fuente más confiable).
        3. Si no está en BD, intenta leer propiedades via API STAAD.
        4. Si el API falla, estima desde dimensiones básicas.
        """
        if member_id in self._sec_cache:
            return self._sec_cache[member_id]

        try:
            geo  = self._staad.Geometry
            prop = self._staad.Property

            # ── Nombre del perfil ─────────────────────────────────────────────
            # Método correcto 2025: Property.GetBeamSectionName(beam_id)
            profile_name = ""
            for attr, method in [
                ("Property", "GetBeamSectionName"),   # ← correcto 2025
                ("Property", "GetBeamProfile"),
                ("Property", "GetMemberProfile"),
                ("Property", "GetSectionName"),
                ("Geometry", "GetBeamProfile"),
                ("Geometry", "GetMemberProfile"),
            ]:
                try:
                    obj = getattr(self._staad, attr)
                    fn  = getattr(obj, method, None)
                    if fn:
                        name = str(fn(member_id)).strip()
                        if name and name.lower() not in ("none", ""):
                            profile_name = name
                            log.debug("Perfil M%d vía %s.%s: '%s'",
                                      member_id, attr, method, name)
                            break
                except Exception:
                    pass

            sp       = SectionProperties()
            sp.label = profile_name.upper() if profile_name else f"MBR{member_id}"
            sp.kind  = _detect_kind(sp.label)

            # ── 1. Base de datos AISC (fuente primaria) ───────────────────────
            db = lookup(sp.label)
            if db:
                sp.A  = db["A"];  sp.d  = db["d"];  sp.bf = db["bf"]
                sp.tf = db["tf"]; sp.tw = db["tw"]
                sp.Ix = db["Ix"]; sp.Sx = db["Sx"]; sp.Zx = db["Zx"]
                sp.Iy = db["Iy"]; sp.Sy = db["Sy"]; sp.Zy = db["Zy"]
                sp.rx = db["rx"]; sp.ry = db["ry"]
                sp.J  = db["J"];  sp.Cw = db["Cw"]
                log.info("M%d '%s' cargado de BD AISC.", member_id, sp.label)

            else:
                # ── 2. API STAAD: GetSectionPropertyValue ─────────────────────
                log.warning("M%d '%s' no en BD — leyendo de STAAD.",
                            member_id, sp.label)

                def _gspv(pname: str) -> float:
                    """GetSectionPropertyValue en Property o Geometry."""
                    for obj in (prop, geo):
                        fn = getattr(obj, "GetSectionPropertyValue", None)
                        if fn:
                            try:
                                v = float(fn(member_id, pname))
                                if v != 0.0:
                                    return v
                            except Exception:
                                pass
                    return 0.0

                sp.A  = _gspv("AX") * 1e4   # m² → cm²
                sp.Ix = _gspv("IX") * 1e8   # m⁴ → cm⁴
                sp.Iy = _gspv("IY") * 1e8
                sp.Sx = _gspv("SX") * 1e6   # m³ → cm³
                sp.Sy = _gspv("SY") * 1e6
                sp.Zx = _gspv("ZX") * 1e6
                sp.Zy = _gspv("ZY") * 1e6
                sp.rx = _gspv("RX") * 1e2   # m → cm
                sp.ry = _gspv("RY") * 1e2
                sp.J  = _gspv("IX_TORSION") * 1e8
                sp.d  = _gspv("D")  * 1e2
                sp.bf = _gspv("B")  * 1e2
                sp.tf = _gspv("TF") * 1e2
                sp.tw = _gspv("TW") * 1e2

                # ── 3. GetBeamPropertyAll como respaldo de dimensiones ─────────
                # En 2025 devuelve un dict; en versiones anteriores puede ser lista.
                if sp.d == 0 or sp.bf == 0:
                    try:
                        raw = prop.GetBeamPropertyAll(member_id)
                        if isinstance(raw, dict):
                            # Claves posibles del dict de 2025
                            sp.bf = float(raw.get("width",  raw.get("b",  0))) * 1e2
                            sp.d  = float(raw.get("depth",  raw.get("d",  0))) * 1e2
                            sp.tf = float(raw.get("flange", raw.get("tf", 0))) * 1e2
                            sp.tw = float(raw.get("web",    raw.get("tw", 0))) * 1e2
                        else:
                            # Versiones anteriores retornan secuencia [b, d, ...]
                            sp.bf = float(raw[0]) * 1e2
                            sp.d  = float(raw[1]) * 1e2
                    except Exception as exc:
                        log.debug("GetBeamPropertyAll M%d: %s", member_id, exc)

                # ── 3b. Para HSS/PIPE: leer espesor de pared con nombres extra ─
                # STAAD reporta el espesor de pared en propiedades no estándar
                # ("T", "TS", "TH") en lugar de TW/TF para secciones tubulares.
                if sp.kind in (SectionKind.HSS_ROUND, SectionKind.HSS_RECT):
                    if sp.tw == 0 and sp.tf == 0:
                        # Intentar nombres alternativos de STAAD para espesor de pared
                        for pname in ("TS", "T", "TH", "WALL_THK", "THICK"):
                            v = _gspv(pname)
                            if v > 0:
                                sp.tw = v * 1e2   # m → cm
                                sp.tf = sp.tw
                                log.info("M%d: espesor de pared via '%s' = %.4f cm",
                                         member_id, pname, sp.tw)
                                break

                    # Fallback para PIPE: intentar leer Di (diámetro interior)
                    if sp.tw == 0 and sp.kind == SectionKind.HSS_ROUND and sp.d > 0:
                        Di_m = 0.0
                        for pname in ("DI", "ID", "DIAM_INT", "OID", "DIAM_I"):
                            v = _gspv(pname)
                            if v > 0:
                                Di_m = v
                                break
                        if Di_m > 0:
                            Di_cm = Di_m * 1e2
                            sp.tw = (sp.d - Di_cm) / 2.0
                            sp.tf = sp.tw
                            log.info("M%d: espesor de pared de Di = (%.3f - %.3f)/2 = %.4f cm",
                                     member_id, sp.d, Di_cm, sp.tw)

                    # Fallback: derivar espesor de área (A = π/4·(D²-Di²) → Di = √(D²-4A/π))
                    if sp.tw == 0 and sp.kind == SectionKind.HSS_ROUND and sp.d > 0 and sp.A > 0:
                        import math as _m
                        Di_sq = sp.d**2 - 4.0 * sp.A / _m.pi
                        if Di_sq > 0:
                            Di   = _m.sqrt(Di_sq)
                            sp.tw = (sp.d - Di) / 2.0
                            sp.tf = sp.tw
                            log.info("M%d PIPE: t derivado de área = %.4f cm", member_id, sp.tw)

                    # Último recurso: tabla de schedules estándar desde el nombre
                    if sp.tw == 0 and sp.kind == SectionKind.HSS_ROUND:
                        pipe_data = pipe_thickness_from_name(sp.label)
                        if pipe_data:
                            OD_cm, t_cm = pipe_data
                            sp.d  = OD_cm    # reemplazar diámetro con valor de tabla
                            sp.bf = OD_cm
                            sp.tw = t_cm
                            sp.tf = t_cm
                            log.info("M%d PIPE: OD=%.3fcm t=%.4fcm de tabla de schedules",
                                     member_id, OD_cm, t_cm)

                # ── 4. Estimar propiedades desde dimensiones si API falló ──────
                if sp.A == 0 and sp.d > 0:
                    if sp.kind == SectionKind.HSS_ROUND and sp.tw > 0:
                        est = estimate_from_hss_round(sp.d, sp.tw)
                        for k, v in est.items():
                            if getattr(sp, k, 0) == 0:
                                setattr(sp, k, v)
                        log.warning("M%d PIPE/HSS_ROUND: propiedades estimadas por fórmula.",
                                    member_id)
                    elif sp.kind == SectionKind.HSS_RECT and sp.tw > 0 and sp.bf > 0:
                        est = estimate_from_hss_rect(sp.d, sp.bf, sp.tw)
                        for k, v in est.items():
                            if getattr(sp, k, 0) == 0:
                                setattr(sp, k, v)
                        log.warning("M%d HSS_RECT: propiedades estimadas por fórmula.",
                                    member_id)
                    elif sp.bf > 0:
                        tf_est = max(sp.tf, sp.d * 0.06)
                        tw_est = max(sp.tw, sp.d * 0.03)
                        est    = estimate_from_dimensions(sp.d, sp.bf, tf_est, tw_est)
                        for k, v in est.items():
                            if getattr(sp, k, 0) == 0:
                                setattr(sp, k, v)
                        log.warning("M%d: propiedades estimadas por formula.", member_id)

            # ── Normalización final de propiedades HSS ────────────────────────
            if sp.kind == SectionKind.HSS_ROUND and sp.d > 0 and sp.bf == 0:
                sp.bf = sp.d
            if sp.kind == SectionKind.HSS_RECT and sp.bf == 0 and sp.d > 0:
                sp.bf = sp.d
                log.warning("M%d HSS_RECT: bf=0, asumiendo sección cuadrada (B=H=%.3f cm)",
                            member_id, sp.d)

            # ── Detección geométrica de tipo para secciones UNKNOWN ───────────
            # Si el nombre no fue reconocido (ISECTION, GENERAL, PRISMATIC,
            # nombre personalizado, etc.), intentar determinar el tipo desde las
            # dimensiones que STAAD entregó.
            if sp.kind == SectionKind.UNKNOWN:
                kind_geo = _detect_kind_from_geometry(
                    sp.d, sp.bf, sp.tf, sp.tw, sp.A)
                if kind_geo != SectionKind.UNKNOWN:
                    log.warning(
                        "M%d '%s': nombre no reconocido → tipo inferido por geometría "
                        "como '%s'. Verifique que el tipo sea correcto.",
                        member_id, sp.label, kind_geo.value)
                    sp.kind = kind_geo
                else:
                    # Sin dimensiones suficientes: tratar como W_OR_IR (más común)
                    # Las propiedades mecánicas (Ix, Sx, Zx, ry) sí vienen de STAAD.
                    log.warning(
                        "M%d '%s': tipo de sección DESCONOCIDO y sin dimensiones "
                        "suficientes. Se tratará como perfil I/H (W_OR_IR). "
                        "Ingrese las dimensiones en STAAD o revise el nombre del perfil.",
                        member_id, sp.label)
                    sp.kind = SectionKind.W_OR_IR

            sp.compute_derived()
            self._sec_cache[member_id] = sp
            log.info("M%d  %s  A=%.1fcm2  Ix=%.0fcm4  ry=%.2fcm  "
                     "Lp≈%.2fm  Cw=%.0fcm6",
                     member_id, sp.label, sp.A, sp.Ix, sp.ry,
                     sp.rts * 1.76 * math.sqrt(2039000 / 3515) / 100
                     if sp.rts > 0 else 0,
                     sp.Cw)
            return sp

        except Exception as exc:
            log.error("get_section_properties(%d): %s", member_id, exc)
            return None

    # ══════════════════════════════════════════════════════════════════════════
    # Casos de carga
    # ══════════════════════════════════════════════════════════════════════════

    def get_load_cases(self) -> List[int]:
        """
        Devuelve la lista real de IDs de casos de carga (primarios + combinaciones).

        Método correcto 2025:
          Load.GetPrimaryLoadCaseNumbers()    → lista de IDs primarios
          Load.GetLoadCombinationCaseNumbers() → lista de IDs de combinaciones
        Fallback 2024:
          Load.GetPrimaryLoadCaseCount() + GetLoadCombinationCaseCount()
        Fallback final: escaneo bruto 1..200
        """
        if not self._ready:
            return []
        ld = self._staad.Load

        # ── Approach A: métodos que devuelven listas de IDs (2025) ────────────
        try:
            prim = list(ld.GetPrimaryLoadCaseNumbers())
            comb = list(ld.GetLoadCombinationCaseNumbers())
            ids  = sorted(set(int(x) for x in prim + comb if x))
            if ids:
                log.info("Casos de carga: %d (primarios=%d, combos=%d)  "
                         "rango %d–%d",
                         len(ids), len(prim), len(comb),
                         min(ids), max(ids))
                return ids
        except Exception as exc:
            log.debug("GetPrimary/ComboNumbers: %s", exc)

        # ── Approach B: conteo → range (2024 / anterior) ─────────────────────
        try:
            n_p = int(ld.GetPrimaryLoadCaseCount())
            n_c = int(ld.GetLoadCombinationCaseCount())
            ids = list(range(1, n_p + n_c + 1))
            if ids:
                log.info("Casos de carga por conteo: %d (prim=%d, comb=%d)",
                         len(ids), n_p, n_c)
                return ids
        except Exception as exc:
            log.debug("GetPrimary/ComboCount: %s", exc)

        # ── Approach C: GetLoadCaseCount total ───────────────────────────────
        for fn_name in ("GetLoadCaseCount", "GetNumberOfLoadCases",
                        "GetTotalLoadCaseCount"):
            fn = getattr(ld, fn_name, None)
            if fn:
                try:
                    n   = int(fn())
                    ids = list(range(1, n + 1))
                    log.info("Casos de carga via %s: %d", fn_name, n)
                    return ids
                except Exception:
                    pass

        # ── Approach D: escaneo bruto (último recurso) ────────────────────────
        ids = []
        for i in range(1, 301):
            try:
                self._get_lc_title(i)
                ids.append(i)
            except Exception:
                if len(ids) > 0:
                    break
        if ids:
            log.warning("Casos de carga por escaneo: %d", len(ids))
            return ids

        log.error("No se pudieron obtener los casos de carga.")
        return []

    def get_load_case_name(self, lc_id: int) -> str:
        """
        Devuelve SÓLO el número del caso de carga como cadena (ej. "15").
        Esto es lo que se muestra en las tablas de la UI y se usa como clave
        en MemberForces.combos.
        """
        return str(lc_id)

    def _get_lc_title(self, lc_id: int) -> str:
        """
        Nombre del caso de carga.
        Método correcto 2025: Load.GetLoadCaseTitle(lc_id)
        Fallback:             Load.GetLoadCaseName(lc_id)
        """
        ld = self._staad.Load
        for fn_name in ("GetLoadCaseTitle",    # ← correcto 2025
                        "GetLoadCaseName",      # ← versiones anteriores
                        "GetLoadCaseLabel"):
            fn = getattr(ld, fn_name, None)
            if fn:
                try:
                    name = str(fn(lc_id)).strip()
                    if name and name.lower() not in ("", "none"):
                        return name
                except Exception:
                    pass
        return f"LC{lc_id}"

    # ══════════════════════════════════════════════════════════════════════════
    # Fuerzas internas
    # ══════════════════════════════════════════════════════════════════════════

    def get_forces_at_sections(self, member_id: int,
                               lc_id: int,
                               length_m: float) -> List[SectionPoint]:
        """
        Fuerzas en Inicio (x=0), Medio (x=L/2) y Fin (x=L).
        Unidades de salida: ton y ton·m.

        Método correcto 2025:
          Output.GetMemberEndForces(memberNo, end, loadCaseNo, LocalOrGlobal=0)
          Output.GetIntermediateMemberForcesAtDistance(memberNo, dist, loadCaseNo)
        Fallback 2024: sin 4º parámetro / interpolación lineal.
        """
        key = (member_id, lc_id)
        if key in self._force_cache:
            return self._force_cache[key]

        out     = self._staad.Output
        f       = self._unit_f
        lc_name = self.get_load_case_name(lc_id)

        def _parse(raw) -> Dict:
            return {
                "Fx": float(raw[0]) * f,
                "Fy": float(raw[1]) * f,
                "Fz": float(raw[2]) * f,
                "Mx": float(raw[3]) * f,
                "My": float(raw[4]) * f,
                "Mz": float(raw[5]) * f,
            }

        def _get_end(end_idx: int):
            """Lee fuerzas en extremo. Prueba firma con 4 y 3 parámetros."""
            # 2025: GetMemberEndForces(memberNo, end, lcNo, 0=Local/1=Global)
            for args in [
                (member_id, end_idx, lc_id, 0),   # 2025
                (member_id, end_idx, lc_id),        # 2024
            ]:
                try:
                    raw = out.GetMemberEndForces(*args)
                    if raw is not None and len(raw) >= 6:
                        return raw
                except Exception:
                    pass
            return None

        def _get_mid(dist: float, raw_start, raw_end):
            """
            Lee fuerzas a distancia intermedia.
            2025: GetIntermediateMemberForcesAtDistance(memberNo, dist, lcNo)
            Fallbacks para 2024 + interpolación lineal.
            """
            for fn_name, args in [
                ("GetIntermediateMemberForcesAtDistance",
                 (member_id, dist, lc_id)),          # ← 2025 correcto
                ("GetMemberForceAtDistance",
                 (member_id, lc_id, dist)),
                ("GetIntermediateMemberForces",
                 (member_id, dist, lc_id)),
            ]:
                fn = getattr(out, fn_name, None)
                if fn:
                    try:
                        raw = fn(*args)
                        if raw is not None and len(raw) >= 6:
                            return raw
                    except Exception:
                        pass

            # Último recurso: interpolación lineal entre extremos
            if raw_start is not None and raw_end is not None:
                return [(float(raw_start[i]) + float(raw_end[i])) / 2.0
                        for i in range(6)]
            return None

        # Leer extremos
        raw0 = _get_end(0)
        raw1 = _get_end(1)

        pts: List[SectionPoint] = []
        for i, (dist_frac, raw_direct) in enumerate(
                [(0.0, raw0), (0.5, None), (1.0, raw1)]):

            dist   = dist_frac * length_m
            sp_pt  = SectionPoint()
            sp_pt.combo = lc_name
            sp_pt.dist  = dist

            if raw_direct is not None:
                raw = raw_direct
            else:
                raw = _get_mid(dist, raw0, raw1)

            if raw is None:
                log.warning("M%d LC%d pt%d: sin fuerzas — usando ceros.",
                            member_id, lc_id, i)
                raw = [0.0] * 6

            d = _parse(raw)

            # N positivo = compresión (STAAD Fx(+) = tensión → invertimos)
            sp_pt.N  = -d["Fx"]
            sp_pt.Vz =  d["Fy"]
            sp_pt.Vy =  d["Fz"]
            sp_pt.T  =  d["Mx"]
            # Nodo FIN (i==2): GetMemberEndForces entrega la ACCIÓN DE EXTREMO,
            # cuyo momento tiene signo OPUESTO al del diagrama interno (inicio y
            # mitad). Se invierte para que + = flexión positiva de forma
            # consistente en toda la barra y con las barras contiguas.
            _sgn = -1.0 if i == 2 else 1.0
            sp_pt.My =  d["My"] * _sgn
            sp_pt.Mz =  d["Mz"] * _sgn
            pts.append(sp_pt)

        self._force_cache[key] = pts
        return pts

    # ══════════════════════════════════════════════════════════════════════════
    # Pre-fetch masivo (ejecutar siempre en el hilo principal — COM STA)
    # ══════════════════════════════════════════════════════════════════════════

    def fetch_all(self, member_ids: List[int],
                  lc_start: int = 0,
                  lc_end:   int = 0) -> Dict:
        """
        Obtiene todos los datos necesarios en el hilo principal (evita
        problemas de afinidad COM / STA).

        lc_start / lc_end: rango de combinaciones a procesar (0 = todos).
        Devuelve dict {member_id: {section, length, forces: MemberForces}}.
        """
        all_lc = self.get_load_cases()

        if lc_start > 0 or lc_end > 0:
            lo     = lc_start if lc_start > 0 else (min(all_lc) if all_lc else 1)
            hi     = lc_end   if lc_end   > 0 else (max(all_lc) if all_lc else 9999)
            lc_ids = [lc for lc in all_lc if lo <= lc <= hi]
            log.info("fetch_all: filtrando LC %d–%d → %d/%d combinaciones",
                     lo, hi, len(lc_ids), len(all_lc))
        else:
            lc_ids = all_lc

        if not lc_ids:
            log.error("fetch_all: no hay casos de carga. Verifique el rango.")

        data: Dict = {}
        for mid in member_ids:
            sp     = self.get_section_properties(mid)
            length = self.get_member_length(mid)

            mf = MemberForces(member_id=mid)
            for lc_id in lc_ids:
                pts  = self.get_forces_at_sections(mid, lc_id, length)
                name = self.get_load_case_name(lc_id)
                if pts:
                    mf.combos[name] = pts

            data[mid] = {
                "section": sp,
                "length":  length,
                "forces":  mf,
            }
            log.info("fetch_all  M%d  %s  L=%.3fm  combos=%d",
                     mid,
                     sp.label if sp else "?",
                     length,
                     len(mf.combos))

        return data
