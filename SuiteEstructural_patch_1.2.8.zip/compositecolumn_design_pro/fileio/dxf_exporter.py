# fileio/dxf_exporter.py
"""
Exportación de ratios a DXF — Composite Column Design Pro.
Mismo formato que columnsteel_design_pro / beamsteel_design_pro.

Los resultados son dicts:  {"member_id": int, "envelope": DesignResult, ...}
El ratio gobernante es envelope.PR_max y la combinación envelope.label.
"""
from __future__ import annotations

import re
from typing import List

try:
    import ezdxf
    from ezdxf.math import Vec3
    DXF_OK = True
except ImportError:
    DXF_OK = False


def _gov_ratio(r: dict) -> tuple[float, str]:
    env = r.get("envelope")
    if env is None:
        return 0.0, ""
    lbl = getattr(env, "label", "") or str(getattr(env, "lc", ""))
    return float(getattr(env, "PR_max", 0.0)), lbl


def export_dxf_single(path: str, results: List[dict],
                      reduction_pct: float = 20.0) -> bool:
    if not DXF_OK:
        return False
    try:
        doc = ezdxf.new("R2010")
        msp = doc.modelspace()
        doc.layers.new("COLUMNAS", dxfattribs={"color": 3})
        doc.layers.new("TEXTO",    dxfattribs={"color": 7})
        doc.layers.new("FALLADAS", dxfattribs={"color": 1})

        factor = (100.0 - reduction_pct) / 100.0
        H_COL  = 30.0
        x_off  = 0.0
        for r in results:
            mid_y = H_COL / 2.0
            half  = (H_COL * factor) / 2.0
            msp.add_line((x_off, mid_y - half), (x_off, mid_y + half),
                         dxfattribs={"layer": "COLUMNAS", "lineweight": 50})
            ratio, gov = _gov_ratio(r)
            layer = "FALLADAS" if ratio > 1.0 else "TEXTO"
            msp.add_text(
                f"{r.get('member_id', '?')} / {ratio:.3f}"
                + (f"  ({gov})" if gov else ""),
                dxfattribs={"height": 0.30, "layer": layer,
                            "rotation": 90.0,
                            "insert": (x_off + 0.5, mid_y)})
            msp.add_text(
                f"{r.get('profile_name', '')}",
                dxfattribs={"height": 0.30, "layer": "TEXTO",
                            "insert": (x_off - 0.4, -1.0)})
            x_off += 6.0

        doc.saveas(path)
        return True
    except Exception:
        return False


def modify_existing_dxf(dxf_path: str, results: List[dict],
                        reduction_pct: float = 20.0) -> tuple[bool, str]:
    if not DXF_OK:
        return False, "ezdxf no instalado"
    try:
        doc = ezdxf.readfile(dxf_path)
    except Exception as ex:
        return False, str(ex)

    msp = doc.modelspace()
    factor = ((100.0 - reduction_pct) / 100.0
              if 0 < reduction_pct < 100 else 1.0)

    ratio_map: dict[int, float] = {}
    gov_map:   dict[int, str]   = {}
    for r in results:
        try:
            mid = int(r.get("member_id"))
        except (TypeError, ValueError):
            continue
        ratio_map[mid], gov_map[mid] = _gov_ratio(r)

    n_lines = 0
    for entity in msp.query("LINE"):
        p1  = Vec3(entity.dxf.start)
        p2  = Vec3(entity.dxf.end)
        mid = (p1 + p2) / 2.0
        d   = (p2 - p1) * (factor / 2.0)
        entity.dxf.start = mid - d
        entity.dxf.end   = mid + d
        n_lines += 1

    # Ignorar textos en capas apagadas/congeladas (p.ej. numeración de
    # nodos oculta): sin este filtro se detecta su numeración y se
    # duplican valores en el DXF.
    try:
        from suite_shared.dxf_text_layout import hidden_layers
        ocultas = hidden_layers(doc)
    except Exception:
        ocultas = set()

    n_texts = 0
    labeled = []
    for entity in msp.query("TEXT MTEXT"):
        if getattr(entity.dxf, "layer", "") in ocultas:
            continue
        try:
            raw = (entity.dxf.text
                   if hasattr(entity.dxf, "text") else entity.text)
        except Exception:
            continue
        mid_id = _parse_member_id(raw)
        if mid_id and mid_id in ratio_map:
            ratio   = ratio_map[mid_id]
            gov     = gov_map.get(mid_id, "")
            new_txt = (f"{mid_id} / {ratio:.3f}"
                       + (f"  ({gov})" if gov else ""))
            try:
                if hasattr(entity.dxf, "text"):
                    entity.dxf.text = new_txt
                else:
                    entity.text = new_txt
                n_texts += 1
                labeled.append((entity, ratio > 1.0))
            except Exception:
                pass

    try:
        from suite_shared.dxf_text_layout import arrange_labels
        arrange_labels(doc, labeled)
    except Exception:
        pass

    out_path = dxf_path.replace(".dxf", "_mod.dxf")
    doc.saveas(out_path)
    return True, out_path


def _parse_member_id(text: str):
    m = re.match(r"\s*(\d+)", text.strip())
    return int(m.group(1)) if m else None
