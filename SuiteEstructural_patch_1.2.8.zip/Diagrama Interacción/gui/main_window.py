﻿"""
Ventana principal de Interaction Design Pro.

Layout:
  Panel izquierdo (QSplitter):
    - Tab "Sección" (rectangular / circular / irregular)
    - Tab "Materiales"
    - Tab "Cargas"
    - Botón [Calcular]

  Panel derecho (QTabWidget):
    - Vista 2D de la sección
    - Diagrama 3D de interacción
    - M-φ / M-θ
    - Curvas σ-ε
    - Memoria de cálculo (texto)
"""
import logging
import traceback
from pathlib import Path

import numpy as np
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QTabWidget, QPushButton, QLabel, QProgressBar, QScrollArea,
    QStatusBar, QFrame, QFileDialog, QMessageBox, QTextEdit,
)
from PySide6.QtCore import Qt, QThread, Signal, Slot, QTimer
from PySide6.QtGui import QFont, QAction

from gui.section_input.rectangular_panel import RectangularPanel
from gui.section_input.circular_panel import CircularPanel
from gui.section_input.irregular_panel import IrregularPanel
from gui.material_panel import MaterialPanel
from gui.loads_panel import LoadsPanel
from gui.plots.section_view import SectionViewWidget
from gui.plots.interaction_plot_3d import InteractionPlot3DWidget
from gui.plots.interaction_plot_2d import InteractionPlot2DWidget
from gui.plots.mc_plot import MCWidget
from gui.plots.stress_strain_plot import StressStrainWidget
from gui.styles import MAIN_STYLE, PLOT_STYLE

from core.interaction_3d import generate_interaction_surface, check_demands, InteractionResult
from core.moment_curvature import compute_moment_curvature, compute_moment_rotation
from config.settings import APP_NAME, APP_VERSION

import matplotlib
matplotlib.rcParams.update(PLOT_STYLE)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Worker thread para cálculo
# ──────────────────────────────────────────────────────────────────────────────

class CalcWorker(QThread):
    """
    Ejecuta el cálculo en un hilo separado.

    do_interaction : genera la superficie de interacción 3D.
    do_mc          : genera M-φ / M-θ.
    Ambos pueden activarse juntos o por separado.
    """

    progress     = Signal(int, str)
    finished_ok  = Signal(object, object, object)  # result, mc, mr
    finished_err = Signal(str)

    def __init__(self, section, concrete, concrete_conf, steel, code, mc_params,
                 do_interaction=True, do_mc=True,
                 prev_result=None, parent=None):
        super().__init__(parent)
        self.section        = section
        self.concrete       = concrete       # sin confinar (para interacción)
        self.concrete_conf  = concrete_conf  # con/sin confinar (para M-φ)
        self.steel          = steel
        self.code           = code
        self.mc_params      = mc_params
        self.do_interaction = do_interaction
        self.do_mc          = do_mc
        self.prev_result    = prev_result    # resultado previo cuando solo se corre M-φ

    def run(self):
        try:
            result = self.prev_result

            if self.do_interaction:
                self.progress.emit(5, "Generando superficie de interacción...")
                result = generate_interaction_surface(
                    self.section, self.concrete, self.steel,
                    code=self.code,
                    n_angles=72, n_points=60,
                    fy=self.steel.fy, Es=self.steel.Es,
                    progress_cb=lambda p, m: self.progress.emit(5 + int(p * 0.75), m),
                )

            mc = mr = None
            if self.do_mc:
                pct_base = 80 if self.do_interaction else 5
                self.progress.emit(pct_base, "Calculando diagrama M-φ...")
                mc = compute_moment_curvature(
                    self.section, self.concrete_conf, self.steel,
                    N_ext_ton=self.mc_params["N_ext"],
                    angle_deg=self.mc_params["angle_deg"],
                    n_points=120,
                )

                self.progress.emit(pct_base + 10, "Calculando diagrama M-θ...")
                if mc.phi_y > 0:
                    mr = compute_moment_rotation(
                        mc, self.section, self.concrete_conf, self.steel,
                        N_ext_ton=self.mc_params["N_ext"],
                        Lv=self.mc_params["Lv"],
                        rho_sh=self.mc_params["rho_sh"],
                        db_long=self.mc_params["db_long"],
                        s_v=self.mc_params["s_v"],
                    )

            self.progress.emit(100, "Cálculo completado.")
            self.finished_ok.emit(result, mc, mr)

        except Exception:
            self.finished_err.emit(traceback.format_exc())


# ──────────────────────────────────────────────────────────────────────────────
# Ventana principal
# ──────────────────────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1400, 860)
        self.setMinimumSize(900, 560)
        self.setStyleSheet(MAIN_STYLE)

        self._result: InteractionResult | None = None
        self._mc_result = None
        self._mr_result = None
        self._section   = None
        self._worker    = None

        self._build_ui()
        self._build_statusbar()
        self._connect()

        # Mostrar sección inicial
        QTimer.singleShot(200, self._preview_section)

    # ──────────────────────────────────────────────────────────────────────────
    # Construcción de la UI
    # ──────────────────────────────────────────────────────────────────────────


        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "diagrama_interaccion")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root_lay = QVBoxLayout(central)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)

        # ── Header estándar (60px) ────────────────────────────────────────────
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(60)
        header.setStyleSheet("QFrame#header { background-color: #1B4F72; }")
        hdr_lay = QHBoxLayout(header)
        hdr_lay.setContentsMargins(16, 0, 16, 0)

        lbl_title = QLabel(APP_NAME)
        lbl_title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        lbl_title.setStyleSheet("color: white;")
        hdr_lay.addWidget(lbl_title)

        lbl_sub = QLabel("Diagrama de Interacción P-Mx-My  ·  Sección de Concreto Reforzado")
        lbl_sub.setStyleSheet("color: #AED6F1;")
        hdr_lay.addWidget(lbl_sub)
        hdr_lay.addStretch()

        lbl_ver = QLabel(f"v{APP_VERSION}  ·  NTC 2023 / ACI 318-25")
        lbl_ver.setStyleSheet("color: rgba(255,255,255,0.65); font-size: 8pt;")
        hdr_lay.addWidget(lbl_ver)
        root_lay.addWidget(header)

        # ── Splitter principal ────────────────────────────────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)

        # Panel izquierdo envuelto en QScrollArea
        left_content = QWidget()
        left_content.setMinimumWidth(260)
        left_lay = QVBoxLayout(left_content)
        left_lay.setContentsMargins(6, 6, 6, 6)
        left_lay.setSpacing(4)

        self.tabs_input = QTabWidget()
        self.tabs_input.setTabPosition(QTabWidget.North)

        # Sección
        sec_widget = QWidget()
        sec_lay = QVBoxLayout(sec_widget)
        sec_lay.setContentsMargins(2, 2, 2, 2)
        self.tabs_sec = QTabWidget()
        self.panel_rect = RectangularPanel()
        self.panel_circ = CircularPanel()
        self.panel_irr  = IrregularPanel()
        self.tabs_sec.addTab(self.panel_rect, "Rectangular")
        self.tabs_sec.addTab(self.panel_circ, "Circular")
        self.tabs_sec.addTab(self.panel_irr,  "Irregular")
        sec_lay.addWidget(self.tabs_sec)
        self.tabs_input.addTab(sec_widget, "Sección")

        self.panel_mat = MaterialPanel()
        self.tabs_input.addTab(self.panel_mat, "Materiales")

        self.panel_loads = LoadsPanel()
        self.tabs_input.addTab(self.panel_loads, "Cargas")

        left_lay.addWidget(self.tabs_input)

        # Botones de cálculo
        self.btn_calc = QPushButton("Calcular Diagrama de Interacción")
        self.btn_calc.setObjectName("btn_run")
        self.btn_calc.setMinimumHeight(36)
        self.btn_calc.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.btn_calc.setToolTip("Genera la superficie de interacción P-Mx-My 3D")
        left_lay.addWidget(self.btn_calc)

        self.btn_calc_mc = QPushButton("Calcular M-φ / M-θ")
        self.btn_calc_mc.setObjectName("btn_connect")
        self.btn_calc_mc.setMinimumHeight(30)
        self.btn_calc_mc.setToolTip(
            "Recalcula solo los diagramas Momento-Curvatura y Momento-Rotación\n"
            "sin regenerar la superficie 3D."
        )
        left_lay.addWidget(self.btn_calc_mc)

        self.btn_word = QPushButton("Exportar Word")
        self.btn_word.setObjectName("btn_word")
        self.btn_word.setToolTip("Exportar resultados a documento Word (.docx)")
        left_lay.addWidget(self.btn_word)

        left_scroll = QScrollArea()
        left_scroll.setWidget(left_content)
        left_scroll.setWidgetResizable(True)
        left_scroll.setMinimumWidth(260)
        left_scroll.setMaximumWidth(430)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Panel derecho
        self.tabs_results = QTabWidget()
        self.tabs_results.setMinimumWidth(400)

        self.w_section_view   = SectionViewWidget()
        self.w_interaction_3d = InteractionPlot3DWidget()
        self.w_interaction_2d = InteractionPlot2DWidget()
        self.w_mc             = MCWidget()
        self.w_ss             = StressStrainWidget()
        self.w_memo           = QTextEdit()
        self.w_memo.setReadOnly(True)
        self.w_memo.setFont(QFont("Consolas", 9))
        self.w_memo.setPlaceholderText("La memoria de cálculo aparecerá aquí tras calcular...")

        self.tabs_results.addTab(self.w_section_view,   "Vista 2D")
        self.tabs_results.addTab(self.w_interaction_3d, "Interacción 3D")
        self.tabs_results.addTab(self.w_interaction_2d, "Interacción 2D")
        self.tabs_results.addTab(self.w_mc,             "M-φ / M-θ")
        self.tabs_results.addTab(self.w_ss,             "σ-ε Materiales")
        self.tabs_results.addTab(self.w_memo,           "Memoria")

        splitter.addWidget(left_scroll)
        splitter.addWidget(self.tabs_results)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        root_lay.addWidget(splitter, 1)

        # ── Barra de progreso delgada (estándar 5px) ─────────────────────────
        self.progress = QProgressBar()
        self.progress.setFixedHeight(5)
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        root_lay.addWidget(self.progress)

    def _build_statusbar(self):
        sb = self.statusBar()
        self.lbl_status = QLabel("  Listo")
        sb.addWidget(self.lbl_status)
        lbl_norm = QLabel("NTC 2023 / ACI 318-25  ")
        sb.addPermanentWidget(lbl_norm)

    # ──────────────────────────────────────────────────────────────────────────
    # Señales
    # ──────────────────────────────────────────────────────────────────────────

    def _connect(self):
        self.btn_calc.clicked.connect(self._on_calculate)
        self.btn_calc_mc.clicked.connect(self._on_calculate_mc)
        self.btn_word.clicked.connect(self._export_word)
        # Cambio de tipo de sección → preview inmediato
        self.tabs_sec.currentChanged.connect(self._on_section_tab_changed)
        # Cualquier cambio en los paneles → preview inmediato + switch a Vista 2D
        self.panel_rect.section_changed.connect(self._preview_section)
        self.panel_circ.section_changed.connect(self._preview_section)
        self.panel_irr.section_changed.connect(self._preview_section)
        self.panel_mat.params_changed.connect(self._on_mat_changed)

    # ──────────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _get_section(self):
        idx = self.tabs_sec.currentIndex()
        if idx == 0:
            return self.panel_rect.get_section()
        elif idx == 1:
            return self.panel_circ.get_section()
        else:
            return self.panel_irr.get_section()

    def _on_section_tab_changed(self, *_):
        """Al cambiar tipo de sección muestra Vista 2D y actualiza preview."""
        self.tabs_results.setCurrentIndex(0)
        self._preview_section()

    def _preview_section(self, *_, switch_tab: bool = True):
        """Actualiza la vista 2D inmediatamente al cambiar cualquier parámetro."""
        try:
            sec = self._get_section()
            self._section = sec
            angle = self.panel_loads.get_mc_params()["angle_deg"]
            # Cambiar a Vista 2D solo si aún no hay resultado calculado
            if switch_tab and self._result is None:
                self.tabs_results.setCurrentIndex(0)
            # Siempre actualizar el canvas de vista 2D
            self.w_section_view.plot_section(sec, angle)
            n_bars = len(sec.rebars)
            rho_pct = sec.rho * 100
            self._status(
                f"Ag={sec.Ag:.1f} cm²  |  Ast={sec.Ast:.2f} cm²  |  "
                f"ρ={rho_pct:.2f}%  |  {n_bars} varillas"
            )
        except Exception as e:
            log.warning(f"Preview section error: {e}")
            self._status(f"⚠ Error de sección: {e}")

    def _on_mat_changed(self):
        self._update_ss_plot()
        # Actualiza f'cc en el panel de cargas cuando cambia f'c
        try:
            self.panel_loads.update_fcc_with_fc(self.panel_mat.sb_fc.value())
        except Exception:
            pass

    def _update_ss_plot(self):
        try:
            use_conf, fl = self.panel_loads.get_confinement()
            self.w_ss.plot(
                self.panel_mat.get_concrete(use_conf, fl),
                self.panel_mat.get_steel(),
            )
        except Exception as e:
            log.debug(f"σ-ε update: {e}")

    # ──────────────────────────────────────────────────────────────────────────
    # Cálculo principal
    # ──────────────────────────────────────────────────────────────────────────

    def _build_worker(self, do_interaction: bool, do_mc: bool):
        section   = self._get_section()
        use_conf, fl = self.panel_loads.get_confinement()
        concrete      = self.panel_mat.get_concrete()                   # sin confinar → interacción
        concrete_conf = self.panel_mat.get_concrete(use_conf, fl)       # con/sin → M-φ
        steel     = self.panel_mat.get_steel()
        code      = self.panel_mat.get_code_class()
        mc_params = self.panel_loads.get_mc_params()
        return section, CalcWorker(
            section, concrete, concrete_conf, steel, code, mc_params,
            do_interaction=do_interaction,
            do_mc=do_mc,
            prev_result=self._result,
            parent=self,
        )

    @Slot()
    def _on_calculate(self):
        """Genera el diagrama de interacción 3D y los diagramas M-φ / M-θ."""
        if self._worker and self._worker.isRunning():
            QMessageBox.warning(self, "Calculando", "Espere a que termine el cálculo actual.")
            return
        try:
            section, worker = self._build_worker(do_interaction=True, do_mc=True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Datos de entrada inválidos:\n{e}")
            return

        self._section = section
        self._last_do_interaction = True
        self._w_section_view_update(section, self.panel_loads.get_mc_params()["angle_deg"])
        self._update_ss_plot()
        self._start_worker(worker)

    @Slot()
    def _on_calculate_mc(self):
        """Genera solo los diagramas M-φ / M-θ sin recalcular la superficie 3D."""
        if self._worker and self._worker.isRunning():
            QMessageBox.warning(self, "Calculando", "Espere a que termine el cálculo actual.")
            return
        try:
            section, worker = self._build_worker(do_interaction=False, do_mc=True)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Datos de entrada inválidos:\n{e}")
            return

        self._section = section
        self._last_do_interaction = False
        self._w_section_view_update(section, self.panel_loads.get_mc_params()["angle_deg"])
        self._update_ss_plot()
        self._start_worker(worker)

    def _start_worker(self, worker):
        self.btn_calc.setEnabled(False)
        self.btn_calc_mc.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self._status("Iniciando cálculo...")
        self._worker = worker
        self._worker.progress.connect(self._on_progress)
        self._worker.finished_ok.connect(self._on_calc_done)
        self._worker.finished_err.connect(self._on_calc_error)
        self._worker.start()

    @Slot(int, str)
    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self._status(msg)

    @Slot(object, object, object)
    def _on_calc_done(self, result: InteractionResult, mc, mr):
        self._result    = result
        self._mc_result = mc
        self._mr_result = mr

        # Obtener demandas
        ids, Pu, Mxu, Myu = self.panel_loads.get_loads()
        inside = None
        if len(Pu) > 0:
            inside = check_demands(result, Pu, Mxu, Myu)
            self.panel_loads.mark_loads(inside)

        Pu_dem  = Pu  if len(Pu)  else None
        Mxu_dem = Mxu if len(Mxu) else None
        Myu_dem = Myu if len(Myu) else None

        # Actualizar gráficas de interacción solo si hay resultado nuevo
        if result is not None:
            self.w_interaction_3d.set_result(
                result, Pu=Pu_dem, Mxu=Mxu_dem, Myu=Myu_dem, inside=inside,
            )
            self.w_interaction_2d.set_result(
                result, Pu=Pu_dem, Mxu=Mxu_dem, Myu=Myu_dem, inside=inside,
            )

        if mc and mc.points:
            self.w_mc.plot_mc(mc)
        if mr:
            self.w_mc.plot_mr(mr, mc.My_val if mc else 0.0)

        self._build_text_memo(result, mc, mr, ids, Pu, Mxu, Myu, inside)

        # Navegar a la pestaña más relevante según qué se calculó
        if getattr(self, '_last_do_interaction', True):
            # Se calculó (o recalculó) la superficie de interacción → mostrarla
            if result is not None:
                self.tabs_results.setCurrentIndex(1)   # Interacción 3D
        else:
            # Solo se recalculó M-φ / M-θ → ir directamente a esa pestaña
            if mc and mc.points:
                self.tabs_results.setCurrentIndex(3)   # M-φ / M-θ

        self.btn_calc.setEnabled(True)
        self.btn_calc_mc.setEnabled(True)
        self.progress.setVisible(False)
        status = f"✓ Completado"
        if result is not None:
            status += f" — Pmax = {result.Pmax_red:.2f} ton"
        self._status(status)

    @Slot(str)
    def _on_calc_error(self, err: str):
        self.btn_calc.setEnabled(True)
        self.btn_calc_mc.setEnabled(True)
        self.progress.setVisible(False)
        self._status("✗ Error en el cálculo")
        QMessageBox.critical(self, "Error de cálculo", err[:1000])
        log.error(err)

    def _w_section_view_update(self, section, angle):
        try:
            self.w_section_view.plot_section(section, angle)
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # Memoria de cálculo (texto rápido)
    # ──────────────────────────────────────────────────────────────────────────

    def _build_text_memo(self, result, mc, mr, ids, Pu, Mxu, Myu, inside):
        import math
        concrete = self.panel_mat.get_concrete()
        steel    = self.panel_mat.get_steel()
        code     = self.panel_mat.get_code_class()
        sec      = self._section

        lines = []
        sep = "─" * 70

        lines.append(f"{'INTERACTION DESIGN PRO':^70}")
        lines.append(f"{'MEMORIA DE CÁLCULO':^70}")
        lines.append(sep)
        lines.append(f"Normativa: {code.NAME}")
        lines.append("")

        lines.append("SECCIÓN")
        lines.append(f"  Tipo:        {sec.section_type}")
        lines.append(f"  Ag:          {sec.Ag:.2f} cm²")
        lines.append(f"  Ast:         {sec.Ast:.3f} cm²")
        lines.append(f"  ρ:           {sec.rho*100:.3f} %")
        if sec.b > 0:
            lines.append(f"  Dimensiones: b={sec.b:.1f} cm × h={sec.h:.1f} cm")
        elif sec.D > 0:
            lines.append(f"  Diámetro:    D={sec.D:.1f} cm")
        lines.append(f"  N° varillas: {len(sec.rebars)}")
        lines.append("")

        lines.append("MATERIALES")
        lines.append(f"  f'c:  {concrete.fc:.1f} kg/cm²")
        lines.append(f"  Ec:   {concrete.Ec:,.0f} kg/cm²")
        lines.append(f"  εcu:  {concrete.eps_cu:.4f}")
        lines.append(f"  β₁:   {code.beta1(concrete.fc):.4f}")
        lines.append(f"  fy:   {steel.fy:,.0f} kg/cm²")
        lines.append(f"  fsu:  {steel.fsu:,.0f} kg/cm²")
        lines.append(f"  Es:   {steel.Es:,.0f} kg/cm²")
        lines.append(f"  εy:   {steel.eps_y:.6f}")
        lines.append("")

        lines.append("CAPACIDADES AXIALES")
        Pn = code.Pmax_nom(concrete.fc, sec.Ast, sec.Ag, steel.fy) / 1000.0
        pPn = code.phi_Pmax(concrete.fc, sec.Ast, sec.Ag, steel.fy) / 1000.0
        lines.append(f"  Pn_max  = 0.85·f'c·(Ag-Ast) + fy·Ast")
        lines.append(f"          = 0.85·{concrete.fc:.0f}·({sec.Ag:.1f}-{sec.Ast:.2f}) + {steel.fy:.0f}·{sec.Ast:.2f}")
        lines.append(f"          = {Pn:.2f} ton")
        lines.append(f"  φPn_max = φ·0.80·Pn_max = {pPn:.2f} ton  (φ=0.65)")
        lines.append(f"  Pt_max  = {result.Ptmax_nom:.2f} ton  (tensión pura)")
        lines.append("")

        lines.append(f"DIAGRAMA DE INTERACCIÓN 3D")
        lines.append(f"  Ángulos: {result.n_angles}  |  Puntos/curva: {result.n_points}")
        lines.append(f"  Pmax (nominal): {result.Pmax_nom:.2f} ton")
        lines.append(f"  Pmax (reducida): {result.Pmax_red:.2f} ton")
        lines.append("")

        if mc and mc.points:
            lines.append("DIAGRAMA M-φ")
            lines.append(f"  N ext:   {mc.N_ext:.2f} ton")
            lines.append(f"  φ_y:     {mc.phi_y:.4e} 1/cm")
            lines.append(f"  My:      {mc.My_val:.3f} ton·m")
            lines.append(f"  φ_u:     {mc.phi_u:.4e} 1/cm")
            lines.append(f"  Mu:      {mc.Mu_val:.3f} ton·m")
            lines.append(f"  μφ:      {mc.mu_phi:.2f}")
            lines.append("")

        if mr:
            lines.append("DIAGRAMA M-θ (Haselton 2008)")
            lines.append(f"  EIeff:   {mr.EI_eff:.3e} kg·cm²")
            lines.append(f"  θ_y:     {mr.theta_y:.5f} rad")
            lines.append(f"  θ_cap:   {mr.theta_cap:.5f} rad")
            lines.append(f"  θ_pc:    {mr.theta_pc:.5f} rad")
            lines.append(f"  Mc/My:   {mr.Mc_My:.3f}")
            lines.append(f"  λ:       {mr.lambda_val:.1f}")
            lines.append(f"  μθ:      {mr.mu_theta:.2f}")
            lines.append("")

        if inside is not None and len(ids) > 0:
            lines.append("VERIFICACIÓN DE COMBINACIONES")
            lines.append(f"  {'ID':<12} {'Pu':>8} {'Mxu':>8} {'Muy':>8} {'Mu':>8} {'Estado'}")
            lines.append(f"  {'':─<12} {'':─>8} {'':─>8} {'':─>8} {'':─>8} {'':─<10}")
            for i, cid in enumerate(ids):
                if i >= len(Pu):
                    break
                Mu = math.sqrt(float(Mxu[i])**2 + float(Myu[i])**2)
                ok = bool(inside[i]) if i < len(inside) else False
                estado = "✓ CUMPLE" if ok else "✗ FALLA"
                lines.append(f"  {str(cid):<12} {Pu[i]:>8.3f} {Mxu[i]:>8.3f} {Myu[i]:>8.3f} {Mu:>8.3f} {estado}")

        self.w_memo.setPlainText("\n".join(lines))

    # ──────────────────────────────────────────────────────────────────────────
    # Exportación
    # ──────────────────────────────────────────────────────────────────────────

    def _export_word(self):
        if self._result is None:
            QMessageBox.information(self, "Exportar", "Primero ejecute el cálculo.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar memoria de cálculo", "memoria_interaccion.docx",
            "Word (*.docx)",
        )
        if not path:
            return

        try:
            from fileio.word_exporter import export_word
            ids, Pu, Mxu, Myu = self.panel_loads.get_loads()
            inside = check_demands(self._result, Pu, Mxu, Myu) if len(Pu) > 0 else None
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando reporte Word…"):
                export_word(
                output_path=path,
                section=self._section,
                concrete=self.panel_mat.get_concrete(),
                steel=self.panel_mat.get_steel(),
                code=self.panel_mat.get_code_class(),
                result=self._result,
                mc_result=self._mc_result,
                mr_result=self._mr_result,
                loads_data=dict(ids=ids, Pu=Pu, Mxu=Mxu, Muy=Myu) if len(ids) else None,
                inside=inside,
            )
            QMessageBox.information(self, "Exportar", f"Memoria guardada en:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Error al exportar", str(e))

    # ──────────────────────────────────────────────────────────────────────────
    # Utilidades
    # ──────────────────────────────────────────────────────────────────────────

    def _status(self, msg: str):
        self.lbl_status.setText(msg)

    def _show_about(self):
        QMessageBox.about(
            self,
            f"Acerca de {APP_NAME}",
            f"<b>{APP_NAME}</b> v{APP_VERSION}<br><br>"
            "Diagrama de interacción 3D para secciones de concreto reforzado.<br>"
            "Normativas: NTC 2023 DEC · ACI 318-25<br><br>"
            "Modelo M-φ: fibras (Bernoulli)<br>"
            "Modelo M-θ: Haselton 2008<br>"
            "Confinamiento: Mander 1988",
        )
