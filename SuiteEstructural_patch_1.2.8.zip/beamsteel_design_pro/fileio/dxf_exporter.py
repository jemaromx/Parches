﻿# fileio/dxf_exporter.py
"""
Exportación de ratios de interacción a DXF.

Genera dos archivos:
  • _Mx.dxf  → ratio Mz (flexión principal) + cortante
  • _My.dxf  → ratio My (flexión secundaria)

Modificación de DXFs existentes del usuario (equivalente Python de reducirlineas.lsp):
  - Escala LINEs desde el punto medio por el porcentaje indicado por el usuario
  - Sustituye TEXT/MTEXT con los ratios calculados

Algoritmo de reducción de líneas (idéntico a reducirlineas.lsp original):
  factor = (100 - porcentaje) / 100
  np1 = polar(mid, ang + π, nueva_dist/2)
  np2 = polar(mid, ang,     nueva_dist/2)
"""

from __future__ import annotations
import math
import re
from typing import List
from design.designer import MemberDesignResult

try:
    import ezdxf
    from ezdxf.math import Vec3
    DXF_OK = True
except ImportError:
    DXF_OK = False


# ══════════════════════════════════════════════════════════════════════════════
# Generación de DXF nuevo
# ══════════════════════════════════════════════════════════════════════════════

def export_dxf_ratios(results: List[MemberDesignResult],
                      base_path: str,
                      reduction_pct: float = 0.0) -> bool:
    """
    Genera _Mx.dxf y _My.dxf.
    reduction_pct: porcentaje de reducción de las líneas (0 = sin reducción).
    """
    if not DXF_OK:
        return False
    _write_dxf(results, base_path + "_Mx.dxf", mode="Mz",
               reduction_pct=reduction_pct)
    _write_dxf(results, base_path + "_My.dxf", mode="My",
               reduction_pct=reduction_pct)
    return True


def export_dxf_single(path: str,
                      results: List[MemberDesignResult],
                      mode: str = "Mz",
                      reduction_pct: float = 20.0) -> bool:
    """
    Genera un DXF nuevo en la ruta exacta indicada.

    Parámetros
    ----------
    path          : ruta completa del archivo a crear (incluye .dxf)
    results       : resultados de diseño
    mode          : "Mz" → ratio flexión principal, "My" → débil
    reduction_pct : porcentaje de reducción de líneas
    """
    if not DXF_OK:
        return False
    try:
        _write_dxf(results, path, mode=mode, reduction_pct=reduction_pct)
        return True
    except Exception:
        return False


def _write_dxf(results: List[MemberDesignResult], path: str,
               mode: str, reduction_pct: float = 0.0):
    doc = ezdxf.new("R2010")
    msp = doc.modelspace()

    doc.layers.new("TRABES",   dxfattribs={"color": 3})
    doc.layers.new("RATIOS",   dxfattribs={"color": 5})
    doc.layers.new("TEXTO",    dxfattribs={"color": 7})
    doc.layers.new("FALLADAS", dxfattribs={"color": 1})

    factor = (100.0 - reduction_pct) / 100.0
    y_offset = 0.0
    ROW_H  = 3.0
    SCALE  = 10.0

    for r in results:
        if not r.envelope:
            continue

        # Línea base de la barra (longitud proporcional, con reducción)
        raw_len = r.length_m * SCALE
        mid_x   = raw_len / 2.0
        half    = (raw_len * factor) / 2.0
        x0 = mid_x - half
        x1 = mid_x + half
        y0 = y_offset

        msp.add_line((x0, y0), (x1, y0),
                     dxfattribs={"layer": "TRABES", "lineweight": 50})
        msp.add_text(
            f"M{r.member_id} - {r.profile}  "
            f"[{'BC' if r.is_beam_col else 'F'}  {r.classification}]",
            dxfattribs={"height": 0.30, "layer": "TEXTO",
                        "insert": (x0, y0 + 0.7)})

        # Ratios en 3 puntos (inicio, medio, fin)
        labels = ["I", "M", "F"]
        for i, (lbl, pt) in enumerate(zip(labels, r.envelope)):
            ratio    = pt.ratio_Mz if mode == "Mz" else pt.ratio_My
            comb_gov = pt.combo_gov_Mz if mode == "Mz" else pt.combo_gov_My
            xp       = x0 + i * (raw_len * factor / 2.0)
            layer    = "FALLADAS" if ratio > 1.0 else "RATIOS"

            # Línea vertical proporcional al ratio
            bar_h = ratio * ROW_H
            msp.add_line((xp, y0), (xp, y0 + bar_h),
                         dxfattribs={"layer": layer, "lineweight": 30})

            # Etiqueta: ratio y combinación gobernante
            # (en ROJO — capa FALLADAS — cuando el ratio excede la unidad)
            txt_layer = "FALLADAS" if ratio > 1.0 else "TEXTO"
            msp.add_text(
                f"{lbl}: {ratio:.3f}",
                dxfattribs={"height": 0.30, "layer": txt_layer,
                            "insert": (xp - 0.3, y0 + bar_h + 0.25)})
            if comb_gov:
                msp.add_text(
                    f"({comb_gov})",
                    dxfattribs={"height": 0.30, "layer": txt_layer,
                                "insert": (xp - 0.3, y0 + bar_h + 0.70)})

        # Ratio de cortante al costado
        v_ratio = max((pt.ratio_V for pt in r.envelope), default=0)
        msp.add_text(
            f"V: {v_ratio:.3f}",
            dxfattribs={"height": 0.30,
                        "layer": "FALLADAS" if v_ratio > 1.0 else "TEXTO",
                        "insert": (x1 + 0.3, y0 + 0.3)})

        y_offset -= (ROW_H + 3.5)

    doc.saveas(path)


# ══════════════════════════════════════════════════════════════════════════════
# Modificación de DXF existente
# Algoritmo idéntico al original reducirlineas.lsp:
#   factor = (100 - porc) / 100
#   mid    = punto medio de la línea
#   nueva_dist = dist * factor
#   np1 = polar(mid, ang + π, nueva_dist/2)
#   np2 = polar(mid, ang,     nueva_dist/2)
# ══════════════════════════════════════════════════════════════════════════════

def modify_existing_dxf(dxf_path: str,
                        results: List[MemberDesignResult],
                        mode: str = "Mz",
                        reduction_pct: float = 20.0) -> tuple[bool, str]:
    """
    Carga el DXF del usuario, aplica reducción de líneas desde el punto medio
    (igual que reducirlineas.lsp) y actualiza etiquetas TEXT/MTEXT con ratios.

    Parámetros
    ----------
    dxf_path       : ruta al DXF original
    results        : lista de resultados de diseño
    mode           : "Mz" para ratio flexión principal, "My" para débil
    reduction_pct  : porcentaje de reducción (ej. 20 → reduce a 80%)

    Devuelve (ok, ruta_archivo_modificado)
    """
    if not DXF_OK:
        return False, ""
    try:
        doc = ezdxf.readfile(dxf_path)
    except Exception as ex:
        return False, str(ex)

    msp = doc.modelspace()

    # Factor de escala (idéntico a reducirlineas.lsp)
    if 0 < reduction_pct < 100:
        factor = (100.0 - reduction_pct) / 100.0
    else:
        factor = 1.0

    # Mapa member_id → ratio máx de la envolvente
    ratio_map: dict[int, float] = {}
    gov_map:   dict[int, str]   = {}
    for r in results:
        if r.envelope:
            v = max((pt.ratio_Mz if mode == "Mz" else pt.ratio_My)
                    for pt in r.envelope)
            ratio_map[r.member_id] = v
            g = max(r.envelope,
                    key=lambda p: (p.ratio_Mz if mode == "Mz" else p.ratio_My))
            gov_map[r.member_id] = (g.combo_gov_Mz if mode == "Mz"
                                    else g.combo_gov_My)

    # 1. Reducir líneas desde el punto medio (algoritmo reducirlineas.lsp)
    n_lines = 0
    for entity in msp.query("LINE"):
        p1  = Vec3(entity.dxf.start)
        p2  = Vec3(entity.dxf.end)
        mid = (p1 + p2) / 2.0

        dx   = p2.x - p1.x
        dy   = p2.y - p1.y
        ang  = math.atan2(dy, dx)
        dist = math.hypot(dx, dy)

        nueva_dist = dist * factor
        half       = nueva_dist / 2.0

        # polar(mid, ang+π, half)  y  polar(mid, ang, half)
        np1 = Vec3(mid.x + half * math.cos(ang + math.pi),
                   mid.y + half * math.sin(ang + math.pi),
                   mid.z)
        np2 = Vec3(mid.x + half * math.cos(ang),
                   mid.y + half * math.sin(ang),
                   mid.z)

        entity.dxf.start = np1
        entity.dxf.end   = np2
        n_lines += 1

    # 2. Actualizar etiquetas TEXT / MTEXT con ratios — solo textos en capas
    # prendidas (los de capas apagadas/congeladas, p.ej. numeración de nodos
    # oculta, se ignoran para no duplicar valores)
    try:
        from suite_shared.dxf_text_layout import hidden_layers
        ocultas = hidden_layers(doc)
    except Exception:
        ocultas = set()

    n_texts = 0
    labeled = []          # (entity, is_failing) para el acomodo automático
    for entity in msp.query("TEXT MTEXT"):
        if getattr(entity.dxf, "layer", "") in ocultas:
            continue
        try:
            raw = (entity.dxf.text
                   if hasattr(entity.dxf, "text") else entity.text)
        except Exception:
            continue
        mid_id = _parse_member_id(raw)
        if mid_id and mid_id in ratio_map:
            ratio    = ratio_map[mid_id]
            gov_comb = gov_map.get(mid_id, "")
            new_txt  = (f"{mid_id} / {ratio:.3f}"
                        + (f"  ({gov_comb})" if gov_comb else ""))
            try:
                if hasattr(entity.dxf, "text"):
                    entity.dxf.text = new_txt
                else:
                    entity.text = new_txt
                n_texts += 1
                labeled.append((entity, ratio > 1.0))
            except Exception:
                pass

    # 3. Acomodo automático: escala, posición, rotación, capa por orientación
    try:
        from suite_shared.dxf_text_layout import arrange_labels
        # Altura adaptativa a la longitud de barra, uniforme: todos los
        # textos con la MENOR altura que cabe en su barra respectiva.
        arrange_labels(doc, labeled, fixed_height=None)
    except Exception:
        pass   # si falla el acomodo, el DXF conserva las etiquetas actualizadas

    out_path = dxf_path.replace(".dxf", "_mod.dxf")
    doc.saveas(out_path)
    return True, out_path


def _parse_member_id(text: str):
    """Extrae el primer número entero del texto de etiqueta."""
    m = re.match(r"\s*(\d+)", text.strip())
    return int(m.group(1)) if m else None
