﻿# ui/main_window.py
"""
Ventana principal de Steel Beam Design Pro.
PySide6 + Matplotlib integrado.
"""

from __future__ import annotations
import sys, os, math, logging
from typing import Dict, List, Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QGroupBox, QLabel, QPushButton, QComboBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QSplitter,
    QFileDialog, QMessageBox, QDoubleSpinBox, QSpinBox,
    QCheckBox, QProgressBar, QLineEdit, QAbstractItemView,
    QStatusBar, QFrame, QScrollArea, QDialog, QTextEdit,
    QDialogButtonBox, QSizePolicy, QRadioButton, QButtonGroup
)
from PySide6.QtCore  import Qt, QThread, Signal, QTimer
from PySide6.QtGui   import QFont, QColor, QBrush

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

from config.settings  import APP_NAME, APP_VERSION, STEEL_MATERIALS, COLORS
from design.materials import SteelMaterial
from design.designer  import SteelDesigner, MemberDesignResult, MemberForces
from design.section_types import SectionProperties
from fileio.openstaad_reader import OpenSTAADReader
from design.web_openings    import OpeningGeometry
from ui.styles import MAIN_STYLE, COLORS

log = logging.getLogger(__name__)

# ── Colores para tablas ───────────────────────────────────────────────────────
C_OK   = QColor("#D5F5E3")
C_WARN = QColor("#FDEBD0")
C_FAIL = QColor("#FADBD8")
C_SEP  = QColor("#D4E6F1")     # filas separadoras entre miembros
C_HDR  = QColor(COLORS["primary"])


# ══════════════════════════════════════════════════════════════════════════════
# Tabla con copia al portapapeles (Ctrl+C → Excel / Word)
# ══════════════════════════════════════════════════════════════════════════════

class CopyableTable(QTableWidget):
    """Ctrl+C copia las celdas seleccionadas como TSV (compatible con Excel/Word)."""

    def keyPressEvent(self, event):
        from PySide6.QtGui import QKeySequence
        if event.matches(QKeySequence.Copy):
            self._copy_to_clipboard()
        else:
            super().keyPressEvent(event)

    def _copy_to_clipboard(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r_min = min(r.topRow()     for r in ranges)
        r_max = max(r.bottomRow()  for r in ranges)
        c_min = min(r.leftColumn() for r in ranges)
        c_max = max(r.rightColumn() for r in ranges)
        headers = []
        for col in range(c_min, c_max + 1):
            h = self.horizontalHeaderItem(col)
            headers.append(h.text().replace("\n", " ") if h else "")
        lines = ["\t".join(headers)]
        for row in range(r_min, r_max + 1):
            cells = []
            for col in range(c_min, c_max + 1):
                item = self.item(row, col)
                cells.append(item.text().strip() if item else "")
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))


# ══════════════════════════════════════════════════════════════════════════════
# Hilo de diseño
# ══════════════════════════════════════════════════════════════════════════════

class DesignWorker(QThread):
    progress = Signal(int, str)
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, staad_data, mat, bracing_data, designer, openings_by_member=None):
        super().__init__()
        self.staad_data         = staad_data
        self.mat                = mat
        self.bracing_data       = bracing_data
        self.designer           = designer
        self.openings_by_member = openings_by_member or {}

    def run(self):
        results = []
        ids = list(self.staad_data.keys())
        for i, mid in enumerate(ids):
            self.progress.emit(int(100 * i / len(ids)), f"Disenando miembro {mid}...")
            d = self.staad_data[mid]
            sp     = d.get("section")
            forces = d.get("forces")
            length = d.get("length", 0.0)
            if sp is None or forces is None:
                self.error.emit(f"Datos faltantes para miembro {mid}.")
                continue
            Ly_cm, Lz_cm = self.bracing_data.get(mid, (length * 100, length * 100))
            openings = self.openings_by_member.get(mid, None)
            try:
                r = self.designer.design_member(mid, sp, self.mat, forces,
                                                length, Ly_cm, Lz_cm,
                                                openings=openings)
                results.append(r)
            except Exception as ex:
                self.error.emit(f"Error en miembro {mid}: {ex}")
                log.exception(f"Error disenando miembro {mid}")
        self.progress.emit(100, "Diseno completado.")
        self.finished.emit(results)


# ══════════════════════════════════════════════════════════════════════════════
# Ventana principal
# ══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.setMinimumSize(1350, 840)
        self.setStyleSheet(MAIN_STYLE)

        self._reader   = OpenSTAADReader()
        # Factor de unidades fijo: kN → ton  (1/9.80665)
        self._reader.set_unit_factor(1.0 / 9.80665)
        self._results: List[MemberDesignResult] = []
        self._staad_data: dict = {}
        self._n_combos = 0

        self._build_ui()
        self._build_statusbar()

    # ── Construcción UI ───────────────────────────────────────────────────────


        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "beamsteel_design_pro")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setSpacing(4)
        root.setContentsMargins(8, 8, 8, 6)

        root.addWidget(self._header_bar())

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._left_panel())
        splitter.addWidget(self._right_panel())
        splitter.setSizes([390, 960])
        root.addWidget(splitter, 1)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(5)
        self.progress_bar.setTextVisible(False)
        root.addWidget(self.progress_bar)

    def _header_bar(self) -> QFrame:
        frame = QFrame()
        frame.setFixedHeight(60)
        frame.setStyleSheet(
            f"background:{COLORS['primary']}; border-radius:6px;")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(18, 4, 18, 4)

        title = QLabel(f"  {APP_NAME}")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title.setStyleSheet("color:white;")
        lay.addWidget(title)
        lay.addStretch()

        # Indicador de combinaciones
        self.lbl_combos_range = QLabel("Combinaciones: —")
        self.lbl_combos_range.setStyleSheet(
            "color:#AED6F1; font-size:10pt; font-weight:bold;")
        lay.addWidget(self.lbl_combos_range)

        lay.addSpacing(20)
        sub = QLabel(f"v{APP_VERSION}  |  NTC 2023 / AISC 360-22")
        sub.setStyleSheet("color:rgba(255,255,255,0.65); font-size:9pt;")
        lay.addWidget(sub)
        return frame

    # ── Panel izquierdo ───────────────────────────────────────────────────────

    def _left_panel(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(370)
        scroll.setMaximumWidth(430)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(10)
        lay.addWidget(self._group_staad())
        lay.addWidget(self._group_material())
        lay.addWidget(self._group_design_options())
        lay.addWidget(self._group_members())
        lay.addWidget(self._group_openings())
        lay.addWidget(self._group_actions())
        lay.addWidget(self._group_dxf())
        lay.addStretch()
        scroll.setWidget(w)
        return scroll

    def _group_staad(self) -> QGroupBox:
        grp = QGroupBox("Conexion STAAD Pro")
        lay = QVBoxLayout(grp)

        self.lbl_status = QLabel("  Sin conexion")
        self.lbl_status.setStyleSheet(
            f"color:{COLORS['accent']}; font-weight:bold;")

        btn_connect = QPushButton("Conectar a STAAD Pro")
        btn_connect.setObjectName("btn_connect")
        btn_connect.setToolTip("Establece conexión con STAAD Pro 2025\n(requiere ejecutar como Administrador)")
        btn_connect.clicked.connect(self._connect_staad)

        self.btn_get_sel = QPushButton("Obtener barras seleccionadas")
        self.btn_get_sel.clicked.connect(self._get_selected)
        self.btn_get_sel.setEnabled(False)

        # ── Rango de combinaciones ────────────────────────────────────────────
        grp_lc = QGroupBox("Rango de combinaciones de carga")
        lc_lay = QHBoxLayout(grp_lc)
        lc_lay.addWidget(QLabel("LC inicial:"))
        self.spn_lc_start = QSpinBox()
        self.spn_lc_start.setRange(0, 9999)
        self.spn_lc_start.setValue(0)
        self.spn_lc_start.setSpecialValueText("Auto")
        self.spn_lc_start.setToolTip(
            "0 = Auto (usar todos los casos de carga).\n"
            "Ingrese el número del primer caso a incluir.")
        lc_lay.addWidget(self.spn_lc_start)
        lc_lay.addSpacing(8)
        lc_lay.addWidget(QLabel("LC final:"))
        self.spn_lc_end = QSpinBox()
        self.spn_lc_end.setRange(0, 9999)
        self.spn_lc_end.setValue(0)
        self.spn_lc_end.setSpecialValueText("Auto")
        self.spn_lc_end.setToolTip(
            "0 = Auto (usar todos los casos de carga).\n"
            "Ingrese el número del último caso a incluir.")
        lc_lay.addWidget(self.spn_lc_end)

        lay.addWidget(self.lbl_status)
        lay.addWidget(btn_connect)
        lay.addWidget(self.btn_get_sel)
        lay.addWidget(grp_lc)
        return grp

    def _group_material(self) -> QGroupBox:
        grp = QGroupBox("Material de acero")
        lay = QVBoxLayout(grp)

        self.cmb_mat = QComboBox()
        for m in STEEL_MATERIALS:
            self.cmb_mat.addItem(m["name"])
        self.cmb_mat.currentIndexChanged.connect(self._on_material_changed)
        lay.addWidget(self.cmb_mat)

        row = QHBoxLayout()
        self.spn_fy = QDoubleSpinBox()
        self.spn_fy.setRange(1000, 10000); self.spn_fy.setSuffix(" kg/cm2")
        self.spn_fy.setValue(2530.0)
        self.spn_fu = QDoubleSpinBox()
        self.spn_fu.setRange(2000, 15000); self.spn_fu.setSuffix(" kg/cm2")
        self.spn_fu.setValue(4080.0)
        row.addWidget(QLabel("Fy:")); row.addWidget(self.spn_fy)
        row.addWidget(QLabel("Fu:")); row.addWidget(self.spn_fu)
        lay.addLayout(row)
        self._on_material_changed(0)
        return grp

    def _group_design_options(self) -> QGroupBox:
        grp = QGroupBox("Opciones de diseno")
        lay = QVBoxLayout(grp)

        row_code = QHBoxLayout()
        row_code.addWidget(QLabel("Codigo:"))
        self.cmb_code = QComboBox()
        self.cmb_code.addItems(["NTC 2023", "AISC 360-22"])
        row_code.addWidget(self.cmb_code)
        lay.addLayout(row_code)

        self.chk_autodetect = QCheckBox(
            "Detectar automaticamente trabe / columna")
        self.chk_autodetect.setChecked(True)
        self.chk_autodetect.setToolTip(
            "Activo: usa Pu/phiPn para determinar si disena como trabe o columna.\n"
            "Inactivo: siempre disena como trabe (solo flexion).")
        lay.addWidget(self.chk_autodetect)

        self.chk_torsion = QCheckBox("Incluir diseno a torsion")
        self.chk_torsion.setChecked(False)
        lay.addWidget(self.chk_torsion)

        self.chk_Cb = QCheckBox("Cb = 1.0 (conservador)")
        self.chk_Cb.setChecked(True)
        lay.addWidget(self.chk_Cb)
        return grp

    def _group_members(self) -> QGroupBox:
        grp = QGroupBox("Barras a disenar")
        lay = QVBoxLayout(grp)

        self.tbl_members = QTableWidget(0, 4)
        self.tbl_members.setHorizontalHeaderLabels(
            ["ID", "Long.\n(m)", "Ly\n(m)", "Lz\n(m)"])
        hdr = self.tbl_members.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.Stretch)
        hdr.setSectionResizeMode(3, QHeaderView.Stretch)
        self.tbl_members.setAlternatingRowColors(True)
        self.tbl_members.setMinimumHeight(160)
        lay.addWidget(self.tbl_members)

        btns = QHBoxLayout()
        btn_ids = QPushButton("Ingresar IDs manual")
        btn_ids.clicked.connect(self._input_ids_dialog)
        btn_clear = QPushButton("Limpiar lista")
        btn_clear.setObjectName("btnRed")
        btn_clear.clicked.connect(self._clear_members)
        btns.addWidget(btn_ids); btns.addWidget(btn_clear)
        lay.addLayout(btns)
        return grp

    def _group_openings(self) -> QGroupBox:
        """Panel de ingreso de aberturas en alma (múltiples por trabe)."""
        grp = QGroupBox("Aberturas en alma (NTC Art. 8.9)")
        lay = QVBoxLayout(grp)
        lay.setSpacing(4)

        # Tabla de aberturas
        self.tbl_openings = QTableWidget(0, 7)
        self.tbl_openings.setHorizontalHeaderLabels([
            "ID\nBarra", "x\n(m)", "Tipo\nC/R", "D o bo\n(cm)",
            "ao\n(cm)", "e\n(cm)", "Atiesada"
        ])
        hdr = self.tbl_openings.horizontalHeader()
        for c in range(7):
            hdr.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        self.tbl_openings.setMinimumHeight(110)
        self.tbl_openings.setMaximumHeight(160)
        lay.addWidget(self.tbl_openings)

        # Leyenda compacta
        note = QLabel(
            "Tipo: C=circular (D=diámetro), R=rectangular (bo=alto, ao=largo)\n"
            "e: excentricidad respecto al eje neutro (+→patín sup., cm)\n"
            "Atiesada: 1=sí, 0=no")
        note.setStyleSheet("font-size:8pt; color:#555;")
        note.setWordWrap(True)
        lay.addWidget(note)

        # Botones de gestión
        btns = QHBoxLayout()
        btn_add = QPushButton("+ Agregar abertura")
        btn_add.clicked.connect(self._add_opening_row)
        btn_del = QPushButton("Eliminar selec.")
        btn_del.setObjectName("btnRed")
        btn_del.clicked.connect(self._del_opening_row)
        btn_clr = QPushButton("Limpiar todo")
        btn_clr.clicked.connect(lambda: self.tbl_openings.setRowCount(0))
        btns.addWidget(btn_add)
        btns.addWidget(btn_del)
        btns.addWidget(btn_clr)
        lay.addLayout(btns)
        return grp

    def _add_opening_row(self):
        """Agrega una fila con valores predeterminados a la tabla de aberturas."""
        row = self.tbl_openings.rowCount()
        self.tbl_openings.insertRow(row)
        defaults = ["1", "0.0", "C", "20.0", "0.0", "0.0", "0"]
        for col, val in enumerate(defaults):
            self.tbl_openings.setItem(row, col, QTableWidgetItem(val))

    def _del_opening_row(self):
        rows = sorted(set(i.row() for i in self.tbl_openings.selectedItems()),
                      reverse=True)
        for r in rows:
            self.tbl_openings.removeRow(r)

    def _get_openings_by_member(self) -> dict:
        """
        Lee la tabla de aberturas y devuelve un dict {member_id: [OpeningGeometry]}.
        Ignora filas con datos inválidos.
        """
        result: dict = {}
        for row in range(self.tbl_openings.rowCount()):
            try:
                mid   = int(self.tbl_openings.item(row, 0).text())
                x_m   = float(self.tbl_openings.item(row, 1).text())
                shape = self.tbl_openings.item(row, 2).text().strip().upper()
                d_bo  = float(self.tbl_openings.item(row, 3).text())
                ao    = float(self.tbl_openings.item(row, 4).text())
                e     = float(self.tbl_openings.item(row, 5).text())
                stiff = self.tbl_openings.item(row, 6).text().strip() in ("1", "s",
                                                                           "S", "si",
                                                                           "Si", "yes")
                if shape not in ("C", "R"):
                    shape = "C"
                op = OpeningGeometry(
                    shape=shape, x_m=x_m,
                    D=d_bo if shape == "C" else 0.0,
                    ao=ao,
                    bo=d_bo if shape == "R" else 0.0,
                    e=e, stiffened=stiff,
                    label=f"A{row+1}"
                )
                result.setdefault(mid, []).append(op)
            except (AttributeError, ValueError, TypeError):
                pass
        return result

    def _group_actions(self) -> QGroupBox:
        grp = QGroupBox("Acciones")
        lay = QVBoxLayout(grp)

        self.btn_design = QPushButton("▶  Ejecutar Diseño")
        self.btn_design.setObjectName("btn_run")
        self.btn_design.setMinimumHeight(38)
        self.btn_design.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.btn_design.setToolTip("Ejecutar el diseño de los miembros seleccionados")
        self.btn_design.clicked.connect(self._run_design)
        self.btn_design.setEnabled(False)
        lay.addWidget(self.btn_design)

        r1 = QHBoxLayout()
        self.btn_excel = QPushButton("Excel")
        self.btn_excel.setObjectName("btn_excel")
        self.btn_excel.setToolTip("Exportar resultados a Excel (.xlsx)")
        self.btn_excel.clicked.connect(self._export_excel)
        self.btn_word = QPushButton("Word (Memoria)")
        self.btn_word.setObjectName("btn_word")
        self.btn_word.setToolTip("Exportar memoria de cálculo a Word (.docx)")
        self.btn_word.clicked.connect(self._export_word)
        r1.addWidget(self.btn_excel); r1.addWidget(self.btn_word)
        lay.addLayout(r1)

        self.btn_dxf_update = QPushButton("Actualizar DXF")
        self.btn_dxf_update.setObjectName("btn_dxf")
        self.btn_dxf_update.setToolTip("Actualizar archivos DXF con los resultados de diseño")
        self.btn_dxf_update.clicked.connect(self._export_dxf_update)
        lay.addWidget(self.btn_dxf_update)

        for b in [self.btn_excel, self.btn_word, self.btn_dxf_update]:
            b.setEnabled(False)
        return grp

    # ── Panel derecho ─────────────────────────────────────────────────────────

    def _right_panel(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 0, 0, 0)

        self.tabs_results = QTabWidget()
        self.tabs_results.addTab(self._tab_envelope(),     "Envolvente")
        self.tabs_results.addTab(self._tab_combinations(), "Por Combinacion")
        self.tabs_results.addTab(self._tab_plots(),        "Graficas")
        self.tabs_results.addTab(self._tab_memory(),       "Memoria de Calculo")
        lay.addWidget(self.tabs_results)
        return w

    # ── Tab Envolvente ────────────────────────────────────────────────────────

    def _tab_envelope(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        self.tbl_env = CopyableTable(0, 30)
        # Columnas gobernantes → inmediatamente a la derecha del elemento mecánico
        self.tbl_env.setHorizontalHeaderLabels([
            "ID", "Long.\n(m)", "Ly\n(m)", "Lz\n(m)", "Perfil", "Tipo",
            "Clasif.", "Lp\n(m)", "Lr\n(m)",
            "phiMnx\n(t*m)", "phiMny\n(t*m)", "phiVn\n(ton)",
            "Punto",
            "Mz act.\n(t*m)", "Comb.\nGob.Mz",   # ← gobernante junto a Mz
            "My act.\n(t*m)", "Comb.\nGob.My",   # ← gobernante junto a My
            "V act.\n(ton)",  "Comb.\nGob.V",    # ← gobernante junto a V
            "Tu act.\n(t*m)", "Comb.\nGob.T",    # ← torsión
            "Pu act.\n(ton)", "Comb.\nGob.Pu",   # ← carga axial en la trabe
            "Ratio\nMz", "Ratio\nMy", "Ratio\nV",
            "Ratio\nT",                            # ← torsión ratio
            "Ratio\nM-V", "Comb.\nGob.M-V",        # ← interacción M-V
            "OK"
        ])
        hdr = self.tbl_env.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(4, QHeaderView.Stretch)
        self.tbl_env.setAlternatingRowColors(True)
        self.tbl_env.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_env.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl_env.verticalHeader().setVisible(False)
        self.tbl_env.itemSelectionChanged.connect(self._on_env_row_selected)
        lay.addWidget(self.tbl_env)
        return w

    # ── Tab Combinaciones ─────────────────────────────────────────────────────

    def _tab_combinations(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        self.tbl_combos = CopyableTable(0, 13)
        self.tbl_combos.setHorizontalHeaderLabels([
            "ID", "Combinacion", "Punto\n(m)",
            "Mz act.\n(t*m)", "My act.\n(t*m)", "V act.\n(ton)",
            "Tu act.\n(t*m)", "Pu\n(ton)",
            "Ratio\nMz", "Ratio\nMy", "Ratio\nV", "Ratio\nT", "Ratio\nH"
        ])
        hdr = self.tbl_combos.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.Stretch)
        self.tbl_combos.setAlternatingRowColors(True)
        self.tbl_combos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl_combos.verticalHeader().setVisible(False)
        lay.addWidget(self.tbl_combos)
        return w

    # ── Tab Graficas ──────────────────────────────────────────────────────────

    def _tab_plots(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        sel = QHBoxLayout()
        sel.addWidget(QLabel("Miembro:"))
        self.cmb_plot_member = QComboBox()
        self.cmb_plot_member.currentIndexChanged.connect(self._update_plot)
        sel.addWidget(self.cmb_plot_member); sel.addStretch()
        lay.addLayout(sel)

        self.fig = Figure(figsize=(11, 5.5), tight_layout=True)
        self.canvas = FigureCanvas(self.fig)
        self.nav_toolbar = NavToolbar(self.canvas, w)
        lay.addWidget(self.nav_toolbar)
        lay.addWidget(self.canvas)
        return w

    # ── Tab Memoria ───────────────────────────────────────────────────────────

    def _tab_memory(self) -> QWidget:
        w = QWidget(); lay = QVBoxLayout(w)
        sel = QHBoxLayout()
        sel.addWidget(QLabel("Miembro:"))
        self.cmb_mem_member = QComboBox()
        self.cmb_mem_member.currentIndexChanged.connect(self._update_memory)
        sel.addWidget(self.cmb_mem_member); sel.addStretch()
        lay.addLayout(sel)
        self.txt_memory = QTextEdit()
        self.txt_memory.setReadOnly(True)
        self.txt_memory.setFont(QFont("Consolas", 9))
        lay.addWidget(self.txt_memory)
        return w

    def _build_statusbar(self):
        sb = QStatusBar()
        sb.showMessage("Listo.")
        self.setStatusBar(sb)

    # ══════════════════════════════════════════════════════════════════════════
    # STAAD Pro
    # ══════════════════════════════════════════════════════════════════════════

    def _connect_staad(self):
        ok, msg = self._reader.connect()
        if ok:
            ver = self._reader.staad_version
            uf  = self._reader.unit_factor
            self.lbl_status.setText(f"  Conectado  v{ver}")
            self.lbl_status.setStyleSheet(
                f"color:{COLORS['success']}; font-weight:bold;")
            self.btn_get_sel.setEnabled(True)

            # Actualizar rango de combinaciones en el encabezado
            lc_ids = self._reader.get_load_cases()
            if lc_ids:
                self._n_combos = len(lc_ids)
                self.lbl_combos_range.setText(
                    f"Combinaciones: {min(lc_ids)} a {max(lc_ids)}"
                    f"  ({self._n_combos} total)")
                # Pre-rellenar los spinboxes con el rango real
                self.spn_lc_start.setValue(min(lc_ids))
                self.spn_lc_end.setValue(max(lc_ids))

            # Mostrar info en status bar
            self.statusBar().showMessage(
                f"STAAD Pro {ver}  |  Unidad: kN → ton  |  "
                f"{self._n_combos} casos de carga")
        else:
            QMessageBox.warning(self, "Error de conexion", msg)
            self.statusBar().showMessage(msg)

    def _get_selected(self):
        ids = self._reader.get_selected_members()
        if not ids:
            QMessageBox.information(
                self, "Sin seleccion",
                "No hay barras seleccionadas en STAAD Pro.\n"
                "Seleccione las barras en STAAD y vuelva a intentarlo.")
            return
        self._load_staad_data(ids)

    def _load_staad_data(self, ids: List[int]):
        self.statusBar().showMessage(
            f"Obteniendo datos de {len(ids)} barras...")
        QTimer.singleShot(0, lambda: self._fetch_data(ids))

    def _fetch_data(self, ids: List[int]):
        try:
            lc_s = self.spn_lc_start.value()
            lc_e = self.spn_lc_end.value()
            self._staad_data = self._reader.fetch_all(ids,
                                                      lc_start=lc_s,
                                                      lc_end=lc_e)
        except Exception as ex:
            QMessageBox.critical(self, "Error",
                                 f"Error al obtener datos de STAAD:\n{ex}")
            return
        self._populate_members_table(ids)
        self.btn_design.setEnabled(True)
        self.statusBar().showMessage(
            f"{len(ids)} barras cargadas correctamente.")

    def _populate_members_table(self, ids):
        self.tbl_members.setRowCount(0)
        for mid in ids:
            d = self._staad_data.get(mid, {})
            length = d.get("length", 0.0)
            sp = d.get("section")
            row = self.tbl_members.rowCount()
            self.tbl_members.insertRow(row)
            id_item = QTableWidgetItem(str(mid))
            id_item.setFlags(id_item.flags() & ~Qt.ItemIsEditable)
            len_item = QTableWidgetItem(f"{length:.3f}")
            len_item.setFlags(len_item.flags() & ~Qt.ItemIsEditable)
            self.tbl_members.setItem(row, 0, id_item)
            self.tbl_members.setItem(row, 1, len_item)
            self.tbl_members.setItem(row, 2, QTableWidgetItem(f"{length:.3f}"))
            self.tbl_members.setItem(row, 3, QTableWidgetItem(f"{length:.3f}"))

    def _clear_members(self):
        self.tbl_members.setRowCount(0)
        self._staad_data.clear()
        self.btn_design.setEnabled(False)

    def _input_ids_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Ingresar IDs de barras")
        dlg.setMinimumWidth(360)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("IDs separados por comas o espacios:"))
        edit = QLineEdit()
        edit.setPlaceholderText("Ej: 1, 5, 10, 23")
        lay.addWidget(edit)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        lay.addWidget(btns)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            import re
            ids = [int(x) for x in re.split(r"[\s,;]+", edit.text().strip())
                   if x.isdigit()]
            if ids and self._reader.connected:
                self._load_staad_data(ids)
            elif ids:
                QMessageBox.warning(self, "Sin conexion",
                                    "Conecte primero a STAAD Pro.")

    # ══════════════════════════════════════════════════════════════════════════
    # Diseño
    # ══════════════════════════════════════════════════════════════════════════

    def _get_material(self) -> SteelMaterial:
        idx = self.cmb_mat.currentIndex()
        m   = STEEL_MATERIALS[idx]
        fy  = self.spn_fy.value() if m["fy"] == 0 else m["fy"]
        fu  = self.spn_fu.value() if m["fu"] == 0 else m["fu"]
        return SteelMaterial(name=m["name"], fy=fy, fu=fu)

    def _get_bracing_data(self):
        data = {}
        for row in range(self.tbl_members.rowCount()):
            mid = int(self.tbl_members.item(row, 0).text())
            try: Ly = float(self.tbl_members.item(row, 2).text()) * 100
            except: Ly = float(self.tbl_members.item(row, 1).text()) * 100
            try: Lz = float(self.tbl_members.item(row, 3).text()) * 100
            except: Lz = Ly
            data[mid] = (Ly, Lz)
        return data

    def _filter_staad_data_by_lc(self, staad_data: dict,
                                   lc_start: int, lc_end: int) -> dict:
        """
        Devuelve una copia de staad_data donde cada MemberForces.combos
        solo contiene los casos de carga en [lc_start, lc_end].
        Si ambos son 0 (Auto), devuelve los datos sin filtrar.
        """
        if lc_start == 0 and lc_end == 0:
            return staad_data

        lo = lc_start if lc_start > 0 else 1
        hi = lc_end   if lc_end   > 0 else 99999

        filtered = {}
        for mid, d in staad_data.items():
            old_mf = d.get("forces")
            if old_mf is None:
                filtered[mid] = d
                continue
            new_mf = MemberForces(member_id=old_mf.member_id)
            for lc_name, pts in old_mf.combos.items():
                try:
                    lc_id = int(lc_name)
                except ValueError:
                    lc_id = -1
                if lo <= lc_id <= hi:
                    new_mf.combos[lc_name] = pts
            filtered[mid] = {
                "section": d.get("section"),
                "length":  d.get("length", 0.0),
                "forces":  new_mf,
            }
        n_total   = sum(len(d["forces"].combos) for d in staad_data.values()
                        if d.get("forces"))
        n_filtered = sum(len(d["forces"].combos) for d in filtered.values()
                         if d.get("forces"))
        log.info("Filtro LC %d–%d: %d → %d combinaciones por miembro",
                 lo, hi, n_total, n_filtered)
        return filtered

    def _run_design(self):
        if not self._staad_data:
            QMessageBox.warning(self, "Sin datos", "No hay barras cargadas.")
            return
        mat      = self._get_material()
        bracing  = self._get_bracing_data()
        code     = self.cmb_code.currentText()
        auto     = self.chk_autodetect.isChecked()
        torsion  = self.chk_torsion.isChecked()
        designer = SteelDesigner(code=code, design_torsion=torsion,
                                 auto_detect_beam_col=auto)

        # Filtrar combinaciones según el rango actual de los spinboxes.
        # El fetch pudo haberse hecho con un rango diferente; aquí se aplica
        # el rango definitivo sin necesidad de volver a conectar a STAAD.
        lc_s = self.spn_lc_start.value()
        lc_e = self.spn_lc_end.value()
        design_data = self._filter_staad_data_by_lc(self._staad_data, lc_s, lc_e)
        if not any(d["forces"].combos for d in design_data.values()):
            QMessageBox.warning(
                self, "Sin combinaciones",
                f"No hay casos de carga en el rango LC {lc_s}–{lc_e}.\n"
                "Verifique el rango de combinaciones y vuelva a intentarlo.")
            return

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.btn_design.setEnabled(False)

        openings_by_member = self._get_openings_by_member()
        self._worker = DesignWorker(
            design_data, mat, bracing, designer,
            openings_by_member=openings_by_member)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_design_done)
        self._worker.error.connect(
            lambda m: self.statusBar().showMessage(f"Aviso: {m}"))
        self._worker.start()

    def _on_progress(self, val, msg):
        self.progress_bar.setValue(val)
        self.statusBar().showMessage(msg)

    def _on_design_done(self, results):
        self._results = results
        self.progress_bar.setVisible(False)
        self.btn_design.setEnabled(True)
        self._populate_envelope_table()
        self._populate_combo_table()
        self._populate_plot_selector()
        self._populate_memory_selector()
        for b in [self.btn_excel, self.btn_word, self.btn_dxf_update]:
            b.setEnabled(True)
        self.statusBar().showMessage(
            f"Diseno completado — {len(results)} miembros procesados.")
        self.tabs_results.setCurrentIndex(0)

    # ══════════════════════════════════════════════════════════════════════════
    # Tablas de resultados
    # ══════════════════════════════════════════════════════════════════════════

    def _populate_envelope_table(self):
        self.tbl_env.setRowCount(0)
        labels = ["Inicio", "Medio", "Fin"]

        for r in self._results:
            # Tipo con la comparación de Pu contra el umbral de la norma
            # (NTC 2023 / AISC 360-22 Cap.H: Pu > 10%·φPn → flexocompresión)
            _pu   = getattr(r, "Pu_max", 0.0)
            _puu  = getattr(r, "Pu_umbral", 0.0)
            if r.is_beam_col:
                tipo = f"Flexocomp.\nPu={_pu:.2f}t > {_puu:.2f}t"
            elif _pu > 0.001:
                tipo = f"Flexion\nPu={_pu:.2f}t <= {_puu:.2f}t"
            else:
                tipo = "Flexion"
            Lp_m    = r.flex.ltb.Lp / 100.0 if r.flex else 0
            Lr_m    = r.flex.ltb.Lr / 100.0 if r.flex else 0
            phi_Mnx = r.flex.phi_Mnx_tm      if r.flex else 0
            phi_Mny = r.flex.phi_Mny_tm      if r.flex else 0
            phi_Vn  = r.shear.phi_Vn         if r.shear else 0

            alt_row = (r.member_id % 2 == 0)
            base_bg = QColor("#EAF4FB") if alt_row else QColor("white")

            for i, (lbl, pt) in enumerate(zip(labels, r.envelope)):
                row = self.tbl_env.rowCount()
                self.tbl_env.insertRow(row)
                ok = (pt.ratio_H <= 1.0 and pt.ratio_V <= 1.0
                      and (pt.ratio_T <= 1.0))

                # Columnas: 0..12 fijos, 13=Mz, 14=CombGovMz, 15=My, 16=CombGovMy,
                #   17=V, 18=CombGovV, 19=Tu, 20=CombGovT,
                #   21=RatMz, 22=RatMy, 23=RatV, 24=RatT,
                #   25=RatMV, 26=CombGovMV, 27=OK
                vals = [
                    str(r.member_id) if i == 0 else "",   # 0
                    f"{r.length_m:.3f}" if i == 0 else "", # 1
                    f"{r.Ly_cm/100:.3f}" if i == 0 else "",# 2
                    f"{r.Lz_cm/100:.3f}" if i == 0 else "",# 3
                    r.profile        if i == 0 else "",    # 4
                    tipo             if i == 0 else "",    # 5
                    r.classification if i == 0 else "",    # 6
                    f"{Lp_m:.3f}"    if i == 0 else "",   # 7
                    f"{Lr_m:.3f}"    if i == 0 else "",   # 8
                    f"{phi_Mnx:.4f}" if i == 0 else "",   # 9
                    f"{phi_Mny:.4f}" if i == 0 else "",   # 10
                    f"{phi_Vn:.4f}"  if i == 0 else "",   # 11
                    lbl,                                   # 12 Punto
                    f"{pt.Mz:.4f}",                        # 13 Mz act
                    pt.combo_gov_Mz,                       # 14 Comb.Gov.Mz
                    f"{pt.My:.4f}",                        # 15 My act
                    pt.combo_gov_My,                       # 16 Comb.Gov.My
                    f"{pt.Vu:.4f}",                        # 17 V act
                    pt.combo_gov_V,                        # 18 Comb.Gov.V
                    f"{pt.Tu:.4f}",                        # 19 Tu act
                    pt.combo_gov_T,                        # 20 Comb.Gov.T
                    f"{pt.Pu:.4f}",                        # 21 Pu act (axial)
                    getattr(pt, "combo_gov_Pu", ""),       # 22 Comb.Gov.Pu
                    f"{pt.ratio_Mz:.3f}",                  # 23 Ratio Mz
                    f"{pt.ratio_My:.3f}",                  # 24 Ratio My
                    f"{pt.ratio_V:.3f}",                   # 25 Ratio V
                    f"{pt.ratio_T:.3f}",                   # 26 Ratio T
                    f"{pt.ratio_H:.3f}",                   # 27 Ratio M-V / H
                    pt.combo_gov_MV,                       # 28 Comb.Gov.MV
                    "OK" if ok else "FALLA",               # 29
                ]

                # Índices de columnas de ratio para colorear
                _ratio_cols = {23: pt.ratio_Mz, 24: pt.ratio_My,
                               25: pt.ratio_V,  26: pt.ratio_T,
                               27: pt.ratio_H}

                for col, val in enumerate(vals):
                    item = QTableWidgetItem(val)
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(base_bg)

                    # Columnas de combinación gobernante: texto pequeño en cursiva
                    if col in (14, 16, 18, 20, 22, 28):
                        item.setFont(QFont("Segoe UI", 8))
                        item.setForeground(QColor(COLORS["secondary"]))

                    # Colorear ratios
                    if col in _ratio_cols:
                        v = _ratio_cols[col]
                        if v > 1.0:
                            item.setBackground(C_FAIL)
                            item.setForeground(QColor(COLORS["accent"]))
                            item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                        elif v > 0.85:
                            item.setBackground(C_WARN)
                        else:
                            item.setBackground(C_OK)

                    if col == 29:   # OK / FALLA
                        item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                        item.setForeground(
                            QColor(COLORS["success"]) if ok
                            else QColor(COLORS["accent"]))

                    self.tbl_env.setItem(row, col, item)

        self.tbl_env.resizeColumnsToContents()

    def _populate_combo_table(self):
        """
        Tabla de combinaciones con fila separadora entre miembros que muestra:
        Perfil | Lp | Lr | phiMnx | phiMny | phiVn | Pu_max_beam
        """
        self.tbl_combos.setRowCount(0)

        for r in self._results:
            # ── Fila separadora con datos del miembro ─────────────────────────
            sep_row = self.tbl_combos.rowCount()
            self.tbl_combos.insertRow(sep_row)

            Lp_m    = r.flex.ltb.Lp / 100.0 if r.flex else 0
            Lr_m    = r.flex.ltb.Lr / 100.0 if r.flex else 0
            phi_Mnx = r.flex.phi_Mnx_tm      if r.flex else 0
            phi_Mny = r.flex.phi_Mny_tm      if r.flex else 0
            phi_Vn  = r.shear.phi_Vn         if r.shear else 0
            # Pu máxima admisible para trabe: BEAM_COL_THRESHOLD × phiPn
            from config.settings import BEAM_COL_THRESHOLD
            Pu_beam = BEAM_COL_THRESHOLD * r.col.phi_Pn if r.col else 0

            sep_texts = [
                f"M{r.member_id}",
                f"{r.profile}  |  {r.classification}",
                f"Lp={Lp_m:.3f}m",
                f"Lr={Lr_m:.3f}m",
                f"phiMnx={phi_Mnx:.3f}t*m",
                f"phiMny={phi_Mny:.3f}t*m",
                f"phiVn={phi_Vn:.3f}ton",
                f"Pu_max_trabe={Pu_beam:.3f}ton",
                "", "", "", "", "",
            ]

            for col, txt in enumerate(sep_texts):
                item = QTableWidgetItem(txt)
                item.setTextAlignment(Qt.AlignCenter)
                item.setBackground(C_SEP)
                item.setForeground(QColor(COLORS["primary"]))
                item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.tbl_combos.setItem(sep_row, col, item)

            # Combinar visualmente celdas de la fila sep (spanning)
            self.tbl_combos.setSpan(sep_row, 1, 1, 2)

            # ── Filas de datos ────────────────────────────────────────────────
            for pt in r.all_points:
                row = self.tbl_combos.rowCount()
                self.tbl_combos.insertRow(row)
                vals = [
                    str(r.member_id), pt.combo, f"{pt.dist:.2f}",
                    f"{pt.Mz:.4f}", f"{pt.My:.4f}", f"{pt.Vu:.4f}",
                    f"{pt.Tu:.4f}", f"{pt.Pu:.4f}",
                    f"{pt.ratio_Mz:.3f}", f"{pt.ratio_My:.3f}",
                    f"{pt.ratio_V:.3f}",  f"{pt.ratio_T:.3f}",
                    f"{pt.ratio_H:.3f}",
                ]
                for col, val in enumerate(vals):
                    item = QTableWidgetItem(val)
                    item.setTextAlignment(Qt.AlignCenter)
                    if col in (8, 9, 10, 11, 12):
                        try:
                            v = float(val)
                            if v > 1.0:
                                item.setBackground(C_FAIL)
                                item.setForeground(QColor(COLORS["accent"]))
                            elif v > 0.85:
                                item.setBackground(C_WARN)
                            else:
                                item.setBackground(C_OK)
                        except: pass
                    self.tbl_combos.setItem(row, col, item)

        self.tbl_combos.resizeColumnsToContents()

    # ══════════════════════════════════════════════════════════════════════════
    # Graficas
    # ══════════════════════════════════════════════════════════════════════════

    def _populate_plot_selector(self):
        self.cmb_plot_member.clear()
        for r in self._results:
            tipo = "BC" if r.is_beam_col else "F"
            self.cmb_plot_member.addItem(
                f"{r.member_id} – {r.profile} [{tipo}]", r.member_id)
        if self._results:
            self._update_plot(0)

    def _on_env_row_selected(self):
        row = self.tbl_env.currentRow()
        mid_item = self.tbl_env.item(row, 0)
        if mid_item and mid_item.text().isdigit():
            mid = int(mid_item.text())
            idx = self.cmb_plot_member.findData(mid)
            if idx >= 0:
                self.cmb_plot_member.setCurrentIndex(idx)
                self.tabs_results.setCurrentIndex(2)

    def _update_plot(self, _=None):
        mid = self.cmb_plot_member.currentData()
        if mid is None:
            return
        res = next((r for r in self._results if r.member_id == mid), None)
        if res is None:
            return

        self.fig.clear()
        if not res.is_beam_col and res.ltb_curve:
            self._plot_ltb(res)        # subplot izquierdo: PLT
            self._plot_shear(res)      # subplot derecho:   Cortante
        elif res.is_beam_col and res.int_diagram:
            self._plot_interaction(res)   # subplot izquierdo: P-M
            self._plot_shear(res)         # subplot derecho:   Cortante
        else:
            self._plot_shear(res)      # solo cortante si no hay otros datos
        self.canvas.draw()

    def _plot_ltb(self, res: MemberDesignResult):
        ax = self.fig.add_subplot(1, 2, 1)
        Lb_m, Mn_tm, phi_Mn_tm = res.ltb_curve

        Lp_m = res.flex.ltb.Lp / 100.0
        Lr_m = res.flex.ltb.Lr / 100.0
        Lb_act = res.Ly_cm / 100.0

        # Curvas nominales
        ax.plot(Lb_m, Mn_tm,     color=COLORS["secondary"],
                lw=2, label="Mn (nominal)")
        ax.plot(Lb_m, phi_Mn_tm, color=COLORS["primary"],
                lw=2.5, ls="--", label="phiMn (diseno)")

        # Líneas verticales Lp / Lr / Lb  (etiquetas según código)
        _is_ntc = (res.code == "NTC 2023")
        lp_lbl = (f"Lp = {Lp_m:.3f} m  (límite Tipo 1→2)"
                  if _is_ntc else f"Lp = {Lp_m:.3f} m  (Compact limit)")
        lr_lbl = (f"Lr = {Lr_m:.3f} m  (límite PLT inel.→elást.)"
                  if _is_ntc else f"Lr = {Lr_m:.3f} m  (Inelastic LTB limit)")
        lb_lbl = (f"Lb = {Lb_act:.3f} m  (longitud no arriostrada)"
                  if _is_ntc else f"Lb = {Lb_act:.3f} m  (unbraced length)")
        ax.axvline(Lp_m,   color=COLORS["success"], ls=":", lw=1.8, label=lp_lbl)
        ax.axvline(Lr_m,   color=COLORS["accent"],  ls=":", lw=1.8, label=lr_lbl)
        ax.axvline(Lb_act, color=COLORS["warning"],  ls="-", lw=2.5, label=lb_lbl)

        # ── Todos los puntos de combinaciones (puntos verdes pequeños) ──────────
        if res.all_points:
            combo_Mz = [abs(pt.Mz) for pt in res.all_points]
            n_pts = len(combo_Mz)
            ax.scatter([Lb_act] * n_pts, combo_Mz,
                       color="#27AE60", alpha=0.55, s=18, zorder=5,
                       linewidths=0,
                       label=f"Todas las combinaciones ({n_pts} pts)")

        # ── Envolvente (marcadores grandes sobre los puntos verdes) ───────────
        markers = ["o", "s", "^"]
        for i, (lbl, pt) in enumerate(zip(["Inicio", "Medio", "Fin"], res.envelope)):
            ax.scatter(Lb_act, abs(pt.Mz), zorder=7, s=90,
                       marker=markers[i], edgecolors="black", linewidths=0.8,
                       label=f"Env. {lbl} = {abs(pt.Mz):.3f} t·m")

        # Zonas sombreadas
        ymax = max(Mn_tm) if Mn_tm else 1
        ax.axvspan(0,    Lp_m, alpha=0.09, color="green")
        ax.axvspan(Lp_m, Lr_m, alpha=0.09, color="orange")
        if max(Lb_m) > Lr_m:
            ax.axvspan(Lr_m, max(Lb_m), alpha=0.09, color="red")

        # Etiquetas de zona — NTC (Tipo 1/2) o AISC (Compact/NC) según resultado
        _is_ntc = (res.code == "NTC 2023")
        _zone_labels = (
            [("Tipo 1\nFluencia", "green"),
             ("Tipo 2\nPLT Inelástico", "darkorange"),
             ("Tipo 2\nPLT Elástico", "red")]
            if _is_ntc else
            [("Compact\nYielding", "green"),
             ("Non-compact\nInelastic LTB", "darkorange"),
             ("Slender\nElastic LTB", "red")]
        )
        for x, (lbl, col) in zip(
                [Lp_m * 0.45, (Lp_m + Lr_m) / 2, Lr_m * 1.25],
                _zone_labels):
            if 0 < x < max(Lb_m):
                ax.text(x, ymax * 0.96, lbl, ha="center", fontsize=8,
                        color=col, style="italic", va="top")

        ax.set_xlabel("Longitud no arriostrada Lb (m)", fontsize=11)
        ax.set_ylabel("Momento (ton·m)", fontsize=11)
        ax.set_title(
            f"Curva PLT – Miembro {res.member_id}  {res.profile}  "
            f"[{res.classification}]",
            fontsize=12, fontweight="bold", color=COLORS["primary"])
        ax.legend(fontsize=8, loc="upper right")
        ax.grid(True, alpha=0.3)
        ax.set_xlim(left=0, right=max(Lb_m))
        ax.set_ylim(bottom=0)

    def _plot_interaction(self, res: MemberDesignResult):
        ax = self.fig.add_subplot(1, 2, 1)
        P_list, M_list = res.int_diagram

        ax.plot(M_list, P_list, color=COLORS["primary"], lw=2.5,
                label="Diagrama de interacción φ(P,M)")

        # ── Todos los puntos de combinaciones (puntos verdes pequeños) ──────────
        if res.all_points:
            combo_Mu = [abs(pt.Mz) for pt in res.all_points]
            combo_Pu = [pt.Pu      for pt in res.all_points]
            n_pts = len(combo_Mu)
            ax.scatter(combo_Mu, combo_Pu,
                       color="#27AE60", alpha=0.55, s=18, zorder=5,
                       linewidths=0,
                       label=f"Todas las combinaciones ({n_pts} pts)")

        # ── Envolvente (marcadores grandes sobre los puntos verdes) ───────────
        env_colors = [COLORS["success"], COLORS["warning"], COLORS["accent"]]
        for i, (lbl, pt) in enumerate(zip(["Inicio", "Medio", "Fin"], res.envelope)):
            ax.scatter(abs(pt.Mz), pt.Pu,
                       color=env_colors[i % 3], s=100, zorder=7,
                       marker=["o", "s", "^"][i],
                       edgecolors="black", linewidths=0.8,
                       label=f"Env. {lbl}: Pu={pt.Pu:.2f} t  Mu={abs(pt.Mz):.2f} t·m")

        # Línea H=1.0 de referencia (interacción = 1.0)
        if M_list:
            ax.axvline(max(M_list), color="gray", ls=":", lw=0.8, alpha=0.5)

        ax.set_xlabel("Momento Mux (ton·m)", fontsize=11)
        ax.set_ylabel("Carga axial Pu (ton, + compresión)", fontsize=11)
        ax.set_title(
            f"Diagrama P-M – Miembro {res.member_id}  {res.profile}  "
            f"[{res.classification}]",
            fontsize=12, fontweight="bold", color=COLORS["primary"])
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.axhline(0, color="black", lw=0.8)
        ax.axvline(0, color="black", lw=0.8)

    def _plot_shear(self, res: MemberDesignResult):
        """
        Gráfica de cortante nominal Vn vs h/t — réplica de Fig. C8.3.2.1 NTC.

        Muestra:
          · Curva Cv vs h/t con 3 zonas (fluencia, pandeo inelástico, elástico)
          · Curvas de campo de tensión diagonal para a/h = 1, 2, 3
          · Eje Y izquierdo: τ_n = Vn/Aw [kg/cm²]   (normalizado)
          · Eje Y derecho:   Vn [ton]                (sección real)
          · Línea vertical: h/tw actual de la sección
          · Línea horizontal: Vu max de la envolvente
        """
        from design.shear import build_shear_curve
        from design.section_types import SectionKind

        if res.shear is None:
            return

        ax = self.fig.add_subplot(1, 2, 2)

        sv   = res.shear
        kv   = sv.kv
        Aw   = sv.Aw       # cm²
        phi_v = sv.phi_v
        h_tw_actual = sv.h_tw

        # ── Generar curva ─────────────────────────────────────────────────────
        # Reconstruir material aproximado desde shear result
        # (solo necesitamos Fy y E para la curva)
        # Calculamos Fy desde Vn bruta y Aw  → Fy = Vn·1000/(0.6·Aw·Cv)
        # Más directo: usar los datos del material del resultado del miembro
        # Acceder indirectamente via los datos calculados
        _Fy_approx = sv.Vn * 1000.0 / (0.6 * Aw * sv.Cv) if (Aw > 0 and sv.Cv > 0) else 3515.0
        _E_approx  = 2_039_000.0
        # Crear un SteelMaterial temporal para build_shear_curve
        from design.materials import SteelMaterial as SM
        _mat_tmp = SM(name="tmp", fy=_Fy_approx, fu=_Fy_approx * 1.4)

        data = build_shear_curve(
            _mat_tmp, kv=kv, Aw_cm2=Aw, phi_v=phi_v,
            tension_field_ratios=(1.0, 2.0, 3.0),
            h_tw_max=max(h_tw_actual * 1.5, 300.0))

        ht   = data["h_t"]
        tau  = data["tau_n"]   # kg/cm²
        Vn_l = data["Vn"]      # ton
        phiVn= data["phi_Vn"]  # ton
        lim1 = data["lim1"]
        lim2 = data["lim2"]
        lim3 = data["lim3"]
        Fy_v = data["Fy"]

        # ── Ejes Y dobles ─────────────────────────────────────────────────────
        ax2 = ax.twinx()

        # Curva principal (sin campo de tensión)
        ax.plot(ht, tau,  color=COLORS["primary"],   lw=2.5,
                label="Vn/Aw = 0.6·Fy·Cv  [sin CTD]")
        ax.plot(ht, [t * phi_v for t in tau],
                color=COLORS["secondary"], lw=2, ls="--",
                label=f"FR·Vn/Aw  (FR={phi_v:.2f})")

        # Curvas de campo de tensión diagonal (CTD)
        _ctd_colors = ["#E67E22", "#8E44AD", "#16A085"]
        for idx, (a_h, curve) in enumerate(data["tension_fields"].items()):
            c = _ctd_colors[idx % len(_ctd_colors)]
            ax.plot(ht,
                    [v * 1000.0 / Aw if Aw > 0 else 0 for v in curve["Vn"]],
                    color=c, lw=1.5, ls=":",
                    label=f"CTD a/h={a_h:.0f}")

        # Eje derecho: Vn ton
        ax2.plot(ht, phiVn, alpha=0.0)  # invisible, solo para escalar
        ax2.set_ylabel("FR·Vn  (ton)", fontsize=9, color=COLORS["secondary"])
        ax2.tick_params(axis="y", labelcolor=COLORS["secondary"], labelsize=8)

        # ── Zonas sombreadas ──────────────────────────────────────────────────
        y_max = max(tau) * 1.05 if tau else Fy_v * 0.65
        ax.axvspan(0,    lim1, alpha=0.10, color="green",  zorder=0)
        ax.axvspan(lim1, lim2, alpha=0.10, color="orange", zorder=0)
        ax.axvspan(lim2, max(ht), alpha=0.08, color="red", zorder=0)

        # ── Líneas de límites ─────────────────────────────────────────────────
        ax.axvline(lim1, color="green",       lw=1.5, ls="--",
                   label=f"1.10√(kv·E/Fy)={lim1:.1f}")
        ax.axvline(lim2, color="darkorange",  lw=1.5, ls="--",
                   label=f"1.37√(kv·E/Fy)={lim2:.1f}")
        ax.axvline(lim3, color="gray",        lw=1.0, ls=":",
                   label=f"2.24√(E/Fy)={lim3:.1f}")

        # ── Línea 0.6·Fy horizontal ───────────────────────────────────────────
        ax.axhline(0.6 * Fy_v, color="gray", lw=0.8, ls="-.", alpha=0.6)
        ax.text(max(ht) * 0.02, 0.6 * Fy_v * 1.01,
                f"0.6·Fy = {0.6*Fy_v:.0f} kg/cm²",
                fontsize=7, color="gray", va="bottom")

        # ── Sección actual ────────────────────────────────────────────────────
        ax.axvline(h_tw_actual, color=COLORS["accent"], lw=2.5,
                   label=f"h/tw = {h_tw_actual:.1f}  (sección)")

        # Punto Vn nominal en la curva (capacidad)
        tau_actual = 0.6 * Fy_v * sv.Cv
        ax.scatter([h_tw_actual], [tau_actual], color=COLORS["accent"],
                   s=80, zorder=8)

        # ── Todas las combinaciones — puntos de Vu ────────────────────────────
        if res.all_points and Aw > 0:
            Vu_combos = [abs(pt.Vu) * 1000.0 / Aw for pt in res.all_points]
            n_combos  = len(Vu_combos)
            ax.scatter([h_tw_actual] * n_combos, Vu_combos,
                       color="#27AE60", alpha=0.50, s=16, zorder=5,
                       linewidths=0,
                       label=f"Todas las combinaciones ({n_combos} pts)")

        # ── Envolvente — 3 puntos (Inicio / Medio / Fin) ─────────────────────
        if res.envelope and Aw > 0:
            mkrs  = ["o", "s", "^"]
            lbls  = ["Inicio", "Medio", "Fin"]
            for i, (lbl, pt) in enumerate(zip(lbls, res.envelope)):
                tau_env = abs(pt.Vu) * 1000.0 / Aw
                ax.scatter([h_tw_actual], [tau_env],
                           zorder=7, s=90, marker=mkrs[i],
                           edgecolors="black", linewidths=0.8,
                           label=f"Env. {lbl} = {abs(pt.Vu):.3f} ton"
                                 f"  ({tau_env:.0f} kg/cm²)")

        # ── Vu máximo de la envolvente ────────────────────────────────────────
        if res.envelope and Aw > 0:
            Vu_max = max(abs(pt.Vu) for pt in res.envelope)
            tau_u  = Vu_max * 1000.0 / Aw   # kg/cm²
            ax.axhline(tau_u, color=COLORS["accent"], lw=1.5, ls="-.",
                       label=f"Vu máx = {Vu_max:.2f} ton  ({tau_u:.0f} kg/cm²)")

        # ── Etiquetas de zonas ────────────────────────────────────────────────
        _is_ntc = (res.code == "NTC 2023")
        zone_lbl = [
            (lim1 * 0.5,  "Fluencia\nCv=1.0",        "green"),
            ((lim1+lim2)/2, "Pandeo\ninelástico",     "darkorange"),
            (lim2 * 1.35, "Pandeo\nelástico",          "red"),
        ]
        for x, lbl, col in zone_lbl:
            if 0 < x < max(ht):
                ax.text(x, y_max * 0.95, lbl, ha="center",
                        fontsize=7, color=col, style="italic", va="top")

        # ── Anotación Cv formula ──────────────────────────────────────────────
        ax.text(lim1 * 0.5, y_max * 0.50,
                f"Cv=1.0", ha="center", fontsize=7, color="green")
        ax.text((lim1+lim2)/2, y_max * 0.40,
                "Cv=1.10·√(kvE/Fy)/(h/t)", ha="center", fontsize=6.5,
                color="darkorange")
        ax.text(lim2 * 1.6, y_max * 0.30,
                "Cv=1.51kvE/[(h/t)²Fy]", ha="center", fontsize=6.5,
                color="red")

        # ── Decoración ───────────────────────────────────────────────────────
        ref = "NTC 2023 Art. 8.2.2" if _is_ntc else "AISC 360-22 G2.1"
        ax.set_xlabel("h/t  (esbeltez del alma)", fontsize=10)
        ax.set_ylabel("τ_n = Vn/Aw  (kg/cm²)", fontsize=10)
        ax.set_title(
            f"Cortante nominal – Miembro {res.member_id}  {res.profile}\n"
            f"kv={kv:.2f}  [{ref}]  —  Fig. C8.3.2.1",
            fontsize=9, fontweight="bold", color=COLORS["primary"])
        ax.legend(fontsize=7, loc="upper right", ncol=1)
        ax.grid(True, alpha=0.25)
        ax.set_xlim(left=0, right=max(ht))
        ax.set_ylim(bottom=0, top=y_max)

    # ══════════════════════════════════════════════════════════════════════════
    # Memoria
    # ══════════════════════════════════════════════════════════════════════════

    def _populate_memory_selector(self):
        self.cmb_mem_member.clear()
        for r in self._results:
            self.cmb_mem_member.addItem(
                f"{r.member_id} – {r.profile}", r.member_id)
        if self._results:
            self._update_memory(0)

    def _update_memory(self, _=None):
        mid = self.cmb_mem_member.currentData()
        if mid is None:
            return
        res = next((r for r in self._results if r.member_id == mid), None)
        if res:
            self.txt_memory.setPlainText("\n".join(res.calc_memory))

    # ══════════════════════════════════════════════════════════════════════════
    # Exportaciones
    # ══════════════════════════════════════════════════════════════════════════

    def _export_excel(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Excel", "", "Excel (*.xlsx)")
        if not path:
            return
        from fileio.excel_exporter import export_excel
        ok = export_excel(self._results, path)
        if ok:
            QMessageBox.information(self, "Exportado",
                                    f"Excel guardado en:\n{path}")
        else:
            QMessageBox.warning(self, "Error",
                                "Instale openpyxl: pip install openpyxl")

    def _export_word(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Word", "", "Word (*.docx)")
        if not path:
            return
        from fileio.word_exporter import export_word
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Generando memoria Word…"):
            ok = export_word(self._results, APP_NAME, path)
        if ok:
            QMessageBox.information(self, "Exportado",
                                    f"Word guardado en:\n{path}")
        else:
            QMessageBox.warning(self, "Error",
                                "Instale python-docx: pip install python-docx")

    def _group_dxf(self) -> QGroupBox:
        """Panel de opciones DXF — similar al de beam_design_pro."""
        grp = QGroupBox("Exportar a DXF")
        lay = QVBoxLayout(grp)
        lay.setSpacing(6)

        # ── Activar DXF ──────────────────────────────────────────────────────
        self.chk_dxf_enable = QCheckBox("Exportar resultados a DXF")
        self.chk_dxf_enable.setChecked(False)
        lay.addWidget(self.chk_dxf_enable)

        # ── Sub-panel (se activa con el checkbox) ────────────────────────────
        self._dxf_sub = QWidget()
        sub_lay = QVBoxLayout(self._dxf_sub)
        sub_lay.setContentsMargins(0, 2, 0, 0)
        sub_lay.setSpacing(5)

        # Modo de etiquetado
        lbl_modo = QLabel("Modo de etiquetado:")
        lbl_modo.setStyleSheet("font-weight: bold;")
        sub_lay.addWidget(lbl_modo)
        self.rdo_dxf_A = QRadioButton("A — Máximos  (ratio_max)")
        self.rdo_dxf_B = QRadioButton("B — Secciones  (ini – mid – fin)")
        self.rdo_dxf_A.setChecked(True)
        bg = QButtonGroup(self)
        bg.addButton(self.rdo_dxf_A)
        bg.addButton(self.rdo_dxf_B)
        sub_lay.addWidget(self.rdo_dxf_A)
        sub_lay.addWidget(self.rdo_dxf_B)

        # Reducción de líneas
        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color:#AED6F1;"); sub_lay.addWidget(sep)

        row_red = QHBoxLayout()
        row_red.addWidget(QLabel("Reducción líneas:"))
        self.spn_dxf_reduc = QDoubleSpinBox()
        self.spn_dxf_reduc.setRange(0.0, 99.0)
        self.spn_dxf_reduc.setValue(20.0)
        self.spn_dxf_reduc.setSuffix(" %")
        self.spn_dxf_reduc.setDecimals(1)
        row_red.addWidget(self.spn_dxf_reduc)
        sub_lay.addLayout(row_red)

        # Archivos DXF
        sep2 = QFrame(); sep2.setFrameShape(QFrame.HLine)
        sep2.setStyleSheet("color:#AED6F1;"); sub_lay.addWidget(sep2)
        lbl_arch = QLabel("Archivos DXF a actualizar:")
        lbl_arch.setStyleSheet("font-weight: bold;")
        sub_lay.addWidget(lbl_arch)

        self._dxf_edits: dict = {}
        self._dxf_chks:  dict = {}
        for key, label, tooltip in [
            ("As_X", "Ratio", "Ratios de esfuerzo (flexión principal Mz)"),
        ]:
            row_w = QWidget()
            row_h = QHBoxLayout(row_w)
            row_h.setContentsMargins(0, 0, 0, 0)
            row_h.setSpacing(4)
            chk = QCheckBox(label + ":")
            chk.setChecked(True)
            chk.setFixedWidth(64)
            chk.setToolTip(tooltip)
            self._dxf_chks[key] = chk
            txt = QLineEdit()
            txt.setPlaceholderText("Ruta del archivo ...")
            txt.setReadOnly(True)
            txt.setToolTip(tooltip)
            btn = QPushButton("...")
            btn.setFixedWidth(26)
            btn.setToolTip(f"Seleccionar {key}.dxf")
            btn.clicked.connect(
                lambda checked, k=key, t=txt: self._browse_dxf(k, t))
            chk.toggled.connect(txt.setEnabled)
            chk.toggled.connect(btn.setEnabled)
            row_h.addWidget(chk)
            row_h.addWidget(txt, 1)
            row_h.addWidget(btn)
            sub_lay.addWidget(row_w)
            self._dxf_edits[key] = txt

        lay.addWidget(self._dxf_sub)
        self._dxf_sub.setEnabled(False)
        self.chk_dxf_enable.toggled.connect(self._dxf_sub.setEnabled)
        return grp

    def _browse_dxf(self, key: str, txt_widget):
        """Abre diálogo para seleccionar un archivo DXF (existente o nueva ruta)."""
        path, _ = QFileDialog.getSaveFileName(
            self, f"Seleccionar / crear {key}.dxf",
            txt_widget.text() or "",
            "DXF Files (*.dxf);;All Files (*)")
        if path:
            txt_widget.setText(path)
            txt_widget.setToolTip(path)

    def _export_dxf_update(self):
        """Exporta ratios a DXF según el panel de opciones."""
        if not self._results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute el diseño primero.")
            return
        if not self.chk_dxf_enable.isChecked():
            QMessageBox.information(self, "DXF desactivado",
                "Active la casilla 'Exportar resultados a DXF' en el panel DXF.")
            return

        pct  = self.spn_dxf_reduc.value()
        mode = "A" if self.rdo_dxf_A.isChecked() else "B"

        from fileio.dxf_exporter import export_dxf_single, modify_existing_dxf
        # Mapeo clave → modo de ratio
        dxf_mode_map = {"As_X": "Mz", "As_Y": "My"}

        resultados = []
        for key, dxf_mode in dxf_mode_map.items():
            chk = self._dxf_chks.get(key)
            txt = self._dxf_edits.get(key)
            if not chk or not chk.isChecked():
                continue
            path = txt.text().strip() if txt else ""
            if not path:
                continue

            import os as _os
            if _os.path.exists(path):
                ok, out = modify_existing_dxf(
                    path, self._results,
                    mode=dxf_mode, reduction_pct=pct)
                if ok:
                    resultados.append(
                        f"  ✔  {key}: modificado → {_os.path.basename(out)}")
                else:
                    resultados.append(f"  ✗  {key}: {out}")
            else:
                ok = export_dxf_single(
                    path, self._results,
                    mode=dxf_mode, reduction_pct=pct)
                if ok:
                    resultados.append(
                        f"  ✔  {key}: creado → {_os.path.basename(path)}")
                else:
                    resultados.append(
                        f"  ✗  {key}: error al crear (verifique ezdxf)")

        if not resultados:
            QMessageBox.warning(
                self, "Sin archivos DXF",
                "Seleccione al menos un archivo DXF y verifique que\n"
                "la casilla correspondiente esté marcada.")
            return

        QMessageBox.information(
            self, f"DXF  —  reducción {pct:.1f}%",
            "\n".join(resultados))

    # ══════════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _on_material_changed(self, idx):
        m = STEEL_MATERIALS[idx]
        manual = (m["fy"] == 0)
        self.spn_fy.setEnabled(manual)
        self.spn_fu.setEnabled(manual)
        if not manual:
            self.spn_fy.setValue(m["fy"])
            self.spn_fu.setValue(m["fu"])

