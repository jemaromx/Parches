﻿# -*- coding: utf-8 -*-
"""
Ventana principal — WallDesignPro.

Arquitectura:
  ┌─ Header (logo + título) ──────────────────────────────────────────┐
  ├─ Left Panel (460px) ───────┬─ Right Panel (QTabWidget) ───────────┤
  │  • Archivos (Excel)        │  • Resultados                        │
  │  • Conexión STAAD Pro      │  • Resumen                           │
  │  • Selección de Grupos     │  • Cort. Res. Ent.                   │
  │  • Acciones                │  • Gráficas                          │
  │  • Log de cálculo          │                                      │
  ├────────────────────────────┴──────────────────────────────────────┤
  │  Barra de progreso (fina)                                          │
  └─ StatusBar ────────────────────────────────────────────────────────┘

Modo de operación: OpenSTAAD API (STAAD Pro 2024 / 2025)
"""
from __future__ import annotations

import logging
import math
import os
import sys
import traceback
from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import (
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavToolbar,
)

from PySide6.QtCore    import Qt, QThread, Signal
from PySide6.QtGui     import QColor, QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QSplitter, QLabel, QPushButton, QLineEdit, QComboBox,
    QFileDialog, QMessageBox, QProgressBar, QStatusBar,
    QFrame, QGroupBox, QTabWidget, QTextEdit, QScrollArea,
    QSizePolicy, QListWidget, QRadioButton, QButtonGroup,
    QAbstractItemView, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QDoubleSpinBox, QSpinBox,
    QDialog, QDialogButtonBox,
)

from config.settings import (
    APP_NAME, APP_VERSION, APP_SUBTITLE,
    COLORS, LOG_COLORS, CRIT_BG, SOURCE_DIR,
)
from gui.styles import MAIN_STYLE, HEADER_STYLE, LOG_STYLE

log = logging.getLogger(__name__)


# ── Widget de texto con colores ───────────────────────────────────────────────

class ColoredLog(QTextEdit):
    """QTextEdit de sólo lectura con soporte de colores por segmento."""

    FG = LOG_COLORS
    BG = CRIT_BG

    def __init__(self, parent=None, wrap: bool = False):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setStyleSheet(LOG_STYLE)
        font = QFont("Consolas", 8)
        self.setFont(font)
        self.setLineWrapMode(QTextEdit.WidgetWidth if wrap else QTextEdit.NoWrap)

    def put(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto sin salto de línea con color fg y fondo opcional bg."""
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(self.FG.get(fg, self.FG[""])))
        if bg in self.BG:
            fmt.setBackground(QColor(self.BG[bg]))
        if fg in ("hdr", "sec"):
            fmt.setFontWeight(QFont.Weight.Bold)
        cursor.setCharFormat(fmt)
        cursor.insertText(text)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()

    def putln(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto + salto de línea."""
        self.put(text + "\n", fg, bg)

    def clear_log(self):
        self.clear()

    def scroll_top(self):
        self.moveCursor(QTextCursor.Start)


# ── Hilo de diseño ────────────────────────────────────────────────────────────

class FetchWorker(QThread):
    """
    Hilo de extracción: conecta a STAAD Pro y descarga esfuerzos y propiedades.
    La geometría (incidencias + coordenadas) se pasa pre-capturada desde el
    hilo principal donde openstaadpy.GetPlateIncidence funciona correctamente.
    """
    sig_log      = Signal(str, str)
    sig_progress = Signal(int, str)
    sig_done     = Signal(object)   # PlateCache
    sig_error    = Signal(str)

    def __init__(self, ver_pref: str, group_plates: dict,
                 load_cases: list, source_dir: str,
                 pre_incidences: dict = None,
                 pre_coordinates: dict = None,
                 parent=None):
        super().__init__(parent)
        self.ver_pref       = ver_pref
        self.group_plates   = group_plates
        self.load_cases     = load_cases
        self.source_dir     = source_dir
        self.pre_incidences  = pre_incidences  or {}
        self.pre_coordinates = pre_coordinates or {}

    def run(self):
        # Inicializar COM para este hilo (STA — Single-Threaded Apartment)
        # Necesario para que GetPlateIncidence funcione en hilos secundarios
        _com_initialized = False
        try:
            import pythoncom
            pythoncom.CoInitialize()
            _com_initialized = True
        except Exception:
            pass   # Si pythoncom no está disponible, continuar sin él

        try:
            sd = self.source_dir
            if sd not in sys.path:
                sys.path.insert(0, sd)
            from openstaad_connector import OpenSTAADConnector

            self.sig_log.emit("Conectando a STAAD Pro (hilo de cálculo)...", "sec")
            conn = OpenSTAADConnector()
            conn.connect(self.ver_pref)
            self.sig_log.emit(f"  Conectado: {conn._ver}", "ok")

            if not conn.results_available():
                self.sig_log.emit(
                    "  [AVISO] Resultados no disponibles — "
                    "los esfuerzos serán cero.", "warn")

            all_pids: list = []
            for pids in self.group_plates.values():
                all_pids.extend(pids)
            all_pids = list(dict.fromkeys(all_pids))

            self.sig_log.emit(
                f"  Extrayendo datos: {len(all_pids)} placas × "
                f"{len(self.load_cases)} CL...", "dim")

            def _cb(step, total, desc):
                pct = int(step / max(total, 1) * 60)
                self.sig_progress.emit(pct, desc)

            cache = conn.fetch_all_data(
                all_pids, self.load_cases,
                callback=_cb,
                pre_incidences=self.pre_incidences  or None,
                pre_coordinates=self.pre_coordinates or None,
            )

            n_inc   = sum(1 for v in cache.incidences.values() if v)
            n_coord = len(cache.coordinates)
            n_thick = sum(1 for v in cache.properties.values()
                          if v.get("thick", 0) > 0)
            n_mat   = len(cache.mat_assignments)

            from openstaad_connector import OpenSTAADConnector
            inc_method = OpenSTAADConnector._inc_method_name or "—ninguno—"
            tag_inc = "ok" if n_inc == len(all_pids) else (
                "warn" if n_inc > 0 else "err")
            self.sig_log.emit(
                f"  Incidencias : {n_inc}/{len(all_pids)} placas "
                f"(método: {inc_method})",
                tag_inc)
            tag_crd = "ok" if n_coord > 0 else "err"
            self.sig_log.emit(
                f"  Coordenadas : {n_coord} nodos", tag_crd)
            self.sig_log.emit(
                f"  Espesores   : {n_thick}/{len(all_pids)} placas", "dim")
            self.sig_log.emit(
                f"  Materiales  : {n_mat}/{len(all_pids)} placas", "dim")

            if n_inc == 0:
                first_err = OpenSTAADConnector._inc_first_error or "—sin detalle—"
                self.sig_log.emit(
                    f"  [ERROR] Incidencias vacías.\n"
                    f"  Métodos probados: GetPlateIncidence, GetPlateIncidence_CIS2, "
                    f"GetNodeIncidence_CIS2\n"
                    f"  Último error: {first_err}\n"
                    f"  Use 🔍 Diagnóstico → OSGeometry para verificar "
                    "el método correcto.", "err")
                OpenSTAADConnector._inc_first_error = ""
            if n_coord == 0 and n_inc > 0:
                self.sig_log.emit(
                    "  [ERROR] GetNodeCoordinates retornó vacío. "
                    "Use 🔍 Diagnóstico → OSGeometry para verificar "
                    "el método correcto de coordenadas.", "err")

            self.sig_done.emit(cache)
        except Exception:
            self.sig_error.emit(traceback.format_exc())
        finally:
            if _com_initialized:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass


class DesignWorker(QThread):
    """Ejecuta todo el cálculo de diseño en un hilo secundario."""

    sig_log      = Signal(str, str)
    sig_progress = Signal(int, str)
    sig_done     = Signal(object)
    sig_error    = Signal(str)

    def __init__(self, user_inputs: object, cache: object,
                 wall_plate_ids: dict, source_dir: str, parent=None):
        super().__init__(parent)
        self.user_inputs    = user_inputs   # UserInputs pre-construido desde la UI
        self.cache          = cache         # PlateCache
        self.wall_plate_ids = wall_plate_ids
        self.source_dir     = source_dir

    def _log(self, text: str, tag: str = ""):
        self.sig_log.emit(text, tag)

    def run(self):  # noqa: C901
        try:
            sd = self.source_dir
            if sd not in sys.path:
                sys.path.insert(0, sd)

            from openstaad_connector   import ANLCompatAdapter
            from wall_models           import WallData, UserInputs
            from wall_geometry         import build_plate_data, determine_direction, build_wall_levels
            from config.settings       import STAAD_FORCE_UNIT, STAAD_KN_FACTOR
            from wall_design_ntc2023   import (
                design_masonry_level, design_concrete_level,
                interaction_diagram_masonry, interaction_diagram_concrete,
            )

            # Adaptador de compatibilidad: expone la interfaz de ANLParser
            parser = ANLCompatAdapter(self.cache)

            # ── Conversión de unidades OpenSTAAD → ton ────────────────────────
            self._log(
                f"  Unidades STAAD: {STAAD_FORCE_UNIT}  "
                f"→  factor conversión a ton: 1/{STAAD_KN_FACTOR:.4f}  "
                f"({'kN ÷ 9.81 = tonf' if STAAD_KN_FACTOR != 1.0 else 'ya en ton, sin conversión'})",
                "sec" if STAAD_KN_FACTOR != 1.0 else "dim",
            )
            if STAAD_KN_FACTOR == 1.0:
                self._log(
                    "  [AVISO] STAAD_FORCE_UNIT = 'MTON' — "
                    "si el modelo usa kN cambie la variable en config/settings.py",
                    "warn",
                )
            parser.kn_factor = STAAD_KN_FACTOR

            # 1. Parámetros desde la UI (ya construido como UserInputs) ─────────
            self._log("Usando parámetros ingresados en la UI...", "sec")
            inputs = self.user_inputs
            self._log(
                f"  Niveles: {len(inputs.floor_levels)}  |  "
                f"combos diseño: {inputs.first_design_combo}–{inputs.last_design_combo}  |  "
                f"Q={inputs.Q_duct}"
            )

            # 2. Reemplazar wall_plate_ids con SOLO los grupos seleccionados en STAAD
            # Los grupos STAAD son la fuente de verdad; el Excel solo aporta config.
            # Esto evita que filas del Excel (NOTAS, encabezados, etc.) se procesen.
            self._log("\n  Muros a diseñar (grupos STAAD seleccionados):", "sec")
            inputs.wall_plate_ids = {}     # limpiar entradas del Excel
            for wname, pids in self.wall_plate_ids.items():
                inputs.wall_plate_ids[wname] = pids
                if pids:
                    self._log(f"    {wname:<14}: {len(pids)} placas", "dim")
                else:
                    self._log(f"    [AVISO] {wname}: sin placas (se omitirá)", "warn")

            found = sum(len(v) for v in inputs.wall_plate_ids.values())
            if found == 0:
                raise ValueError(
                    "No se encontraron placas en ningún grupo seleccionado.\n"
                    "Seleccione al menos un grupo en el panel izquierdo.")

            # 3. Espesores y coordenadas (desde caché OpenSTAAD) ─────────────
            all_pids = list({pid for pids in inputs.wall_plate_ids.values()
                             for pid in pids})
            self._log(f"\n  Espesores ({len(all_pids)} placas)...", "dim")
            element_prop: dict = {}
            try:
                element_prop = parser.find_element_property(all_pids)
                self._log(
                    f"  {len(element_prop)}/{len(all_pids)} placas con espesor.", "dim")
                t_counts = Counter(
                    round(v['thick'], 4)
                    for v in element_prop.values() if v['thick'] > 0)
                for tv, cnt in sorted(t_counts.items()):
                    self._log(f"    t={tv:.4f} m  →  {cnt} placas", "dim")
                if not t_counts:
                    self._log(
                        "  [AVISO] Sin espesores desde OpenSTAAD. "
                        "Se usará el valor del Excel.", "warn")
            except Exception as exc:
                self._log(f"  [AVISO] Espesores: {exc}", "warn")

            # 4. Asignaciones de material (desde caché OpenSTAAD) ───────────
            self._log("  Asignaciones de material...", "dim")
            mat_assign: dict = {}
            try:
                mat_assign = parser.find_material_assignments(all_pids)
                if mat_assign:
                    for mname, cnt in sorted(Counter(mat_assign.values()).items()):
                        excel_mat = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mname.strip().upper()),
                            None,
                        )
                        flag = "✓" if excel_mat else "?"
                        tag  = "ok"  if excel_mat else "warn"
                        self._log(
                            f"    {flag} {mname:<14}  {cnt:>4} placas  "
                            + (f"→ {excel_mat.name}"
                               if excel_mat else "→ NO en Excel"),
                            tag,
                        )
                else:
                    self._log(
                        "  [AVISO] Sin asignaciones de material en OpenSTAAD. "
                        "Usando nombre del Excel.", "warn")
            except Exception as exc:
                self._log(f"  [AVISO] Material: {exc}", "warn")

            # 6. Combinaciones ──────────────────────────────────────────────
            design_combos  = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            service_combos = list(range(
                inputs.first_service_combo, inputs.last_service_combo + 1))
            pp_combo   = inputs.pp_cm_cvacc_combo
            all_combos = sorted(set(design_combos + service_combos + [pp_combo]))

            walls_out    : List[WallData]            = []
            results_all  : Dict[str, Dict[str, list]] = {}
            diagrams_all : Dict[str, Dict[str, list]] = {}
            # Iterar solo los grupos seleccionados (no las filas del Excel)
            design_walls = [(wn, pids) for wn, pids in self.wall_plate_ids.items()
                            if pids]
            total_walls  = max(len(design_walls), 1)

            # 7. Procesar cada muro ─────────────────────────────────────────
            for wi, (wall_name, plate_ids) in enumerate(design_walls):

                self.sig_progress.emit(
                    int(wi / total_walls * 90),
                    f"Muro {wall_name}  ({wi+1}/{total_walls})",
                )
                self._log(
                    f"\n{'='*55}\nMuro: {wall_name}  ({len(plate_ids)} placas)",
                    "sec")

                if not plate_ids:
                    self._log("  Sin placas asignadas. Saltando.", "warn")
                    continue

                # ── Espesor global del muro (promedio de todas sus placas) ──────
                # Se usará como fallback; el espesor real por nivel se calcula
                # en build_wall_levels a partir de las placas de ese nivel.
                thickness_excel = inputs.wall_thickness.get(wall_name, 0.15)
                if element_prop:
                    wt = [
                        element_prop[pid]["thick"]
                        for pid in plate_ids
                        if pid in element_prop
                        and element_prop[pid]["thick"] > 0
                    ]
                    if wt:
                        thickness = sum(wt) / len(wt)
                        self._log(
                            f"  Espesor prom. (OpenSTAAD): {thickness:.4f} m  "
                            f"(Excel: {thickness_excel:.4f} m)", "ok")
                    else:
                        thickness = thickness_excel
                        self._log(
                            f"  Espesor (Excel fallback): {thickness:.4f} m  "
                            f"[OpenSTAAD no devolvió espesores]", "warn")
                else:
                    thickness = thickness_excel
                    self._log(
                        f"  Espesor (Excel): {thickness:.4f} m", "dim")

                # Material
                mat = None
                if mat_assign and inputs.materials:
                    wm = [mat_assign[pid] for pid in plate_ids
                          if pid in mat_assign]
                    if wm:
                        mc = Counter(wm).most_common(1)[0][0]
                        mat = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mc.strip().upper()),
                            None,
                        )
                        if mat:
                            self._log(
                                f"  Material (CONSTANTS): {mat.name} ✓", "dim")
                        else:
                            self._log(
                                f"  [AVISO] Material STAAD '{mc}' "
                                "no en Excel.", "warn")

                if mat is None:
                    mat_name = inputs.wall_material.get(wall_name, "")
                    mat = next(
                        (m for m in inputs.materials
                         if m.name == mat_name), None)
                    if mat:
                        self._log(
                            f"  Material (Excel, por nombre): {mat.name}", "dim")
                    elif inputs.materials:
                        mat = inputs.materials[0]
                        self._log(
                            f"  [AVISO] Usando primer material: {mat.name}", "warn")

                if mat is None:
                    self._log(
                        f"  [ERROR] Sin material para {wall_name}. Saltando.", "err")
                    continue

                position = inputs.wall_positions.get(wall_name, 1)

                # PlateData
                combined: dict = {
                    pid: {'thick': element_prop[pid]['thick']}
                    for pid in plate_ids
                    if pid in element_prop
                } if element_prop else {}

                self._log("  Extrayendo geometría y esfuerzos...", "dim")
                plates = build_plate_data(
                    parser, plate_ids, all_combos, thickness,
                    combined or None,
                    material_assignments=mat_assign,
                )
                if not plates:
                    self._log("  [ERROR] No se obtuvieron placas.", "err")
                    continue

                direction = determine_direction(plates)
                self._log(
                    f"  {len(plates)} placas procesadas.  "
                    f"Dirección: {direction}  "
                    f"t_prom: {thickness:.4f} m", "dim")

                # RelTan
                sdx = sum(p.x_max - p.x_min for p in plates)
                sdz = sum(p.z_max - p.z_min for p in plates)
                den = math.sqrt(sdx**2 + sdz**2)
                if den > 1e-9:
                    rt1, rt2 = sdx / den, sdz / den
                else:
                    rt1 = 1.0 if direction == "X" else 0.0
                    rt2 = 1.0 if direction == "Z" else 0.0
                reltan = {"reltan1": rt1, "reltan2": rt2}
                inputs.wall_reltan[wall_name] = reltan
                self._log(
                    f"  reltan: {rt1:.4f} (Dir X) / {rt2:.4f} (Dir Z)", "dim")

                # Niveles
                Ht = inputs.floor_levels[0] - inputs.floor_levels[-1]
                levels = build_wall_levels(
                    plates=plates,
                    floor_levels=inputs.floor_levels,
                    direction=direction,
                    thickness=thickness,
                    all_design_combos=design_combos,
                    pp_combo=pp_combo,
                    story_shears=inputs.story_shears,
                    wall_name=wall_name,
                    reltan=reltan,
                    materials=inputs.materials,
                    service_combos=service_combos,
                )
                self._log(f"  {len(levels)} niveles construidos.", "dim")

                wall = WallData(
                    name=wall_name, position=position,
                    plate_ids=plate_ids, direction=direction,
                    levels=levels, material=mat, Ht=Ht, thickness=thickness,
                )
                walls_out.append(wall)

                # Diseñar niveles
                results_w: dict  = {}
                diagrams_w: dict = {}

                for lv in levels:
                    lv_mat   = lv.material if lv.material is not None else mat
                    mat_src  = "OpenSTAAD" if lv.material is not None else "Excel↓"
                    tipo_str = "Mamp." if lv_mat.tipo_material == 1 else "Conc."
                    e_tag    = "ok" if lv.material is not None else "warn"

                    # Detalle de espesores y materiales de placas del nivel
                    plc_thicks  = [p.thick for p in lv.plates if p.thick > 0]
                    plc_matnames = [p.material_name for p in lv.plates
                                    if p.material_name and p.material_name.strip()]
                    t_detail = (
                        f"t_prom={sum(plc_thicks)/len(plc_thicks):.4f}m"
                        if plc_thicks else "t=Excel"
                    )
                    m_detail = (
                        Counter(plc_matnames).most_common(1)[0][0]
                        if plc_matnames else "—"
                    )

                    self._log(
                        f"  Nivel {lv.nivel_name}: "
                        f"Lm={lv.lm:.2f}m  t_dom={lv.thickness:.4f}m ({t_detail})  "
                        f"Hi={lv.hi:.2f}m  "
                        f"Mat_dom={m_detail} → Excel: {lv_mat.name} [{tipo_str}] ({mat_src})",
                        e_tag)

                    if lv_mat.tipo_material == 1:
                        res_list = design_masonry_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, Q_duct=inputs.Q_duct,
                            position=position, service_combos=service_combos,
                        )
                        diag_pts = (
                            interaction_diagram_masonry(
                                fm=lv_mat.fm, fc=lv_mat.fc_castillos,
                                fy=lv_mat.fy_vert, Lm=lv.lm, t=lv.thickness,
                                As_castillo=max(
                                    max((r.Asc1 for r in res_list), default=4.0),
                                    4.0),
                                n_castillos=2,
                            ) if res_list else []
                        )
                    else:
                        res_list = design_concrete_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, position=position, Ht=wall.Ht,
                        )
                        if res_list:
                            asext_max = max((r.AsExt1 for r in res_list), default=4.0)
                            asv_max   = max((r.Asv   for r in res_list), default=0.0)
                            secc_tc   = res_list[0].SeccTC if res_list else 0.15 * lv.lm
                            diag_pts  = interaction_diagram_concrete(
                                fc=lv_mat.fc, fy=lv_mat.fy_vert,
                                Lm=lv.lm, t=lv.thickness, SeccTC=secc_tc,
                                AsExt=max(asext_max, 4.0),
                                Asv_total=max(asv_max * lv.lm, 8.0),
                            )
                        else:
                            diag_pts = []

                    n_ok = sum(
                        1 for r in res_list
                        if getattr(r, "cond_axial", "") in ("Si Pasa", "Tension")
                        and getattr(r, "cond_cortante", "") == "Si Pasa"
                    )
                    self._log(
                        f"    {len(res_list)} combos  |  {n_ok} OK",
                        "ok" if (n_ok == len(res_list) and res_list) else "warn")

                    results_w[lv.nivel_name]  = res_list
                    diagrams_w[lv.nivel_name] = diag_pts

                results_all[wall_name]  = results_w
                diagrams_all[wall_name] = diagrams_w

            self.sig_progress.emit(100, "Completado")
            self.sig_done.emit({
                "walls":    walls_out,
                "results":  results_all,
                "diagrams": diagrams_all,
                "inputs":   inputs,
            })

        except Exception:
            self.sig_error.emit(traceback.format_exc())


# ── Hilo de exportación de memoria de cálculo ─────────────────────────────────

class CalcMemoryWorker(QThread):
    """Genera la memoria de cálculo Word en un hilo secundario."""

    sig_progress = Signal(int, str)
    sig_done     = Signal(str)    # ruta del archivo generado
    sig_error    = Signal(str)

    def __init__(self, walls, results_by_wall, inputs, output_path,
                 diagrams_by_wall=None, include_2d=True, include_3d=False,
                 source_dir="", parent=None):
        super().__init__(parent)
        self.walls            = walls
        self.results_by_wall  = results_by_wall
        self.inputs           = inputs
        self.output_path      = output_path
        self.diagrams_by_wall = diagrams_by_wall or {}
        self.include_2d       = include_2d
        self.include_3d       = include_3d
        self.source_dir       = source_dir

    def run(self):
        try:
            import sys
            if self.source_dir and self.source_dir not in sys.path:
                sys.path.insert(0, self.source_dir)

            # Cambiar al backend Agg (sin display) para renderizado thread-safe.
            # Solo afecta figuras creadas DESPUÉS de este punto; las que ya están
            # abiertas en la UI conservan su canvas QtAgg.
            import matplotlib.pyplot as plt
            plt.switch_backend("agg")

            from wall_design_calc_memory import export_calc_memory_word

            export_calc_memory_word(
                walls=self.walls,
                results_by_wall=self.results_by_wall,
                inputs=self.inputs,
                output_path=self.output_path,
                diagrams_by_wall=self.diagrams_by_wall,
                include_2d=self.include_2d,
                include_3d=self.include_3d,
                progress_callback=lambda pct, msg: self.sig_progress.emit(pct, msg),
            )
            self.sig_done.emit(self.output_path)

        except Exception:
            self.sig_error.emit(traceback.format_exc())


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._walls:    list = []
        self._results:  dict = {}
        self._diagrams: dict = {}
        self._inputs         = None
        self._shear_data     = {}
        self._plot_paths     = {}
        self._worker:     Optional[DesignWorker]     = None
        self._fetcher:    Optional[FetchWorker]      = None
        self._mem_worker: Optional[CalcMemoryWorker] = None
        self._plot_canvas: Optional[FigureCanvas]  = None
        self._plot_toolbar: Optional[NavToolbar]   = None

        # Estado de conexión STAAD
        self._staad_connected     = False
        self._all_groups: list    = []         # [(name, type), ...]
        self._ver_pref            = "2025"     # solo STAAD Pro 2025
        self._user_inputs_pending = None       # UserInputs desde la UI
        self._wall_plate_ids_pending: dict = {}

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1420, 820)
        self.setStyleSheet(MAIN_STYLE)
        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────


        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "wall_design_pro")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_right_tabs())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([490, 940])
        root.addWidget(splitter, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(5)
        root.addWidget(self.progress)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.lbl_badge = QLabel("  NTC 2023  ")
        self.lbl_badge.setStyleSheet(
            "background:#2874A6; color:white; padding:0 8px; border-radius:3px;")
        self.status.addPermanentWidget(self.lbl_badge)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    def _build_header(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(HEADER_STYLE)
        frame.setFixedHeight(60)
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)

        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet(
            "color:white; font-size:15pt; font-weight:bold;")
        lay.addWidget(lbl_title)

        lbl_sub = QLabel(APP_SUBTITLE)
        lbl_sub.setStyleSheet("color:#AED6F1; font-size:9pt;")
        lay.addWidget(lbl_sub)

        lay.addStretch()

        lbl_ver = QLabel(f"v{APP_VERSION}")
        lbl_ver.setStyleSheet("color:#AED6F1; font-size:8pt;")
        lay.addWidget(lbl_ver)
        return frame

    def _build_left_panel(self) -> QWidget:
        """Panel izquierdo: toda la configuración + selección de grupos y acciones."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setMinimumWidth(500)

        panel = QWidget()
        panel.setFont(QFont("Segoe UI", 8))
        vlay = QVBoxLayout(panel)
        vlay.setContentsMargins(8, 8, 8, 8)
        vlay.setSpacing(6)

        # ── Conexión STAAD Pro 2025 ───────────────────────────────────────
        grp_staad = QGroupBox("Conexión STAAD Pro 2025")
        slay = QVBoxLayout(grp_staad)
        slay.setSpacing(4)

        self._ver_pref = "2025"
        row_btn = QHBoxLayout()
        self.btn_connect = QPushButton("Conectar a STAAD Pro 2025")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.setToolTip(
            "Establece conexión con STAAD Pro 2025 via openstaadpy\n"
            "(requiere ejecutar como Administrador)")
        self.btn_connect.clicked.connect(self._on_staad_connect)
        row_btn.addWidget(self.btn_connect)

        self.lbl_conn_st = QLabel("● Sin conexión")
        self.lbl_conn_st.setStyleSheet("color:#C0392B; font-weight:bold;")
        row_btn.addWidget(self.lbl_conn_st)

        btn_diag = QPushButton("🔍")
        btn_diag.setFixedWidth(30)
        btn_diag.setToolTip("Diagnóstico de métodos OpenSTAAD API")
        btn_diag.clicked.connect(self._on_diagnostics)
        row_btn.addWidget(btn_diag)
        row_btn.addStretch()
        slay.addLayout(row_btn)

        self.lbl_conn_info = QLabel("")
        self.lbl_conn_info.setStyleSheet("color:#607D8B; font-size:7pt;")
        slay.addWidget(self.lbl_conn_info)
        vlay.addWidget(grp_staad)

        # ── Cargas ────────────────────────────────────────────────────────
        grp_loads = QGroupBox("Cargas")
        gload = QGridLayout(grp_loads)
        gload.setSpacing(4)
        gload.setColumnMinimumWidth(1, 70)
        gload.setColumnMinimumWidth(3, 70)

        def _spn(mn=1, mx=999, val=1):
            s = QSpinBox()
            s.setRange(mn, mx)
            s.setValue(val)
            s.setFixedWidth(70)
            return s

        gload.addWidget(QLabel("PP+CM+CVacc (CL):"), 0, 0)
        self.spn_pp_combo = _spn(1, 999, 1)
        self.spn_pp_combo.setToolTip("Número de caso de carga permanente PP+CM+CVacc")
        gload.addWidget(self.spn_pp_combo, 0, 1)

        gload.addWidget(QLabel("Comb. Servicio:"), 1, 0)
        self.spn_svc_start = _spn(1, 999, 2)
        self.spn_svc_start.setToolTip("Inicio combinaciones de servicio")
        gload.addWidget(self.spn_svc_start, 1, 1)
        gload.addWidget(QLabel("hasta:"), 1, 2)
        self.spn_svc_end = _spn(1, 999, 5)
        self.spn_svc_end.setToolTip("Fin combinaciones de servicio")
        gload.addWidget(self.spn_svc_end, 1, 3)

        gload.addWidget(QLabel("Comb. Diseño:"), 2, 0)
        self.spn_des_start = _spn(1, 999, 6)
        self.spn_des_start.setToolTip("Inicio combinaciones de diseño")
        gload.addWidget(self.spn_des_start, 2, 1)
        gload.addWidget(QLabel("hasta:"), 2, 2)
        self.spn_des_end = _spn(1, 999, 20)
        self.spn_des_end.setToolTip("Fin combinaciones de diseño")
        gload.addWidget(self.spn_des_end, 2, 3)

        vlay.addWidget(grp_loads)

        # ── Ductilidad ────────────────────────────────────────────────────
        grp_duct = QGroupBox("Ductilidad")
        dl = QHBoxLayout(grp_duct)
        dl.setSpacing(6)
        dl.addWidget(QLabel("Factor Q:"))
        self.spn_ductility = QDoubleSpinBox()
        self.spn_ductility.setRange(1.0, 4.0)
        self.spn_ductility.setSingleStep(0.5)
        self.spn_ductility.setValue(2.0)
        self.spn_ductility.setFixedWidth(70)
        self.spn_ductility.setDecimals(1)
        dl.addWidget(self.spn_ductility)
        lbl_q = QLabel("  1.5 = Media ductilidad  ·  2.0 = Alta ductilidad")
        lbl_q.setStyleSheet("color:#607D8B; font-size:7pt;")
        dl.addWidget(lbl_q)
        dl.addStretch()
        vlay.addWidget(grp_duct)

        # ── Sección Niveles ───────────────────────────────────────────────
        grp_niv = QGroupBox("Niveles")
        nl = QVBoxLayout(grp_niv)
        nl.setSpacing(4)

        lbl_note = QLabel(
            "Elevación (m) desde el nivel de desplante (cota 0.00 = desplante).\n"
            "Incluir todas las losas: base, intermedias y azotea.")
        lbl_note.setStyleSheet("color:#607D8B; font-size:7pt; font-style:italic;")
        lbl_note.setWordWrap(True)
        nl.addWidget(lbl_note)

        lbl_note_desc = QLabel(
            "⚠  NOTA: Ingrese los niveles en orden DESCENDENTE de elevación\n"
            "   (azotea → pisos intermedios → desplante).\n"
            "   La fila superior = nivel más alto (mayor elevación).")
        lbl_note_desc.setStyleSheet(
            "color:#E67E22; font-size:7pt; font-weight:bold; "
            "background:#1A1A00; border:1px solid #E67E22; padding:4px; border-radius:3px;")
        lbl_note_desc.setWordWrap(True)
        nl.addWidget(lbl_note_desc)

        row_btn_n = QHBoxLayout()
        btn_add_n = QPushButton("＋ Nivel")
        btn_add_n.clicked.connect(self._add_nivel_row)
        btn_del_n = QPushButton("－ Eliminar")
        btn_del_n.clicked.connect(lambda: self._del_tbl_row(self.tbl_niveles))
        row_btn_n.addWidget(btn_add_n)
        row_btn_n.addWidget(btn_del_n)
        row_btn_n.addStretch()
        nl.addLayout(row_btn_n)

        self.tbl_niveles = QTableWidget(0, 2)
        self.tbl_niveles.setFont(QFont("Consolas", 7))
        self.tbl_niveles.setHorizontalHeaderLabels(["Nombre del Nivel", "Elevación (m)"])
        self.tbl_niveles.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tbl_niveles.horizontalHeader().setSectionResizeMode(1, QHeaderView.Fixed)
        self.tbl_niveles.setColumnWidth(1, 90)
        self.tbl_niveles.setMaximumHeight(180)
        nl.addWidget(self.tbl_niveles)
        vlay.addWidget(grp_niv)

        # ── Sección Materiales ────────────────────────────────────────────
        grp_mat = QGroupBox("Materiales")
        ml = QVBoxLayout(grp_mat)
        ml.setSpacing(4)

        row_type = QHBoxLayout()
        row_type.addWidget(QLabel("Tipo(s) de material:"))
        self.chk_mamp = QCheckBox("Mampostería")
        self.chk_mamp.setChecked(True)
        self.chk_conc = QCheckBox("Concreto")
        self.chk_mamp.toggled.connect(self._toggle_material_tables)
        self.chk_conc.toggled.connect(self._toggle_material_tables)
        row_type.addWidget(self.chk_mamp)
        row_type.addWidget(self.chk_conc)
        row_type.addStretch()
        ml.addLayout(row_type)

        # Sub-tabla Mampostería
        self.grp_mamp_tbl = QGroupBox("Mampostería")
        mamp_l = QVBoxLayout(self.grp_mamp_tbl)
        mamp_l.setSpacing(3)

        hint_mamp = QLabel(
            "Nombre Material Staad debe coincidir exactamente con CONSTANTS MATERIAL en STAAD Pro.")
        hint_mamp.setStyleSheet("color:#607D8B; font-size:7pt;")
        hint_mamp.setWordWrap(True)
        mamp_l.addWidget(hint_mamp)

        row_btn_m = QHBoxLayout()
        btn_add_m = QPushButton("＋ Material")
        btn_add_m.clicked.connect(self._add_mamp_row)
        btn_del_m = QPushButton("－ Eliminar")
        btn_del_m.clicked.connect(lambda: self._del_tbl_row(self.tbl_mamp))
        row_btn_m.addWidget(btn_add_m)
        row_btn_m.addWidget(btn_del_m)
        row_btn_m.addStretch()
        mamp_l.addLayout(row_btn_m)

        _mamp_hdrs = [
            "Nombre\nStaad", "Descripción\n(Tipo I/II…)",
            "Tipo\nMuro", "Tipo\nPieza",
            "v'm\n(kg/cm²)", "f'm\n(kg/cm²)",
            "f_an\n(f_nm)", "Pes.Vol\n(t/m³)", "f'c Cast\n(kg/cm²)",
            "fyCast\n(kg/cm²)", "fyhor\n(kg/cm²)", "h pieza\n(cm)",
        ]
        self.tbl_mamp = QTableWidget(0, len(_mamp_hdrs))
        self.tbl_mamp.setFont(QFont("Consolas", 7))
        self.tbl_mamp.setHorizontalHeaderLabels(_mamp_hdrs)
        for i in range(len(_mamp_hdrs)):
            self.tbl_mamp.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.Interactive)
        self.tbl_mamp.horizontalHeader().setMinimumSectionSize(55)
        self.tbl_mamp.setMinimumHeight(110)
        self.tbl_mamp.setMaximumHeight(200)
        mamp_l.addWidget(self.tbl_mamp)
        ml.addWidget(self.grp_mamp_tbl)

        # Sub-tabla Concreto
        self.grp_conc_tbl = QGroupBox("Concreto")
        conc_l = QVBoxLayout(self.grp_conc_tbl)
        conc_l.setSpacing(3)

        row_btn_c = QHBoxLayout()
        btn_add_c = QPushButton("＋ Material")
        btn_add_c.clicked.connect(self._add_conc_row)
        btn_del_c = QPushButton("－ Eliminar")
        btn_del_c.clicked.connect(lambda: self._del_tbl_row(self.tbl_conc))
        row_btn_c.addWidget(btn_add_c)
        row_btn_c.addWidget(btn_del_c)
        row_btn_c.addStretch()
        conc_l.addLayout(row_btn_c)

        _conc_hdrs = [
            "Nombre\nStaad", "f'c\n(kg/cm²)",
            "fy Vert.\n(kg/cm²)", "fy Hor.\n(kg/cm²)", "Pes.Vol\n(t/m³)",
        ]
        self.tbl_conc = QTableWidget(0, len(_conc_hdrs))
        self.tbl_conc.setFont(QFont("Consolas", 7))
        self.tbl_conc.setHorizontalHeaderLabels(_conc_hdrs)
        for i in range(len(_conc_hdrs)):
            self.tbl_conc.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.Stretch)
        self.tbl_conc.setMinimumHeight(90)
        self.tbl_conc.setMaximumHeight(160)
        conc_l.addWidget(self.tbl_conc)
        ml.addWidget(self.grp_conc_tbl)
        self.grp_conc_tbl.setVisible(False)

        vlay.addWidget(grp_mat)

        # ── Cortantes de Entrepiso ────────────────────────────────────────
        grp_cort = QGroupBox("Cortantes de Entrepiso  (ΣVr ≥ 0.8·Vu)")
        cort_l = QVBoxLayout(grp_cort)
        cort_l.setSpacing(4)

        hint_cort = QLabel(
            "Cortante de diseño por entrepiso para cada dirección. "
            "El nombre del nivel debe coincidir con el generado por la geometría.")
        hint_cort.setStyleSheet("color:#607D8B; font-size:7pt;")
        hint_cort.setWordWrap(True)
        cort_l.addWidget(hint_cort)

        row_btn_crt = QHBoxLayout()
        btn_add_crt = QPushButton("＋ Entrepiso")
        btn_add_crt.clicked.connect(self._add_cortante_row)
        btn_del_crt = QPushButton("－ Eliminar")
        btn_del_crt.clicked.connect(lambda: self._del_tbl_row(self.tbl_cortantes))
        row_btn_crt.addWidget(btn_add_crt)
        row_btn_crt.addWidget(btn_del_crt)
        row_btn_crt.addStretch()
        cort_l.addLayout(row_btn_crt)

        self.tbl_cortantes = QTableWidget(0, 3)
        self.tbl_cortantes.setFont(QFont("Consolas", 7))
        self.tbl_cortantes.setHorizontalHeaderLabels(
            ["Nombre Entrepiso", "Vx (ton)", "Vz (ton)"])
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(1, QHeaderView.Fixed)
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.tbl_cortantes.setColumnWidth(1, 80)
        self.tbl_cortantes.setColumnWidth(2, 80)
        self.tbl_cortantes.setMaximumHeight(160)
        cort_l.addWidget(self.tbl_cortantes)
        vlay.addWidget(grp_cort)

        # ── Selección de Grupos de Placas ─────────────────────────────────
        grp_groups = QGroupBox("Grupos de Placas  [PLC] — Seleccionar para diseño")
        ggrp = QVBoxLayout(grp_groups)
        ggrp.setSpacing(4)

        row_flt = QHBoxLayout()
        row_flt.addWidget(QLabel("Filtrar:"))
        self.edit_grp_filter = QLineEdit()
        self.edit_grp_filter.setPlaceholderText("nombre...")
        self.edit_grp_filter.textChanged.connect(self._on_group_filter)
        row_flt.addWidget(self.edit_grp_filter, 1)
        btn_clr = QPushButton("✕")
        btn_clr.setFixedWidth(26)
        btn_clr.clicked.connect(lambda: self.edit_grp_filter.clear())
        row_flt.addWidget(btn_clr)
        self.chk_only_plates = QCheckBox("Solo [PLC]")
        self.chk_only_plates.setChecked(True)
        self.chk_only_plates.toggled.connect(self._refresh_group_list)
        row_flt.addWidget(self.chk_only_plates)
        ggrp.addLayout(row_flt)

        lists_lay = QHBoxLayout()
        lists_lay.setSpacing(4)

        left_col = QVBoxLayout()
        left_col.addWidget(QLabel("Disponibles:"))
        self.lst_avail = QListWidget()
        self.lst_avail.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_avail.setFont(QFont("Consolas", 7))
        self.lst_avail.setFixedHeight(130)
        self.lst_avail.doubleClicked.connect(self._on_grp_add)
        left_col.addWidget(self.lst_avail)
        lists_lay.addLayout(left_col, 1)

        mid_col = QVBoxLayout()
        mid_col.addStretch()
        for txt, slot, tip in [
            ("▶",  self._on_grp_add,    "Agregar seleccionados"),
            ("◀",  self._on_grp_remove, "Quitar seleccionados"),
        ]:
            b = QPushButton(txt); b.setFixedWidth(32); b.setToolTip(tip)
            b.clicked.connect(slot); mid_col.addWidget(b)
        mid_col.addSpacing(6)
        for txt, slot, tip in [
            ("▶▶", self._on_grp_add_all,    "Agregar todos"),
            ("◀◀", self._on_grp_remove_all, "Quitar todos"),
        ]:
            b = QPushButton(txt); b.setFixedWidth(32); b.setToolTip(tip)
            b.clicked.connect(slot); mid_col.addWidget(b)
        mid_col.addStretch()
        lists_lay.addLayout(mid_col)

        right_col = QVBoxLayout()
        lbl_sel = QLabel(
            "Para diseño  [doble-clic = quitar]  "
            "  <b>Int</b> = Interior  <b>Ext</b> = Exterior")
        lbl_sel.setStyleSheet("font-size:7pt; color:#607D8B;")
        right_col.addWidget(lbl_sel)
        self.tbl_sel = QTableWidget(0, 3)
        self.tbl_sel.setHorizontalHeaderLabels(["Grupo / Muro", "Int.", "Ext."])
        self.tbl_sel.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tbl_sel.horizontalHeader().setSectionResizeMode(1, QHeaderView.Fixed)
        self.tbl_sel.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.tbl_sel.setColumnWidth(1, 36)
        self.tbl_sel.setColumnWidth(2, 36)
        self.tbl_sel.setFont(QFont("Consolas", 7))
        self.tbl_sel.setFixedHeight(130)
        self.tbl_sel.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_sel.doubleClicked.connect(self._on_grp_remove)
        right_col.addWidget(self.tbl_sel)
        lists_lay.addLayout(right_col, 2)

        ggrp.addLayout(lists_lay)
        vlay.addWidget(grp_groups)

        # ── Acciones ──────────────────────────────────────────────────────
        grp_actions = QGroupBox("Acciones")
        alay = QGridLayout(grp_actions)
        alay.setSpacing(5)

        self.btn_run = QPushButton("▶   Calcular")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.clicked.connect(self._start_calculation)
        alay.addWidget(self.btn_run, 0, 0, 1, 2)

        btn_word = QPushButton("Resultados + Gráficas  (Word)")
        btn_word.setObjectName("btn_word")
        btn_word.clicked.connect(self._export_word)
        alay.addWidget(btn_word, 1, 0)

        btn_mem = QPushButton("Memoria de Cálculo  (Word)")
        btn_mem.setObjectName("btn_memory")
        btn_mem.clicked.connect(self._export_calc_memory)
        alay.addWidget(btn_mem, 1, 1)

        btn_plots = QPushButton("Guardar Gráficas  (PNG)")
        btn_plots.setObjectName("btn_plots")
        btn_plots.clicked.connect(self._save_plots)
        alay.addWidget(btn_plots, 2, 0)

        btn_clear = QPushButton("Limpiar")
        btn_clear.setObjectName("btn_clear")
        btn_clear.clicked.connect(self._clear_all)
        alay.addWidget(btn_clear, 2, 1)

        vlay.addWidget(grp_actions)
        vlay.addStretch()

        scroll.setWidget(panel)
        return scroll

    def _build_right_tabs(self) -> QTabWidget:
        self.tabs = QTabWidget()

        # Tab 0: Resultados
        self.tab_results = QWidget()
        self.tabs.addTab(self.tab_results, "  Resultados  ")
        self._init_tab_results()

        # Tab 1: Resumen
        self.tab_summary = QWidget()
        self.tabs.addTab(self.tab_summary, "  Resumen  ")
        self._init_tab_summary()

        # Tab 2: Cort. Res. Ent.
        self.tab_shear = QWidget()
        self.tabs.addTab(self.tab_shear, "  Cort. Res. Ent.  ")
        self._init_tab_shear()

        # Tab 3: Gráficas
        self.tab_plots = QWidget()
        self.tabs.addTab(self.tab_plots, "  Gráficas  ")
        self._init_tab_plots()

        # Tab 4: Log de proceso
        self.tab_log_widget = QWidget()
        self.tabs.addTab(self.tab_log_widget, "  Log  ")
        self._init_tab_log()

        self.tabs.setCurrentIndex(0)
        return self.tabs

    # ── Pestañas ──────────────────────────────────────────────────────────────

    def _wall_selector_row(self, parent_lay: QHBoxLayout, combo_attr: str,
                           extra_btn_text: str = "", extra_slot=None):
        """Crea la barra de selección de muro + botón exportar opcional."""
        parent_lay.addWidget(QLabel("Muro:"))
        cb = QComboBox()
        cb.setFixedWidth(120)
        setattr(self, combo_attr, cb)
        parent_lay.addWidget(cb)
        parent_lay.addStretch()
        if extra_btn_text:
            btn = QPushButton(extra_btn_text)
            btn.setObjectName("btn_word")
            if extra_slot:
                btn.clicked.connect(extra_slot)
            parent_lay.addWidget(btn)

    def _init_tab_results(self):
        vlay = QVBoxLayout(self.tab_results)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        self._wall_selector_row(
            bar, "cb_res_wall",
            "Exportar Word", self._export_results_word)
        self.cb_res_wall.currentTextChanged.connect(
            lambda name: self._populate_results(name))
        vlay.addLayout(bar)

        self.res_log = ColoredLog()
        vlay.addWidget(self.res_log, 1)

    def _init_tab_summary(self):
        vlay = QVBoxLayout(self.tab_summary)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "Combinaciones críticas por nivel  "
            "(compresión · tensión · cortante · Mu · refuerzo)")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_summary_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.cb_sum_wall = QComboBox()
        self.cb_sum_wall.setFixedWidth(120)
        self.cb_sum_wall.currentTextChanged.connect(
            lambda name: self._populate_summary(name))
        # small row
        row = QHBoxLayout()
        row.addWidget(QLabel("Muro:"))
        row.addWidget(self.cb_sum_wall)
        row.addStretch()
        vlay.addLayout(row)

        self.sum_log = ColoredLog()
        vlay.addWidget(self.sum_log, 1)

    def _init_tab_shear(self):
        vlay = QVBoxLayout(self.tab_shear)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_shear_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.shear_log = ColoredLog()
        vlay.addWidget(self.shear_log, 1)

    def _init_tab_plots(self):
        vlay = QVBoxLayout(self.tab_plots)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Muro:"))
        self.cb_plot_wall = QComboBox()
        self.cb_plot_wall.setFixedWidth(110)
        self.cb_plot_wall.currentTextChanged.connect(self._on_plot_wall_change)
        ctrl.addWidget(self.cb_plot_wall)

        ctrl.addWidget(QLabel("Nivel:"))
        self.cb_plot_nivel = QComboBox()
        self.cb_plot_nivel.setFixedWidth(100)
        ctrl.addWidget(self.cb_plot_nivel)

        ctrl.addWidget(QLabel("Gráfica:"))
        self.cb_plot_type = QComboBox()
        self.cb_plot_type.addItems([
            "Interacción 2D", "Interacción 3D",
            "Envolvente Momentos", "Envolvente Cortantes"])
        self.cb_plot_type.setFixedWidth(180)
        ctrl.addWidget(self.cb_plot_type)

        btn_show = QPushButton("Mostrar")
        btn_show.clicked.connect(self._show_plot)
        ctrl.addWidget(btn_show)
        ctrl.addStretch()

        vlay.addLayout(ctrl)

        self.plot_container = QWidget()
        self.plot_layout    = QVBoxLayout(self.plot_container)
        self.plot_layout.setContentsMargins(0, 0, 0, 0)
        placeholder = QLabel("Ejecute el cálculo y seleccione muro + tipo de gráfica.")
        placeholder.setAlignment(Qt.AlignCenter)
        placeholder.setStyleSheet("color:#607D8B; font-size:11pt;")
        self.plot_layout.addWidget(placeholder)
        self.plot_placeholder = placeholder
        vlay.addWidget(self.plot_container, 1)

    # ── Tab Configuración ─────────────────────────────────────────────────────

    def _init_tab_log(self):
        vlay = QVBoxLayout(self.tab_log_widget)
        vlay.setContentsMargins(4, 4, 4, 4)
        lbl = QLabel("Proceso de cálculo y diagnóstico de conexión STAAD Pro")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        vlay.addWidget(lbl)
        self.log_widget = ColoredLog(wrap=True)
        vlay.addWidget(self.log_widget, 1)

    # ── Helpers para tablas de configuración ─────────────────────────────────

    def _toggle_material_tables(self):
        self.grp_mamp_tbl.setVisible(self.chk_mamp.isChecked())
        self.grp_conc_tbl.setVisible(self.chk_conc.isChecked())

    def _add_nivel_row(self):
        row = self.tbl_niveles.rowCount()
        self.tbl_niveles.insertRow(row)
        self.tbl_niveles.setItem(row, 0, QTableWidgetItem(f"N{row+1}"))
        self.tbl_niveles.setItem(row, 1, QTableWidgetItem("0.00"))

    def _add_mamp_row(self):
        row = self.tbl_mamp.rowCount()
        self.tbl_mamp.insertRow(row)
        # Col 0: nombre (editable)
        self.tbl_mamp.setItem(row, 0, QTableWidgetItem("MAMP1"))
        # Col 1: descripción
        self.tbl_mamp.setItem(row, 1, QTableWidgetItem("Tipo I"))
        # Col 2: Tipo de Muro (combo)
        cb_tm = QComboBox()
        cb_tm.addItems(["2 - Confinada (Cap.6)", "1 - Reforzada Interior (Cap.7)"])
        self.tbl_mamp.setCellWidget(row, 2, cb_tm)
        # Col 3: Tipo de Pieza (combo)
        cb_tp = QComboBox()
        cb_tp.addItems(["1 - Multiperforada", "2 - Sólida", "3 - Maciza", "4 - Hueca"])
        self.tbl_mamp.setCellWidget(row, 3, cb_tp)
        # Cols 4-11: valores numéricos con defaults NTC
        defaults = ["7.0", "35.0", "1.0", "2.0", "200.0", "4200.0", "4200.0", "20.0"]
        for c, v in enumerate(defaults, start=4):
            self.tbl_mamp.setItem(row, c, QTableWidgetItem(v))

    def _add_conc_row(self):
        row = self.tbl_conc.rowCount()
        self.tbl_conc.insertRow(row)
        defaults = ["CONC1", "250.0", "4200.0", "4200.0", "2.4"]
        for c, v in enumerate(defaults):
            self.tbl_conc.setItem(row, c, QTableWidgetItem(v))

    def _add_cortante_row(self):
        row = self.tbl_cortantes.rowCount()
        self.tbl_cortantes.insertRow(row)
        self.tbl_cortantes.setItem(row, 0, QTableWidgetItem(f"Nivel-{row+1}"))
        self.tbl_cortantes.setItem(row, 1, QTableWidgetItem("0.0"))
        self.tbl_cortantes.setItem(row, 2, QTableWidgetItem("0.0"))

    @staticmethod
    def _del_tbl_row(tbl: QTableWidget):
        rows = sorted(set(idx.row() for idx in tbl.selectedIndexes()), reverse=True)
        for r in rows:
            tbl.removeRow(r)
        if tbl.rowCount() == 0:
            pass   # tabla vacía, OK

    # ── Helpers para tabla de grupos (tbl_sel) ────────────────────────────────

    @staticmethod
    def _center_widget(w: QWidget) -> QWidget:
        c = QWidget()
        hl = QHBoxLayout(c)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setAlignment(Qt.AlignCenter)
        hl.addWidget(w)
        return c

    def _get_chk_from_cell(self, row: int, col: int) -> Optional[QCheckBox]:
        container = self.tbl_sel.cellWidget(row, col)
        if container:
            return container.findChild(QCheckBox)
        return None

    def _add_group_to_sel(self, label: str):
        """Agrega un grupo a tbl_sel con checkboxes Interior (default) / Exterior."""
        row = self.tbl_sel.rowCount()
        self.tbl_sel.insertRow(row)

        item = QTableWidgetItem(label)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        self.tbl_sel.setItem(row, 0, item)

        chk_int = QCheckBox()
        chk_int.setChecked(True)
        chk_ext = QCheckBox()
        chk_ext.setChecked(False)

        # Comportamiento mutuamente excluyente
        chk_int.toggled.connect(
            lambda checked, ce=chk_ext: ce.setChecked(False) if checked else None)
        chk_ext.toggled.connect(
            lambda checked, ci=chk_int: ci.setChecked(False) if checked else None)

        self.tbl_sel.setCellWidget(row, 1, self._center_widget(chk_int))
        self.tbl_sel.setCellWidget(row, 2, self._center_widget(chk_ext))

    # ── Helpers de lectura de tablas ─────────────────────────────────────────

    @staticmethod
    def _tbl_text(tbl: QTableWidget, row: int, col: int) -> str:
        item = tbl.item(row, col)
        return item.text().strip() if item else ""

    @staticmethod
    def _tbl_float(tbl: QTableWidget, row: int, col: int,
                   default: float = 0.0) -> float:
        try:
            return float(tbl.item(row, col).text().strip())
        except (AttributeError, ValueError, TypeError):
            return default

    def _build_user_inputs_from_ui(self) -> object:
        """Construye un UserInputs completo a partir de los widgets de la UI."""
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        from wall_models import UserInputs, MaterialProps

        inp = UserInputs()

        # Combinaciones de carga
        inp.pp_cm_cvacc_combo   = self.spn_pp_combo.value()
        inp.first_service_combo = self.spn_svc_start.value()
        inp.last_service_combo  = self.spn_svc_end.value()
        inp.first_design_combo  = self.spn_des_start.value()
        inp.last_design_combo   = self.spn_des_end.value()
        inp.n_service_combos = max(0, inp.last_service_combo - inp.first_service_combo + 1)
        inp.n_design_combos  = max(0, inp.last_design_combo  - inp.first_design_combo  + 1)

        # Ductilidad
        inp.Q_duct = self.spn_ductility.value()

        # Niveles (elevaciones ordenadas de mayor a menor)
        levels = []
        for row in range(self.tbl_niveles.rowCount()):
            txt = self._tbl_text(self.tbl_niveles, row, 1)
            try:
                levels.append(float(txt))
            except ValueError:
                pass
        inp.floor_levels = sorted(set(levels), reverse=True) if levels else []

        # Materiales — Mampostería
        inp.materials = []
        if self.chk_mamp.isChecked():
            for row in range(self.tbl_mamp.rowCount()):
                name = self._tbl_text(self.tbl_mamp, row, 0)
                if not name:
                    continue
                descripcion = self._tbl_text(self.tbl_mamp, row, 1)

                cb_tm = self.tbl_mamp.cellWidget(row, 2)
                # índice 0 → tipo_muro=2 (confinada), índice 1 → tipo_muro=1 (reforzada)
                tipo_muro = 1 if (cb_tm and cb_tm.currentIndex() == 1) else 2

                cb_tp = self.tbl_mamp.cellWidget(row, 3)
                tipo_pieza = (cb_tp.currentIndex() + 1) if cb_tp else 1

                vm      = self._tbl_float(self.tbl_mamp, row, 4, 7.0)
                fm      = self._tbl_float(self.tbl_mamp, row, 5, 35.0)
                fan     = self._tbl_float(self.tbl_mamp, row, 6, 1.0)
                pvol    = self._tbl_float(self.tbl_mamp, row, 7, 2.0)
                fc_cast = self._tbl_float(self.tbl_mamp, row, 8, 200.0)
                fy_cast = self._tbl_float(self.tbl_mamp, row, 9, 4200.0)
                fy_hor  = self._tbl_float(self.tbl_mamp, row, 10, 4200.0)
                h_pza   = self._tbl_float(self.tbl_mamp, row, 11, 20.0)

                m = MaterialProps(
                    name=name, descripcion=descripcion,
                    tipo_material=1, tipo_muro=tipo_muro, tipo_pieza=tipo_pieza,
                    vm=vm, fm=fm, fan=fan, peso_vol=pvol,
                    fc_castillos=fc_cast, fc=fc_cast,
                    fy_vert=fy_cast, fy_hor=fy_hor,
                    h_pieza=h_pza,
                )
                inp.materials.append(m)

        # Materiales — Concreto
        if self.chk_conc.isChecked():
            for row in range(self.tbl_conc.rowCount()):
                name = self._tbl_text(self.tbl_conc, row, 0)
                if not name:
                    continue
                m = MaterialProps(
                    name=name, tipo_material=2, tipo_muro=2, tipo_pieza=0,
                    fc=self._tbl_float(self.tbl_conc, row, 1, 250.0),
                    fc_castillos=self._tbl_float(self.tbl_conc, row, 1, 250.0),
                    fy_vert=self._tbl_float(self.tbl_conc, row, 2, 4200.0),
                    fy_hor=self._tbl_float(self.tbl_conc, row, 3, 4200.0),
                    peso_vol=self._tbl_float(self.tbl_conc, row, 4, 2.4),
                )
                inp.materials.append(m)

        # Cortantes de entrepiso
        inp.story_shears = {}
        for row in range(self.tbl_cortantes.rowCount()):
            niv = self._tbl_text(self.tbl_cortantes, row, 0)
            if niv:
                vx = self._tbl_float(self.tbl_cortantes, row, 1, 0.0)
                vz = self._tbl_float(self.tbl_cortantes, row, 2, 0.0)
                inp.story_shears[niv] = {"Vx": vx, "Vz": vz}

        # Posiciones de muros desde tbl_sel (Interior=2, Exterior=1)
        for row in range(self.tbl_sel.rowCount()):
            item = self.tbl_sel.item(row, 0)
            if not item:
                continue
            gname = self._name_from_label(item.text())
            chk_int = self._get_chk_from_cell(row, 1)
            inp.wall_positions[gname] = 2 if (chk_int and chk_int.isChecked()) else 1

        return inp

    # ── Navegación / Slots de UI ──────────────────────────────────────────────

    def _browse_excel(self):
        # Mantenido por compatibilidad (ya no se usa en la UI)
        pass

    # ── Diagnóstico OpenSTAAD API ─────────────────────────────────────────────
    def _on_diagnostics(self):
        """Muestra todos los métodos de los tres objetos OpenSTAAD."""
        if not self._staad_connected:
            QMessageBox.warning(self, "Sin conexión",
                                "Conecte a STAAD Pro primero.")
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from openstaad_connector import OpenSTAADConnector
            conn = OpenSTAADConnector()
            conn.connect(self._ver_pref)
            geo_m  = conn.get_geo_methods()
            out_m  = conn.list_output_methods()
            prop_m = conn.list_prop_methods()
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))
            return

        dlg = QWidget(self, Qt.Window)
        dlg.setWindowTitle("Diagnóstico — Métodos OpenSTAAD API")
        dlg.resize(680, 580)
        vl = QVBoxLayout(dlg)

        tabs = QTabWidget()
        # Destacar métodos clave ya confirmados
        confirmed = {"GetPlateThickness", "GetElementMaterialName",
                     "GetGroupNames", "GetGroupEntities",
                     "GetPlateIncidence"}

        for label, methods in [
            ("OSGeometry", geo_m),
            ("OSOutput",   out_m),
            ("OSProperty", prop_m),
        ]:
            w = QWidget()
            wl = QVBoxLayout(w)
            # filtro
            flt_box = QHBoxLayout()
            flt_box.addWidget(QLabel("Filtrar:"))
            flt_edit = QLineEdit()
            flt_box.addWidget(flt_edit)
            wl.addLayout(flt_box)
            # lista
            lst = QListWidget()
            lst.setFont(QFont("Consolas", 9))
            for m in methods:
                lst.addItem(m)
            wl.addWidget(lst)

            def _make_filter(le, lw, ml):
                def _f(txt):
                    lw.clear()
                    for mm in ml:
                        if txt.lower() in mm.lower():
                            lw.addItem(mm)
                return _f
            flt_edit.textChanged.connect(_make_filter(flt_edit, lst, methods))

            count_lbl = QLabel(f"{len(methods)} métodos")
            count_lbl.setStyleSheet("color:#607D8B; font-size:8pt;")
            wl.addWidget(count_lbl)
            tabs.addTab(w, f"  {label} ({len(methods)})  ")

        vl.addWidget(tabs)

        # Botón copiar todo
        def _copy_all():
            lines = []
            for label, methods in [("OSGeometry", geo_m),
                                    ("OSOutput", out_m),
                                    ("OSProperty", prop_m)]:
                lines.append(f"=== {label} ===")
                lines.extend(methods)
                lines.append("")
            dlg.clipboard().setText("\n".join(lines))
            QMessageBox.information(dlg, "Copiado",
                                    "Métodos copiados al portapapeles.")

        btn_copy = QPushButton("Copiar todo al portapapeles")
        btn_copy.clicked.connect(_copy_all)
        vl.addWidget(btn_copy)
        dlg.show()

    # ── Conexión STAAD Pro ────────────────────────────────────────────────────
    def _on_staad_connect(self):
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from openstaad_connector import OpenSTAADConnector
            self.btn_connect.setEnabled(False)
            self.lbl_conn_st.setText("● Conectando...")
            self.lbl_conn_st.setStyleSheet("color:#E67E22; font-weight:bold;")

            conn = OpenSTAADConnector()
            ver = conn.connect(self._ver_pref)

            self._staad_connected = True
            self.lbl_conn_st.setText(f"● Conectado")
            self.lbl_conn_st.setStyleSheet("color:#27AE60; font-weight:bold;")

            self._all_groups = conn.get_all_group_names()
            n_plates = conn.get_plate_count()
            res_avail = conn.results_available()

            n_plc = sum(1 for _, t in self._all_groups if t == 3)
            self.lbl_conn_info.setText(
                f"{ver}  |  Grupos totales: {len(self._all_groups)}  "
                f"[Placa: {n_plc}]  |  Placas: {n_plates}  "
                f"|  Resultados: {'✔' if res_avail else '✗'}"
            )

            self._refresh_group_list()

            if not res_avail:
                QMessageBox.warning(
                    self, "Sin resultados",
                    "Conexión establecida, pero el modelo no tiene resultados.\n\n"
                    "Ejecute el análisis en STAAD Pro antes de calcular.\n"
                    "Los esfuerzos serán cero si continúa sin resultados.")
            else:
                self.status.showMessage(
                    f"  Conectado a STAAD Pro  |  {n_plc} grupos de placa  "
                    f"|  {n_plates} placas")
        except Exception as exc:
            self._staad_connected = False
            self.lbl_conn_st.setText("● Error")
            self.lbl_conn_st.setStyleSheet("color:#C0392B; font-weight:bold;")
            QMessageBox.critical(self, "Error de conexión",
                                 f"{exc}\n\n"
                                 "Ejecute como Administrador y verifique que "
                                 "STAAD Pro esté abierto con un modelo cargado.")
        finally:
            self.btn_connect.setEnabled(True)

    # ── Manejo de listas de grupos ────────────────────────────────────────────
    @staticmethod
    def _group_label(name: str, gtype: int) -> str:
        tag = {1:"[NOD]", 2:"[MBR]", 3:"[PLC]", 4:"[SOL]"}.get(gtype, "[?]")
        return f"{tag}  {name}"

    @staticmethod
    def _name_from_label(label: str) -> str:
        return label.split("]  ", 1)[1] if "]  " in label else label

    def _refresh_group_list(self):
        flt         = self.edit_grp_filter.text().upper()
        only_plates = self.chk_only_plates.isChecked()
        # Grupos ya en la tabla de diseño
        sel_labels = {
            self.tbl_sel.item(r, 0).text()
            for r in range(self.tbl_sel.rowCount())
            if self.tbl_sel.item(r, 0)
        }

        self.lst_avail.clear()
        for name, gtype in self._all_groups:
            if only_plates and gtype != 3:
                continue
            if flt and flt not in name.upper():
                continue
            label = self._group_label(name, gtype)
            if label in sel_labels:
                continue
            self.lst_avail.addItem(label)

    def _on_group_filter(self):
        self._refresh_group_list()

    def _on_grp_add(self):
        for item in self.lst_avail.selectedItems():
            self._add_group_to_sel(item.text())
            self.lst_avail.takeItem(self.lst_avail.row(item))

    def _on_grp_remove(self):
        rows = sorted(
            set(idx.row() for idx in self.tbl_sel.selectedIndexes()),
            reverse=True)
        for row in rows:
            item = self.tbl_sel.item(row, 0)
            if item:
                self.lst_avail.addItem(item.text())
            self.tbl_sel.removeRow(row)

    def _on_grp_add_all(self):
        while self.lst_avail.count() > 0:
            lbl = self.lst_avail.item(0).text()
            self._add_group_to_sel(lbl)
            self.lst_avail.takeItem(0)

    def _on_grp_remove_all(self):
        for row in range(self.tbl_sel.rowCount()):
            item = self.tbl_sel.item(row, 0)
            if item:
                self.lst_avail.addItem(item.text())
        self.tbl_sel.setRowCount(0)

    def _preview_excel(self):
        # Ya no se usa — los parámetros se ingresan directamente en la UI
        pass

    # ── Cálculo ───────────────────────────────────────────────────────────────

    def _start_calculation(self):
        if not self._staad_connected:
            QMessageBox.critical(self, "Sin conexión",
                                 "Conecte a STAAD Pro 2025 antes de calcular.")
            return
        if self.tbl_sel.rowCount() == 0:
            QMessageBox.critical(self, "Sin grupos",
                                 "Seleccione al menos un grupo de placas para diseñar.")
            return

        # ── Validar parámetros de la UI ──────────────────────────────────────
        try:
            ui_inputs = self._build_user_inputs_from_ui()
        except Exception as exc:
            QMessageBox.critical(self, "Error en parámetros", str(exc))
            return

        if not ui_inputs.floor_levels or len(ui_inputs.floor_levels) < 2:
            QMessageBox.critical(
                self, "Niveles insuficientes",
                "Ingrese al menos 2 elevaciones en la tabla 'Sección Niveles'.\n"
                "(Nivel de desplante + al menos un nivel superior)")
            return
        if not ui_inputs.materials:
            QMessageBox.critical(
                self, "Sin materiales",
                "Ingrese al menos un material en 'Sección Materiales'.")
            return

        # ── Load cases desde los spinboxes ────────────────────────────────────
        first = ui_inputs.first_design_combo
        last  = ui_inputs.last_design_combo
        pp    = ui_inputs.pp_cm_cvacc_combo
        svc_f = ui_inputs.first_service_combo
        svc_l = ui_inputs.last_service_combo
        load_cases = sorted(set(
            list(range(first, last + 1)) +
            list(range(svc_f, svc_l + 1)) +
            [pp]
        ))

        # ── Resolver grupos → IDs de placas ───────────────────────────────────
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)

        group_plates:   dict = {}
        wall_plate_ids: dict = {}

        try:
            from openstaad_connector import OpenSTAADConnector
            conn_tmp = OpenSTAADConnector()
            conn_tmp.connect(self._ver_pref)

            for row in range(self.tbl_sel.rowCount()):
                item = self.tbl_sel.item(row, 0)
                if not item:
                    continue
                gname = self._name_from_label(item.text())
                pids  = conn_tmp.get_plates_in_group(gname, 3)
                group_plates[gname]   = pids
                wall_plate_ids[gname] = pids
                # La posición ya está en ui_inputs.wall_positions

        except Exception as exc:
            QMessageBox.critical(self, "Error obteniendo placas de grupos", str(exc))
            return

        if not any(group_plates.values()):
            QMessageBox.critical(
                self, "Sin placas",
                "Los grupos seleccionados no contienen placas en STAAD Pro.\n\n"
                "Verifique que los grupos sean de tipo Placa (Shell).")
            return

        self.btn_run.setEnabled(False)
        self.btn_connect.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.log_widget.clear_log()
        self.status.showMessage("  Capturando geometría de placas (hilo principal)…")
        self.tabs.setCurrentWidget(self.tab_log_widget)

        self._on_log("Capturando geometría en hilo principal...", "sec")
        all_pids_geo = [p for pids in group_plates.values() for p in pids]
        all_pids_geo = list(dict.fromkeys(all_pids_geo))

        pre_inc: dict = {}
        pre_crd: dict = {}

        try:
            inc_map, crd_map = conn_tmp.fetch_geometry_main_thread(
                all_pids_geo,
                callback=lambda i, t, d: (
                    self.progress.setValue(int(i / max(t, 1) * 30)),
                    self.status.showMessage(f"  {d}"),
                ) and None,
            )
            pre_inc = inc_map
            pre_crd = crd_map
            geo_ok  = sum(1 for v in pre_inc.values() if v)
            tag = "ok" if geo_ok == len(all_pids_geo) else "warn"
            self._on_log(
                f"  Geometría: {geo_ok}/{len(all_pids_geo)} placas con nodos, "
                f"{len(pre_crd)} nodos únicos con coordenadas.", tag)
        except Exception as exc:
            self._on_log(f"  [AVISO] Geometría parcial: {exc}", "warn")

        # ── Fase 1: FetchWorker ────────────────────────────────────────────────
        self._wall_plate_ids_pending = wall_plate_ids
        self._user_inputs_pending    = ui_inputs        # UserInputs desde la UI
        self.status.showMessage("  Extrayendo esfuerzos de STAAD Pro…")

        self._fetcher = FetchWorker(
            self._ver_pref, group_plates, load_cases, SOURCE_DIR,
            pre_incidences=pre_inc,
            pre_coordinates=pre_crd,
            parent=self,
        )
        self._fetcher.sig_log.connect(self._on_log)
        self._fetcher.sig_progress.connect(self._on_progress)
        self._fetcher.sig_done.connect(self._on_fetch_done)
        self._fetcher.sig_error.connect(self._on_error)
        self._fetcher.start()

    def _on_fetch_done(self, cache):
        """Fase 2: lanza el DesignWorker con los datos pre-extraídos."""
        self.status.showMessage("  Calculando diseño…")
        self._worker = DesignWorker(
            self._user_inputs_pending,   # UserInputs desde la UI
            cache,
            self._wall_plate_ids_pending,
            SOURCE_DIR,
            self,
        )
        self._worker.sig_log.connect(self._on_log)
        self._worker.sig_progress.connect(self._on_progress)
        self._worker.sig_done.connect(self._on_done)
        self._worker.sig_error.connect(self._on_error)
        self._worker.finished.connect(self._on_worker_finished)
        self._worker.start()

    def _on_worker_finished(self):
        self.btn_run.setEnabled(True)
        self.btn_connect.setEnabled(True)

    def _on_log(self, text: str, tag: str):
        self.log_widget.putln(text, tag)

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self.status.showMessage(f"  {msg}")

    def _on_done(self, result: dict):
        self._walls    = result["walls"]
        self._results  = result["results"]
        self._diagrams = result["diagrams"]
        self._inputs   = result["inputs"]

        self.progress.setVisible(False)
        ts = datetime.now().strftime("%H:%M:%S")
        n  = len(self._walls)
        self.status.showMessage(
            f"  ✔  Diseño completado  ·  {n} muro(s)  ·  {ts}")
        self.log_widget.putln("\n✔  Cálculo completado exitosamente.", "ok")
        self.tabs.setCurrentWidget(self.tab_results)

        wall_names = [w.name for w in self._walls]

        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.blockSignals(True)
            cb.clear()
            cb.addItems(wall_names)
            cb.blockSignals(False)

        if wall_names:
            for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
                cb.setCurrentIndex(0)
            first = wall_names[0]
            self._populate_results(first)
            self._populate_summary(first)
            self._on_plot_wall_change(first)

        self._populate_shear()

    def _on_error(self, msg: str):
        self.progress.setVisible(False)
        self.status.showMessage("  ✗  Error en el cálculo.")
        self.log_widget.putln("\n✗  Error durante el cálculo:", "err")
        last = [l for l in msg.strip().splitlines() if l.strip()]
        if last:
            self.log_widget.putln(f"  {last[-1]}", "err")
        self.log_widget.putln("\nDetalle:", "dim")
        self.log_widget.putln(msg, "dim")

    # ── Poblar pestañas ───────────────────────────────────────────────────────

    def _populate_results(self, wall_name: str):
        self.res_log.clear_log()
        if not wall_name:
            return
        wall   = next((w for w in self._walls if w.name == wall_name), None)
        inputs = self._inputs
        if not wall or not inputs:
            return
        reltan       = inputs.wall_reltan.get(wall_name, {"reltan1": 0.0, "reltan2": 0.0})
        position_str = "Exterior" if wall.position == 1 else "Interior"
        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat = lv.material if lv.material is not None else wall.material
            if isinstance(res_list[0].__class__.__name__, str):
                pass  # won't happen
            try:
                from wall_models import DesignResultMasonry
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_masonry_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
                else:
                    self._write_concrete_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
            except ImportError:
                pass
        self.res_log.scroll_top()

    def _populate_summary(self, wall_name: str):
        self.sum_log.clear_log()
        if not wall_name:
            return
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            from wall_models import DesignResultMasonry
        except ImportError:
            return

        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat   = lv.material if lv.material is not None else wall.material
            tipo_str = "Mampostería" if (lv_mat and lv_mat.tipo_material == 1) else "Concreto"
            SEP = "=" * 120
            self.sum_log.putln(f"\n{SEP}", "hdr")
            self.sum_log.putln(
                f"  NIVEL: {lv.nivel_name}    Hi={lv.hi:.2f} m    "
                f"Lm={lv.lm:.2f} m    [{tipo_str}]    Muro: {wall.name}", "sec")
            self.sum_log.putln(f"{SEP}", "hdr")
            crit = get_critical_combos(res_list)
            if crit:
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_critical_block_masonry(self.sum_log, crit)
                else:
                    self._write_critical_block_concrete(self.sum_log, crit)
        self.sum_log.scroll_top()

    def _populate_shear(self):
        self.shear_log.clear_log()
        if not self._walls or not self._inputs:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_shear_check import compute_shear_resistente
            shear_data = compute_shear_resistente(
                self._walls, self._results, self._inputs)
            self._shear_data = shear_data
            self._render_shear(shear_data)
        except Exception:
            self.shear_log.putln(
                f"Error al calcular cortante:\n{traceback.format_exc()}", "err")

    def _render_shear(self, shear_data: dict):
        W = self.shear_log
        SEP = "=" * 155
        sep = "-" * 155
        _c = ["Muro","Material","t(m)","Lm(m)","A(m2)",
              "sCalc","3.33vm","si","0.5vm","0.3si","n*rh*fy",
              "Vr(t)","Rel.","Vres(t)"]
        _w = [10,12,6,7,7,8,8,8,7,7,9,8,6,9]
        HDR = "  " + " ".join(c.rjust(w) for c, w in zip(_c, _w))

        for direction in ('X', 'Z'):
            level_list = shear_data.get(direction, [])
            if not level_list:
                W.putln(f"\n  Dirección {direction}: sin muros contribuyentes.", "dim")
                continue
            W.putln(f"\n{SEP}", "hdr")
            W.putln(f"  DIRECCIÓN {direction}  —  Cortante Resistente por Entrepiso",
                    "sec")
            W.putln(f"  NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso", "dim")
            W.putln(f"{SEP}", "hdr")
            for lev in level_list:
                W.putln(
                    f"\n  NIVEL: {lev['nivel_name']}    "
                    f"V_entrepiso {direction} = {lev['story_shear']:.2f} ton", "sec")
                W.putln(f"{HDR}", "hdr")
                W.putln(f"{'─'*155}", "dim")
                for w in lev['walls']:
                    if w['tipo'] == 'Mamposteria':
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{w['sigcalc']:>8.4f} {w['sigma_lim']:>8.4f} "
                            f"{w['sigma_i']:>8.4f} "
                            f"{w['vm05']:>7.4f} {w['sig03']:>7.4f} "
                            f"{w['nph_fyh']:>9.4f} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                    else:
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{'—':>8} {'—':>8} {'—':>8} "
                            f"{'—':>7} {'—':>7} {'—':>9} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                W.putln(f"{'─'*155}", "dim")
                cumple   = lev['cumple']
                cond_str = "✓  CUMPLE" if cumple else "✗  NO CUMPLE"
                cond_tag = "ok" if cumple else "fail"
                W.put(
                    f"  {'Σ Vres':>20} = {lev['sum_vres']:>8.2f} ton    "
                    f"V_ent = {lev['story_shear']:>8.2f} ton    "
                    f"Ratio = {lev['ratio']:>6.3f}    "
                )
                W.putln(cond_str, cond_tag)
                W.putln(f"{sep}", "dim")

    # ── Resultados por nivel ──────────────────────────────────────────────────

    def _build_crit_map(self, res_list: list) -> dict:
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
        except ImportError:
            return {}
        if not crit:
            return {}
        crit_map: dict = {}
        for key, tag in [
            ("max_refs","crit_refs"), ("max_refv","crit_refv"),
            ("max_refc","crit_refc"), ("max_mu","crit_mu"),
            ("max_shear","crit_shear"), ("max_tens","crit_tens"),
            ("max_comp","crit_comp"),
        ]:
            r = crit.get(key)
            if r is not None:
                crit_map[r.combo] = tag
        return crit_map

    def _write_masonry_level(self, W: ColoredLog, wall, lv, res_list,
                             mat, position_str, reltan):
        r0 = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Ht_t = lv.hi / lv.thickness if lv.thickness > 0 else 0.0
        fiel1 = reltan.get("reltan1", 0.0)
        fiel2 = reltan.get("reltan2", 0.0)
        SEP = "=" * 165
        sep = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Mampostería   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Fiel: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   Hcr={lv.hi:.2f} m   "
            f"H/t={Ht_t:.2f}   H/L={HL:.4f}   "
            f"Asmin(Cast.)={r0.AsminCast:.2f} cm²   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        W.putln(
            f"  v'm={mat.vm:.2f} kg/cm²   f'm={mat.fm:.2f} kg/cm²   "
            f"f'c(Cast.)={mat.fc_castillos:.2f} kg/cm²   "
            f"fy(Vert.)={mat.fy_vert:.0f} kg/cm²   "
            f"fy(Hor.)={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            f"{'FrFlC':>6} {'Pres(t)':>9} {'AscCal':>7} {'C.P':>9} "
            f"{'Asc(cm2)':>9} {'Pt(t)':>8} {'Vres(t)':>8} "
            f"{'k0':>5} {'k1':>5} {'ns':>5} {'nEfic':>6} "
            f"{'AshH':>7} {'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            cp_fg = "ok" if r.cond_axial    in ("Si Pasa","Tension") else "fail"
            cv_fg = "ok" if r.cond_cortante == "Si Pasa"             else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                f"{r.Frflcomp:>6.2f} {r.Pr:>9.2f} {r.Asc1_calc:>7.2f} ",
                bg=bg)
            W.put(f"{r.cond_axial:>9} ", cp_fg, bg)
            W.put(
                f"{r.Asc1:>9.2f} {r.Pt_svc:>8.2f} {r.Vr:>8.2f} "
                f"{r.k0:>5.2f} {r.k11:>5.2f} {r.ns:>5.2f} {r.n:>6.2f} "
                f"{r.Ash:>7.2f} {r.Vras:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.putln(f"{r.cond_cortante:>9}", cv_fg, bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_masonry(W, crit)
        except ImportError:
            pass

    def _write_concrete_level(self, W: ColoredLog, wall, lv, res_list,
                              mat, position_str, reltan):
        r0   = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Lt   = lv.lm / lv.thickness if lv.thickness > 0 else 0.0
        L3   = lv.lm / 3.0
        fiel1= reltan.get("reltan1", 0.0)
        fiel2= reltan.get("reltan2", 0.0)
        SEP  = "=" * 165
        sep  = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Concreto   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Rel.: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   H/L={HL:.4f}   L/t={Lt:.2f}   "
            f"L/3={L3:.2f} m   Asmin(Ver.)={r0.Asvmin:.2f} cm²/m   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        W.putln(
            f"  Hi={lv.hi:.2f} m   An.Sec.Ext.={r0.SeccTC:.2f} m   "
            f"Vmax={r0.Vmax:.2f} ton   "
            f"f'c={mat.fc:.2f} kg/cm²   "
            f"fyVert.={mat.fy_vert:.0f} kg/cm²   "
            f"fyHor.={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            f"{'Pres(t)':>9} {'RefVCent':>9} {'C.P':>9} "
            f"{'AsExt1':>9} {'SecTC(m)':>9} "
            f"{'Vcr(t)':>8} {'Sep3(cm)':>9} {'Sep4(cm)':>9} "
            f"{'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            cp_fg = "ok" if r.cond_axial    in ("Si Pasa","Tension") else "fail"
            cv_fg = "ok" if r.cond_cortante == "Si Pasa"             else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                f"{r.Pres:>9.2f} {r.Asv:>9.2f} ",
                bg=bg)
            W.put(f"{r.cond_axial:>9} ", cp_fg, bg)
            W.put(
                f"{r.AsExt1:>9.2f} {r.SeccTC:>9.2f} "
                f"{r.Vcr:>8.2f} {r.Sep1:>9.2f} {r.Sep2:>9.2f} "
                f"{r.Vs:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.putln(f"{r.cond_cortante:>9}", cv_fg, bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_concrete(W, crit)
        except ImportError:
            pass

    def _write_critical_block_masonry(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   Asc1={r.Asc1:>7.2f} cm²   "
              f"Ash={r.Ash:>6.2f} cm²/m   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_axial}]", cp)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   Asc1={r.Asc1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        r = crit['max_mu']
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   Asc1={r.Asc1:>7.2f} cm²")
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Ash={r.Ash:>6.2f} cm²/m   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        if getattr(r, "prop_n", 0) > 0:
            W.putln(f"  {'Propuesta Ref. Hor.':<20}: {r.prop_n} × varillín "
                    f"Ø{r.prop_diam}\" @ {r.prop_sep:.0f} cm   "
                    f"Ash prov={r.prop_Ash:>6.2f} cm²/m   "
                    f"peso≈{r.prop_peso:.2f} kg/m²", "ok")
        W.putln(f"{sep}", "dim")

    def _write_critical_block_concrete(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r  = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   Asv={r.Asv:>7.2f} cm²/m   "
              f"VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_axial}]", cp)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   AsExt1={r.AsExt1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        r = crit['max_mu']
        req_ext = r.AsExt1 > r.Asvmin * r.SeccTC * 1.01
        mu_tag  = "warn" if req_ext else "dim"
        ext_str = (f"AsExt1={r.AsExt1:.2f} cm²"
                   if req_ext else "No se req. ref. de borde adicional")
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   SeccTC={r.SeccTC:.3f} m   "
                f"{ext_str}", mu_tag)
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vs={r.Vs:>7.2f} ton   ph={r.ph:.5f}   "
              f"Sep #3={r.Sep1:>6.1f} cm   Sep #4={r.Sep2:>6.1f} cm   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        W.putln(f"{sep}", "dim")

    # ── Gráficas ──────────────────────────────────────────────────────────────

    def _on_plot_wall_change(self, wall_name: str = ""):
        if not wall_name:
            wall_name = self.cb_plot_wall.currentText()
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if wall:
            niveles = [lv.nivel_name for lv in wall.levels]
            self.cb_plot_nivel.blockSignals(True)
            self.cb_plot_nivel.clear()
            self.cb_plot_nivel.addItems(niveles)
            self.cb_plot_nivel.blockSignals(False)
            if niveles:
                self.cb_plot_nivel.setCurrentIndex(0)

    def _show_plot(self):
        wall_name  = self.cb_plot_wall.currentText()
        nivel      = self.cb_plot_nivel.currentText()
        plot_type  = self.cb_plot_type.currentText()

        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            QMessageBox.warning(self, "Aviso", "Seleccione un muro válido.")
            return

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)

        try:
            from wall_design_plots import (
                plot_interaction_masonry, plot_interaction_concrete,
                plot_interaction_concrete_3d,
                plot_moment_envelope, plot_shear_envelope,
            )
            mat       = wall.material
            tipo      = mat.tipo_material if mat else 1
            results_w = self._results.get(wall_name, {})
            diag_w    = self._diagrams.get(wall_name, {})

            if plot_type in ("Interacción 2D", "Interacción 3D"):
                diag_pts = diag_w.get(nivel, [])
                res_list = results_w.get(nivel, [])
                demand   = [(r.Pu, r.Mu) for r in res_list]
                if plot_type == "Interacción 3D":
                    if tipo == 1:
                        # 3D no disponible para mamposteria — mostrar 2D
                        fig = plot_interaction_masonry(diag_pts, demand, nivel, wall_name)
                    else:
                        lv_obj = next(
                            (lv for lv in wall.levels if lv.nivel_name == nivel), None
                        )
                        demand_3d = [
                            (r.Pu, r.Mu,
                             lv_obj.resultantes_by_combo.get(r.combo, {}).get("Mfp", 0.0)
                             if lv_obj else 0.0)
                            for r in res_list
                        ]
                        AsExt1_v = max((r.AsExt1 for r in res_list), default=0.0) if mat else 5.0
                        Asv_v    = max((r.Asv    for r in res_list), default=0.0) if mat else 0.0
                        fig = plot_interaction_concrete_3d(
                            diag_pts, demand_3d, nivel, wall_name,
                            fc=mat.fc if mat else 250.0,
                            fy=mat.fy_vert if mat else 4200.0,
                            Lm=lv_obj.lm if lv_obj else 3.0,
                            t=lv_obj.thickness if lv_obj else 0.20,
                            AsExt1=AsExt1_v, RefVCent=Asv_v,
                        )
                else:
                    fig = (plot_interaction_masonry(diag_pts, demand, nivel, wall_name)
                           if tipo == 1
                           else plot_interaction_concrete(diag_pts, demand, nivel, wall_name))
            elif plot_type == "Envolvente Momentos":
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_moment_envelope(
                    wall.levels, results_w, floor_levels, wall_name)
            else:
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_shear_envelope(
                    wall.levels, results_w, floor_levels, wall_name)

            self._embed_figure(fig)

        except Exception:
            self._on_log(f"Error al generar gráfica:\n{traceback.format_exc()}", "err")

    def _embed_figure(self, fig):
        # Limpiar contenedor
        if self._plot_canvas:
            self._plot_canvas.setParent(None)
            self._plot_canvas = None
        if self._plot_toolbar:
            self._plot_toolbar.setParent(None)
            self._plot_toolbar = None
        if self.plot_placeholder:
            self.plot_placeholder.setParent(None)
            self.plot_placeholder = None

        while self.plot_layout.count():
            item = self.plot_layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)

        canvas  = FigureCanvas(fig)
        toolbar = NavToolbar(canvas, self.plot_container)
        self.plot_layout.addWidget(toolbar)
        self.plot_layout.addWidget(canvas)
        canvas.draw()
        self._plot_canvas  = canvas
        self._plot_toolbar = toolbar

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _require_results(self) -> bool:
        if not self._walls:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return False
        return True

    def _export_word(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione la carpeta de salida")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            fname = os.path.join(
                output_dir,
                f"Diseno_Muros_{datetime.now():%Y%m%d_%H%M}.docx")
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall=self._plot_paths,
                output_path=fname, design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Word exportado: {os.path.basename(fname)}")
            QMessageBox.information(
                self, "Listo", f"Documento exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error exportando Word", str(exc))

    def _export_results_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resultados Word", "",
            "Word Documents (*.docx)",
            options=QFileDialog.DontConfirmOverwrite)
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall={}, output_path=fname,
                design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_summary_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resumen Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_summary_word
            export_summary_word(
                walls=self._walls, results_by_wall=self._results,
                output_path=fname)
            self.status.showMessage(f"  Resumen exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_shear_word(self):
        if not self._require_results() or not self._shear_data:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Cortante Resistente Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_shear_check_word
            export_shear_check_word(
                self._shear_data, self._inputs, fname)
            self.status.showMessage(f"  Cortante exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_calc_memory(self):
        if not self._require_results():
            return
        if self._mem_worker and self._mem_worker.isRunning():
            QMessageBox.warning(self, "En proceso",
                                "Ya se está generando una memoria de cálculo.")
            return

        # ── Diálogo de opciones ───────────────────────────────────────────────
        n_walls  = len(self._walls)
        n_levels = sum(len(w.levels) for w in self._walls)
        dlg = QDialog(self)
        dlg.setWindowTitle("Opciones — Memoria de Cálculo")
        dlg.setFixedWidth(430)
        dl = QVBoxLayout(dlg)

        dl.addWidget(QLabel(
            f"<b>Muros: {n_walls}  |  Niveles totales: {n_levels}</b>"))
        dl.addWidget(QLabel(
            "Incluir diagramas de interacción en la memoria Word.\n"
            "Cada diagrama agrega ~2-5 s al tiempo de exportación."))

        chk_2d = QCheckBox("Incluir diagramas de interacción 2D (recomendado)")
        chk_3d = QCheckBox("Incluir diagramas de interacción 3D")
        chk_2d.setChecked(True)
        chk_3d.setChecked(False)
        dl.addWidget(chk_2d)
        dl.addWidget(chk_3d)

        lbl_est = QLabel()
        lbl_est.setStyleSheet("color:#E67E22; font-size:7pt;")

        def _update_est():
            secs = n_levels * ((3 if chk_2d.isChecked() else 0) +
                               (5 if chk_3d.isChecked() else 0) + 1)
            lbl_est.setText(
                f"Tiempo estimado: ~{secs} s  "
                f"({'sin' if not chk_2d.isChecked() and not chk_3d.isChecked() else 'con'} "
                f"generación de figuras)")

        chk_2d.toggled.connect(lambda _: _update_est())
        chk_3d.toggled.connect(lambda _: _update_est())
        _update_est()
        dl.addWidget(lbl_est)

        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dlg.accept)
        btn_box.rejected.connect(dlg.reject)
        dl.addWidget(btn_box)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        include_2d = chk_2d.isChecked()
        include_3d = chk_3d.isChecked()

        # ── Selección de archivo ──────────────────────────────────────────────
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Memoria de Cálculo Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)

        # ── Iniciar hilo de exportación ───────────────────────────────────────
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.status.showMessage("  Generando memoria de cálculo…")
        self.log_widget.putln(
            f"\nGenerando memoria de cálculo: {os.path.basename(fname)}", "sec")
        if include_2d or include_3d:
            self.log_widget.putln(
                f"  Diagramas: {'2D ' if include_2d else ''}{'3D' if include_3d else ''}  "
                f"— puede tardar varios minutos.", "dim")
        self.tabs.setCurrentWidget(self.tab_log_widget)

        self._mem_worker = CalcMemoryWorker(
            walls=self._walls,
            results_by_wall=self._results,
            inputs=self._inputs,
            output_path=fname,
            diagrams_by_wall=self._diagrams,
            include_2d=include_2d,
            include_3d=include_3d,
            source_dir=sd,
            parent=self,
        )
        self._mem_worker.sig_progress.connect(self._on_mem_progress)
        self._mem_worker.sig_done.connect(self._on_mem_done)
        self._mem_worker.sig_error.connect(self._on_mem_error)
        self._mem_worker.start()

    def _on_mem_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self.status.showMessage(f"  Memoria: {msg}")

    def _on_mem_done(self, path: str):
        self.progress.setVisible(False)
        self.status.showMessage(f"  Memoria exportada: {os.path.basename(path)}")
        self.log_widget.putln(f"  ✔ Memoria exportada: {path}", "ok")
        QMessageBox.information(self, "Listo", f"Memoria exportada:\n{path}")

    def _on_mem_error(self, msg: str):
        self.progress.setVisible(False)
        self.status.showMessage("  ✗ Error generando memoria.")
        last = [l for l in msg.strip().splitlines() if l.strip()]
        self.log_widget.putln(
            f"\n✗ Error en memoria de cálculo:\n"
            f"  {last[-1] if last else msg}", "err")
        self.log_widget.putln("\nDetalle:", "dim")
        self.log_widget.putln(msg, "dim")
        QMessageBox.critical(self, "Error generando memoria",
                             f"{last[-1] if last else msg}\n\n"
                             "(Ver pestaña Log para el detalle completo)")

    def _save_plots(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione carpeta para gráficas")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_plots import save_all_plots
            for wall in self._walls:
                paths = save_all_plots(
                    wall=wall,
                    results_by_level=self._results.get(wall.name, {}),
                    output_dir=output_dir,
                    diagram_points_by_level=self._diagrams.get(wall.name, {}),
                )
                self._plot_paths[wall.name] = paths
                self._on_log(
                    f"  {wall.name}: {len(paths)} gráficas guardadas.", "ok")
            self.status.showMessage(f"  Gráficas guardadas en: {output_dir}")
            QMessageBox.information(
                self, "Listo", f"Gráficas guardadas en:\n{output_dir}")
        except Exception as exc:
            QMessageBox.critical(self, "Error guardando gráficas", str(exc))

    # ── Limpiar ───────────────────────────────────────────────────────────────

    def _clear_all(self):
        self._walls    = []
        self._results  = {}
        self._diagrams = {}
        self._inputs   = None
        self._shear_data  = {}
        self._plot_paths  = {}
        for w in (self.res_log, self.sum_log, self.shear_log, self.log_widget):
            w.clear_log()
        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.clear()
        self.progress.setVisible(False)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")
        self.tabs.setCurrentIndex(0)

    # ── Cierre ────────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        running = (
            (self._fetcher and self._fetcher.isRunning()) or
            (self._worker  and self._worker.isRunning())
        )
        if running:
            resp = QMessageBox.question(
                self, "Proceso en ejecución",
                "Hay un proceso en ejecución. ¿Desea cancelar y salir?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                event.ignore()
                return
            for w in (self._fetcher, self._worker):
                if w and w.isRunning():
                    w.terminate()
                    w.wait()
        event.accept()
