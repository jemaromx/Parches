# -*- coding: utf-8 -*-
"""
Directorios iniciales estándar para los cuadros de diálogo de la suite.

Regla (aplica a TODOS los módulos):
  • Guardar (memorias, DXF, resultados, proyectos…): el diálogo abre en la
    carpeta del modelo de STAAD Pro conectado; si no hay modelo, en C:\\.
  • Abrir (cualquier archivo o carpeta): siempre abre en C:\\.

Se implementa envolviendo los métodos estáticos de QFileDialog una sola vez
por proceso (instalar_dialogos_suite), de modo que las ~50 llamadas
existentes en la suite obedecen la regla sin modificarlas una por una.
La ruta del modelo se descubre inspeccionando la ventana principal del
diálogo: cualquier atributo (o valor de dict de atributos, o texto de
QLabel/QLineEdit) que sea una ruta existente a un archivo .std.
"""
from __future__ import annotations

import os

RAIZ_ABRIR = "C:\\"

_instalado = False


# ─────────────────────────────────────────────────────────────────────────────
# Descubrir la ruta del modelo STAAD conectado
# ─────────────────────────────────────────────────────────────────────────────

def _dir_de_std(valor) -> str | None:
    if isinstance(valor, str) and valor.lower().endswith(".std") \
            and os.path.isfile(valor):
        return os.path.dirname(valor) or None
    return None


def ruta_modelo_staad(widget) -> str | None:
    """Carpeta del .std conectado de la ventana de `widget`, o None."""
    try:
        from PySide6.QtWidgets import QApplication, QLabel, QLineEdit
        win = widget.window() if widget is not None else None
        if win is None:
            win = QApplication.activeWindow()
        if win is None:
            return None

        # 1) Atributos de la ventana (y dicts como _params)
        for v in vars(win).values():
            r = _dir_de_std(v)
            if r:
                return r
            if isinstance(v, dict):
                for vv in v.values():
                    r = _dir_de_std(vv)
                    if r:
                        return r
            # objetos conectores con atributos de ruta
            for attr in ("std_path", "staad_file", "model_path", "ruta_std"):
                r = _dir_de_std(getattr(v, attr, None))
                if r:
                    return r

        # 2) Etiquetas/campos que muestran la ruta en la UI
        for cls in (QLineEdit, QLabel):
            for w in win.findChildren(cls):
                r = _dir_de_std(w.text().strip())
                if r:
                    return r
    except Exception:                               # noqa: BLE001
        pass
    return None


def _dir_guardar(parent) -> str:
    return ruta_modelo_staad(parent) or RAIZ_ABRIR


def _componer_guardar(parent, dir_arg: str) -> str:
    """Directorio del modelo + el nombre sugerido de la llamada original."""
    base = _dir_guardar(parent)
    nombre = os.path.basename(str(dir_arg)) if dir_arg else ""
    return os.path.join(base, nombre) if nombre else base


# ─────────────────────────────────────────────────────────────────────────────
# Instalación (una vez por proceso)
# ─────────────────────────────────────────────────────────────────────────────

def instalar_dialogos_suite() -> None:
    global _instalado
    if _instalado:
        return
    from PySide6.QtWidgets import QFileDialog

    _save   = QFileDialog.getSaveFileName
    _open   = QFileDialog.getOpenFileName
    _opens  = QFileDialog.getOpenFileNames
    _dirsel = QFileDialog.getExistingDirectory

    def getSaveFileName(parent=None, caption="", dir="", filter="", *a, **k):
        return _save(parent, caption, _componer_guardar(parent, dir),
                     filter, *a, **k)

    def getOpenFileName(parent=None, caption="", dir="", filter="", *a, **k):
        return _open(parent, caption, RAIZ_ABRIR, filter, *a, **k)

    def getOpenFileNames(parent=None, caption="", dir="", filter="", *a, **k):
        return _opens(parent, caption, RAIZ_ABRIR, filter, *a, **k)

    def getExistingDirectory(parent=None, caption="", dir="", *a, **k):
        return _dirsel(parent, caption, RAIZ_ABRIR, *a, **k)

    QFileDialog.getSaveFileName      = staticmethod(getSaveFileName)
    QFileDialog.getOpenFileName      = staticmethod(getOpenFileName)
    QFileDialog.getOpenFileNames     = staticmethod(getOpenFileNames)
    QFileDialog.getExistingDirectory = staticmethod(getExistingDirectory)
    _instalado = True
