# -*- coding: utf-8 -*-
"""
Acomodo automático de etiquetas de resultados en archivos DXF.

Reemplaza el tratamiento manual que el usuario hacía en AutoCAD:
  • Asocia cada texto de resultado con su barra (LINE más cercana).
  • Escala el texto para que quepa a lo largo de la barra.
  • Lo centra sobre la barra:
      - Horizontal → encima de la barra, sin rotar.
      - Vertical   → al costado, rotado 90° (alineado con la barra).
      - Diagonal   → sobre la barra, rotado al ángulo de la barra.
  • Evita traslapes entre etiquetas (desplaza en la dirección del offset).
  • Mueve cada etiqueta a una capa según orientación para facilitar
    ajustes manuales posteriores:
      RESULT_HOR  (cyan)  · RESULT_VER (verde) · RESULT_DIAG (magenta)
      RESULT_FALLA (rojo) — barras que fallan o exceden acero permisible.

Soporta dibujos 2D (planta) y 3D (columnas verticales en Z).
"""
from __future__ import annotations

import math
import logging

log = logging.getLogger(__name__)

# Capas y colores ACI
LAYER_HOR   = "RESULT_HOR"
LAYER_VER   = "RESULT_VER"
LAYER_DIAG  = "RESULT_DIAG"
LAYER_FALLA = "RESULT_FALLA"

_LAYER_COLORS = {
    LAYER_HOR:   4,   # cyan
    LAYER_VER:   3,   # verde
    LAYER_DIAG:  6,   # magenta
    LAYER_FALLA: 1,   # rojo
}

# Tolerancia angular para clasificar horizontal/vertical (grados)
_ANG_TOL = 15.0
# Ancho medio estimado de un carácter en función de la altura del texto
_CHAR_W = 0.75


def hidden_layers(doc) -> set[str]:
    """
    Nombres de las capas APAGADAS o CONGELADAS del documento.

    Se usa para ignorar textos de elementos que el usuario tiene ocultos
    (p.ej. numeración de nodos): aunque no se vean, siguen en el DXF y
    sin este filtro se detectaría su numeración y se duplicarían valores.
    """
    ocultas: set[str] = set()
    for layer in doc.layers:
        try:
            apagada = layer.is_off() if callable(
                getattr(layer, "is_off", None)) else layer.dxf.color < 0
            congelada = layer.is_frozen() if callable(
                getattr(layer, "is_frozen", None)) else bool(
                layer.dxf.flags & 1)
            if apagada or congelada:
                ocultas.add(layer.dxf.name)
        except Exception:
            continue
    return ocultas


def _ensure_layers(doc) -> None:
    for name, color in _LAYER_COLORS.items():
        if name not in doc.layers:
            doc.layers.new(name, dxfattribs={"color": color})


def _line_info(entity):
    """(midpoint(x,y,z), length3d, dx, dy, dz) de una LINE."""
    p1, p2 = entity.dxf.start, entity.dxf.end
    mid = ((p1.x + p2.x) / 2.0, (p1.y + p2.y) / 2.0, (p1.z + p2.z) / 2.0)
    dx, dy, dz = p2.x - p1.x, p2.y - p1.y, p2.z - p1.z
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    return mid, length, dx, dy, dz


def _text_insert(entity):
    """Punto de inserción (x, y, z) de un TEXT o MTEXT."""
    if entity.dxftype() == "TEXT":
        p = entity.dxf.insert
    else:
        p = entity.dxf.insert
    return (p.x, p.y, getattr(p, "z", 0.0))


def _classify(dx: float, dy: float, dz: float, length: float) -> str:
    """'hor' | 'ver' | 'diag' según la dirección de la barra."""
    if length <= 0:
        return "hor"
    # Barra vertical en Z (modelos 3D de columnas)
    if abs(dz) > 0.7 * length:
        return "ver"
    ang = math.degrees(math.atan2(abs(dy), abs(dx)))   # 0..90 en el plano XY
    if ang <= _ANG_TOL:
        return "hor"
    if ang >= 90.0 - _ANG_TOL:
        return "ver"
    return "diag"


def _plain_text(entity) -> str:
    if entity.dxftype() == "TEXT":
        return entity.dxf.text or ""
    try:
        return entity.plain_mtext()
    except Exception:
        return entity.text or ""


def _boxes_overlap(a, b) -> bool:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    return not (ax1 < bx0 or bx1 < ax0 or ay1 < by0 or by1 < ay0)


def arrange_labels(doc, labeled, offset_factor: float = 0.9,
                   max_h_ratio: float = 0.08,
                   fixed_height: float | None = 0.30) -> int:
    """
    Acomoda las etiquetas de resultados.

    Parámetros
    ----------
    doc      : documento ezdxf (ya con los textos de resultados escritos)
    labeled  : lista de tuplas (entity, is_failing) donde entity es el
               TEXT/MTEXT del resultado e is_failing indica si la barra
               falla o excede el acero permisible.
    offset_factor : separación de la etiqueta respecto a la barra, en
               múltiplos de la altura del texto.
    max_h_ratio   : altura máxima del texto como fracción de la longitud
               de la barra.
    fixed_height  : altura fija para todos los textos (default 0.30).
               None → altura adaptativa: se calcula la altura que cabe en
               cada barra (según su longitud) y se aplica a TODOS los
               textos la MENOR resultante, de modo que queden uniformes
               y ninguno rebase su barra.

    Retorna el número de etiquetas acomodadas.
    """
    _ensure_layers(doc)
    msp = doc.modelspace()

    lines = []
    for ln in msp.query("LINE"):
        try:
            lines.append(_line_info(ln))
        except Exception:
            continue
    if not lines:
        return 0

    def _nearest(tx, ty, tz):
        return min(
            lines,
            key=lambda li: (li[0][0] - tx) ** 2
                         + (li[0][1] - ty) ** 2
                         + (li[0][2] - tz) ** 2,
        )

    def _h_fit(entity, length: float) -> float:
        """Altura que hace caber el texto a lo largo de su barra."""
        nchar = max(4, len(_plain_text(entity)))
        L_eff = max(length, 1e-6)
        return max(min(0.85 * L_eff / (nchar * _CHAR_W),
                       max_h_ratio * L_eff), 1e-4)

    # Altura adaptativa uniforme: pasada previa sobre todas las etiquetas
    # para tomar la MENOR altura que cabe en su barra respectiva.
    h_uniform: float | None = None
    if fixed_height is None:
        alturas = []
        for entity, _f in labeled:
            try:
                tx, ty, tz = _text_insert(entity)
                _mid, length, *_ = _nearest(tx, ty, tz)
                alturas.append(_h_fit(entity, length))
            except Exception:
                continue
        if alturas:
            h_uniform = min(alturas)

    placed_boxes: list[tuple] = []
    n = 0

    for entity, is_failing in labeled:
        try:
            tx, ty, tz = _text_insert(entity)

            # 1. Barra más cercana (por punto medio, en 3D)
            best = _nearest(tx, ty, tz)
            (mx, my, mz), length, dx, dy, dz = best

            orient = _classify(dx, dy, dz, length)
            text   = _plain_text(entity)
            nchar  = max(4, len(text))

            # 2. Altura del texto:
            #    - fixed_height: todos los textos con esa altura fija.
            #    - None: altura adaptativa uniforme = la menor que cabe
            #      en su barra entre todas las etiquetas (h_uniform).
            if fixed_height is not None:
                height = float(fixed_height)
            else:
                height = h_uniform if h_uniform else _h_fit(entity, length)

            # 3. Posición y rotación según orientación
            off = offset_factor * height
            if orient == "hor":
                pos, rot = (mx, my + off, mz), 0.0
                shift_dir = (0.0, 1.0)          # anti-traslape: hacia arriba
            elif orient == "ver":
                pos, rot = (mx + off, my, mz), 90.0
                shift_dir = (1.0, 0.0)          # hacia la derecha
            else:
                ang = math.degrees(math.atan2(dy, dx))
                # Mantener legible (evitar texto de cabeza)
                if ang > 90.0:
                    ang -= 180.0
                elif ang < -90.0:
                    ang += 180.0
                rad  = math.radians(ang)
                nxv, nyv = -math.sin(rad), math.cos(rad)   # normal "arriba"
                pos = (mx + nxv * off, my + nyv * off, mz)
                rot = ang
                shift_dir = (nxv, nyv)

            # 4. Anti-traslape: caja aproximada (AABB del texto rotado)
            w = nchar * _CHAR_W * height
            for _try in range(6):
                rad = math.radians(rot)
                bw = abs(w * math.cos(rad)) + abs(height * math.sin(rad))
                bh = abs(w * math.sin(rad)) + abs(height * math.cos(rad))
                box = (pos[0] - bw / 2, pos[1] - bh / 2,
                       pos[0] + bw / 2, pos[1] + bh / 2)
                if not any(_boxes_overlap(box, b) for b in placed_boxes):
                    break
                pos = (pos[0] + shift_dir[0] * height * 1.3,
                       pos[1] + shift_dir[1] * height * 1.3,
                       pos[2])
            placed_boxes.append(box)

            # 5. Aplicar geometría
            if entity.dxftype() == "TEXT":
                entity.dxf.height   = height
                entity.dxf.rotation = rot
                try:
                    from ezdxf.enums import TextEntityAlignment
                    entity.set_placement(
                        pos, align=TextEntityAlignment.MIDDLE_CENTER)
                except Exception:
                    entity.dxf.insert = pos
            else:   # MTEXT
                entity.dxf.char_height = height
                entity.dxf.rotation    = rot
                entity.dxf.insert      = pos
                try:
                    entity.dxf.attachment_point = 5   # MIDDLE_CENTER
                except Exception:
                    pass

            # 6. Capa por orientación / falla, color BYLAYER
            layer = (LAYER_FALLA if is_failing else
                     {"hor": LAYER_HOR, "ver": LAYER_VER,
                      "diag": LAYER_DIAG}[orient])
            entity.dxf.layer = layer
            entity.dxf.color = 256   # BYLAYER

            n += 1
        except Exception as exc:
            log.debug("Etiqueta omitida en acomodo automático: %s", exc)

    return n
