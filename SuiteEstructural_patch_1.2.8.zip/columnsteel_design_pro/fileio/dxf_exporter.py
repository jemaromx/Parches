# fileio/dxf_exporter.py
"""
Exportación de ratios de interacción a DXF — Column Steel Design Pro.
Mismo formato que beamsteel_design_pro:

  • modify_existing_dxf : toma el DXF del usuario (columnas como LINEs con
    etiqueta de número de miembro), reduce las líneas desde el punto medio y
    sustituye las etiquetas por "id / ratio (combo)". El acomodo automático
    coloca los textos (altura 0.3) junto a cada columna y los manda a capa
    ROJA cuando el ratio excede la unidad.
  • export_dxf_single   : genera un DXF nuevo con una línea vertical por
    columna y sus ratios.
"""
from __future__ import annotations

import math
import re
from typing import List

try:
    import ezdxf
    from ezdxf.math import Vec3
    DXF_OK = True
except ImportError:
    DXF_OK = False


def _gov_ratio(r) -> tuple[float, str]:
    """(ratio gobernante, etiqueta de combinación) de un MemberDesignResult."""
    best = 0.0
    lbl = ""
    for c in (r.combos or []):
        for val in (c.H_ratio, getattr(c, "H_ext", 0.0), c.V_ratio):
            if val > best:
                best = val
                lbl = c.lc_label or str(c.lc_id)
    return best, lbl


# ══════════════════════════════════════════════════════════════════════════════
# DXF nuevo (columnas verticales)
# ══════════════════════════════════════════════════════════════════════════════

def export_dxf_single(path: str, results: List,
                      reduction_pct: float = 20.0) -> bool:
    if not DXF_OK:
        return False
    try:
        doc = ezdxf.new("R2010")
        msp = doc.modelspace()
        doc.layers.new("COLUMNAS", dxfattribs={"color": 3})
        doc.layers.new("TEXTO",    dxfattribs={"color": 7})
        doc.layers.new("FALLADAS", dxfattribs={"color": 1})

        factor = (100.0 - reduction_pct) / 100.0
        SCALE  = 10.0
        x_off  = 0.0
        for r in results:
            h_raw = max(r.length_m, 1.0) * SCALE
            mid_y = h_raw / 2.0
            half  = (h_raw * factor) / 2.0
            msp.add_line((x_off, mid_y - half), (x_off, mid_y + half),
                         dxfattribs={"layer": "COLUMNAS", "lineweight": 50})

            ratio, gov = _gov_ratio(r)
            layer = "FALLADAS" if ratio > 1.0 else "TEXTO"
            msp.add_text(
                f"{r.member_id} / {ratio:.3f}" + (f"  ({gov})" if gov else ""),
                dxfattribs={"height": 0.30, "layer": layer,
                            "rotation": 90.0,
                            "insert": (x_off + 0.5, mid_y)})
            msp.add_text(
                f"{r.profile}",
                dxfattribs={"height": 0.30, "layer": "TEXTO",
                            "insert": (x_off - 0.4, -1.0)})
            x_off += 6.0

        doc.saveas(path)
        return True
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Modificación de DXF existente (igual que beamsteel)
# ══════════════════════════════════════════════════════════════════════════════

def modify_existing_dxf(dxf_path: str, results: List,
                        reduction_pct: float = 20.0) -> tuple[bool, str]:
    if not DXF_OK:
        return False, "ezdxf no instalado"
    try:
        doc = ezdxf.readfile(dxf_path)
    except Exception as ex:
        return False, str(ex)

    msp = doc.modelspace()

    if 0 < reduction_pct < 100:
        factor = (100.0 - reduction_pct) / 100.0
    else:
        factor = 1.0

    ratio_map: dict[int, float] = {}
    gov_map:   dict[int, str]   = {}
    for r in results:
        ratio, gov = _gov_ratio(r)
        ratio_map[r.member_id] = ratio
        gov_map[r.member_id]   = gov

    # 1. Reducir líneas desde el punto medio
    n_lines = 0
    for entity in msp.query("LINE"):
        p1  = Vec3(entity.dxf.start)
        p2  = Vec3(entity.dxf.end)
        mid = (p1 + p2) / 2.0
        d   = (p2 - p1) * (factor / 2.0)
        entity.dxf.start = mid - d
        entity.dxf.end   = mid + d
        n_lines += 1

    # 2. Actualizar etiquetas — solo textos en capas prendidas (los de capas
    # apagadas/congeladas, p.ej. numeración de nodos oculta, se ignoran
    # para no duplicar valores)
    try:
        from suite_shared.dxf_text_layout import hidden_layers
        ocultas = hidden_layers(doc)
    except Exception:
        ocultas = set()

    n_texts = 0
    labeled = []
    for entity in msp.query("TEXT MTEXT"):
        if getattr(entity.dxf, "layer", "") in ocultas:
            continue
        try:
            raw = (entity.dxf.text
                   if hasattr(entity.dxf, "text") else entity.text)
        except Exception:
            continue
        mid_id = _parse_member_id(raw)
        if mid_id and mid_id in ratio_map:
            ratio   = ratio_map[mid_id]
            gov     = gov_map.get(mid_id, "")
            new_txt = (f"{mid_id} / {ratio:.3f}"
                       + (f"  ({gov})" if gov else ""))
            try:
                if hasattr(entity.dxf, "text"):
                    entity.dxf.text = new_txt
                else:
                    entity.text = new_txt
                n_texts += 1
                labeled.append((entity, ratio > 1.0))
            except Exception:
                pass

    # 3. Acomodo automático (altura 0.3, capas por orientación, rojo si falla)
    try:
        from suite_shared.dxf_text_layout import arrange_labels
        arrange_labels(doc, labeled)
    except Exception:
        pass

    out_path = dxf_path.replace(".dxf", "_mod.dxf")
    doc.saveas(out_path)
    return True, out_path


def _parse_member_id(text: str):
    m = re.match(r"\s*(\d+)", text.strip())
    return int(m.group(1)) if m else None
