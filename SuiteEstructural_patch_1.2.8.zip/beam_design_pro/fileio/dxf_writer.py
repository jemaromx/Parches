﻿"""
DXFWriter — BeamDesignPro
=========================
Modifica archivos DXF *existentes* (preparados por el usuario en AutoCAD)
con los resultados del diseño de trabes.

Flujo de trabajo:
  1. El usuario dibuja (o ya tiene) su planta en AutoCAD con líneas por barra.
  2. Coloca un texto con el número de barra STAAD junto a cada línea.
     Formatos aceptados:  "101"   o   "101 / 101"
  3. Ejecuta BeamDesignPro → "Actualizar DXF"
  4. El código:
       a. Abre cada DXF
       b. Reduce TODAS las LINEs desde su punto medio × factor
       c. Busca entidades TEXT/MTEXT que contengan el número de barra
       d. Reemplaza el texto con el resultado calculado
       e. Sobreescribe el DXF original

Formato de salida — Modo A (máximos de toda la barra):
  Flexión:  "101  sup:18.40  inf:14.60 cm²"
  Cortante: "101  Avs:0.0125 cm²/cm  Smax:22.5 cm"

Formato de salida — Modo B (inicio – mitad – fin):
  Flexión:  "101  sup:12.50-18.40-15.20  inf:10.20-14.60-11.80 cm²"
  Cortante: "101  Avs:0.010-0.013-0.011 cm²/cm"
"""
from __future__ import annotations

import re
import logging
from pathlib import Path

log = logging.getLogger(__name__)

try:
    import ezdxf
    from ezdxf.enums import TextEntityAlignment
    _EZDXF = True
except ImportError:
    _EZDXF = False


# Patrón: acepta "101" o "101 / 101" al inicio del texto
_RE_BID = re.compile(r'^(\d+)(?:\s*/\s*(\d+))?')


class DXFWriter:
    """
    Modifica DXFs existentes con resultados de diseño de trabes.

    Parameters
    ----------
    mode        'A' → máximos de toda la barra  |  'B' → inicio/mitad/fin
    reduc_pct   Porcentaje de longitud final de las líneas (0-100 %).
                Ej. 80 → las líneas quedan al 80 % de su longitud original.
    """

    def __init__(self, mode: str = "A", reduc_pct: float = 20.0):
        if not _EZDXF:
            raise RuntimeError("ezdxf no instalado.  Ejecute: pip install ezdxf")
        self.mode   = mode.upper()
        # reduc_pct = porcentaje de REDUCCIÓN (20 % → línea queda al 80 %)
        self.factor = max(0.01, 1.0 - reduc_pct / 100.0)

    # ── API pública ───────────────────────────────────────────────────────────

    def process_flex(self, dxf_path: str, beam_results: list) -> dict:
        """
        Actualiza el DXF con resultados de acero longitudinal (As).

        Returns dict con estadísticas: {"lineas": N, "textos": M, "errores": K}
        """
        return self._process(dxf_path, beam_results, "flex")

    def process_shear(self, dxf_path: str, beam_results: list) -> dict:
        """
        Actualiza el DXF con resultados de acero transversal (Avs).
        """
        return self._process(dxf_path, beam_results, "shear")

    # ── Procesamiento interno ─────────────────────────────────────────────────

    def _process(self, dxf_path: str, beam_results: list,
                 result_type: str) -> dict:
        path = Path(dxf_path)
        if not path.exists():
            raise FileNotFoundError(f"DXF no encontrado: {dxf_path}")

        try:
            doc = ezdxf.readfile(str(path))
        except Exception as exc:
            raise RuntimeError(f"Error al abrir '{path.name}': {exc}") from exc

        msp = doc.modelspace()

        # a) Reducir líneas
        n_lin = self._reduce_lines(msp)

        # b) Reemplazar textos
        br_map = {br.beam_id: br for br in beam_results}
        n_txt, n_err = self._replace_texts(msp, br_map, result_type)

        # c) Guardar (sobreescribe)
        try:
            doc.saveas(str(path))
        except Exception as exc:
            raise RuntimeError(f"Error al guardar '{path.name}': {exc}") from exc

        log.info("DXF '%s': %d líneas reducidas, %d textos actualizados, %d errores.",
                 path.name, n_lin, n_txt, n_err)
        return {"lineas": n_lin, "textos": n_txt, "errores": n_err}

    # ── Reducción de líneas ───────────────────────────────────────────────────

    def _reduce_lines(self, msp) -> int:
        """
        Reduce todas las entidades LINE desde su punto medio.
        Equivalente Python de reducirlineas_v3.lsp.
        """
        if abs(self.factor - 1.0) < 1e-6:
            return 0   # sin cambio
        count = 0
        for ent in msp.query("LINE"):
            try:
                p1 = ent.dxf.start
                p2 = ent.dxf.end
                mx = (p1.x + p2.x) / 2.0
                my = (p1.y + p2.y) / 2.0
                mz = (p1.z + p2.z) / 2.0
                f  = self.factor
                ent.dxf.start = (mx + (p1.x - mx) * f,
                                 my + (p1.y - my) * f,
                                 mz + (p1.z - mz) * f)
                ent.dxf.end   = (mx + (p2.x - mx) * f,
                                 my + (p2.y - my) * f,
                                 mz + (p2.z - mz) * f)
                count += 1
            except Exception as exc:
                log.debug("Línea omitida: %s", exc)
        return count

    # ── Reemplazo de textos ───────────────────────────────────────────────────

    def _replace_texts(self, msp, br_map: dict,
                       result_type: str) -> tuple[int, int]:
        """
        Busca TEXT/MTEXT con formato 'N / N' y reemplaza con el resultado.
        Returns (n_reemplazados, n_errores).
        """
        n_ok = n_err = 0
        labeled = []          # (entity, is_failing) para el acomodo automático

        # Solo textos en capas prendidas: los de capas apagadas/congeladas
        # (p.ej. numeración de nodos oculta) se ignoran para no duplicar
        # valores.
        try:
            from suite_shared.dxf_text_layout import hidden_layers
            ocultas = hidden_layers(msp.doc)
        except Exception:
            ocultas = set()

        for ent in msp.query("TEXT MTEXT"):
            if getattr(ent.dxf, "layer", "") in ocultas:
                continue
            try:
                raw = self._get_text(ent)
                bid = self._parse_bid(raw)
                if bid is None or bid not in br_map:
                    continue

                br    = br_map[bid]
                nuevo = self._format(br, bid, result_type)
                self._set_text(ent, nuevo)
                falla = any(not s.cumple for s in (br.envelope or []))
                labeled.append((ent, falla))
                n_ok += 1
            except Exception as exc:
                log.debug("Error actualizando texto: %s", exc)
                n_err += 1

        # Acomodo automático: escala, posición, rotación y capa por orientación
        try:
            from suite_shared.dxf_text_layout import arrange_labels
            # Altura adaptativa a la longitud de barra, uniforme: todos los
            # textos con la MENOR altura que cabe en su barra respectiva.
            arrange_labels(msp.doc, labeled, fixed_height=None)
        except Exception as exc:
            log.debug("Acomodo automático omitido: %s", exc)

        return n_ok, n_err

    # ── Helpers DXF ──────────────────────────────────────────────────────────

    @staticmethod
    def _get_text(ent) -> str:
        """Extrae el texto limpio de una entidad TEXT o MTEXT."""
        if ent.dxftype() == "TEXT":
            return (ent.dxf.text or "").strip()

        # MTEXT: intentar plain_mtext() (ezdxf >= 0.17, disponible en ezdxf >= 1.x)
        try:
            return ent.plain_mtext().strip()
        except (AttributeError, Exception):
            pass

        # Fallback manual: extraer contenido de bloques de formato MTEXT.
        # Un bloque típico es  {\fArial|b0|i0;CONTENIDO}  o  {\H0.2x;CONTENIDO}
        # El contenido está después del último ";" dentro del bloque.
        raw = ent.text or ""
        # 1. Extraer contenido de bloques { \ ... ; contenido }
        raw = re.sub(r'\{\\[^;{}]*;([^}]*)\}', r'\1', raw)
        # 2. Eliminar comandos sueltos tipo \H0.2x; \fArial; etc.
        raw = re.sub(r'\\[A-Za-z][^;]*;', '', raw)
        # 3. Párrafos y espacios especiales
        raw = re.sub(r'\\P', ' ', raw)
        raw = re.sub(r'\\~', ' ', raw)
        # 4. Cualquier llave sobrante
        raw = re.sub(r'[{}]', '', raw)
        return raw.strip()

    @staticmethod
    def _set_text(ent, text: str):
        if ent.dxftype() == "TEXT":
            # TEXT no soporta saltos de línea (\P); usamos " | " como separador visual
            ent.dxf.text = text.replace("\\P", "  |  ")
        else:
            # MTEXT soporta \P como salto de párrafo
            ent.text = text

    @staticmethod
    def _parse_bid(raw: str) -> int | None:
        """
        Extrae el ID de barra del texto.

        Acepta:
          "101"           → 101
          "101 / 101"     → 101
          "101  sup:..."  → 101   (texto ya actualizado — re-procesable)
        Rechaza:
          "101 / 102"     → None  (dos IDs distintos: no es un marcador válido)
        """
        m = _RE_BID.match(raw.strip())
        if not m:
            return None
        n1 = int(m.group(1))
        n2 = int(m.group(2)) if m.group(2) else n1
        return n1 if n1 == n2 else None

    # ── Formateo de resultados ────────────────────────────────────────────────

    def _format(self, br, bid: int, result_type: str) -> str:
        env = br.envelope
        if not env:
            return f"{bid}  (sin datos)"
        return (self._fmt_flex(br, bid) if result_type == "flex"
                else self._fmt_shear(br, bid))

    def _fmt_flex(self, br, bid: int) -> str:
        env = br.envelope
        if self.mode == "A":
            # Orden solicitado: ID  As(+)/As(-)  ->  inferior / superior
            sup = max(s.As_sup_tot for s in env)
            inf = max(s.As_inf_tot for s in env)
            return f"{bid}  {inf:.2f} / {sup:.2f} cm2"
        else:
            # 2 líneas en MTEXT: sup en línea 1, inf en línea 2
            sups = " - ".join(f"{s.As_sup_tot:.2f}" for s in env)
            infs = " - ".join(f"{s.As_inf_tot:.2f}" for s in env)
            return f"{bid}  {infs}\\P      {sups} cm2"

    def _fmt_shear(self, br, bid: int) -> str:
        env = br.envelope
        if self.mode == "A":
            avs = max(s.shear.Avs for s in env)
            return f"{bid}  {avs:.4f} cm2/cm"
        else:
            avs_vals  = " - ".join(f"{s.shear.Avs:.4f}"  for s in env)
            smax_vals = " - ".join(f"{s.shear.Smax:.1f}" for s in env)
            return f"{bid}  {avs_vals} cm2/cm\\P      S: {smax_vals} cm"
