﻿"""
Ventana principal — BeamDesignPro.

Arquitectura:
  ┌─────────────────────────────────────────────────────┐
  │  Header (logo + título + botones globales)          │
  ├──────────────────┬──────────────────────────────────┤
  │  InputPanel      │  ResultsWidget (tablas)          │
  │  (parámetros)    │                                  │
  ├──────────────────┴──────────────────────────────────┤
  │  StatusBar + ProgressBar                            │
  └─────────────────────────────────────────────────────┘

Flujo de diseño:
  1. InputPanel recopila parámetros
  2. main_window.py hace pre_fetch STAAD en hilo principal (COM thread-affinity)
  3. DesignWorker (QThread) ejecuta el diseño en segundo plano
  4. Resultados → ResultsWidget
"""
from __future__ import annotations

import logging
import os
from datetime import datetime

from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QSplitter,
    QLabel,
    QProgressBar,
    QStatusBar,
    QFrame,
    QMessageBox,
    QFileDialog,
    QApplication,
)
from PySide6.QtCore import Qt, QThread, Signal, QSize, Slot
from PySide6.QtGui import QFont, QIcon, QColor, QPalette, QAction

from config.settings import APP_NAME, APP_VERSION, COLORS
from gui.styles import MAIN_STYLE, HEADER_STYLE
from gui.input_panel import InputPanel
from gui.results_widget import ResultsWidget
from fileio.openstaad_reader import OpenSTAADReader
from design.beam_design import BeamDesigner

log = logging.getLogger(__name__)


# ── Worker de diseño ──────────────────────────────────────────────────────────

class DesignWorker(QThread):
    """
    Ejecuta el diseño de todas las trabes en un hilo secundario.

    IMPORTANTE: recibe sec_data y force_data como dicts Python puros
    (sin referencia al objeto COM de STAAD). Esto evita el error de
    acceso a objetos STA (Single-Thread Apartment) desde otro hilo,
    que provocaba el cierre del modelo en STAAD Pro.
    """

    sig_progress  = Signal(int, str)   # (porcentaje, mensaje)
    sig_finished  = Signal(list)        # lista de BeamResult
    sig_error     = Signal(str)

    def __init__(self, members: list, params: dict,
                 sec_data: dict, force_data: dict, parent=None):
        super().__init__(parent)
        self.members    = members
        self.params     = params
        self.sec_data   = sec_data    # {beam_id: {width, depth, length}}
        self.force_data = force_data  # {(beam_id, comb_id): [f_ini, f_mid, f_fin]}

    def run(self):
        _zero = {"Fx": 0.0, "Fy": 0.0, "Fz": 0.0,
                 "Mx": 0.0, "My": 0.0, "Mz": 0.0}
        _zero3 = [dict(_zero), dict(_zero), dict(_zero)]

        try:
            p = self.params
            designer = BeamDesigner(
                fc             = p["fc"],
                fy             = p["fy"],
                fy_s           = p["fy_s"],
                rec_flex       = p["rec_flex"],
                rec_comp       = p["rec_comp"],
                rec_lateral    = p.get("rec_lateral", 4.0),
                Qduct          = p["Q"],
                code_name      = p["codigo"],
                lamda          = p["lamda"],
                diseno_torsion = p["diseno_torsion"],
                frame_type     = p.get("frame_type", "OMF"),
            )

            comb_ids      = p["comb_ids"]
            comb_grav_CM  = p.get("comb_CM",   0)
            comb_grav_CMCV= p.get("comb_CMCV", 0)

            # IDs extra a incluir en forces_by_comb (combinaciones gravitacionales)
            grav_ids = [g for g in (comb_grav_CM, comb_grav_CMCV)
                        if g > 0 and g not in comb_ids]

            results  = []
            total    = len(self.members)

            for i, m in enumerate(self.members):
                bid   = m["id"]
                direc = m["dir"]

                # Geometría — solo datos Python (sin COM)
                sec  = self.sec_data.get(
                    bid, {"width": 0.30, "depth": 0.50, "length": 5.0})
                b_cm = m["b"] if m["b"] > 0 else round(sec["width"]  * 100, 1)
                h_cm = m["h"] if m["h"] > 0 else round(sec["depth"]  * 100, 1)
                L_m  = sec["length"]

                # Recubrimientos personalizados por barra
                designer.rec_flex = m.get("rec_flex", p["rec_flex"])
                designer.rec_comp = m.get("rec_comp", p["rec_comp"])

                # Fuerzas — diseño + gravitacionales para Vg (SMF)
                forces_by_comb = {
                    cid: self.force_data.get((bid, cid), list(_zero3))
                    for cid in list(comb_ids) + grav_ids
                }

                br = designer.design(
                    beam_id        = bid,
                    b              = b_cm,
                    h              = h_cm,
                    L              = L_m,
                    forces_by_comb = forces_by_comb,
                    comb_ids       = comb_ids,
                    direccion      = direc,
                    comb_grav_CM   = comb_grav_CM,
                    comb_grav_CMCV = comb_grav_CMCV,
                )
                results.append(br)

                pct = int((i + 1) / total * 100)
                self.sig_progress.emit(pct, f"Barra {bid}  ({i+1}/{total})")

            self.sig_finished.emit(results)

        except Exception as exc:
            log.exception("Error en DesignWorker")
            self.sig_error.emit(str(exc))


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._reader  = OpenSTAADReader()
        self._results : list  = []
        self._params  : dict  = {}
        self._members : list  = []   # trabes cargadas desde STAAD Pro
        self._worker  : DesignWorker | None = None

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1280, 780)
        # Tamaño mínimo: impide que el usuario comprima la ventana tanto
        # que el panel de controles quede oculto o recortado.
        self.setMinimumSize(860, 540)
        self.setStyleSheet(MAIN_STYLE)
        self._build_ui()
        self._connect_signals()

    # ── Construcción de la UI ─────────────────────────────────────────────────


        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "beam_design_pro")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        root.addWidget(self._build_header())

        # Splitter: InputPanel | ResultsWidget
        self.splitter = QSplitter(Qt.Horizontal)
        self.input_panel    = InputPanel()
        self.results_widget = ResultsWidget()
        self.splitter.addWidget(self.input_panel)
        self.splitter.addWidget(self.results_widget)
        self.splitter.setStretchFactor(0, 0)   # panel izq: no estira
        self.splitter.setStretchFactor(1, 1)   # panel der: toma el espacio extra
        self.splitter.setSizes([275, 1005])
        # Evitar que cualquier pane del splitter colapse a 0 px
        self.splitter.setCollapsible(0, False)
        self.splitter.setCollapsible(1, False)
        # Ancho mínimo de cada mitad (el panel derecho necesita al menos 400 px)
        self.input_panel.setMinimumWidth(245)
        self.results_widget.setMinimumWidth(400)
        root.addWidget(self.splitter, 1)

        # Barra de progreso — exportación Word / diseño
        self._progress_label = QLabel()
        self._progress_label.setVisible(False)
        self._progress_label.setStyleSheet(
            "color: #2874A6; font-size: 8pt; padding: 0 4px;")
        root.addWidget(self._progress_label)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(18)
        self.progress.setTextVisible(True)
        self.progress.setFormat("%p%  —  %v / 100")
        self.progress.setStyleSheet(
            "QProgressBar { border: 1px solid #AED6F1; border-radius: 3px;"
            "  background: #EBF5FB; text-align: center; font-size: 8pt; }"
            "QProgressBar::chunk { background: #2874A6; border-radius: 2px; }")
        root.addWidget(self.progress)

        # Status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.lbl_code_badge = QLabel()
        self.lbl_code_badge.setStyleSheet(
            "background:#2874A6; color:white; padding:0 8px; border-radius:3px;")
        self.status.addPermanentWidget(self.lbl_code_badge)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    def _build_header(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(HEADER_STYLE)
        frame.setFixedHeight(60)

        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)

        # Título
        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet("color: white; font-size: 14pt; font-weight: bold;")
        lay.addWidget(lbl_title)

        lbl_sub = QLabel("Diseño de Trabes de Concreto Reforzado")
        lbl_sub.setStyleSheet("color: #AED6F1; font-size: 9pt;")
        lay.addWidget(lbl_sub)

        lay.addStretch()

        # Versión
        lbl_ver = QLabel(f"v{APP_VERSION}")
        lbl_ver.setStyleSheet("color: #AED6F1; font-size: 8pt;")
        lay.addWidget(lbl_ver)

        return frame

    # ── Conexión de señales ───────────────────────────────────────────────────

    def _connect_signals(self):
        ip = self.input_panel
        rw = self.results_widget

        ip.sig_connect_staad.connect(self._on_connect_staad)
        ip.sig_run_design.connect(self._on_run_design)
        ip.sig_refresh_beams.connect(self._on_refresh_beams)

        rw.sig_export_word.connect(self._on_export_word)
        rw.sig_export_memory.connect(self._on_export_memory)
        rw.sig_export_dxf.connect(self._on_export_dxf)
        rw.btn_joint_json.clicked.connect(self._on_export_joint_json)

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _on_connect_staad(self):
        self.status.showMessage("  Conectando con STAAD Pro 2025…")
        QApplication.processEvents()
        ok, msg = self._reader.connect()
        self.input_panel.set_staad_status(ok, msg)
        self.status.showMessage(f"  STAAD: {msg}")
        # Al conectar exitosamente, leer automáticamente la selección activa
        if ok:
            self._on_refresh_beams()

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_manual_ids(text: str) -> list[int]:
        """
        Convierte texto libre de IDs a lista de enteros.

        Acepta:
          "59, 87, 88"        → [59, 87, 88]
          "90-94"             → [90, 91, 92, 93, 94]
          "59; 87-90; 100"    → [59, 87, 88, 89, 90, 100]
        """
        ids: set[int] = set()
        for token in text.replace(";", ",").split(","):
            token = token.strip()
            if not token:
                continue
            if "-" in token:
                parts = token.split("-", 1)
                try:
                    a, b = int(parts[0].strip()), int(parts[1].strip())
                    ids.update(range(min(a, b), max(a, b) + 1))
                except ValueError:
                    pass
            else:
                try:
                    ids.add(int(token))
                except ValueError:
                    pass
        return sorted(ids)

    def _on_refresh_beams(self):
        """
        Lee las trabes a diseñar desde STAAD Pro.

        Intenta primero la detección automática de la selección activa.
        Si devuelve 0 barras y hay IDs escritos manualmente, los usa como respaldo.
        """
        if not self._reader.connected:
            QMessageBox.warning(
                self, "Sin conexión STAAD",
                "Conéctese primero a STAAD Pro\n"
                "usando el botón 'Conectar a STAAD Pro'.")
            return

        params = self.input_panel.get_params()
        self.status.showMessage("  Leyendo trabes seleccionadas en STAAD Pro…")
        QApplication.processEvents()

        # ── 1) Intento automático: selección activa en STAAD Pro ──────────────
        members = []
        try:
            members = self._reader.build_members_from_staad(params)
        except Exception as exc:
            log.exception("Error leyendo trabes seleccionadas")
            QMessageBox.critical(self, "Error al leer trabes", str(exc))
            return

        # ── 2) Respaldo: IDs ingresados manualmente ───────────────────────────
        if not members:
            manual_text = params.get("manual_beam_ids", "")
            if manual_text.strip():
                manual_ids = self._parse_manual_ids(manual_text)
                if manual_ids:
                    self.status.showMessage(
                        f"  Selección automática vacía — cargando {len(manual_ids)} "
                        f"ID(s) manuales…")
                    QApplication.processEvents()
                    try:
                        members = self._reader.build_members_for_ids(
                            manual_ids, params)
                        if members:
                            log.info("Trabes cargadas desde IDs manuales: %s",
                                     manual_ids)
                    except Exception as exc:
                        log.exception("Error cargando IDs manuales")
                        QMessageBox.critical(
                            self, "Error al leer trabes (manual)", str(exc))
                        return

        self._members = members
        n = len(members)
        self.input_panel.set_beam_count(n)

        if n == 0:
            self.status.showMessage(
                "  Sin trabes — seleccione en STAAD Pro o escriba IDs en "
                "'IDs manuales' y presione '↻ Actualizar selección'")
        else:
            dirs: dict[str, int] = {}
            for m in members:
                d = m.get("dir", "?")
                dirs[d] = dirs.get(d, 0) + 1
            resumen = "  ".join(f"{d}:{c}" for d, c in sorted(dirs.items()))
            self.status.showMessage(
                f"  {n} trabe(s) cargada(s)  ·  {resumen}")

    def _on_run_design(self, params: dict):
        # ── Validación: trabes cargadas ───────────────────────────────────────
        if not self._members:
            if not self._reader.connected:
                QMessageBox.warning(
                    self, "Sin conexión y sin trabes",
                    "Conecte a STAAD Pro para cargar las trabes a diseñar.\n\n"
                    "Pasos:\n"
                    "  1. Abra el modelo en STAAD Pro 2025\n"
                    "  2. Seleccione las trabes a diseñar\n"
                    "  3. Presione 'Conectar a STAAD Pro'")
            else:
                QMessageBox.warning(
                    self, "Sin trabes seleccionadas",
                    "No hay trabes cargadas para diseñar.\n\n"
                    "Seleccione trabes en el modelo de STAAD Pro\n"
                    "y presione '↻ Actualizar selección'.")
            return

        members = self._members

        # ── Sin conexión STAAD: advertencia modo demo ─────────────────────────
        if not self._reader.connected:
            resp = QMessageBox.question(
                self, "Sin conexión STAAD",
                f"No hay conexión activa con STAAD Pro.\n"
                f"Se diseñarán {len(members)} trabe(s) con fuerzas = 0.\n\n"
                "¿Continuar en modo demostración?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                return

        # ── Pre-fetch en hilo principal (COM STA — no puede cruzar hilos) ─────
        if self._reader.connected:
            beam_ids = [m["id"] for m in members]
            # Incluir combinaciones gravitacionales en el pre-fetch (para Vg/SMF)
            comb_ids = list(params["comb_ids"])
            for gcid in (params.get("comb_CM", 0), params.get("comb_CMCV", 0)):
                if gcid > 0 and gcid not in comb_ids:
                    comb_ids.append(gcid)
            self.status.showMessage("  Extrayendo datos de STAAD Pro…")
            QApplication.processEvents()
            try:
                self._reader.pre_fetch(beam_ids, comb_ids)
            except Exception as exc:
                QMessageBox.critical(self, "Error al leer STAAD", str(exc))
                return

        # Volcar caché a datos Python puros ANTES de lanzar el QThread.
        # Así el worker NUNCA toca el objeto COM → STAAD no se cierra.
        sec_data, force_data = self._reader.dump_cache()

        # ── Guardar parámetros para exportaciones posteriores ─────────────────
        self._params = params

        # Actualizar badge de código
        self.lbl_code_badge.setText(f"  {params['codigo']}  ")

        # Limpiar resultados anteriores
        self.results_widget.clear_results()

        # ── Lanzar worker (solo datos Python, sin objeto COM) ─────────────────
        self._worker = DesignWorker(members, params, sec_data, force_data, self)
        self._worker.sig_progress.connect(self._on_progress)
        self._worker.sig_finished.connect(self._on_design_finished)
        self._worker.sig_error.connect(self._on_design_error)
        self._worker.finished.connect(lambda: self.input_panel.set_running(False))

        self.input_panel.set_running(True)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.status.showMessage(f"  Diseñando {len(members)} trabe(s)…")
        self._worker.start()

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self.status.showMessage(f"  {msg}")

    def _on_design_finished(self, beam_results: list):
        self._results = beam_results
        self.progress.setVisible(False)
        try:
            self.results_widget.load_results(beam_results, self._params)
        except Exception as exc:
            import traceback
            log.exception("Error al cargar resultados en la tabla")
            QMessageBox.critical(
                self, "Error al mostrar resultados",
                f"{exc}\n\nRevise el archivo de log para más detalles.\n"
                f"{traceback.format_exc()[-800:]}")
            return
        n = len(beam_results)
        ts = datetime.now().strftime("%H:%M:%S")
        self.status.showMessage(
            f"  ✔  Diseño completado  ·  {n} barra(s)  ·  {ts}")

    def _on_design_error(self, msg: str):
        self.progress.setVisible(False)
        self.status.showMessage(f"  ✗  Error: {msg}")
        QMessageBox.critical(self, "Error en el diseño", msg)

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _get_export_path(self, title: str, ext: str, default_name: str) -> str:
        proyecto = self._params.get("proyecto", "Proyecto").replace(" ", "_")
        default  = os.path.join(os.path.expanduser("~"), f"{proyecto}_{default_name}")
        path, _ = QFileDialog.getSaveFileName(self, title, default, ext)
        return path

    def _on_export_word(self):
        if not self._results:
            return
        path = self._get_export_path(
            "Guardar resultados en Word",
            "Word Documents (*.docx)", "Resultados.docx")
        if not path:
            return

        # Modo indeterminado mientras no lleguen callbacks del exporter
        self.progress.setRange(0, 0)
        self._show_progress("  Exportando resultados Word…")

        def _cb(pct, msg):
            if pct > 0:
                self.progress.setRange(0, 100)
            self.progress.setValue(pct)
            self._progress_label.setText(f"  Exportando resultados Word  —  {msg}")
            self.status.showMessage(f"  Resultados Word  —  {msg}")
            QApplication.processEvents()

        try:
            from fileio.word_exporter import WordExporter
            exp = WordExporter()
            exp.export_results(self._results, self._params, path,
                               progress_cb=_cb)
            self.status.showMessage(
                f"  ✔  Resultados exportados: {os.path.basename(path)}")
        except Exception as exc:
            QMessageBox.critical(self, "Error exportando Word", str(exc))
        finally:
            self.progress.setRange(0, 100)
            self._hide_progress()

    def _on_export_memory(self):
        if not self._results:
            return
        path = self._get_export_path(
            "Guardar memoria de cálculo en Word",
            "Word Documents (*.docx)", "MemoriaCalculo.docx")
        if not path:
            return

        # Modo indeterminado mientras no lleguen callbacks del exporter
        self.progress.setRange(0, 0)
        self._show_progress("  Generando memoria de cálculo Word…")

        def _cb(pct, msg):
            if pct > 0:
                self.progress.setRange(0, 100)
            self.progress.setValue(pct)
            self._progress_label.setText(f"  Memoria de cálculo  —  {msg}")
            self.status.showMessage(f"  Memoria Word  —  {msg}")
            QApplication.processEvents()

        try:
            from fileio.word_exporter import WordExporter
            exp = WordExporter()
            exp.export_memory(self._results, self._params, path,
                              progress_cb=_cb)
            self.status.showMessage(
                f"  ✔  Memoria de cálculo exportada: {os.path.basename(path)}")
        except Exception as exc:
            QMessageBox.critical(self, "Error exportando memoria de cálculo", str(exc))
        finally:
            self.progress.setRange(0, 100)
            self._hide_progress()

    def _on_export_dxf(self):
        """
        Actualiza los 2 DXF existentes con los resultados de diseño.
          • As  — acero longitudinal (flexión + torsión), todas las trabes
          • Avs — cuantía de acero transversal (cortante), todas las trabes
        El usuario ya indicó las rutas en el panel de entrada.
        """
        if not self._results:
            return

        dxf_paths   = self._params.get("dxf_paths",   {})
        dxf_activos = self._params.get("dxf_activos", {k: True for k in dxf_paths})
        dxf_mode    = self._params.get("dxf_mode",    "A")
        reduc_pct   = self._params.get("dxf_reduc",   20.0)

        # Solo procesar los que el usuario marcó Y tienen ruta
        paths_validas = {
            k: v for k, v in dxf_paths.items()
            if dxf_activos.get(k, True) and v.strip()
        }
        if not paths_validas:
            QMessageBox.warning(
                self, "Sin archivos DXF activos",
                "No hay archivos DXF listos para actualizar.\n\n"
                "Verifique que:\n"
                "  • La casilla del archivo esté marcada  ☑\n"
                "  • La ruta del archivo esté seleccionada  (botón …)")
            return

        try:
            from fileio.dxf_writer import DXFWriter
            writer = DXFWriter(mode=dxf_mode, reduc_pct=reduc_pct)
        except RuntimeError as exc:
            QMessageBox.critical(self, "ezdxf no instalado", str(exc))
            return

        # 2 tareas: As (flex) y Avs (cortante) con TODOS los resultados
        _tareas = [
            ("As",  "flex",  self._results),
            ("Avs", "shear", self._results),
        ]

        tareas_validas = [
            (k, t, bl) for k, t, bl in _tareas
            if paths_validas.get(k, "")
        ]
        total   = max(len(tareas_validas), 1)
        resumen = []

        self._show_progress("  Actualizando archivos DXF…")

        for i, (key, tipo, beam_list) in enumerate(tareas_validas):
            pct = int(i / total * 100)
            self.progress.setValue(pct)
            self.status.showMessage(f"  DXF  [{i + 1}/{total}]  Procesando {key}…")
            QApplication.processEvents()

            path = paths_validas[key]
            try:
                fn    = writer.process_flex if tipo == "flex" else writer.process_shear
                stats = fn(path, beam_list)
                resumen.append(
                    f"  ✔  {key}: {stats['lineas']} líneas reducidas, "
                    f"{stats['textos']} textos actualizados.")
            except Exception as exc:
                resumen.append(f"  ✗  {key}: {exc}")
                log.exception("Error actualizando %s", key)

        self.progress.setValue(100)
        QApplication.processEvents()
        self._hide_progress()

        self.status.showMessage(f"  DXF: {len(tareas_validas)} archivo(s) procesado(s)")
        QMessageBox.information(
            self, "Actualización DXF completada",
            "\n".join(resumen) or "No se procesó ningún archivo.")

    # ── Barra de progreso ─────────────────────────────────────────────────────

    def _show_progress(self, msg: str = ""):
        """Muestra la barra de avance y el label descriptivo."""
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(True)
        if msg:
            self._progress_label.setText(msg)
            self._progress_label.setVisible(True)
            self.status.showMessage(msg)
        QApplication.processEvents()

    def _hide_progress(self):
        """Oculta la barra de avance y el label descriptivo."""
        self.progress.setVisible(False)
        self._progress_label.setVisible(False)
        QApplication.processEvents()

    # ── Exportar a Joint Design Pro ───────────────────────────────────────────

    def _on_export_joint_json(self):
        """Exporta areas de acero de trabes al formato JSON para joint_design_pro."""
        if not self._results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute primero el diseno de trabes.")
            return
        # Construir dict {beam_id: BeamResult}
        beam_dict = {br.beam_id: br for br in self._results}
        model_name = self._params.get("staad_file", "modelo.std")
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar JSON para Joint Design Pro",
            f"beam_results_{os.path.splitext(os.path.basename(model_name))[0]}.json",
            "JSON (*.json)",
        )
        if not path:
            return
        try:
            from fileio.joint_exporter import export_beam_results_json
            export_beam_results_json(beam_dict, model_name, path)
            QMessageBox.information(
                self, "Exportado",
                f"Archivo JSON generado:\n{path}\n\n"
                "Importelo en Joint Design Pro desde la\n"
                "pestana 'Topologia y Acero'."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    # ── Cierre ────────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        if self._worker and self._worker.isRunning():
            resp = QMessageBox.question(
                self, "Diseño en progreso",
                "El diseño está en ejecución. ¿Desea cancelar y salir?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                event.ignore()
                return
            self._worker.terminate()
            self._worker.wait()
        event.accept()
