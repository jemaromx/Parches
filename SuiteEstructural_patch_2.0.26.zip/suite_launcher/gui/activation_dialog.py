# -*- coding: utf-8 -*-
"""
Diálogo de activación de licencia — Struct-Link.

Tres vías:
  • En línea: clave de compra → servicio web → licencia automática.
  • Por correo: genera archivo de solicitud para enviar a soporte.
  • Importar: pega o carga el archivo de licencia recibido.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTabWidget, QWidget, QTextEdit, QFileDialog, QMessageBox, QCheckBox,
    QGroupBox, QTextBrowser,
)

from suite_shared.licensing import (
    machine_id, generar_solicitud, importar_licencia, activar_en_linea,
    estado_licencia,
)
from suite_shared.licensing import ruta_licencia
from suite_shared.licensing.activation import CORREO_SOPORTE
from suite_shared import privacidad
from config.settings import APP_NOMBRE


class ActivationDialog(QDialog):
    """Regresa QDialog.Accepted cuando la suite queda licenciada."""

    def __init__(self, parent=None, estado: str = "", detalle: str = ""):
        super().__init__(parent)
        self.setWindowTitle(f"Activación — {APP_NOMBRE}")
        self.setMinimumWidth(560)
        self._build(estado, detalle)

    def _build(self, estado: str, detalle: str):
        lay = QVBoxLayout(self)

        if detalle:
            lbl_est = QLabel(f"<b>Estado:</b> {detalle}")
            lbl_est.setWordWrap(True)
            lay.addWidget(lbl_est)

        lbl_id = QLabel(f"<b>ID de este equipo:</b> "
                        f"<code>{machine_id()}</code>")
        lbl_id.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(lbl_id)

        # ── Aviso de privacidad (26-oct-2026) ───────────────────────────
        # La activación recaba datos personales: el aviso se acepta ANTES.
        # Sin la primera casilla no se puede activar en línea ni generar la
        # solicitud por correo; la segunda (novedades) es opcional.
        grp = QGroupBox("Aviso de privacidad")
        lg = QVBoxLayout(grp)
        fila_av = QHBoxLayout()
        self.chk_aviso = QCheckBox(
            f"He leído y acepto el Aviso de Privacidad "
            f"(versión {privacidad.AVISO_VERSION})")
        btn_aviso = QPushButton("Ver aviso…")
        btn_aviso.clicked.connect(self._ver_aviso)
        fila_av.addWidget(self.chk_aviso, 1)
        fila_av.addWidget(btn_aviso)
        lg.addLayout(fila_av)
        self.chk_novedades = QCheckBox(
            "Acepto recibir avisos de nuevas versiones y promociones (opcional)")
        lg.addWidget(self.chk_novedades)
        lay.addWidget(grp)

        tabs = QTabWidget()
        lay.addWidget(tabs, 1)

        # ── Pestaña 1: Activación en línea ──────────────────────────────
        w1 = QWidget(); l1 = QVBoxLayout(w1)
        l1.addWidget(QLabel("Ingrese su clave de compra (se la entregamos al "
                            "confirmar su pago):"))
        self.ed_clave = QLineEdit()
        self.ed_clave.setPlaceholderText("SUITE-2026-XXXX-XXXX")
        l1.addWidget(self.ed_clave)
        fila = QHBoxLayout()
        self.ed_nombre1 = QLineEdit(); self.ed_nombre1.setPlaceholderText("Nombre / despacho")
        self.ed_mail1   = QLineEdit(); self.ed_mail1.setPlaceholderText("Correo electrónico")
        fila.addWidget(self.ed_nombre1); fila.addWidget(self.ed_mail1)
        l1.addLayout(fila)
        btn1 = QPushButton("Activar en línea")
        btn1.clicked.connect(self._activar_online)
        l1.addWidget(btn1)
        self.btn_activar = btn1
        l1.addStretch(1)
        tabs.addTab(w1, "Activación en línea")

        # ── Pestaña 2: Solicitud por correo ─────────────────────────────
        w2 = QWidget(); l2 = QVBoxLayout(w2)
        l2.addWidget(QLabel(
            f"Sin conexión a internet: genere su solicitud y envíela a "
            f"<b>{CORREO_SOPORTE}</b> junto con su referencia de pago."))
        fila2 = QHBoxLayout()
        self.ed_nombre2 = QLineEdit(); self.ed_nombre2.setPlaceholderText("Nombre / despacho")
        self.ed_mail2   = QLineEdit(); self.ed_mail2.setPlaceholderText("Correo electrónico")
        fila2.addWidget(self.ed_nombre2); fila2.addWidget(self.ed_mail2)
        l2.addLayout(fila2)
        btn2 = QPushButton("Generar archivo de solicitud…")
        btn2.clicked.connect(self._generar_solicitud)
        l2.addWidget(btn2)
        self.btn_solicitud = btn2
        self.txt_sol = QTextEdit(); self.txt_sol.setReadOnly(True)
        self.txt_sol.setPlaceholderText("Aquí aparecerá la solicitud generada…")
        l2.addWidget(self.txt_sol, 1)
        tabs.addTab(w2, "Solicitud por correo")

        # ── Pestaña 3: Importar licencia ────────────────────────────────
        w3 = QWidget(); l3 = QVBoxLayout(w3)
        l3.addWidget(QLabel("Pegue el contenido de su licencia o cargue el "
                            f"archivo {ruta_licencia().name} que recibió:"))
        self.txt_lic = QTextEdit()
        self.txt_lic.setPlaceholderText("SUITE-LIC-V1\n…")
        l3.addWidget(self.txt_lic, 1)
        fila3 = QHBoxLayout()
        btn_file = QPushButton("Cargar archivo…")
        btn_file.clicked.connect(self._cargar_archivo)
        btn_imp = QPushButton("Importar y activar")
        btn_imp.clicked.connect(self._importar)
        fila3.addWidget(btn_file); fila3.addStretch(1); fila3.addWidget(btn_imp)
        l3.addLayout(fila3)
        tabs.addTab(w3, "Importar licencia")

        # ── Pie ─────────────────────────────────────────────────────────
        pie = QHBoxLayout()
        pie.addStretch(1)
        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.reject)
        pie.addWidget(btn_cerrar)
        lay.addLayout(pie)

        self.chk_aviso.toggled.connect(self._habilitar)
        self._habilitar(False)

    def _habilitar(self, aceptado: bool) -> None:
        msg = ("" if aceptado else
               "Acepte el Aviso de Privacidad para continuar.")
        for b in (self.btn_activar, self.btn_solicitud):
            b.setEnabled(bool(aceptado))
            b.setToolTip(msg)

    def _ver_aviso(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Aviso de Privacidad — {APP_NOMBRE}")
        dlg.resize(760, 620)
        v = QVBoxLayout(dlg)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        try:
            tb.setHtml(privacidad.ruta_aviso().read_text(encoding="utf-8"))
        except OSError:
            tb.setHtml(f"<p>Consulte el aviso en "
                       f"<a href='{privacidad.AVISO_URL}'>{privacidad.AVISO_URL}"
                       f"</a>.</p>")
        v.addWidget(tb, 1)
        b = QPushButton("Cerrar")
        b.clicked.connect(dlg.accept)
        v.addWidget(b, 0, Qt.AlignRight)
        dlg.exec()

    def _aceptacion(self) -> dict:
        return privacidad.registrar_aceptacion(self.chk_novedades.isChecked())

    # ── Acciones ────────────────────────────────────────────────────────
    def _activar_online(self):
        clave = self.ed_clave.text().strip()
        if not clave:
            QMessageBox.warning(self, "Activación",
                                "Ingrese su clave de compra.")
            return
        if not self.chk_aviso.isChecked():
            return
        reg = self._aceptacion()
        try:
            ok, msg = activar_en_linea(clave, self.ed_nombre1.text(),
                                       self.ed_mail1.text(),
                                       aviso_version=reg["aviso_version"],
                                       novedades=reg["novedades"])
        except TypeError:
            # licensing de un instalador anterior (no se parcha): activa sin
            # los campos nuevos; la aceptación ya quedó en privacidad.json.
            ok, msg = activar_en_linea(clave, self.ed_nombre1.text(),
                                       self.ed_mail1.text())
        if ok:
            QMessageBox.information(self, "Activación", msg)
            self.accept()
        else:
            QMessageBox.warning(self, "Activación", msg)

    def _generar_solicitud(self):
        nombre = self.ed_nombre2.text().strip()
        if not nombre:
            QMessageBox.warning(self, "Solicitud",
                                "Ingrese su nombre o despacho.")
            return
        if not self.chk_aviso.isChecked():
            return
        reg = self._aceptacion()
        try:
            sol = generar_solicitud(nombre, self.ed_mail2.text(),
                                    aviso_version=reg["aviso_version"],
                                    novedades=reg["novedades"])
        except TypeError:       # licensing anterior (ver _activar_online)
            sol = generar_solicitud(nombre, self.ed_mail2.text()) + (
                f"Aviso de privacidad aceptado: versión {reg['aviso_version']}"
                f" ({reg['fecha']})\n")
        self.txt_sol.setPlainText(sol)
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar solicitud", "solicitud_activacion.txt",
            "Texto (*.txt)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(sol)
            QMessageBox.information(
                self, "Solicitud",
                f"Solicitud guardada:\n{path}\n\n"
                f"Envíela a {CORREO_SOPORTE} junto con su referencia de pago.")

    def _cargar_archivo(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Cargar licencia", "", "Licencia (*.lic *.txt)")
        if path:
            with open(path, "r", encoding="utf-8") as f:
                self.txt_lic.setPlainText(f.read())

    def _importar(self):
        ok, msg = importar_licencia(self.txt_lic.toPlainText())
        if ok:
            QMessageBox.information(self, "Licencia", msg)
            self.accept()
        else:
            QMessageBox.warning(self, "Licencia", msg)
