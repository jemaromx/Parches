# -*- coding: utf-8 -*-
"""Aviso de privacidad: versión vigente, copia local y registro de aceptación.

La fuente del aviso es `herramientas_admin/legal/AVISO_PRIVACIDAD_v<ver>.md`;
`generar_aviso.py` produce la copia que se muestra aquí
(`suite_shared/legal/aviso_privacidad.html`). La aceptación se guarda en el
equipo del usuario (`%APPDATA%\\SuiteEstructural\\privacidad.json`) y viaja con
la activación para que el registro de la licencia diga qué versión aceptó.

Lo carga el launcher (diálogo de activación): se distribuye en `.py`
(`build_protegido.NO_COMPILAR`) para que un parche pueda reemplazarlo.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

#: Versión del aviso que se pide aceptar. Al cambiar el aviso se sube aquí.
AVISO_VERSION = "1.0"
#: Dirección pública del aviso integral (la del producto, si está).
try:
    from suite_shared.licensing.producto import AVISO_URL
except Exception:                                   # noqa: BLE001
    AVISO_URL = "https://struct-link.com.mx/privacidad"


def ruta_aviso() -> Path:
    return Path(__file__).resolve().parent / "legal" / "aviso_privacidad.html"


def _carpeta_producto() -> str:
    """La carpeta en %APPDATA% del producto (`licensing/producto.py`).

    Con un `licensing` anterior al 26-oct-2026 (sin `producto`), la de
    Struct-Link: este archivo viaja en parches y el licensing solo cambia
    por instalador."""
    try:
        from suite_shared.licensing import producto
        return producto.CARPETA_APPDATA
    except Exception:                               # noqa: BLE001
        return "SuiteEstructural"


def _archivo() -> Path:
    base = Path(os.environ.get("APPDATA", str(Path.home()))) / _carpeta_producto()
    return base / "privacidad.json"


def registrar_aceptacion(novedades: bool) -> dict:
    """Anota en el equipo la aceptación del aviso vigente."""
    reg = {"aviso_version": AVISO_VERSION,
           "fecha": time.strftime("%Y-%m-%d %H:%M:%S"),
           "novedades": bool(novedades)}
    try:
        p = _archivo()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(reg, ensure_ascii=False, indent=2),
                     encoding="utf-8")
    except OSError:
        pass                    # no impide activar: también viaja al servidor
    return reg


def aceptacion() -> dict | None:
    """La aceptación registrada en este equipo, o None."""
    try:
        return json.loads(_archivo().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
