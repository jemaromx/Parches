"""Configuración de logging centralizada para todos los módulos."""

import sys
import logging
from pathlib import Path

LOG_DIR = Path.home() / "AppData" / "Roaming" / "SuiteEstructural" / "logs"


def setup_logging(module_name: str) -> logging.Logger:
    """
    Configura handlers de consola y archivo para el módulo dado.
    Retorna el logger raíz del módulo.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"{module_name}.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )
    return logging.getLogger(module_name)
