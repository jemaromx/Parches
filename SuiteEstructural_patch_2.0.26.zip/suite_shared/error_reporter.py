"""error_reporter.py — ALIAS de `suite_shared.reporte_errores` (2.0.25).

Se conserva para quien lo importe por su nombre viejo. El código vive en
`reporte_errores.py`; ver la nota ahí.
"""
from suite_shared.reporte_errores import *            # noqa: F401,F403
from suite_shared.reporte_errores import (            # noqa: F401
    SUPPORT_EMAIL, install_excepthook)
