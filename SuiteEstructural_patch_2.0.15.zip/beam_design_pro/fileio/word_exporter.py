"""
Exportador de resultados a Word (.docx) — BeamDesignPro v1.4.
NTC DEC 2024 / ACI 318-25

Genera dos documentos con exactamente las mismas columnas que la interfaz:
  1. export_results()  → "Por Combinación": 3 grupos por barra
                         (Flexión · Cortante · Torsión)
  2. export_memory()   → "Envolvente": mismo formato, máximos + memoria
                         detallada con fórmulas y referencias NTC.
                         Incluye diagramas 2D si params["diagramas_2d"]=True.

Ambas funciones aceptan un callback:
    progress_cb(pct: int, msg: str)
que se invoca en cada barra procesada para actualizar la barra de avance.

Correcciones v1.4:
  • β₁ NTC: umbral corregido 280→300 kg/cm²  [§3.6.1]
  • φ_flex NTC: denominador 0.003 fijo, umbral εy+0.003  [Tabla 3.8.2.2]
  • Vcr_min/max en memoria: coeficientes 0.08 / 0.42  [§5.5.3.1.1]
  • Referencias: §5.x / §6.x para DEC (antes §7.x de NTC Acero)
  • Diagramas 2D de sección transversal con refuerzo propuesto

Página: A4 Horizontal (landscape) para acomodar las tablas anchas.
"""
from __future__ import annotations

import datetime
import io
import math
from pathlib import Path

from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.enum.section import WD_ORIENTATION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from config.settings import APP_NAME, APP_VERSION, COLORS


# ── Encabezados de columna (idénticos a _FLEX_COLS / _SHEAR_COLS / _TOR_COLS) ─
_FLEX_HDR = [
    "Sección",
    "Comb\nMu+", "Mu+\n(t·m)", "As flex(+)\n(cm²)", "φ(+)", "Mr(+)\n(t·m)", "Cond.\nMu+",
    "Comb\nMu−", "Mu−\n(t·m)", "As flex(−)\n(cm²)", "φ(−)", "Mr(−)\n(t·m)", "Cond.\nMu−",
]
_SHEAR_HDR = [
    "Sección",
    "Comb\nVu", "Vu\n(t)", "Vc\n(t)", "Vmax\n(t)", "Cond.\nSec",
    "Vcr\n(t)", "Vsr\n(t)", "Av/s\n(cm²/cm)",
    "S(#3)\n(cm)", "S(#4)\n(cm)", "S(#5)\n(cm)", "Smax\n(cm)",
]
_TOR_HDR = [
    "Sección",
    "Comb\n(V+T)", "Mt\n(t·m)", "Tch\n(t·m)", "Cond.\nDis",
    "At/s\n(cm²/cm)", "(Av+At/s)\nTot", "Ast\n(cm²)", "Ast,min\n(cm²)",
    "As(+)Tot\n(cm²)", "As(−)Tot\n(cm²)",
]

HDR_BG  = COLORS.get("primary",   "#1B4F72")
PASS_BG = "D5F5E3"
FAIL_BG = "FADBD8"
NOREQ_BG = "F4F6F7"


# ── Helpers de formato ────────────────────────────────────────────────────────

def _rgb(hex_c: str) -> RGBColor:
    h = hex_c.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _bg_cell(cell, hex_c: str):
    tc  = cell._tc
    pr  = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_c.lstrip("#"))
    pr.append(shd)


def _write_cell(cell, text: str, sz: int = 6, bold: bool = False,
                color: str = "#1C2833", center: bool = True):
    """Escribe texto en una celda con formato."""
    cell.text = str(text)
    para = cell.paragraphs[0]
    run  = para.runs[0] if para.runs else para.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(sz)
    run.font.color.rgb = _rgb(color)
    para.alignment = (WD_ALIGN_PARAGRAPH.CENTER
                      if center else WD_ALIGN_PARAGRAPH.LEFT)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _f(v, dec: int = 2) -> str:
    try:
        return f"{float(v):.{dec}f}"
    except Exception:
        return str(v)


def _tor_cond(tor) -> str:
    if not tor.req_design:
        return "No req."
    return tor.cond_sec   # "OK" | "Aumentar sección"


def _tbl_full_width(tbl):
    """Expande la tabla al 100 % del ancho disponible."""
    tblPr = tbl._tbl.tblPr
    for child in list(tblPr):
        if child.tag == qn("w:tblW"):
            tblPr.remove(child)
    tblW = OxmlElement("w:tblW")
    tblW.set(qn("w:w"),    "5000")
    tblW.set(qn("w:type"), "pct")
    tblPr.append(tblW)


# ── Clase principal ───────────────────────────────────────────────────────────

from design.beam_design import SEP_MAX_TORSION

class WordExporter:

    def __init__(self):
        self.doc: Document | None = None

    # ═══════════════════════════════════════════════════════════════════════
    # API pública
    # ═══════════════════════════════════════════════════════════════════════

    def export_results(self, beam_results: list, params: dict,
                       path: str, progress_cb=None) -> bool:
        """
        Tabla POR COMBINACIÓN — mismas columnas que la UI.
        Por cada barra: encabezado · Flexión · Cortante · Torsión.
        """
        self.doc = Document()
        self._page_landscape()
        self._cover(params, "TABLA DE RESULTADOS  —  POR COMBINACIÓN")
        self.doc.add_page_break()

        n = len(beam_results)
        for i, br in enumerate(beam_results):
            if progress_cb:
                progress_cb(int(i / n * 90),
                            f"Barra {br.beam_id}  ({i + 1}/{n})")
            self._beam_hdr(br, params)
            self._sec_flex_comb(br)
            self._sec_shear_comb(br)
            if params.get("diseno_torsion", True):
                self._sec_tor_comb(br)
            if i < n - 1:
                self.doc.add_page_break()

        if progress_cb:
            progress_cb(95, "Guardando archivo…")
        self.doc.save(path)
        if progress_cb:
            progress_cb(100, f"Listo → {Path(path).name}")
        return True

    def export_memory(self, beam_results: list, params: dict,
                      path: str, progress_cb=None) -> bool:
        """
        ENVOLVENTE por barra — mismas columnas que la UI.
        Por cada barra: encabezado · Flexión env · Cortante env · Torsión env.
        Reemplaza la antigua memoria de cálculo con fórmulas.
        """
        self.doc = Document()
        self._page_landscape()
        self._cover(params, "ENVOLVENTE DE RESULTADOS")
        self.doc.add_page_break()

        n = len(beam_results)
        for i, br in enumerate(beam_results):
            if progress_cb:
                progress_cb(int(i / n * 90),
                            f"Barra {br.beam_id}  ({i + 1}/{n})")
            self._beam_hdr(br, params)
            self._sec_flex_env(br)
            self._sec_shear_env(br)
            if params.get("diseno_torsion", True):
                self._sec_tor_env(br)
            if getattr(br, "seismic_applicable", False):
                self._sec_seismic_env(br)
            self._mem_detail(br, params)
            if params.get("diagramas_2d", True):
                self._add_section_diagrams(br, params)
            if i < n - 1:
                self.doc.add_page_break()

        if progress_cb:
            progress_cb(95, "Guardando archivo…")
        self.doc.save(path)
        if progress_cb:
            progress_cb(100, f"Listo → {Path(path).name}")
        return True

    # ═══════════════════════════════════════════════════════════════════════
    # Bloques Por Combinación
    # ═══════════════════════════════════════════════════════════════════════

    def _sec_flex_comb(self, br):
        self._grp_title("📐  FLEXIÓN")
        rows = []
        for cid, sec_list in sorted(br.by_comb.items()):
            for sr in sec_list:
                fp = sr.flex_pos; fn = sr.flex_neg
                ok = fp.ok and fn.ok
                rows.append(([
                    sr.label, str(cid),
                    _f(fp.Mu, 3), _f(fp.As, 2), _f(fp.phi, 3), _f(fp.Mr, 3), fp.cond,
                    str(cid),
                    _f(fn.Mu, 3), _f(fn.As, 2), _f(fn.phi, 3), _f(fn.Mr, 3), fn.cond,
                ], ok, False))
        self._write_table(_FLEX_HDR, rows)

    def _sec_shear_comb(self, br):
        self._grp_title("⚡  CORTANTE")
        rows = []
        for cid, sec_list in sorted(br.by_comb.items()):
            for sr in sec_list:
                sh = sr.shear
                rows.append(([
                    sr.label, str(cid),
                    _f(sh.Vu, 3), _f(sh.Vc, 3), _f(sh.Vmax, 3), sh.cond,
                    _f(sh.Vcr, 3), _f(sh.Vsr, 3), _f(sh.Avs, 4),
                    _f(sh.S3, 1), _f(sh.S4, 1), _f(sh.S5, 1), _f(sh.Smax, 1),
                ], sh.ok, False))
        self._write_table(_SHEAR_HDR, rows)

    def _sec_tor_comb(self, br):
        self._grp_title("🔄  TORSIÓN")
        rows = []
        for cid, sec_list in sorted(br.by_comb.items()):
            for sr in sec_list:
                tor   = sr.torsion
                noreq = not tor.req_design
                rows.append(([
                    sr.label, str(cid),
                    _f(tor.Tu, 3), _f(tor.Tch, 3), _tor_cond(tor),
                    _f(tor.At_s, 4), _f(tor.Avtotal, 4),
                    _f(tor.Ast, 2), _f(tor.Ast_min, 2),
                    _f(sr.As_sup_tot, 2), _f(sr.As_inf_tot, 2),   # As(+) / As(−)
                ], tor.ok, noreq))
        self._write_table(_TOR_HDR, rows)

    # ═══════════════════════════════════════════════════════════════════════
    # Bloques Envolvente
    # ═══════════════════════════════════════════════════════════════════════

    def _sec_flex_env(self, br):
        self._grp_title("📐  FLEXIÓN  —  Envolvente")
        rows = []
        for sr in br.envelope:
            fp = sr.flex_pos; fn = sr.flex_neg
            ok = fp.ok and fn.ok
            rows.append(([
                sr.label,
                str(sr.comb_flex_pos),
                _f(fp.Mu, 3), _f(fp.As, 2), _f(fp.phi, 3), _f(fp.Mr, 3), fp.cond,
                str(sr.comb_flex_neg),
                _f(fn.Mu, 3), _f(fn.As, 2), _f(fn.phi, 3), _f(fn.Mr, 3), fn.cond,
            ], ok, False))
        self._write_table(_FLEX_HDR, rows)

    def _sec_shear_env(self, br):
        self._grp_title("⚡  CORTANTE  —  Envolvente")
        rows = []
        for sr in br.envelope:
            sh = sr.shear
            rows.append(([
                sr.label, str(sr.comb_shear),
                _f(sh.Vu, 3), _f(sh.Vc, 3), _f(sh.Vmax, 3), sh.cond,
                _f(sh.Vcr, 3), _f(sh.Vsr, 3), _f(sh.Avs, 4),
                _f(sh.S3, 1), _f(sh.S4, 1), _f(sh.S5, 1), _f(sh.Smax, 1),
            ], sh.ok, False))
        self._write_table(_SHEAR_HDR, rows)

    def _sec_tor_env(self, br):
        self._grp_title("🔄  TORSIÓN  —  Envolvente")
        rows = []
        for sr in br.envelope:
            tor   = sr.torsion
            noreq = not tor.req_design
            rows.append(([
                sr.label, str(sr.comb_torsion),
                _f(tor.Tu, 3), _f(tor.Tch, 3), _tor_cond(tor),
                _f(tor.At_s, 4), _f(tor.Avtotal, 4),
                _f(tor.Ast, 2), _f(tor.Ast_min, 2),
                _f(sr.As_sup_tot, 2), _f(sr.As_inf_tot, 2),   # As(+) / As(−)
            ], tor.ok, noreq))
        self._write_table(_TOR_HDR, rows)

    # ═══════════════════════════════════════════════════════════════════════
    # Escritura genérica de tabla
    # ═══════════════════════════════════════════════════════════════════════

    def _write_table(self, headers: list, rows_data: list):
        """
        rows_data: [(vals, cumple, noreq), ...]
          cumple → bool (verde / rojo)
          noreq  → bool; True fuerza fondo neutro (torsión no requerida)
        """
        if not rows_data:
            p = self.doc.add_paragraph("(Sin datos disponibles)")
            if p.runs:
                p.runs[0].font.size = Pt(7)
            self.doc.add_paragraph()
            return

        nc  = len(headers)
        nr  = len(rows_data)
        tbl = self.doc.add_table(rows=1 + nr, cols=nc)
        tbl.style = "Table Grid"
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        _tbl_full_width(tbl)

        # Fila de encabezado
        for c, h in enumerate(headers):
            _write_cell(tbl.rows[0].cells[c], h,
                        sz=6, bold=True, color="#FFFFFF")
            _bg_cell(tbl.rows[0].cells[c], HDR_BG)

        # Filas de datos
        for ri, (vals, cumple, noreq) in enumerate(rows_data, 1):
            if noreq:
                bg_hex = NOREQ_BG
            else:
                bg_hex = PASS_BG if cumple else FAIL_BG

            for c, v in enumerate(vals):
                txt  = str(v)
                bold = txt in ("OK", "Aumentar sección", "No req.")
                if txt == "OK":
                    clr = "#1E8449"
                elif "Aumentar" in txt:
                    clr = "#C0392B"
                elif "No req" in txt:
                    clr = "#7D6608"
                else:
                    clr = "#1C2833"
                _write_cell(tbl.rows[ri].cells[c], txt,
                            sz=6, bold=bold, color=clr)
                _bg_cell(tbl.rows[ri].cells[c], bg_hex)

        self.doc.add_paragraph()

    # ═══════════════════════════════════════════════════════════════════════
    # Encabezado de barra
    # ═══════════════════════════════════════════════════════════════════════

    def _beam_hdr(self, br, params: dict):
        fc  = params.get("fc",          250)
        fy  = params.get("fy",         4200)
        fys = params.get("fy_s",       4200)
        rf  = params.get("rec_flex",    6.0)
        rc  = params.get("rec_comp",    4.0)
        rl  = params.get("rec_lateral", 4.0)
        code = params.get("codigo", "NTC 2023")
        norm = "NTC 2023" if str(code).startswith("NTC") else "ACI 318-25"

        h = self.doc.add_heading(
            f"BARRA {br.beam_id}  —  Dir. {br.direccion}  —  {norm}", level=1)
        h.paragraph_format.space_before = Pt(10)
        h.paragraph_format.space_after  = Pt(2)

        info = (
            f"b = {br.b:.1f} cm  |  h = {br.h:.1f} cm  |  "
            f"d = {br.d:.1f} cm  |  L = {br.L:.2f} m\n"
            f"f'c = {fc} kg/cm²   fy = {fy} kg/cm²   fy,s = {fys} kg/cm²   "
            f"Rec:  flex = {rf} cm   comp = {rc} cm   lat = {rl} cm"
        )
        p = self.doc.add_paragraph(info)
        if p.runs:
            p.runs[0].font.size = Pt(8)
        p.paragraph_format.space_after = Pt(4)

    def _grp_title(self, text: str):
        """Título de grupo (Flexión / Cortante / Torsión) dentro de la barra."""
        p = self.doc.add_paragraph()
        r = p.add_run(text)
        r.bold = True
        r.font.size = Pt(9)
        r.font.color.rgb = _rgb(HDR_BG)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after  = Pt(2)

    # ═══════════════════════════════════════════════════════════════════════
    # Portada
    # ═══════════════════════════════════════════════════════════════════════

    def _cover(self, params: dict, title: str):
        for _ in range(4):
            self.doc.add_paragraph()

        p = self.doc.add_paragraph()
        r = p.add_run(APP_NAME)
        r.bold = True
        r.font.size = Pt(26)
        r.font.color.rgb = _rgb(HDR_BG)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

        p2 = self.doc.add_paragraph()
        r2 = p2.add_run(title)
        r2.bold = True
        r2.font.size = Pt(13)
        r2.font.color.rgb = _rgb(COLORS.get("secondary", "#2874A6"))
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER

        self.doc.add_paragraph()

        code  = params.get("codigo",      "NTC 2023")
        norm  = "NTC 2023" if str(code).startswith("NTC") else "ACI 318-25"
        obra  = params.get("proyecto",    "—")
        nivel = params.get("nivel",       "—")
        fc    = params.get("fc",           0)
        fy    = params.get("fy",           0)
        fys   = params.get("fy_s",         0)
        rf    = params.get("rec_flex",     0)
        rc    = params.get("rec_comp",     0)
        rl    = params.get("rec_lateral",  0)

        for lbl, val in [
            ("Norma de diseño:",   norm),
            ("Proyecto:",          obra),
            ("Nivel:",             nivel),
            ("f'c:",               f"{fc} kg/cm²"),
            ("fy (long.):",        f"{fy} kg/cm²"),
            ("fy (estrib.):",      f"{fys} kg/cm²"),
            ("Rec. tracción:",     f"{rf} cm"),
            ("Rec. compresión:",   f"{rc} cm"),
            ("Rec. lateral:",      f"{rl} cm"),
            ("Fecha:",             datetime.date.today().strftime("%d/%m/%Y")),
        ]:
            pi = self.doc.add_paragraph()
            ri = pi.add_run(f"{lbl}  ")
            ri.bold = True
            ri.font.size = Pt(9)
            pi.add_run(val).font.size = Pt(9)
            pi.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ═══════════════════════════════════════════════════════════════════════
    # Memoria de cálculo detallada — fórmulas con valores
    # ═══════════════════════════════════════════════════════════════════════

    def _mem_detail(self, br, params: dict):
        """
        Genera los bloques de fórmulas con valores numéricos para la envolvente.
        Por cada sección (Inicio / Mitad / Fin) muestra las operaciones completas
        de la combinación más desfavorable para Flexión, Cortante y Torsión.
        """
        fc   = float(params.get("fc",          250))
        fy   = float(params.get("fy",         4200))
        fy_s = float(params.get("fy_s",       4200))
        rf   = float(params.get("rec_flex",    6.0))
        rc   = float(params.get("rec_comp",    4.0))
        rl   = float(params.get("rec_lateral", 4.0))
        lam  = float(params.get("lamda",       1.0))
        is_ntc = str(params.get("codigo", "NTC")).upper().startswith("NTC")

        FR_cort = 0.75
        FR_tor  = 0.75
        # β₁ NTC DEC 2024 §3.6.1: umbral 300 kg/cm² (antes 280)
        if is_ntc:
            B1 = 0.85 if fc <= 300.0 else max(0.65, 1.05 - fc / 1400.0)
        else:
            # ACI 318-25 Tabla 22.2.2.4.3: umbral 280 kg/cm²
            B1 = 0.85 if fc <= 280.0 else max(0.65, 0.85 - 0.05 * (fc - 280.0) / 70.0)

        b = br.b;  h = br.h;  d = br.d

        # ── Título de la sección ──
        norm_lbl = "NTC DEC 2024" if is_ntc else "ACI 318-25"
        p = self.doc.add_paragraph()
        r = p.add_run(
            f"MEMORIA DE CÁLCULO DETALLADA — COMBINACIONES CRÍTICAS  [{norm_lbl}]")
        r.bold = True
        r.font.size = Pt(9)
        r.font.color.rgb = _rgb(HDR_BG)
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after  = Pt(4)

        for sr in br.envelope:
            sec_p = self.doc.add_paragraph()
            run   = sec_p.add_run(
                f"▌  SECCIÓN: {sr.label.upper()}  —  x = {sr.x_frac:.1f} · L")
            run.bold = True
            run.font.size = Pt(8.5)
            run.font.color.rgb = _rgb(COLORS.get("secondary", "#2874A6"))
            sec_p.paragraph_format.space_before = Pt(8)
            sec_p.paragraph_format.space_after  = Pt(2)

            self._mfd_flex(sr, b, d, fc, fy, B1, is_ntc, params)
            self._mfd_shear(sr, b, d, fc, fy_s, lam, FR_cort, is_ntc)
            if params.get("diseno_torsion", True):
                self._mfd_tor(sr, b, h, d, fc, fy, fy_s, lam,
                              FR_tor, rf, rc, rl, is_ntc)

    # ── Bloque FLEXIÓN ───────────────────────────────────────────────────────

    def _mfd_flex(self, sr, b, d, fc, fy, B1, is_ntc: bool = True,
                  params: dict | None = None):
        fp = sr.flex_pos
        fn = sr.flex_neg
        norm_ref = "NTC DEC 2024" if is_ntc else "ACI 318-25"
        self._grp_title(
            f"📐  FLEXIÓN  —  Comb. más desfavorable"
            f"  (Mu+: comb. {sr.comb_flex_pos}  |  Mu−: comb. {sr.comb_flex_neg})")

        fc2   = 0.85 * fc
        eps_y = fy / 2_039_000.0

        # β₁ — mostrar fórmula correcta según código
        b1_ref = "§3.6.1" if is_ntc else "Tabla 22.2.2.4.3"
        if is_ntc:
            if fc <= 300.0:
                b1_formula = f"f'c = {fc:.0f} ≤ 300 kg/cm²  →  β₁ = 0.85"
            else:
                b1_formula = (f"1.05 − {fc:.0f}/1400 = {B1:.4f}  "
                              f"(≥ 0.65)")
        else:
            if fc <= 280.0:
                b1_formula = f"f'c = {fc:.0f} ≤ 280 kg/cm²  →  β₁ = 0.85"
            else:
                b1_formula = (f"0.85 − 0.05·({fc:.0f}−280)/70 = {B1:.4f}  "
                              f"(≥ 0.65)")
        self._fline(f"β₁  [{norm_ref} {b1_ref}]", b1_formula, f"β₁ = {B1:.4f}")

        a1    = 0.8 * math.sqrt(fc) / fy
        a2    = 14.0 / fy
        Asmin = max(a1, a2) * b * d
        self._fline(
            "As,mín = max(0.8√f'c/fy,  14/fy) · b · d  [NTC DEC §6.3.5.1 / ACI §9.6.1.2]",
            f"max(0.8·√{fc:.0f}/{fy:.0f},  14/{fy:.0f}) · {b:.0f} · {d:.1f}",
            f"max({a1*b*d:.2f},  {a2*b*d:.2f}) = {Asmin:.2f} cm²")

        # Nota excepción 1.33 (NTC Q≤2 / ACI §9.6.1.3)
        Qduct = float((params or {}).get("Q", 2.0))
        if is_ntc:
            if Qduct <= 2.0:
                self._fline(
                    "  Excepción As,mín [NTC §6.3.5.1 / ACI §9.6.1.3]  Q ≤ 2:",
                    "Si As,calc < As,mín  →  As,dis = min(1.33·As,calc, As,mín)",
                    "Aplica")
            else:
                self._fline(
                    f"  Q = {Qduct:.0f} ≥ 3  →  As,mín riguroso [NTC Cap. {int(Qduct)+5}]:",
                    "Excepción 1.33·As,calc NO aplica",
                    "As,dis ≥ As,mín  siempre")
        else:
            self._fline(
                "  Excepción As,mín [ACI §9.6.1.3]:",
                "Si As,calc < As,mín  →  As,dis = min(1.33·As,calc, As,mín)",
                "Aplica")

        for fr, lecho, lbl in (
                (fp, "inferior (Mu+)", "Mu+"),
                (fn, "superior (Mu−)", "Mu−")):
            Mu = fr.Mu
            As = fr.As
            self._fsep(f"Lecho {lecho}")
            self._fline(lbl, "", f"{Mu:.3f} t·m")

            if Mu * 100_000 < 1.0:
                self._fline("  Mu ≈ 0  →  As = As,mín", "",
                            f"As = {As:.2f} cm²")
                continue

            # Mostrar As_calc y cómo se llegó a As_diseño
            As_calc_v = getattr(fr, "As_calc", None)
            uso_exc   = getattr(fr, "uso_excepcion_133", False)
            if As_calc_v is not None and As_calc_v > 1e-9:
                self._fline(
                    "  As,calc (análisis, sin piso As,mín)",
                    "", f"{As_calc_v:.2f} cm²")
            if uso_exc and As_calc_v is not None:
                self._fline(
                    "  As,dis = 1.33·As,calc  (excepción §9.6.1.3 / NTC §6.3.5.1)",
                    f"1.33 × {As_calc_v:.2f}",
                    f"{As:.2f} cm²  < As,mín = {Asmin:.2f} cm²")

            a_v   = As * fy / (fc2 * b)
            c_v   = a_v / B1
            eps_t = (0.003 * (d - c_v) / c_v) if c_v > 1e-9 else 0.005
            phi   = fr.phi
            Mn    = As * fy * (d - a_v / 2)     # kg·cm
            Mr    = phi * Mn / 100_000            # ton·m

            self._fline(
                "  a = As·fy / (0.85f'c·b)  [§5.2.2.1.1.b]",
                f"{As:.2f}·{fy:.0f} / ({fc2:.2f}·{b:.0f})",
                f"{a_v:.3f} cm")
            self._fline("  c = a / β₁",
                        f"{a_v:.3f} / {B1:.4f}",
                        f"{c_v:.3f} cm")
            self._fline("  εt = εcu·(d − c) / c",
                        f"0.003·({d:.1f} − {c_v:.3f}) / {c_v:.3f}",
                        f"{eps_t:.5f}")

            # φ (FR) según código  [NTC DEC Tabla 3.8.2.2 / ACI Tabla 21.2.2]
            if is_ntc:
                thr = eps_y + 0.003
                fr_ref = "NTC DEC Tabla 3.8.2.2"
                if eps_t >= thr:
                    phi_formula = (
                        f"εt = {eps_t:.5f} ≥ εy+0.003 = {thr:.5f}  "
                        f"→  tensión controlada  →  FR = {phi:.2f}")
                elif eps_t >= eps_y:
                    phi_formula = (
                        f"0.65 + 0.25·({eps_t:.5f} − {eps_y:.5f}) / 0.003"
                        f" = {phi:.4f}  (transición)")
                else:
                    phi_formula = f"εt = {eps_t:.5f} < εy  →  FR = 0.65"
            else:
                fr_ref = "ACI Tabla 21.2.2"
                if eps_t >= 0.005:
                    phi_formula = (
                        f"εt = {eps_t:.5f} ≥ 0.005  "
                        f"→  tension-controlled  →  φ = {phi:.2f}")
                elif eps_t >= eps_y:
                    phi_formula = (
                        f"0.65 + 0.25·({eps_t:.5f} − {eps_y:.5f}) / "
                        f"(0.005 − {eps_y:.5f}) = {phi:.4f}")
                else:
                    phi_formula = f"εt = {eps_t:.5f} < εy  →  φ = 0.65"

            self._fline(f"  FR (φ)  [{fr_ref}]", phi_formula, "")

            self._fline(
                "  Mn = As·fy·(d − a/2)  [§5.2.2.1.1.b]",
                f"{As:.2f}·{fy:.0f}·({d:.1f} − {a_v/2:.3f})",
                f"{Mn/100_000:.3f} t·m")
            note = "✓" if Mr >= Mu - 1e-6 else "✗  Aumentar sección"
            self._fline("  Mr = FR·Mn",
                        f"{phi:.4f} · {Mn/100_000:.3f}",
                        f"{Mr:.3f} t·m  {note}")

    # ── Bloque CORTANTE ──────────────────────────────────────────────────────

    def _mfd_shear(self, sr, b, d, fc, fy_s, lam, FR_cort, is_ntc):
        sh = sr.shear
        self._grp_title(
            f"⚡  CORTANTE  —  Comb. más desfavorable (comb. {sr.comb_shear})")

        Vu   = sh.Vu
        Vcr  = sh.Vcr
        Vc   = sh.Vc
        Vmax = sh.Vmax
        Vsr  = sh.Vsr
        Avs  = sh.Avs
        sqfc = math.sqrt(fc)

        As_tens = max(sr.flex_pos.As, sr.flex_neg.As)
        rho     = As_tens / (b * d) if b * d > 0 else 0.0

        self._fline("Vu", "", f"{Vu:.3f} t")
        self._fline("As,tens = max(As+, As−)",
                    f"max({sr.flex_pos.As:.2f},  {sr.flex_neg.As:.2f})",
                    f"{As_tens:.2f} cm²")
        self._fline("ρ = As,tens / (bw·d)",
                    f"{As_tens:.2f} / ({b:.0f}·{d:.1f})",
                    f"{rho:.6f}")

        if is_ntc:
            Vcr_a = FR_cort * 0.5 * lam * sqfc * b * d / 1000
            Vcr_b = (FR_cort * 2.0 * lam * (rho ** (1/3)) * sqfc * b * d / 1000
                     if rho > 1e-12 else Vcr_a)
            Vcr_min_val = FR_cort * 0.08 * lam * sqfc * b * d / 1000
            Vcr_max_val = FR_cort * 0.42 * lam * sqfc * b * d / 1000
            self._fline(
                "Vcr,a = FR·0.5·λ·√f'c·bw·d / 1000  [NTC DEC §5.5.3.1.1.a]",
                f"{FR_cort}·0.5·{lam:.1f}·{sqfc:.3f}·{b:.0f}·{d:.1f} / 1000",
                f"{Vcr_a:.3f} t")
            self._fline(
                "Vcr,b = FR·2·λ·ρ^(1/3)·√f'c·bw·d / 1000  [NTC DEC §5.5.3.1.1.b]",
                f"{FR_cort}·2·{lam:.1f}·({rho:.6f})^(1/3)·{sqfc:.3f}·{b:.0f}·{d:.1f} / 1000",
                f"{Vcr_b:.3f} t")
            self._fline(
                "Vcr,mín = FR·0.08·λ·√f'c·bw·d/1000  [límite inferior §5.5.3.1.1]",
                f"{FR_cort}·0.08·{lam:.1f}·{sqfc:.3f}·{b:.0f}·{d:.1f}/1000",
                f"{Vcr_min_val:.3f} t")
            self._fline(
                "Vcr,máx = FR·0.42·λ·√f'c·bw·d/1000  [límite superior §5.5.3.1.1]",
                f"{FR_cort}·0.42·{lam:.1f}·{sqfc:.3f}·{b:.0f}·{d:.1f}/1000",
                f"{Vcr_max_val:.3f} t")
            self._fline(
                "Vcr = clamp(min(Vcr,a, Vcr,b),  Vcr,mín,  Vcr,máx)",
                f"clamp(min({Vcr_a:.3f}, {Vcr_b:.3f}),  {Vcr_min_val:.3f},  {Vcr_max_val:.3f})",
                f"{Vcr:.3f} t")
        else:
            self._fline(
                "Vcr = FR·0.53·λ·√f'c·bw·d / 1000  [ACI §22.5.5.1]",
                f"{FR_cort}·0.53·{lam:.1f}·{sqfc:.3f}·{b:.0f}·{d:.1f} / 1000",
                f"{Vcr:.3f} t")

        self._fline("Vc = Vcr / FR",
                    f"{Vcr:.3f} / {FR_cort}",
                    f"{Vc:.3f} t")
        note_vm = "✓" if Vu <= Vmax + 1e-6 else "✗  Aumentar sección"
        self._fline(
            "Vmax = FR·(Vc + 2.2·√f'c·bw·d / 1000)  [NTC DEC §5.5.2.2 / ACI §22.5.1.2]",
            f"{FR_cort}·({Vc:.3f} + 2.2·{sqfc:.3f}·{b:.0f}·{d:.1f} / 1000)",
            f"{Vmax:.3f} t  {note_vm}")
        self._fline("Vsr = max(Vu − Vcr,  0)",
                    f"max({Vu:.3f} − {Vcr:.3f},  0)",
                    f"{Vsr:.3f} t")

        if Vsr > 1e-6:
            self._fline(
                "Av/s = Vsr·1000 / (FR·fy,s·d)  [NTC DEC §5.5.3.6.1.b]",
                f"{Vsr:.3f}·1000 / ({FR_cort}·{fy_s:.0f}·{d:.1f})",
                f"{Avs:.4f} cm²/cm")
        else:
            self._fline(
                "  Vsr ≈ 0  →  Av/s = Av,mín  [NTC DEC §6.3.5.4 / ACI §9.6.3.4]",
                "",
                f"{Avs:.4f} cm²/cm")

        Av_min = max(0.2 * sqfc / fy_s, 3.5 / fy_s) * b
        self._fline(
            "Av,mín = max(0.2√f'c/fy,s,  3.5/fy,s)·bw  [NTC DEC §6.3.5.4]",
            f"max(0.2·{sqfc:.3f}/{fy_s:.0f},  3.5/{fy_s:.0f})·{b:.0f}",
            f"{Av_min:.4f} cm²/cm")

        self._fline("S(#3) = 2·0.71 / Av/s",
                    f"2·0.71 / {Avs:.4f}",
                    f"{sh.S3:.1f} cm")
        self._fline("S(#4) = 2·1.27 / Av/s",
                    f"2·1.27 / {Avs:.4f}",
                    f"{sh.S4:.1f} cm")
        self._fline("S(#5) = 2·1.99 / Av/s",
                    f"2·1.99 / {Avs:.4f}",
                    f"{sh.S5:.1f} cm")
        lim_v = 1.1 * sqfc * b * d / 1000
        smax_frm = (f"d/2 = {d:.1f}/2  (Vsr ≤ 1.1·√f'c·bw·d/1000)" if Vsr <= lim_v
                    else f"d/4 = {d:.1f}/4  (Vsr > 1.1·√f'c·bw·d/1000)")
        self._fline("Smax  [NTC DEC §6.3.7.5 / ACI §9.7.6.2.2]",
                    smax_frm, f"{sh.Smax:.1f} cm")

    # ── Bloque TORSIÓN ───────────────────────────────────────────────────────

    def _mfd_tor(self, sr, b, h, d, fc, fy, fy_s, lam,
                 FR_tor, rf, rc, rl, is_ntc):
        tor  = sr.torsion
        self._grp_title(
            f"🔄  TORSIÓN  —  Comb. más desfavorable (comb. {sr.comb_torsion})")

        Tu   = tor.Tu
        Tch  = tor.Tch
        sqfc = math.sqrt(fc)
        Acp  = b * h
        Pcp  = 2.0 * (b + h)

        self._fline("Acp = b · h",
                    f"{b:.0f} · {h:.0f}", f"{Acp:.0f} cm²")
        self._fline("Pcp = 2(b + h)",
                    f"2·({b:.0f} + {h:.0f})", f"{Pcp:.0f} cm")

        if is_ntc:
            self._fline(
                "Tch = FR·0.27·λ·√f'c·(Acp²/Pcp) / 100 000  [NTC DEC 2024 §5.8.2.5]",
                f"{FR_tor}·0.27·{lam:.1f}·{sqfc:.3f}"
                f"·({Acp:.0f}² / {Pcp:.0f}) / 100 000",
                f"{Tch:.4f} t·m")
        else:
            self._fline(
                "Tch = FR·0.000266·λ·√f'c·(Acp²/Pcp)  [ACI §22.7.1.1]",
                f"{FR_tor}·0.000266·{lam:.1f}·{sqfc:.3f}"
                f"·({Acp:.0f}² / {Pcp:.0f})",
                f"{Tch:.4f} t·m")

        self._fline("Tu", "", f"{Tu:.4f} t·m")

        if not tor.req_design:
            self._fline(
                f"  Tu = {Tu:.4f} < Tch = {Tch:.4f}  →",
                "", "No requiere diseño por torsión  ✓")
            return

        self._fline(
            f"  Tu = {Tu:.4f} ≥ Tch = {Tch:.4f}  →",
            "", "SE REQUIERE diseño por torsión")

        hi  = h - rf - rc
        bi  = b - 2.0 * rl
        Aoh = hi * bi
        ph  = 2.0 * (hi + bi)

        self._fline("hi = h − rec,flex − rec,comp",
                    f"{h:.1f} − {rf:.1f} − {rc:.1f}", f"{hi:.1f} cm")
        self._fline("bi = b − 2·rec,lat",
                    f"{b:.1f} − 2·{rl:.1f}", f"{bi:.1f} cm")
        self._fline("Aoh = hi · bi",
                    f"{hi:.1f} · {bi:.1f}", f"{Aoh:.1f} cm²")
        self._fline("ph  = 2(hi + bi)",
                    f"2·({hi:.1f} + {bi:.1f})", f"{ph:.1f} cm")

        if tor.cond_sec == "Aumentar sección":
            self._fline("  Verificación de sección:", "",
                        "✗  Aumentar sección")
            return

        At_s    = tor.At_s
        Ast     = tor.Ast
        Ast_min = tor.Ast_min
        Avtotal = tor.Avtotal

        self._fline(
            "At/s = Tu·100 000 / (FR·2·0.85·Aoh·fy,s)  [NTC DEC §5.8.3.2.2]",
            f"{Tu:.4f}·100 000 / ({FR_tor}·2·0.85·{Aoh:.1f}·{fy_s:.0f})",
            f"{At_s:.4f} cm²/cm")
        self._fline(
            "Ast = (At/s) · ph · (fy,s / fy)  [NTC DEC §5.8.3.2.3]",
            f"{At_s:.4f} · {ph:.1f} · ({fy_s:.0f} / {fy:.0f})",
            f"{tor.Ast:.3f} cm²")

        if is_ntc:
            min_a = 1.33*sqfc*Acp/fy - At_s*ph*fy_s/fy
            min_b = 1.33*sqfc*Acp/fy - 1.75*b/fy_s*ph*fy_s/fy
            self._fline(
                "Ast,mín,a = 1.33√f'c·Acp/fy − (At/s)·ph·fy,s/fy  [NTC DEC §6.3.5.5.3.a]",
                f"1.33·{sqfc:.3f}·{Acp:.0f}/{fy:.0f}"
                f" − {At_s:.4f}·{ph:.1f}·{fy_s:.0f}/{fy:.0f}",
                f"{min_a:.3f} cm²")
            self._fline(
                "Ast,mín,b = 1.33√f'c·Acp/fy − 1.75·bw/fy,s·ph·fy,s/fy  [§6.3.5.5.3.b]",
                f"1.33·{sqfc:.3f}·{Acp:.0f}/{fy:.0f}"
                f" − 1.75·{b:.0f}/{fy_s:.0f}·{ph:.1f}·{fy_s:.0f}/{fy:.0f}",
                f"{min_b:.3f} cm²")
            self._fline(
                "Ast,mín = min(a, b)  [NTC DEC §6.3.5.5.3]",
                f"min({min_a:.3f},  {min_b:.3f})",
                f"{Ast_min:.3f} cm²")
        else:
            min_aci = max(
                0.42*lam*sqfc*Acp/fy - At_s*ph*fy_s/fy, 0.0)
            self._fline(
                "Ast,mín = max(0.42λ√f'c·Acp/fy − (At/s)·ph·fy,s/fy,  0)"
                "  [ACI §9.6.4.2]",
                f"max(0.42·{lam:.1f}·{sqfc:.3f}·{Acp:.0f}/{fy:.0f}"
                f" − {At_s:.4f}·{ph:.1f}·{fy_s:.0f}/{fy:.0f},  0)",
                f"{Ast_min:.3f} cm²")

        self._fline("Ast = max(Ast,calc, Ast,mín)",
                    f"max({tor.Ast:.3f},  {Ast_min:.3f})",
                    f"{Ast:.3f} cm²")

        Avcort = Avtotal - At_s   # cortante contribution per arm (stored)
        self._fline(
            "Avcort,tor = Vsr·1000/(FR·fy,s·d)·0.5",
            f"{sr.shear.Vsr:.3f}·1000/({FR_tor}·{fy_s:.0f}·{d:.1f})·0.5",
            f"{Avcort:.4f} cm²/cm")
        self._fline(
            "(Av+At/s)Tot = At/s + Avcort,tor",
            f"{At_s:.4f} + {Avcort:.4f}",
            f"{Avtotal:.4f} cm²/cm")

        # El reparto lo decide el MOTOR con el criterio de separación de
        # §6.3.7.5.1 y viaja en el resultado: aquí estaba repetido, con el
        # umbral de 70 cm que no sale de ningún artículo.
        n_capas  = getattr(sr, "n_capas_tor", 2)
        sep      = getattr(sr, "sep_tor", 0.0)
        huecos   = max(n_capas - 1, 1)
        h_libre  = sep * huecos
        frac     = 1.0 / n_capas
        frac_lbl = f"1/{n_capas}"

        self._fline("Reparto del refuerzo longitudinal por torsión "
                    "[NTC 2023 DEC §6.3.7.5.1]")
        self._fline(
            "  Separación ≤ 300 mm alrededor del perímetro de estribos "
            "cerrados, con al menos una barra en cada esquina.")
        # d = h − rec_flex, y h_libre = h − rec_flex − rec_comp = d − rec_comp,
        # así que los dos recubrimientos salen de lo que ya se recibió.
        rec_f, rec_c = h - d, d - h_libre
        self._fline(
            "  h_libre = h − rec_flex − rec_comp    (entre centroides de lechos)",
            f"{h:.1f} − {rec_f:.1f} − {rec_c:.1f}",
            f"{h_libre:.1f} cm")
        self._fline(
            f"  n_huecos = techo(h_libre / {SEP_MAX_TORSION:.0f})",
            f"techo({h_libre:.1f} / {SEP_MAX_TORSION:.0f})",
            f"{huecos:d}")
        self._fline(
            "  n_capas = n_huecos + 1",
            f"{huecos:d} + 1",
            f"{n_capas:d}  ({n_capas - 2} intermedia(s))")
        self._fline(
            f"  s_real = h_libre / n_huecos  ≤  {SEP_MAX_TORSION:.0f} cm",
            f"{h_libre:.1f} / {huecos:d}",
            f"{sep:.1f} cm  "
            + ("CUMPLE" if sep <= SEP_MAX_TORSION + 1e-6 else "NO CUMPLE"))
        if n_capas > 2:
            self._fline(
                f"  Ast por capa intermedia = Ast · {frac_lbl}",
                f"{Ast:.3f} · {frac:.4f}",
                f"{Ast * frac:.2f} cm²  × {n_capas - 2} capa(s) "
                f"en caras laterales")
        # Mu+ arma el lecho SUPERIOR (convención de STAAD); se leen del
        # motor para no repetir la asignación.
        As_mas   = sr.As_sup_tot
        As_menos = sr.As_inf_tot
        self._fline(
            f"As(+)Tot = As,flex(+) + Ast · {frac_lbl}",
            f"{sr.flex_pos.As:.2f} + {Ast:.3f} · {frac:.4f}",
            f"{As_mas:.2f} cm²")
        self._fline(
            f"As(−)Tot = As,flex(−) + Ast · {frac_lbl}",
            f"{sr.flex_neg.As:.2f} + {Ast:.3f} · {frac:.4f}",
            f"{As_menos:.2f} cm²")

    # ═══════════════════════════════════════════════════════════════════════
    # Bloque Sísmico ACI 318-25 §18
    # ═══════════════════════════════════════════════════════════════════════

    def _sec_seismic_env(self, br):
        """Tabla y memoria de verificaciones sísmicas ACI 318-25 §18.4 / §18.6."""
        seis = br.envelope[0].seismic if br.envelope else None
        if seis is None:
            return

        is_smf = seis.frame_type == "SMF"
        ref = "ACI 318-25 §18.6" if is_smf else "ACI 318-25 §18.4"
        self._grp_title(f"{'🔴' if is_smf else '🟡'}  DISEÑO SÍSMICO — {ref}  ({seis.frame_type})")

        # ── tabla resumen de parámetros ────────────────────────────────────
        hdr = ["Parámetro", "Valor", "Referencia"]
        rows_data = []

        def _row(lbl, val, ref_str, ok=None):
            if ok is True:
                cond = "OK"
            elif ok is False:
                cond = "NO cumple"
            else:
                cond = ""
            rows_data.append(([lbl, val, ref_str + ("  " + cond if cond else "")],
                               ok is not False, False))

        _row("Tipo de marco",
             seis.frame_type,
             ref)
        _row("Longitud zona de confinamiento  lc",
             f"{seis.lc:.1f} cm",
             "§18.6.4.1" if is_smf else "§18.4.2.3")
        _row("Separacion max. estribos en zona  Sc",
             f"{seis.Sc:.1f} cm",
             "§18.6.4.4" if is_smf else "§18.4.2.4")
        _row("Separacion max. fuera de zona  S fuera",
             f"{seis.S_fuera:.1f} cm",
             "§18.6.4.5" if is_smf else "§18.4.2.5")
        _row("Primer estribo desde apoyo",
             f"{seis.primer_estribo:.1f} cm",
             "§18.6.4.3" if is_smf else "§18.4.2.3")
        if is_smf:
            _row("Momento probable positivo  Mpr,i",
                 f"{seis.Mpr_i:.3f} t·m",
                 "§18.6.5.1  (1.25 fy)")
            _row("Momento probable negativo  Mpr,j",
                 f"{seis.Mpr_j:.3f} t·m",
                 "§18.6.5.1  (1.25 fy)")
            _row("Cortante gravitacional  Vg",
                 f"{seis.Vg:.3f} t",
                 "§18.6.5.1  comb. grav.")
            _row("Cortante de diseno sismico  Ve",
                 f"{seis.Ve:.3f} t",
                 "§18.6.5.1  Ve = (Mpr,i+Mpr,j)/Ln + Vg")
            _row("Vc = 0  (Vu,sismo >= 0.5 Ve)",
                 "SI — Vc = 0" if seis.Vc_cero else "NO — Vc activo",
                 "§18.6.3.2")
            _row("Cuantia longitudinal  rho <= 0.025",
                 "Cumple" if seis.rho_max_ok else "NO cumple",
                 "§18.6.3.3",
                 ok=seis.rho_max_ok)
            _row("Mr(+) >= 1/2 Mr(-)  en apoyos",
                 "Cumple" if seis.Mr_pos_ok else "NO cumple",
                 "§18.6.3.4",
                 ok=seis.Mr_pos_ok)
            _row("Mr >= 1/4 Mr,max  en cualquier seccion",
                 "Cumple" if seis.Mr_min_ok else "NO cumple",
                 "§18.6.3.5",
                 ok=seis.Mr_min_ok)
        else:
            _row("Cuantia longitudinal  rho <= 0.025",
                 "Cumple" if seis.rho_max_ok else "NO cumple",
                 "§18.4",
                 ok=seis.rho_max_ok)

        self._write_table(hdr, rows_data)

        # ── memoria de fórmulas (SMF) ──────────────────────────────────────
        if is_smf:
            self._fline("Mpr = As · 1.25fy · (d − a/2)     a = As·1.25fy / (0.85f'c·b)",
                        "", "")
            self._fline("  Mpr,i (inicio)",  "", f"{seis.Mpr_i:.3f} t·m")
            self._fline("  Mpr,j (fin)",     "", f"{seis.Mpr_j:.3f} t·m")
            self._fline("Ve = (Mpr,i + Mpr,j) / Ln  +  Vg  [§18.6.5.1]",
                        f"({seis.Mpr_i:.3f} + {seis.Mpr_j:.3f}) / Ln  +  {seis.Vg:.3f}",
                        f"{seis.Ve:.3f} t")
            if seis.Vc_cero:
                self._fline("  Vu,sismo >= 0.5·Ve  =>  Vc = 0  [§18.6.3.2]",
                            "", "Vc = 0, Vcr = 0  —  Vs = Ve  (calculado)")
            else:
                self._fline("  Vu,sismo < 0.5·Ve  =>  Vc activo  [§18.6.3.2]",
                            "", "Vc se conserva segun §22.5")

        # ── advertencias ─────────────────────────────────────────────────
        if seis.warnings:
            p = self.doc.add_paragraph()
            r = p.add_run("Advertencias:")
            r.bold = True
            r.font.size = Pt(7)
            r.font.color.rgb = _rgb("#7D6608")
            p.paragraph_format.left_indent = Cm(0.6)
            for w in seis.warnings:
                pw = self.doc.add_paragraph(f"  * {w}")
                pw.paragraph_format.left_indent = Cm(1.0)
                pw.paragraph_format.space_before = Pt(0)
                pw.paragraph_format.space_after  = Pt(1)
                if pw.runs:
                    pw.runs[0].font.size = Pt(7)
                    pw.runs[0].font.color.rgb = _rgb("#784212")

    # ── Helpers de formato para fórmulas ─────────────────────────────────────

    def _fline(self, label: str, formula: str = "", result: str = ""):
        """
        Escribe una línea de fórmula con el formato:
          label  =  formula  =  result
        Si formula está vacío:  label  =  result
        Si ambos vacíos:        label  (línea de cabecera/separador)
        """
        p = self.doc.add_paragraph()
        p.paragraph_format.left_indent  = Cm(0.6)
        p.paragraph_format.space_before = Pt(0.5)
        p.paragraph_format.space_after  = Pt(0.5)

        # Label (concepto)
        rl = p.add_run(label)
        rl.font.size      = Pt(7)
        rl.font.color.rgb = _rgb("#1C2833")
        rl.bold           = not formula and not result

        # Desarrollo numérico
        if formula:
            sep = p.add_run("  =  ")
            sep.font.size = Pt(7)
            rf2 = p.add_run(formula)
            rf2.font.size      = Pt(7)
            rf2.font.color.rgb = _rgb("#2C3E50")

        # Resultado final
        if result:
            sep2 = p.add_run("  =  " if formula else "  ")
            sep2.font.size = Pt(7)
            rr = p.add_run(result)
            rr.font.size = Pt(7)
            rr.bold      = True
            if "✓" in result:
                rr.font.color.rgb = _rgb("#1E8449")
            elif "✗" in result or "Aumentar" in result:
                rr.font.color.rgb = _rgb("#C0392B")
            elif "No req" in result:
                rr.font.color.rgb = _rgb("#7D6608")
            else:
                rr.font.color.rgb = _rgb("#1A5276")

    def _fsep(self, text: str):
        """Separador de sub-bloque dentro de la memoria (lecho sup / inf)."""
        p = self.doc.add_paragraph()
        p.paragraph_format.left_indent  = Cm(0.4)
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after  = Pt(1)
        r = p.add_run(f"── {text} {'─' * 40}")
        r.font.size      = Pt(6.5)
        r.font.color.rgb = _rgb("#7F8C8D")

    # ═══════════════════════════════════════════════════════════════════════
    # Diagramas 2D de sección transversal
    # ═══════════════════════════════════════════════════════════════════════

    def _add_section_diagrams(self, br, params: dict):
        """
        Genera e inserta los 3 diagramas de sección transversal (Inicio/Mitad/Fin)
        para una barra, con el refuerzo propuesto (varillas y estribos).
        Si matplotlib no está disponible, inserta un aviso de texto.
        """
        try:
            from design.section_diagram import generate_section_diagrams
            png_bytes = generate_section_diagrams(br, params)
        except Exception as exc:
            self._grp_title("📏  DIAGRAMAS 2D — Secciones transversales")
            p = self.doc.add_paragraph(
                f"  ⚠  No se pudieron generar los diagramas: {exc}\n"
                "  Instale matplotlib con:  pip install matplotlib")
            if p.runs:
                p.runs[0].font.size = Pt(7)
            return

        if not png_bytes:
            return

        self._grp_title(
            "📏  DIAGRAMAS 2D — Secciones transversales con refuerzo propuesto")

        # Nota de interpretación
        nota_lines = [
            "Los diagramas muestran el refuerzo mínimo propuesto que satisface los resultados "
            "del diseño en cada sección.",
            "Barras rojas = lecho superior (As−)  ·  Barras azules = lecho inferior (As+)  "
            "·  Barras verdes = capa intermedia (torsión/temperatura).",
            "Separación mínima entre barras: max(ø_var, 2.5 cm)  [NTC DEC 2024 §14.2]. "
            "Las separaciones de estribos están redondeadas a múltiplos de 5 cm.",
        ]
        for line in nota_lines:
            p = self.doc.add_paragraph(line)
            p.paragraph_format.left_indent = Cm(0.6)
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after  = Pt(1)
            if p.runs:
                p.runs[0].font.size = Pt(6.5)
                p.runs[0].font.color.rgb = _rgb("#5D6D7E")

        # Insertar imagen
        try:
            buf = io.BytesIO(png_bytes)
            pic_para = self.doc.add_paragraph()
            pic_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = pic_para.add_run()
            run.add_picture(buf, width=Cm(24.0))
        except Exception as exc2:
            p = self.doc.add_paragraph(f"  ⚠  Error al insertar imagen: {exc2}")
            if p.runs:
                p.runs[0].font.size = Pt(7)
        self.doc.add_paragraph()

    # ═══════════════════════════════════════════════════════════════════════
    # Configuración de página (landscape A4)
    # ═══════════════════════════════════════════════════════════════════════

    def _page_landscape(self):
        # Hoja CARTA apaisada (tablas de trabes de hasta 13 columnas) + fuente
        # base unificada de la suite y títulos sin numeración automática.
        try:
            from suite_shared.docx_style import aplicar_estilo_memoria
            aplicar_estilo_memoria(self.doc, apaisado=True)
        except Exception:
            sec = self.doc.sections[0]
            sec.orientation = WD_ORIENTATION.LANDSCAPE
            sec.page_width, sec.page_height = Cm(27.94), Cm(21.59)
            self.doc.styles["Normal"].font.name = "Calibri"
