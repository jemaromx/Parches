"""
BeamDesignPro — Punto de entrada.

Uso:
    python main.py

Requiere:
    PySide6, openstaadpy, openpyxl, python-docx, ezdxf
"""
import sys
from pathlib import Path

# ── suite_shared ──────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ── Gate de licencia (seguridad, auditoría #1/#3): cada punto de entrada
#    verifica la licencia ANTES de ejecutar. La decisión vive en license_core (.pyd).
try:
    from suite_shared.licensing.license_core import gate_o_salir as _gate
    _gate("beam_design_pro", gui=("--batch" not in sys.argv))
except ImportError:
    pass

# ── Modo batch headless (ADR-001) — despachar ANTES de importar Qt ────────────
# `python main.py --batch entrada.json salida.json` disena sin levantar PySide6.
if "--batch" in sys.argv:
    from batch import main as _batch_main
    _i = sys.argv.index("--batch")
    raise SystemExit(_batch_main(["batch", *sys.argv[_i + 1:]]))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.splash import make_splash

log = setup_logging("beam_design_pro")
install_excepthook("beam_design_pro")

# ── PySide6 ───────────────────────────────────────────────────────────────────
from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import Qt, QTimer

from config.settings import APP_NAME, APP_VERSION
from gui.main_window import MainWindow

def _make_splash():
    return make_splash(APP_NAME, "Diseño de Trabes de Concreto Reforzado", APP_VERSION, "NTC 2023 / ACI 318-25")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    # Asegurar DPI correcto en Windows con pantallas de alta resolución

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("BeamDesignPro")

    log.info("Iniciando %s v%s", APP_NAME, APP_VERSION)

    # Splash
    splash = _make_splash()
    splash.show()
    app.processEvents()

    # Ventana principal (construcción diferida para que el splash se vea)
    window = MainWindow()

    def _show_window():
        splash.finish(window)
        window.showMaximized()   # abre siempre maximizado → ambos paneles visibles
        log.info("Ventana principal lista.")

    QTimer.singleShot(400, _show_window)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
