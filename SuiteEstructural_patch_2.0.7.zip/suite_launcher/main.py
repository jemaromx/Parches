﻿"""
Struct-Link — Launcher
Punto de entrada.
"""
import sys
from pathlib import Path

_HERE       = Path(__file__).resolve().parent         # suite_launcher/
_SUITE_ROOT = _HERE.parent                            # raíz de la suite

# suite_launcher/ y la raíz de la suite en sys.path
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from suite_shared.logging_setup  import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.version        import SUITE_VERSION

log = setup_logging("launcher")
install_excepthook("launcher")

from PySide6.QtWidgets import QApplication


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Struct-Link")
    app.setApplicationVersion(SUITE_VERSION)

    from gui.main_window import MainWindow
    window = MainWindow()
    window.show()

    # Verificar parches/actualizaciones sin bloquear el arranque
    def _check_patches():
        try:
            from patches.patch_manager import PatchManager
            PatchManager().check_on_startup(window)
        except Exception as exc:
            log.debug("Chequeo de parches omitido: %s", exc)

    from PySide6.QtCore import QTimer
    QTimer.singleShot(2500, _check_patches)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
