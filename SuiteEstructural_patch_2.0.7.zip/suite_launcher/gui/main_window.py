﻿"""
MainWindow del Launcher — Struct-Link.

Composición (ver mapa de distribución entregado al usuario):
    Header  →  Barra de categorías (filtro segmentado)  →
    Grid de ToolCards (con scroll)  →  StatusBar

Cada tarjeta lanza su módulo correspondiente como PROCESO INDEPENDIENTE
(`python main.py` dentro de la carpeta del proyecto). Esto evita choques
entre instancias de QApplication y entre los entornos/():dependencias
propios de cada script auditado — no se modifica el código de ninguno.
"""

import subprocess
import sys
from datetime import datetime
from pathlib import Path

import qtawesome as qta
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QFrame, QLabel, QVBoxLayout, QHBoxLayout,
    QGridLayout, QScrollArea, QPushButton, QStatusBar, QMessageBox,
)

from config.settings import (
    COLORS, CATEGORY_COLORS, CATEGORY_LABELS, CATEGORY_ICONS,
    MODULES, PROJECTS_ROOT,
    WINDOW_DEFAULT_SIZE, WINDOW_MINIMUM_SIZE,
    HEADER_HEIGHT, CATEGORY_BAR_HEIGHT, GRID_COLUMNS, GRID_SPACING,
    FONT_APP_TITLE, FONT_APP_SUB, FONT_VERSION,
)
from gui.styles import MAIN_STYLE
from gui.tool_card import ToolCard


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._current_category = "todas"
        self._category_buttons = {}
        self._processes = []          # referencias a subprocess.Popen activos

        self.setWindowTitle("Struct-Link — Launcher")
        _ico = Path(__file__).resolve().parent.parent.parent / "installer" / "suite_icon.ico"
        if _ico.exists():
            self.setWindowIcon(QIcon(str(_ico)))
        self.resize(*WINDOW_DEFAULT_SIZE)
        self.setMinimumSize(*WINDOW_MINIMUM_SIZE)
        self.setStyleSheet(MAIN_STYLE)

        self._build_ui()
        self._populate_cards()

        # Reloj del header
        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)
        self._update_clock()

        # Estado de licencia (licenciada / gracia / expirada)
        self._lic_estado, self._lic_detalle = "gracia", ""
        self._refresh_license_status()
        if self._lic_estado == "expirada":
            QTimer.singleShot(600, self._show_activation)

    # ================================================================== UI ==
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())
        root.addWidget(self._build_category_bar())
        root.addWidget(self._build_card_area(), 1)

        self._build_status_bar()

    # ---- Header --------------------------------------------------------
    def _build_header(self):
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(HEADER_HEIGHT)

        lay = QHBoxLayout(header)
        lay.setContentsMargins(24, 0, 24, 0)
        lay.setSpacing(14)

        icon_label = QLabel()
        _suite_root = Path(__file__).resolve().parent.parent.parent
        _candidates = [_suite_root / "suite_icon.ico", _suite_root / "installer" / "suite_icon.ico"]
        _suite_ico = next((p for p in _candidates if p.exists()), None)
        if _suite_ico:
            icon_label.setPixmap(QIcon(str(_suite_ico)).pixmap(34, 34))
        else:
            icon_label.setPixmap(qta.icon("fa5s.drafting-compass", color=COLORS["accent"]).pixmap(30, 30))
        lay.addWidget(icon_label)

        text_col = QVBoxLayout()
        text_col.setSpacing(2)

        title = QLabel("STRUCT-LINK")
        title.setObjectName("appTitle")
        title.setFont(self._font(*FONT_APP_TITLE))
        text_col.addWidget(title)

        subtitle = QLabel("Centralizador de herramientas de diseño · NTC / ACI 318 / AISC 360")
        subtitle.setObjectName("appSubtitle")
        subtitle.setFont(self._font(*FONT_APP_SUB))
        text_col.addWidget(subtitle)

        lay.addLayout(text_col)
        lay.addStretch(1)

        self._clock_label = QLabel()
        self._clock_label.setObjectName("appVersion")
        self._clock_label.setFont(self._font(*FONT_VERSION))
        self._clock_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lay.addWidget(self._clock_label)

        return header

    # ---- Barra de categorías -------------------------------------------
    def _build_category_bar(self):
        bar = QFrame()
        bar.setObjectName("categoryBar")
        bar.setFixedHeight(CATEGORY_BAR_HEIGHT)

        lay = QHBoxLayout(bar)
        lay.setContentsMargins(24, 0, 24, 0)
        lay.setSpacing(10)

        for key in ("todas", "mamposteria", "concreto", "acero"):
            btn = QPushButton(f"  {CATEGORY_LABELS[key]}")
            btn.setProperty("class", "categoryBtn")
            btn.setIcon(qta.icon(CATEGORY_ICONS[key], color=COLORS["text_dim"]))
            btn.setCursor(Qt.PointingHandCursor)
            btn.setCheckable(True)
            btn.clicked.connect(lambda _checked, k=key: self._filter_by_category(k))
            lay.addWidget(btn)
            self._category_buttons[key] = btn

        lay.addStretch(1)
        self._set_active_category_button("todas")
        return bar

    # ---- Área de tarjetas (scroll + grid) -------------------------------
    def _build_card_area(self):
        self._scroll = QScrollArea()
        self._scroll.setObjectName("cardArea")
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self._card_container = QWidget()
        self._card_container.setObjectName("cardContainer")
        self._grid = QGridLayout(self._card_container)
        self._grid.setContentsMargins(24, 24, 24, 24)
        self._grid.setSpacing(GRID_SPACING)
        self._grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        self._scroll.setWidget(self._card_container)
        return self._scroll

    # ---- StatusBar -------------------------------------------------------
    def _build_status_bar(self):
        bar = QStatusBar()
        self.setStatusBar(bar)

        self._status_label = QLabel(f"  Listo · {len(MODULES)} módulos disponibles")
        bar.addWidget(self._status_label)

        self._lic_label = QLabel("")
        self._lic_label.setCursor(Qt.PointingHandCursor)
        self._lic_label.mousePressEvent = lambda e: self._show_activation()
        bar.addPermanentWidget(self._lic_label)

        from suite_shared.version import SUITE_VERSION
        version_label = QLabel(f"Struct-Link v{SUITE_VERSION} · PySide6  ")
        bar.addPermanentWidget(version_label)

    # ============================================================ Tarjetas ==
    def _populate_cards(self):
        """(Re)crea las tarjetas visibles según la categoría activa."""
        # limpiar grid
        while self._grid.count():
            item = self._grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)

        if self._current_category == "todas":
            visible = MODULES
        else:
            visible = [m for m in MODULES if m["category"] == self._current_category]

        for index, module in enumerate(visible):
            row, col = divmod(index, GRID_COLUMNS)
            card = ToolCard(module)
            card.clicked.connect(self._launch_module)
            self._grid.addWidget(card, row, col)

        self._status_label.setText(f"  Listo · {len(visible)} módulo(s) en esta vista")

    def _filter_by_category(self, key: str):
        self._current_category = key
        self._set_active_category_button(key)
        self._populate_cards()

    def _set_active_category_button(self, active_key: str):
        for key, btn in self._category_buttons.items():
            is_active = (key == active_key)
            btn.setChecked(is_active)
            btn.setProperty("active", "true" if is_active else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            icon_color = "#0B1622" if is_active else COLORS["text_dim"]
            btn.setIcon(qta.icon(CATEGORY_ICONS[key], color=icon_color))

    # ============================================================ Lanzar ====
    def _launch_module(self, module_id: str):
        if self._lic_estado == "expirada":
            self._show_activation()
            if self._lic_estado == "expirada":
                return
        module = next((m for m in MODULES if m["id"] == module_id), None)
        if module is None:
            return

        candidates = module["folder"]
        if isinstance(candidates, str):
            candidates = [candidates]

        project_dir = None
        entry_path = None
        for folder in candidates:
            cand_dir = PROJECTS_ROOT / folder
            cand_entry = cand_dir / module["entry"]
            if cand_entry.exists():
                project_dir, entry_path = cand_dir, cand_entry
                break

        if entry_path is None:
            tried = "\n".join(str(PROJECTS_ROOT / f / module["entry"]) for f in candidates)
            QMessageBox.warning(
                self, "Módulo no encontrado",
                f"No se encontró el script de entrada. Rutas probadas:\n{tried}"
            )
            return

        title_oneline = module["title"].replace("\n", " ")
        self._status_label.setText(f"  Abriendo: {title_oneline}…")
        try:
            proc = subprocess.Popen(
                [sys.executable, str(entry_path)],
                cwd=str(project_dir),
            )
            self._processes.append(proc)
            self._status_label.setText(f"  ✔  {title_oneline} iniciado (PID {proc.pid})")
        except OSError as exc:
            QMessageBox.critical(
                self, "Error al iniciar el módulo",
                f"No fue posible iniciar '{title_oneline}':\n{exc}"
            )
            self._status_label.setText(f"  ✗  Error al iniciar {title_oneline}")

    # ============================================================== Util ====
    @staticmethod
    def _font(family, size, weight=None):
        from PySide6.QtGui import QFont
        f = QFont(family, size)
        if weight == "Bold":
            f.setBold(True)
        return f

    # ========================================================== Licencia ==
    def _refresh_license_status(self):
        try:
            from suite_shared.licensing import estado_licencia
            self._lic_estado, self._lic_detalle = estado_licencia()
        except Exception:
            self._lic_estado, self._lic_detalle = "gracia", ""
        colores = {"licenciada": "#2ECC71", "gracia": "#F39C12",
                   "expirada": "#E74C3C"}
        textos  = {"licenciada": "● Licenciada",
                   "gracia":     "● " + self._lic_detalle,
                   "expirada":   "● Sin licencia — clic para activar"}
        if hasattr(self, "_lic_label"):
            self._lic_label.setText(textos.get(self._lic_estado, "") + "  ")
            self._lic_label.setStyleSheet(
                "color: " + colores.get(self._lic_estado, "#999") + ";")

    def _show_activation(self):
        try:
            from gui.activation_dialog import ActivationDialog
        except Exception as exc:
            QMessageBox.warning(self, "Licencia",
                                "No fue posible abrir la activacion: "
                                + str(exc))
            return
        dlg = ActivationDialog(self, self._lic_estado, self._lic_detalle)
        dlg.exec()
        self._refresh_license_status()

    def _update_clock(self):
        now = datetime.now().strftime("%a %d %b %Y · %H:%M")
        self._clock_label.setText(now)

    # closeEvent: los módulos lanzados siguen como procesos independientes,
    # así que no requieren confirmación (no comparten hilo/recursos con el launcher).
