﻿# ui/main_window.py  —  Column Steel Design Pro
from __future__ import annotations
import logging, traceback, math
from typing import List, Dict, Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QSplitter,
    QTabWidget, QLabel, QStatusBar, QProgressBar, QMessageBox,
    QFileDialog, QApplication, QPushButton, QGroupBox,
    QDoubleSpinBox, QSpinBox, QLineEdit, QComboBox, QScrollArea,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QDialog, QDialogButtonBox, QTextEdit, QRadioButton, QButtonGroup,
    QCheckBox, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, QThread, QObject, Signal
from PySide6.QtGui  import QFont, QColor, QBrush, QKeySequence

import numpy as np
import matplotlib
matplotlib.use("QtAgg")
from mpl_toolkits.mplot3d import Axes3D          # noqa: F401
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from matplotlib.lines  import Line2D

from config.settings import (APP_NAME, APP_VERSION, COLORS,
                              NTC_FR_FLEX, NTC_FR_SHEAR, NTC_FR_COMP,
                              AISC_PHI_B, AISC_PHI_V, AISC_PHI_C)
from design.materials     import SteelMaterial
from design.section_types import SectionProperties, SectionKind
from design.column_design import (design_member, MemberDesignResult, ComboCheck,
                                   build_3d_interaction_surface)
from design.k_factor      import BOUNDARY_PRESETS, k_braced_approx, k_sway_approx
from ui.styles import MAIN_STYLE

log = logging.getLogger(__name__)

# ── Paleta de tabla ───────────────────────────────────────────────────────────
C_OK   = QColor("#D5F5E3")
C_FAIL = QColor("#FADBD8")
C_WARN = QColor("#FAD7A0")   # naranja: KL/r excedida con ratios <= 1
C_SEP  = QColor(COLORS["primary"])

# Estilo de QGroupBox del panel de 2° orden: reserva espacio para el título
# (al fijar solo font-size, Qt pierde el margen del título y este se encima
# con el primer widget del grupo).
_GRP_STYLE_SO = (
    "QGroupBox { font-size:8pt; margin-top:9px; padding:6px 4px 4px 4px; }"
    "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; "
    "left:6px; padding:0 3px; }"
)

# Colores fijos (compatible con todas las versiones de matplotlib)
_COLORS_10 = ['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd',
              '#8c564b','#e377c2','#7f7f7f','#bcbd22','#17becf']


def _h_expr(cc: ComboCheck) -> str:
    """Expresion de interaccion con valores sustituidos (NTC o AISC)."""
    if cc.H_eq == "NTC-9.1.6.2.a":
        mx_b = cc.mx_ratio**cc.beta if cc.mx_ratio > 1e-9 else 0.0
        my_b = cc.my_ratio**cc.beta if cc.my_ratio > 1e-9 else 0.0
        return (f"NTC-9.1.6.2.a b={cc.beta:.2f}: "
                f"Pu/Rc={cc.pn_ratio:.3f} | "
                f"({cc.mx_ratio:.3f})^b+({cc.my_ratio:.3f})^b"
                f"={mx_b+my_b:.4f} => H={cc.H_ratio:.4f}")
    elif cc.H_eq.startswith("NTC"):
        denom = "Rt" if "9.2" in cc.H_eq else "Rc"
        return (f"{cc.H_eq}: Pu/{denom}={cc.pn_ratio:.3f}+"
                f"Mux={cc.mx_ratio:.3f}+Muy={cc.my_ratio:.3f}={cc.H_ratio:.4f}")
    elif cc.H_eq == "H1-1a":
        return (f"H1-1a: {cc.pn_ratio:.3f}+(8/9)*"
                f"({cc.mx_ratio:.3f}+{cc.my_ratio:.3f})={cc.H_ratio:.4f}")
    else:
        return (f"H1-1b: {cc.pn_ratio:.3f}/2+"
                f"{cc.mx_ratio:.3f}+{cc.my_ratio:.3f}={cc.H_ratio:.4f}")


# ══════════════════════════════════════════════════════════════════════════════
# Tabla con copia al portapapeles (Ctrl+C → Excel / Word)
# ══════════════════════════════════════════════════════════════════════════════

class CopyableTable(QTableWidget):
    """
    QTableWidget que soporta Ctrl+C para copiar celdas seleccionadas al
    portapapeles en formato TSV (Tab-Separated Values), compatible con
    Excel y Word directamente al pegar.
    """

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self._copy_to_clipboard()
        else:
            super().keyPressEvent(event)

    def _copy_to_clipboard(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r_min = min(r.topRow()     for r in ranges)
        r_max = max(r.bottomRow()  for r in ranges)
        c_min = min(r.leftColumn() for r in ranges)
        c_max = max(r.rightColumn() for r in ranges)

        # Incluir encabezados de columna
        headers = []
        for col in range(c_min, c_max + 1):
            h = self.horizontalHeaderItem(col)
            headers.append(h.text() if h else "")

        lines = ["\t".join(headers)]
        for row in range(r_min, r_max + 1):
            cells = []
            for col in range(c_min, c_max + 1):
                item = self.item(row, col)
                cells.append(item.text().strip() if item else "")
            lines.append("\t".join(cells))

        QApplication.clipboard().setText("\n".join(lines))


# ══════════════════════════════════════════════════════════════════════════════
# Dialogo K factor
# ══════════════════════════════════════════════════════════════════════════════

class KDetailDialog(QDialog):
    """
    Muestra la memoria de calculo detallada del factor K para todos
    los miembros procesados con Auto K — AISC App.7.
    Incluye formulas, referencias normativas y operaciones numericas.
    """

    def __init__(self, detail_texts: list, parent=None):
        """
        detail_texts: lista de (mid, perfil, Ky, Kz, texto_detalle)
        """
        super().__init__(parent)
        self.setWindowTitle("Memoria de Calculo — Factor K  (AISC 360-22 App.7)")
        self.setMinimumSize(900, 620)
        self.setStyleSheet(MAIN_STYLE)
        self._detail_texts = detail_texts
        self._build(detail_texts)

    def _build(self, data: list):
        v = QVBoxLayout(self); v.setSpacing(6)

        # ── Encabezado ─────────────────────────────────────────────────────────
        hdr = QLabel(
            "  Factor de Longitud Efectiva K — Calculo por Abaco de Alineacion"
            "  |  AISC 360-22 Apendice 7  /  NTC Acero CDMX 2024 Art.3.6.3  ")
        hdr.setStyleSheet(
            "background:#1B4F72; color:white; font-weight:bold; "
            "font-size:10pt; padding:4px;")
        v.addWidget(hdr)

        # ── Selector de miembro ────────────────────────────────────────────────
        if len(data) > 1:
            sh = QHBoxLayout()
            sh.addWidget(QLabel("Miembro:"))
            self._cmb = QComboBox()
            for mid, perfil, Ky, Kz, _ in data:
                self._cmb.addItem(
                    f"Barra {mid}  —  {perfil}   Ky={Ky:.4f}  Kz={Kz:.4f}")
            self._cmb.currentIndexChanged.connect(self._show_idx)
            sh.addWidget(self._cmb, 1)
            v.addLayout(sh)

        # ── Texto de calculo ───────────────────────────────────────────────────
        self._txt = QTextEdit()
        self._txt.setReadOnly(True)
        self._txt.setFont(QFont("Courier New", 8))
        self._txt.setLineWrapMode(QTextEdit.NoWrap)
        v.addWidget(self._txt, 1)

        # ── Botones ────────────────────────────────────────────────────────────
        bh = QHBoxLayout()
        btn_all  = QPushButton("Ver todo (todos los miembros)")
        btn_word = QPushButton("Exportar a Word")
        btn_word.setObjectName("btnGreen")
        btn_cls  = QPushButton("Cerrar")
        btn_all.clicked.connect(self._show_all)
        btn_word.clicked.connect(self._export_word)
        btn_cls.clicked.connect(self.accept)
        bh.addWidget(btn_all); bh.addWidget(btn_word); bh.addStretch()
        bh.addWidget(btn_cls)
        v.addLayout(bh)

        # Mostrar primer miembro
        if data:
            self._show_idx(0)

    def _show_idx(self, idx: int):
        if 0 <= idx < len(self._detail_texts):
            _, _, _, _, texto = self._detail_texts[idx]
            self._txt.setPlainText(texto)
            from PySide6.QtGui import QTextCursor
            self._txt.moveCursor(QTextCursor.MoveOperation.Start)

    def _show_all(self):
        """Concatena los detalles de todos los miembros."""
        lines = []
        for mid, perfil, Ky, Kz, texto in self._detail_texts:
            lines.append(texto)
            lines.append("")
        self._txt.setPlainText("\n".join(lines))
        from PySide6.QtGui import QTextCursor
        self._txt.moveCursor(QTextCursor.MoveOperation.Start)

    def _export_word(self):
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar memoria K", "", "Word (*.docx)")
        if not path:
            return
        try:
            _export_k_detail_word(self._detail_texts, path)
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(self, "Word", f"Exportado:\n{path}")
        except Exception as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "Error", str(exc))


def _export_k_detail_word(data: list, path: str) -> None:
    """Exporta la memoria de calculo de K a un documento Word."""
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from datetime import datetime
    except ImportError:
        raise ImportError("Instale python-docx:  pip install python-docx")

    doc = Document()

    # Portada / encabezado
    h = doc.add_heading("MEMORIA DE CALCULO", 0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    h.runs[0].font.color.rgb = RGBColor(0x1B, 0x4F, 0x72)

    sub = doc.add_paragraph("Factor de Longitud Efectiva K")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.runs[0].font.size = Pt(13); sub.runs[0].font.bold = True
    sub.runs[0].font.color.rgb = RGBColor(0x1B, 0x4F, 0x72)

    ref = doc.add_paragraph(
        "AISC 360-22 Apendice 7 — Alignment Chart  "
        "/  NTC Acero CDMX 2024 Art.3.6.3")
    ref.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ref.runs[0].font.size = Pt(10)

    fecha = doc.add_paragraph(
        f"Fecha: {datetime.now().strftime('%d/%m/%Y  %H:%M hrs')}")
    fecha.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fecha.runs[0].font.size = Pt(9)

    doc.add_page_break()

    for mid, perfil, Ky, Kz, texto in data:
        doc.add_heading(
            f"Miembro {mid}  —  {perfil}   "
            f"Ky = {Ky:.4f}   Kz = {Kz:.4f}", level=1)
        p = doc.add_paragraph()
        run = p.add_run(texto)
        run.font.name = "Courier New"
        run.font.size = Pt(7)
        doc.add_page_break()

    doc.save(path)


class KSimpleDialog(QDialog):
    """
    Dialogo simplificado para asignar el factor K manualmente.
    Sin nomograma. Permite:
      - Presets de condicion de contorno
      - Ingreso manual de Ky y Kz
    """
    def __init__(self, Ky0: float = 1.0, Kz0: float = 1.0, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Factor K — Asignacion Manual")
        self.setMinimumWidth(380)
        self.setStyleSheet(MAIN_STYLE)
        self.Ky_result = Ky0
        self.Kz_result = Kz0
        self._build()

    def _build(self):
        v = QVBoxLayout(self); v.setSpacing(10)

        # ── Presets ────────────────────────────────────────────────────────────
        g1 = QGroupBox("Preset de condicion de contorno")
        gv = QVBoxLayout(g1)
        note = QLabel("Seleccione un preset o ingrese Ky/Kz manualmente:")
        note.setStyleSheet("font-size:8pt; color:#555;")
        gv.addWidget(note)
        self.cmb_pre = QComboBox()
        self.cmb_pre.addItem("-- Seleccionar preset --")
        for k in BOUNDARY_PRESETS:
            self.cmb_pre.addItem(k)
        self.cmb_pre.currentIndexChanged.connect(self._preset)
        gv.addWidget(self.cmb_pre)
        v.addWidget(g1)

        # ── Valores manuales ───────────────────────────────────────────────────
        g2 = QGroupBox("Valores de K a aplicar")
        gv2 = QVBoxLayout(g2)
        for attr, lbl, val in [
            ("spn_Ky", "Ky  (eje debil  — pandeo en plano XY):", self.Ky_result),
            ("spn_Kz", "Kz  (eje fuerte — pandeo en plano XZ):", self.Kz_result),
        ]:
            row = QHBoxLayout()
            row.addWidget(QLabel(lbl))
            s = QDoubleSpinBox()
            s.setRange(0.1, 5.0); s.setValue(val)
            s.setDecimals(4); s.setSingleStep(0.05)
            setattr(self, attr, s)
            row.addWidget(s)
            gv2.addLayout(row)
        v.addWidget(g2)

        # ── Nota ───────────────────────────────────────────────────────────────
        note2 = QLabel(
            "Para calculo automatico desde el modelo STAAD,\n"
            "use el boton  [Auto K — AISC App.7]  en la tabla de miembros.")
        note2.setStyleSheet("font-size:8pt; color:#777; font-style:italic;")
        v.addWidget(note2)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def _preset(self, idx: int):
        if idx <= 0:
            return
        key = self.cmb_pre.currentText()
        if key in BOUNDARY_PRESETS:
            Ky, Kz = BOUNDARY_PRESETS[key]
            self.spn_Ky.setValue(Ky)
            self.spn_Kz.setValue(Kz)

    def _ok(self):
        self.Ky_result = self.spn_Ky.value()
        self.Kz_result = self.spn_Kz.value()
        self.accept()


# ══════════════════════════════════════════════════════════════════════════════
# Worker
# ══════════════════════════════════════════════════════════════════════════════

class DesignWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, params, reader):
        super().__init__()
        self.p = params; self.reader = reader; self._running = True

    def stop(self): self._running = False

    def run(self):
        try: self._execute()
        except Exception: self.error.emit(traceback.format_exc())

    def _execute(self):
        p = self.p; reader = self.reader
        results: List[MemberDesignResult] = []
        total = len(p["members"])
        for i, mp in enumerate(p["members"]):
            if not self._running: return
            mid = mp["id"]
            self.progress.emit(int(i/max(total,1)*90),
                               f"Disenando miembro {mid} ({i+1}/{total})...")
            sec = reader.get_section(mid)
            sp  = _dict_to_sp(sec)
            if sp is None:
                log.warning("Miembro %d: sp None — omitido", mid); continue
            ini, fin = reader.get_forces(mid, p["lc_ids"])
            _sop = p.get("so_params")
            if _sop is not None and getattr(_sop, "lc_grav", 0):
                try:
                    _gi, _gf = reader.get_forces(mid, [_sop.lc_grav])
                    _sop.grav_ini = _gi[0] if _gi else None
                    _sop.grav_fin = _gf[0] if _gf else None
                except Exception:
                    _sop.grav_ini = _sop.grav_fin = None
            L = sec.get("length_m", mp["Ly_m"])
            try:
                r = design_member(
                    sp=sp, mat=p["material"],
                    lc_ids=p["lc_ids"], lc_labels=p["lc_labels"],
                    forces_ini=ini, forces_fin=fin,
                    Ly_m=mp["Ly_m"], Lz_m=mp["Lz_m"],
                    Ky=mp["Ky"], Kz=mp["Kz"],
                    member_id=mid, length_m=L,
                    code=p["code"], member_type=p["member_type"],
                    phi_b=p["phi_b"], phi_c=p["phi_c"], phi_v=p["phi_v"],
                    so_params=p.get("so_params"))
                results.append(r)
            except Exception as exc:
                log.exception("Error miembro %d", mid)
                self.error.emit(f"Error en miembro {mid}: {exc}")
        self.progress.emit(100, "Diseno completado.")
        self.finished.emit(results)


def _dict_to_sp(sec: dict) -> Optional[SectionProperties]:
    try:
        kind_str = sec.get("kind_str","W / IR")
        kind = next((k for k in SectionKind if k.value == kind_str), SectionKind.W_OR_IR)
        sp = SectionProperties(); sp.label = sec.get("profile_name","?"); sp.kind = kind
        for a in ("A","d","bf","tf","tw","Ix","Iy","Sx","Sy","Zx","Zy","rx","ry","J","Cw","h","ho"):
            setattr(sp, a, float(sec.get(a, 0.0)))
        sp.compute_derived()
        return sp
    except Exception as e:
        log.warning("_dict_to_sp: %s", e); return None


# ══════════════════════════════════════════════════════════════════════════════
# Ventana principal
# ══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.setMinimumSize(1420, 880)
        self.setStyleSheet(MAIN_STYLE)
        self._results: List[MemberDesignResult] = []
        self._reader = self._member_params = None
        self._worker = self._thread = None
        self._lc_ids: List[int] = []
        self._lc_labels: Dict[int, str] = {}
        self._init_reader()
        self._build_ui()



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "columnsteel_design_pro")
        except Exception:
            pass
    def _init_reader(self):
        try:
            from fileio.openstaad_reader import OpenSTAADReader
            self._reader = OpenSTAADReader()
        except Exception:
            self._reader = None

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        # Header unificado con la suite
        from PySide6.QtWidgets import QFrame
        hdr_frame = QFrame()
        hdr_frame.setFixedHeight(60)
        hdr_frame.setStyleSheet(f"background:{COLORS['primary']};")
        hdr_lay = QHBoxLayout(hdr_frame)
        hdr_lay.setContentsMargins(16, 0, 16, 0)
        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet("color:white; font-size:14pt; font-weight:bold;")
        hdr_lay.addWidget(lbl_title)
        lbl_sub = QLabel("Columnas y Contravientos de Acero")
        lbl_sub.setStyleSheet("color:#AED6F1; font-size:9pt;")
        hdr_lay.addWidget(lbl_sub)
        hdr_lay.addStretch()
        lbl_ver = QLabel(f"NTC 2023 DEA / AISC 360-22  |  v{APP_VERSION}")
        lbl_ver.setStyleSheet("color:rgba(255,255,255,0.65); font-size:8pt;")
        hdr_lay.addWidget(lbl_ver)
        root.addWidget(hdr_frame)

        body = QWidget(); bl = QHBoxLayout(body); bl.setContentsMargins(4,4,4,4)
        spl  = QSplitter(Qt.Horizontal)
        spl.addWidget(self._left_panel())
        spl.addWidget(self._right_panel())
        spl.setSizes([312, 1100])
        spl.setCollapsible(0, False)
        spl.setCollapsible(1, False)
        bl.addWidget(spl)
        root.addWidget(body, 1)

        self.pbar = QProgressBar()
        self.pbar.setRange(0, 100); self.pbar.setValue(0)
        self.pbar.setFixedHeight(5)
        self.pbar.setTextVisible(False)
        self.pbar.setVisible(False)
        root.addWidget(self.pbar)

        self.sb = QStatusBar(); self.setStatusBar(self.sb)
        self.sb.showMessage("Listo — Conecte a STAAD Pro y seleccione miembros.")

    # ── Panel izquierdo ────────────────────────────────────────────────────────

    def _left_panel(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(290)
        scroll.setMaximumWidth(380)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        inner = QWidget()
        inner.setMinimumWidth(280)
        v = QVBoxLayout(inner); v.setSpacing(4); v.setContentsMargins(4,4,4,4)
        v.addWidget(self._grp_staad())
        v.addWidget(self._grp_members())
        v.addWidget(self._grp_lc())
        v.addWidget(self._grp_member_table())
        v.addWidget(self._grp_type_code())
        v.addWidget(self._grp_second_order())
        v.addWidget(self._grp_dxf())
        btn = QPushButton("▶  CALCULAR")
        btn.setObjectName("btn_run"); btn.setMinimumHeight(38)
        btn.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        btn.setToolTip("Ejecutar diseño de los miembros seleccionados")
        btn.clicked.connect(self._run_design)
        v.addWidget(btn)
        btn_m = QPushButton("Memoria de Cálculo (Word)")
        btn_m.setObjectName("btn_memory")
        btn_m.setToolTip("Exportar memoria de cálculo a Word (.docx)")
        btn_m.clicked.connect(self._print_memory)
        v.addWidget(btn_m); v.addStretch()
        scroll.setWidget(inner); return scroll

    def _grp_dxf(self) -> QGroupBox:
        """Panel DXF — mismo formato que beamsteel_design_pro."""
        g = QGroupBox("Exportar a DXF"); v = QVBoxLayout(g)
        self.chk_dxf_enable = QCheckBox("Exportar resultados a DXF")
        self.chk_dxf_enable.setChecked(False)
        v.addWidget(self.chk_dxf_enable)

        self._dxf_sub = QWidget()
        sv = QVBoxLayout(self._dxf_sub)
        sv.setContentsMargins(0, 2, 0, 0); sv.setSpacing(5)

        row_red = QHBoxLayout()
        row_red.addWidget(QLabel("Reducción líneas:"))
        self.spn_dxf_reduc = QDoubleSpinBox()
        self.spn_dxf_reduc.setRange(0.0, 99.0)
        self.spn_dxf_reduc.setValue(20.0)
        self.spn_dxf_reduc.setSuffix(" %")
        self.spn_dxf_reduc.setDecimals(1)
        row_red.addWidget(self.spn_dxf_reduc)
        sv.addLayout(row_red)

        row_f = QHBoxLayout()
        self.chk_dxf_ratio = QCheckBox("Ratio:")
        self.chk_dxf_ratio.setChecked(True)
        self.chk_dxf_ratio.setFixedWidth(64)
        self.txt_dxf_path = QLineEdit()
        self.txt_dxf_path.setPlaceholderText("Ruta del archivo ...")
        self.txt_dxf_path.setReadOnly(True)
        btn_b = QPushButton("..."); btn_b.setFixedWidth(26)
        btn_b.clicked.connect(self._browse_dxf)
        self.chk_dxf_ratio.toggled.connect(self.txt_dxf_path.setEnabled)
        self.chk_dxf_ratio.toggled.connect(btn_b.setEnabled)
        row_f.addWidget(self.chk_dxf_ratio)
        row_f.addWidget(self.txt_dxf_path, 1)
        row_f.addWidget(btn_b)
        sv.addLayout(row_f)

        btn_u = QPushButton("Actualizar DXF")
        btn_u.clicked.connect(self._export_dxf_update)
        sv.addWidget(btn_u)

        v.addWidget(self._dxf_sub)
        self._dxf_sub.setEnabled(False)
        self.chk_dxf_enable.toggled.connect(self._dxf_sub.setEnabled)
        return g

    def _browse_dxf(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Seleccionar / crear DXF de ratios",
            self.txt_dxf_path.text() or "",
            "DXF Files (*.dxf);;All Files (*)")
        if path:
            self.txt_dxf_path.setText(path)
            self.txt_dxf_path.setToolTip(path)

    def _export_dxf_update(self):
        """Exporta ratios a DXF (mismo flujo que beamsteel_design_pro)."""
        import os as _os
        if not self._results:
            QMessageBox.warning(self, "Sin resultados",
                                "Ejecute el diseño primero.")
            return
        if not (self.chk_dxf_enable.isChecked()
                and self.chk_dxf_ratio.isChecked()):
            QMessageBox.information(self, "DXF desactivado",
                "Active las casillas del panel 'Exportar a DXF'.")
            return
        path = self.txt_dxf_path.text().strip()
        if not path:
            QMessageBox.warning(self, "Sin archivo",
                                "Seleccione la ruta del archivo DXF (botón ...).")
            return
        pct = self.spn_dxf_reduc.value()
        from fileio.dxf_exporter import export_dxf_single, modify_existing_dxf
        from suite_shared.busy_progress import busy_progress
        with busy_progress(self, "Actualizando DXF de ratios…"):
            if _os.path.exists(path):
                ok, out = modify_existing_dxf(path, self._results,
                                              reduction_pct=pct)
            else:
                ok = export_dxf_single(path, self._results,
                                       reduction_pct=pct)
                out = path
        if ok:
            QMessageBox.information(self, "DXF",
                                    f"DXF generado:\n{out}")
        else:
            QMessageBox.warning(self, "DXF", f"No fue posible generar el DXF:\n{out}")

    def _grp_staad(self) -> QGroupBox:
        g = QGroupBox("Conexion STAAD Pro"); v = QVBoxLayout(g)
        row = QHBoxLayout()
        self.btn_connect = QPushButton("Conectar a STAAD Pro")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.setToolTip("Establece conexión con STAAD Pro 2025\n(requiere ejecutar como Administrador)")
        self.btn_connect.clicked.connect(self._connect_staad)
        self.lbl_conn = QLabel("Sin conexion")
        self.lbl_conn.setStyleSheet("color:#C0392B; font-weight:bold;")
        row.addWidget(self.btn_connect); row.addWidget(self.lbl_conn)
        v.addLayout(row)
        note = QLabel("Fuerzas STAAD en kN — conversion automatica a ton")
        note.setStyleSheet("font-size:8pt; color:#777;")
        v.addWidget(note)
        return g

    def _grp_members(self) -> QGroupBox:
        g = QGroupBox("Miembros a disenar"); v = QVBoxLayout(g)
        rh = QHBoxLayout()
        btn_sel = QPushButton("Desde seleccion STAAD"); btn_sel.clicked.connect(self._load_from_selection)
        btn_man = QPushButton("IDs manuales");           btn_man.clicked.connect(self._load_from_ids)
        rh.addWidget(btn_sel); rh.addWidget(btn_man); v.addLayout(rh)
        self.txt_ids = QLineEdit(); self.txt_ids.setPlaceholderText("IDs: 1, 5, 12-20  (manual)")
        v.addWidget(self.txt_ids)
        self.lbl_members = QLabel("Sin miembros cargados.")
        self.lbl_members.setStyleSheet("font-size:8pt; color:#555;")
        v.addWidget(self.lbl_members)
        return g

    def _grp_lc(self) -> QGroupBox:
        g = QGroupBox("Combinaciones de carga"); v = QVBoxLayout(g)
        row = QHBoxLayout()
        row.addWidget(QLabel("Desde LC:"))
        self.spn_lc_ini = QSpinBox(); self.spn_lc_ini.setRange(1,9999); self.spn_lc_ini.setValue(1)
        row.addWidget(self.spn_lc_ini); row.addWidget(QLabel("Hasta:"))
        self.spn_lc_fin = QSpinBox(); self.spn_lc_fin.setRange(1,9999); self.spn_lc_fin.setValue(50)
        row.addWidget(self.spn_lc_fin); v.addLayout(row)
        btn = QPushButton("Detectar desde STAAD"); btn.clicked.connect(self._detect_lc)
        v.addWidget(btn)
        self.lbl_lc = QLabel("---"); self.lbl_lc.setStyleSheet("font-size:8pt; color:#555;")
        v.addWidget(self.lbl_lc)
        return g

    # Indices de columnas en la tabla de miembros (constantes de clase)
    _TBL_COL_ID    = 0
    _TBL_COL_L     = 1
    _TBL_COL_LY    = 2
    _TBL_COL_LZ    = 3
    _TBL_COL_KY    = 4
    _TBL_COL_KZ    = 5
    _TBL_COL_GAY   = 6   # G extremo A  eje debil  (auto-K)
    _TBL_COL_GBY   = 7   # G extremo B  eje debil
    _TBL_COL_GAX   = 8   # G extremo A  eje fuerte (auto-K)
    _TBL_COL_GBX   = 9   # G extremo B  eje fuerte
    _TBL_NCOLS     = 10

    def _grp_member_table(self) -> QGroupBox:
        """
        Tabla inline de miembros:
        ID | L_real | Ly | Lz | Ky | Kz | GA_y | GB_y | GA_x | GB_x
        Las columnas GA/GB son de solo lectura y las llena 'Auto K'.
        """
        g = QGroupBox("Miembros — Longitudes y Factores K (AISC App.7)")
        v = QVBoxLayout(g)

        lbl = QLabel(
            "Ly/Lz = longitudes no arriostradas  |  Ky/Kz = factores de long. efectiva\n"
            "GA, GB = factores de rigidez en nodo A y B  (calculados con Auto K)")
        lbl.setStyleSheet("font-size:8pt; color:#555;")
        v.addWidget(lbl)

        # ── Botones de accion ──────────────────────────────────────────────────
        rh1 = QHBoxLayout()
        btn_kk = QPushButton("Asignar K\nmanual...")
        self.btn_k_lengths = QPushButton("Longitudes\ntrabes (K)")
        self.btn_k_lengths.setEnabled(False)
        self.btn_k_lengths.setToolTip(
            "Tabla de longitudes de trabes usadas en el calculo de K.\n"
            "Permite corregirlas y recalcular los factores K.")
        self.btn_k_lengths.clicked.connect(self._edit_k_lengths)

        self.btn_col_len = QPushButton("Longitud\ncolumna...")
        self.btn_col_len.setToolTip(
            "Longitud REAL de la columna cuando esta partida en 2 o mas barras.\n"
            "Suma los tramos verticales continuos hasta encontrar una trabe en\n"
            "Dir.X y/o Dir.Z (las diagonales se descomponen). La tabla permite\n"
            "modificar manualmente la longitud antes de aplicarla a Ly/Lz.")
        self.btn_col_len.clicked.connect(self._edit_col_lengths)

        btn_ak = QPushButton("Auto K\nAISC App.7")
        btn_r1 = QPushButton("Ly=Lz=\nL real")
        for _b in (btn_kk, btn_ak, btn_r1, self.btn_col_len):
            _b.setStyleSheet("font-size:8pt;")
            _b.setMinimumHeight(38)
        btn_r1.setObjectName("btnOrange")
        btn_kk.clicked.connect(self._tbl_open_k)
        btn_ak.setObjectName("btnGreen")
        btn_ak.clicked.connect(self._tbl_auto_k)
        btn_r1.clicked.connect(self._tbl_reset_ly_lz)
        rh1.addWidget(btn_kk); rh1.addWidget(btn_ak); rh1.addWidget(self.btn_k_lengths)
        rh1.addWidget(self.btn_col_len); rh1.addWidget(btn_r1)
        v.addLayout(rh1)

        # ── Tabla ──────────────────────────────────────────────────────────────
        hdrs = ["ID", "L real (m)", "Ly (m)", "Lz (m)", "Ky", "Kz",
                "GA  eje Y", "GB  eje Y", "GA  eje X", "GB  eje X"]
        self.tbl_members = QTableWidget(0, self._TBL_NCOLS)
        self.tbl_members.setHorizontalHeaderLabels(hdrs)
        hh = self.tbl_members.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(False)
        # Anchos iniciales
        for col, w in [(0,40),(1,72),(2,65),(3,65),(4,55),(5,55),
                       (6,65),(7,65),(8,65),(9,65)]:
            self.tbl_members.setColumnWidth(col, w)
        self.tbl_members.setAlternatingRowColors(True)
        self.tbl_members.setMinimumHeight(110)
        self.tbl_members.setMaximumHeight(270)
        self.tbl_members.itemChanged.connect(self._tbl_sync)
        v.addWidget(self.tbl_members)
        return g

    def _grp_type_code(self) -> QGroupBox:
        g = QGroupBox("Tipo / Codigo"); v = QVBoxLayout(g)
        rh1 = QHBoxLayout()
        self.rb_col   = QRadioButton("Columna");       self.rb_col.setChecked(True)
        self.rb_brace = QRadioButton("Contraviento")
        bg1 = QButtonGroup(self); bg1.addButton(self.rb_col); bg1.addButton(self.rb_brace)
        rh1.addWidget(self.rb_col); rh1.addWidget(self.rb_brace); v.addLayout(rh1)
        rh2 = QHBoxLayout()
        self.rb_ntc  = QRadioButton("NTC 2023 (DEA)"); self.rb_ntc.setChecked(True)
        self.rb_aisc = QRadioButton("AISC 360-22")
        bg2 = QButtonGroup(self); bg2.addButton(self.rb_ntc); bg2.addButton(self.rb_aisc)
        rh2.addWidget(self.rb_ntc); rh2.addWidget(self.rb_aisc); v.addLayout(rh2)
        return g

    # ── Segundo orden ─────────────────────────────────────────────────────────

    def _grp_second_order(self) -> QWidget:
        """
        Panel de efectos de segundo orden.
        El checkbox habilita/deshabilita y muestra/oculta los controles.
        AISC 360-22 Apéndice 8 / NTC Acero CDMX 2024 Art. 3.7.3
        """
        outer = QWidget()
        outer_v = QVBoxLayout(outer); outer_v.setContentsMargins(0,0,0,0); outer_v.setSpacing(2)

        # ── Checkbox habilitador (visible siempre) ────────────────────────────
        self.chk_so = QCheckBox(
            "Amplificacion 2ndo Orden (AISC App.8 / NTC Art.3.7.3)")
        self.chk_so.setToolTip(
            "Marque para que el script amplifique los momentos por efectos "
            "de 2° orden (B1-B2).\nDESMARQUE si los efectos de 2° orden ya "
            "fueron considerados en su modelo matemático\n(análisis P-Δ / "
            "análisis directo en STAAD Pro).")
        self.chk_so.setStyleSheet(
            "font-size:8pt; font-weight:bold; color:#1B4F72;")
        outer_v.addWidget(self.chk_so)

        # ── Contenedor de controles (oculto por defecto) ──────────────────────
        self._so_content = QGroupBox()
        self._so_content.setVisible(False)
        self._so_content.setStyleSheet(
            "QGroupBox { border:1px solid #AED6F1; border-radius:4px; "
            "margin-top:2px; padding:4px; }")
        v = QVBoxLayout(self._so_content); v.setSpacing(4)
        v.setContentsMargins(4, 4, 4, 4)

        lbl_ref = QLabel("Mr = B1·Mnt + B2·Mlt  [AISC A-8-1]")
        lbl_ref.setStyleSheet("font-size:8pt; color:#555;")
        v.addWidget(lbl_ref)

        # ── B1 ────────────────────────────────────────────────────────────────
        gb1 = QGroupBox("B1 — Curvatura del miembro  (P-delta)")
        gb1.setStyleSheet(_GRP_STYLE_SO)
        vb1 = QVBoxLayout(gb1); vb1.setSpacing(2)

        self.chk_B1 = QCheckBox("Aplicar B1  [AISC A-8-3]")
        self.chk_B1.setChecked(True)
        vb1.addWidget(self.chk_B1)

        vb1.addSpacing(4)
        lbl_k1 = QLabel(
            "K1 (Pe1) automático: K≤1 del análisis si la dirección es "
            "contraventeada; 1.0 en otro caso  [NTC 3.7.2 / 3.6.3.1]")
        lbl_k1.setWordWrap(True)
        lbl_k1.setMinimumHeight(38)
        lbl_k1.setStyleSheet("font-size:7.5pt; color:#666;")
        vb1.addWidget(lbl_k1)
        vb1.addSpacing(2)
        vb1.addWidget(QLabel("Cm:"))

        rg_cm = QButtonGroup(self)
        self.rb_cm_auto = QRadioButton("Cm = 0.6-0.4(M1/M2)  [auto]")
        self.rb_cm_cons = QRadioButton("Cm = 1.0  [conservador]")
        self.rb_cm_man  = QRadioButton("Cm manual:")
        self.rb_cm_auto.setStyleSheet("font-size:8pt;")
        self.rb_cm_cons.setStyleSheet("font-size:8pt;")
        self.rb_cm_man.setStyleSheet("font-size:8pt;")
        self.rb_cm_auto.setChecked(True)
        for rb in (self.rb_cm_auto, self.rb_cm_cons, self.rb_cm_man):
            rg_cm.addButton(rb); vb1.addWidget(rb)

        r_cm_m = QHBoxLayout(); r_cm_m.addSpacing(18)
        self.spn_Cm = QDoubleSpinBox()
        self.spn_Cm.setRange(0.4, 1.0); self.spn_Cm.setValue(0.85)
        self.spn_Cm.setDecimals(2); self.spn_Cm.setMinimumWidth(90)
        self.spn_Cm.setEnabled(False)
        r_cm_m.addWidget(self.spn_Cm); r_cm_m.addStretch()
        vb1.addLayout(r_cm_m)
        self.rb_cm_man.toggled.connect(self.spn_Cm.setEnabled)
        v.addWidget(gb1)

        # ── B2 ────────────────────────────────────────────────────────────────
        gb2 = QGroupBox("B2 — Desplazamiento de piso  (P-Delta)")
        gb2.setStyleSheet(_GRP_STYLE_SO)
        vb2 = QVBoxLayout(gb2); vb2.setSpacing(2)

        # ── Separación Mnt/Mlt por casos de carga ─────────────────────────
        row_g = QHBoxLayout()
        row_g.addWidget(QLabel("LC gravitacional (PP+CM+CVacc):"))
        self.spn_lc_grav = QSpinBox()
        self.spn_lc_grav.setRange(0, 9999)
        self.spn_lc_grav.setValue(0)
        self.spn_lc_grav.setMinimumWidth(70)
        self.spn_lc_grav.setToolTip(
            "Caso de carga GRAVITACIONAL (PP+CM+CVacc) para separar\n"
            "Mnt (sin traslación) de Mlt (con traslación):\n"
            "  Mr = B1·Mnt + B2·Mlt   [AISC A-8-1]\n"
            "0 = no separar (se aplica max(B1,B2) al momento total).")
        row_g.addWidget(self.spn_lc_grav); row_g.addStretch()
        v.addLayout(row_g)

        self.chk_B2 = QCheckBox("Aplicar B2  [AISC A-8-6]")
        self.chk_B2.setChecked(False)
        vb2.addWidget(self.chk_B2)

        # Contenido B2 (se muestra al activar chk_B2)
        self._w_B2 = QWidget(); self._w_B2.setVisible(False)
        vb2i = QVBoxLayout(self._w_B2); vb2i.setContentsMargins(0,0,0,0); vb2i.setSpacing(2)

        rg_b2 = QButtonGroup(self)
        self.rb_b2_staad  = QRadioButton("STAAD incluye P-Delta → B2=1.0 (ambas dir.)")
        self.rb_b2_manual = QRadioButton("B2 indicado por dirección:")
        self.rb_b2_manual.setToolTip(
            "Indique el valor de B2 calculado externamente (con ΣPu, ΣH y Δoh —\n"
            "AISC 360-22 Ec. A-8-6 / NTC Acero CDMX 2024 Ec. 3.7.3.2.1),\n"
            "por separado para cada dirección de traslación:\n"
            "  • Dir. X → eje fuerte (Mux/Muz)\n"
            "  • Dir. Z → eje débil (Muy)\n"
            "Se aplica a Mlt en Mr = B1·Mnt + B2·Mlt.")
        for rb in (self.rb_b2_staad, self.rb_b2_manual):
            rb.setStyleSheet("font-size:8pt;")
            rg_b2.addButton(rb)

        vb2i.addWidget(self.rb_b2_staad)
        vb2i.addWidget(self.rb_b2_manual)

        # B2 por dirección: dos cuadros (Dir. X y Dir. Z)
        r_dirs = QHBoxLayout(); r_dirs.setContentsMargins(18, 0, 0, 0); r_dirs.setSpacing(6)
        lbl_bx = QLabel("Dir. X (Mx):"); lbl_bx.setStyleSheet("font-size:8pt;")
        self.spn_B2x = QDoubleSpinBox()
        self.spn_B2x.setRange(1.0, 5.0); self.spn_B2x.setValue(1.0)
        self.spn_B2x.setDecimals(3); self.spn_B2x.setMinimumWidth(95)
        lbl_bz = QLabel("Dir. Z (My):"); lbl_bz.setStyleSheet("font-size:8pt;")
        self.spn_B2z = QDoubleSpinBox()
        self.spn_B2z.setRange(1.0, 5.0); self.spn_B2z.setValue(1.0)
        self.spn_B2z.setDecimals(3); self.spn_B2z.setMinimumWidth(95)
        r_dirs.addWidget(lbl_bx); r_dirs.addWidget(self.spn_B2x)
        r_dirs.addWidget(lbl_bz); r_dirs.addWidget(self.spn_B2z)
        r_dirs.addStretch()
        vb2i.addLayout(r_dirs)

        self.rb_b2_manual.setChecked(True)   # el usuario indica B2 (externo)
        def _b2_manual_toggle(on):
            self.spn_B2x.setEnabled(on); self.spn_B2z.setEnabled(on)
        self.rb_b2_manual.toggled.connect(_b2_manual_toggle)

        vb2.addWidget(self._w_B2)
        self.chk_B2.toggled.connect(self._w_B2.setVisible)
        v.addWidget(gb2)

        # Nota de uso
        nota = QLabel(
            "STAAD con P-Delta → marcar solo B1.\n"
            "STAAD sin P-Delta → marcar B1 y B2.")
        nota.setStyleSheet("font-size:7pt; color:#7D6608; font-style:italic;")
        nota.setWordWrap(True)
        v.addWidget(nota)

        outer_v.addWidget(self._so_content)
        self.chk_so.toggled.connect(self._so_content.setVisible)
        return outer

    def _get_so_params(self):
        """
        Lee la configuración de la UI y retorna un SecondOrderParams.
        Retorna None si el grupo está desactivado.
        """
        from design.second_order import (SecondOrderParams, CmConfig, B2Config)

        if not self.chk_so.isChecked():
            return None

        # Cm
        if self.rb_cm_auto.isChecked():
            cm_cfg = CmConfig(mode="auto")
        elif self.rb_cm_cons.isChecked():
            cm_cfg = CmConfig(mode="conservador")
        else:
            cm_cfg = CmConfig(mode="manual", valor_manual=self.spn_Cm.value())

        lc_grav = self.spn_lc_grav.value()

        # Contravientos por dirección desde el Auto-K (sway_x, sway_z).
        # braced = no sway; si no se corrió Auto-K, se asume no contraventeado
        # (K1 = 1.0, conservador).
        _sway = getattr(self, "_k_sway", None)
        _braced_x = (not _sway[0]) if _sway else False   # dir X (Kz)
        _braced_z = (not _sway[1]) if _sway else False   # dir Z (Ky)

        # B2 por dirección (STAAD ya incluye P-Delta, o B2 indicado por dir.)
        if self.chk_B2.isChecked():
            if self.rb_b2_staad.isChecked():
                b2_cfg = B2Config(modo="staad_pdelta")
            else:
                b2_cfg = B2Config(modo="manual",
                                  B2_manual_x=self.spn_B2x.value(),
                                  B2_manual_z=self.spn_B2z.value(),
                                  B2_manual=max(self.spn_B2x.value(),
                                                self.spn_B2z.value()))
            aplicar_B2 = True
        else:
            b2_cfg     = B2Config(modo="manual",
                                  B2_manual_x=1.0, B2_manual_z=1.0)
            aplicar_B2 = False

        return SecondOrderParams(
            activo      = True,
            aplicar_B1  = self.chk_B1.isChecked(),
            cm_config   = cm_cfg,
            aplicar_B2  = aplicar_B2,
            b2_config   = b2_cfg,
            lc_grav=lc_grav,
            braced_x=_braced_x,
            braced_z=_braced_z,
        )

    # ── Panel derecho ──────────────────────────────────────────────────────────

    def _right_panel(self) -> QWidget:
        w = QWidget(); v = QVBoxLayout(w); v.setSpacing(4)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_combos(),   "Por Combinacion")
        self.tabs.addTab(self._tab_summary(),  "Resumen")
        self.tabs.addTab(self._tab_diagram(),  "Dia. Interaccion")
        v.addWidget(self.tabs)
        return w

    # Columnas fijas (sin encabezado dinámico H1-1/NTC)
    _COMBO_COLS_HEADER = ["Barra","Perfil","L (m)","KLy/ry","KLz/rx",
                          "FR*Pn (t)","FR*Mnx (tm)","FR*Mny (tm)","FR*Vn (t)"]
    _COMBO_COLS_DATA   = ["LC","Extr.","Pu (t)","Mux (tm)","Muy (tm)","Vux (t)",
                          "Interaccion","V/FRVn","Estado"]
    # col 15 = "Interaccion" (nombre dinámico según norma)
    _COMBO_COL_INTER   = 9 + 6   # índice global = 15

    _SUMM_COLS_HEADER = ["Barra","Perfil","L (m)","KLy/ry","KLz/rx","Clase"]
    _SUMM_COLS_DATA   = ["Caso","LC gob.","Extr.","Pu (t)","Mux (tm)",
                         "Muy (tm)","Vux (t)","Interaccion","Estado"]

    def _tab_combos(self) -> QWidget:
        w = QWidget(); v = QVBoxLayout(w)
        nota = QLabel("  Ctrl+C para copiar seleccion a Excel / Word")
        nota.setStyleSheet("font-size:8pt; color:#777;"); v.addWidget(nota)

        cols = self._COMBO_COLS_HEADER + self._COMBO_COLS_DATA
        self.tbl_combos = CopyableTable(0, len(cols))
        self.tbl_combos.setHorizontalHeaderLabels(cols)
        hh = self.tbl_combos.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setStretchLastSection(False)
        self.tbl_combos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl_combos.setAlternatingRowColors(True)
        self.tbl_combos.setFont(QFont("Segoe UI", 8))
        v.addWidget(self.tbl_combos)

        bh = QHBoxLayout()
        btn = QPushButton("Exportar Word — Por Combinacion")
        btn.clicked.connect(lambda: self._export_word("combos"))
        bh.addWidget(btn); bh.addStretch(); v.addLayout(bh)
        return w

    def _tab_summary(self) -> QWidget:
        w = QWidget(); v = QVBoxLayout(w)
        nota = QLabel("  Ctrl+C para copiar seleccion a Excel / Word")
        nota.setStyleSheet("font-size:8pt; color:#777;"); v.addWidget(nota)

        cols = self._SUMM_COLS_HEADER + self._SUMM_COLS_DATA
        self.tbl_summary = CopyableTable(0, len(cols))
        self.tbl_summary.setHorizontalHeaderLabels(cols)
        hh = self.tbl_summary.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(True)
        self.tbl_summary.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl_summary.setAlternatingRowColors(True)
        self.tbl_summary.setFont(QFont("Segoe UI", 8))
        v.addWidget(self.tbl_summary)

        bh = QHBoxLayout()
        btn = QPushButton("Exportar Word — Resumen")
        btn.clicked.connect(lambda: self._export_word("summary"))
        bh.addWidget(btn); bh.addStretch(); v.addLayout(bh)
        return w

    def _tab_diagram(self) -> QWidget:
        w = QWidget(); v = QVBoxLayout(w)
        rh = QHBoxLayout(); rh.addWidget(QLabel("Barra:"))
        self.cmb_barra = QComboBox()
        self.cmb_barra.currentIndexChanged.connect(self._redraw_diagram)
        rh.addWidget(self.cmb_barra); rh.addStretch(); v.addLayout(rh)

        self.fig_d  = Figure(figsize=(8, 6), tight_layout=True)
        self.can_d  = FigureCanvas(self.fig_d)
        nav = NavToolbar(self.can_d, w)
        v.addWidget(nav); v.addWidget(self.can_d)
        self._draw_empty_diag()

        btn = QPushButton("Exportar Word — Diagrama de interaccion")
        btn.clicked.connect(lambda: self._export_word("diagram")); v.addWidget(btn)
        return w

    # ── Tabla inline de miembros ───────────────────────────────────────────────

    # ── Helpers de la tabla de miembros ──────────────────────────────────────

    def _tbl_load(self, data: list):
        """Carga lista de dicts {id, length_m, Ly_m, Lz_m, Ky, Kz} en la tabla."""
        C = self  # alias para _TBL_COL_*
        tbl = self.tbl_members
        tbl.blockSignals(True)
        tbl.setRowCount(0)
        for mp in data:
            row = tbl.rowCount(); tbl.insertRow(row)
            col_cfg = [
                (C._TBL_COL_ID,  "id",       True,  str),
                (C._TBL_COL_L,   "length_m", True,  lambda v: f"{v:.2f}"),
                (C._TBL_COL_LY,  "Ly_m",     False, lambda v: f"{v:.2f}"),
                (C._TBL_COL_LZ,  "Lz_m",     False, lambda v: f"{v:.2f}"),
                (C._TBL_COL_KY,  "Ky",       False, lambda v: f"{v:.2f}"),
                (C._TBL_COL_KZ,  "Kz",       False, lambda v: f"{v:.2f}"),
            ]
            for col, key, read_only, fmt in col_cfg:
                val = mp.get(key, 0.0)
                it  = QTableWidgetItem(fmt(val) if callable(fmt) else str(val))
                it.setTextAlignment(Qt.AlignCenter)
                if read_only:
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                    it.setForeground(QBrush(QColor("#5D6D7E")))
                tbl.setItem(row, col, it)
            # Columnas GA/GB: inicialmente vacías, read-only
            for col in (C._TBL_COL_GAY, C._TBL_COL_GBY,
                        C._TBL_COL_GAX, C._TBL_COL_GBX):
                it = QTableWidgetItem("---")
                it.setTextAlignment(Qt.AlignCenter)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                it.setForeground(QBrush(QColor("#7D8C99")))
                tbl.setItem(row, col, it)
        tbl.blockSignals(False)
        ids = [mp["id"] for mp in data]
        self.txt_ids.setText(", ".join(str(i) for i in ids))
        self._tbl_sync()

    def _tbl_sync(self):
        """Lee la tabla y actualiza self._member_params."""
        C   = self
        tbl = self.tbl_members
        params = []
        for row in range(tbl.rowCount()):
            def _f(col):
                try: return float(tbl.item(row, col).text())
                except: return 1.0
            try:
                mid = int(tbl.item(row, C._TBL_COL_ID).text())
            except Exception:
                continue
            params.append({
                "id":       mid,
                "length_m": _f(C._TBL_COL_L),
                "Ly_m":     _f(C._TBL_COL_LY),
                "Lz_m":     _f(C._TBL_COL_LZ),
                "Ky":       _f(C._TBL_COL_KY),
                "Kz":       _f(C._TBL_COL_KZ),
            })
        self._member_params = params if params else None
        n = len(params)
        self.lbl_members.setText(
            f"{n} miembro(s) configurados." if n else "Sin miembros cargados.")

    def _tbl_set_k_row(self, row: int, kdata: dict):
        """
        Escribe Ky, Kz y GA/GB en una fila de la tabla (sin emitir señales).
        kdata: dict con claves Ky, Kz, GA_y, GB_y, GA_x, GB_x, ok.
        """
        C   = self
        tbl = self.tbl_members

        def _set_ro(col: int, text: str, ok: bool = True):
            it = tbl.item(row, col)
            if it is None:
                it = QTableWidgetItem()
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                tbl.setItem(row, col, it)
            it.setText(text)
            color = QColor("#1E8449") if ok else QColor("#C0392B")
            it.setForeground(QBrush(color))

        def _set_edit(col: int, text: str):
            it = tbl.item(row, col)
            if it:
                it.setText(text)

        _set_edit(C._TBL_COL_KY,  f"{kdata['Ky']:.2f}")
        _set_edit(C._TBL_COL_KZ,  f"{kdata['Kz']:.2f}")
        _set_ro(C._TBL_COL_GAY, f"{kdata['GA_y']:.2f}", kdata.get("ok", True))
        _set_ro(C._TBL_COL_GBY, f"{kdata['GB_y']:.2f}", kdata.get("ok", True))
        _set_ro(C._TBL_COL_GAX, f"{kdata['GA_x']:.2f}", kdata.get("ok", True))
        _set_ro(C._TBL_COL_GBX, f"{kdata['GB_x']:.2f}", kdata.get("ok", True))

        # Tooltip en las celdas K con el estado del cálculo
        if kdata.get("msg"):
            for col in (C._TBL_COL_KY, C._TBL_COL_KZ):
                it = tbl.item(row, col)
                if it:
                    it.setToolTip(kdata["msg"])

    def _tbl_reset_ly_lz(self):
        """Resetea Ly=Lz=L_real y K=1.0 para todas las filas."""
        C   = self
        tbl = self.tbl_members
        tbl.blockSignals(True)
        for row in range(tbl.rowCount()):
            try:
                L = float(tbl.item(row, C._TBL_COL_L).text())
            except Exception:
                L = 4.0
            for col in (C._TBL_COL_LY, C._TBL_COL_LZ):
                it = tbl.item(row, col)
                if it: it.setText(f"{L:.4f}")
            for col in (C._TBL_COL_KY, C._TBL_COL_KZ):
                it = tbl.item(row, col)
                if it: it.setText("1.0000")
        tbl.blockSignals(False)
        self._tbl_sync()

    def _tbl_open_k(self):
        """Abre dialogo de asignacion manual de K y aplica a todas las filas."""
        C   = self
        tbl = self.tbl_members
        Ky0, Kz0 = 1.0, 1.0
        if tbl.rowCount() > 0:
            try: Ky0 = float(tbl.item(0, C._TBL_COL_KY).text())
            except: pass
            try: Kz0 = float(tbl.item(0, C._TBL_COL_KZ).text())
            except: pass
        dlg = KSimpleDialog(Ky0, Kz0, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            Ky = dlg.Ky_result; Kz = dlg.Kz_result
            tbl.blockSignals(True)
            for row in range(tbl.rowCount()):
                it_y = tbl.item(row, C._TBL_COL_KY)
                it_z = tbl.item(row, C._TBL_COL_KZ)
                if it_y: it_y.setText(f"{Ky:.4f}")
                if it_z: it_z.setText(f"{Kz:.4f}")
            tbl.blockSignals(False)
            self._tbl_sync()
            self.sb.showMessage(f"K asignado manualmente: Ky={Ky:.4f}  Kz={Kz:.4f}")

    def _tbl_auto_k(self):
        """
        Calcula K automaticamente usando AISC 360-22 Apendice 7 (Alignment Chart).
        Pasos:
          1. Pregunta tipo de estructura por direccion (marco/contraventeado).
          2. Construye la conectividad del modelo (build_connectivity).
          3. Calcula G_A, G_B y K para cada miembro seleccionado.
          4. Muestra resultados en la tabla (Ky, Kz, GA_y, GB_y, GA_x, GB_x).
        """
        if not (self._reader and self._reader.connected):
            QMessageBox.warning(self, "Auto K", "Conecte primero a STAAD Pro.")
            return
        tbl = self.tbl_members
        if tbl.rowCount() == 0:
            QMessageBox.warning(self, "Auto K", "Cargue miembros primero.")
            return

        # ── Dialogo de tipo de estructura ──────────────────────────────────────
        dlg = QDialog(self)
        dlg.setWindowTitle("Auto K — AISC 360-22 Apendice 7")
        dlg.setMinimumWidth(430)
        dlg.setStyleSheet(MAIN_STYLE)
        vv = QVBoxLayout(dlg); vv.setSpacing(8)

        # Titulo y referencia
        lbl_title = QLabel("Tipo de estructura por direccion")
        lbl_title.setStyleSheet("font-weight:bold; font-size:10pt; color:#1B4F72;")
        vv.addWidget(lbl_title)

        lbl_ref = QLabel(
            "AISC 360-22 Apendice 7 — Metodo del abaco de alineacion (Alignment Chart)\n"
            "G = sum(EI/L)columna / sum(EI/L)vigas_en_el_nodo\n"
            "Los valores GA y GB calculados se muestran en la tabla de miembros.")
        lbl_ref.setStyleSheet("font-size:8pt; color:#555;")
        lbl_ref.setWordWrap(True)
        vv.addWidget(lbl_ref)

        # ── Dir X (eje fuerte, pandeo → Kz) ───────────────────────────────────
        gx = QGroupBox("Direccion X  (pandeo eje fuerte — Kz)")
        vgx = QVBoxLayout(gx)
        self._rb_x_sway   = QRadioButton("Marco  (con desplazamiento lateral — sway)")
        self._rb_x_braced = QRadioButton("Contraventeado  (sin desplazamiento — braced)")
        self._rb_x_sway.setChecked(True)
        bg_x = QButtonGroup(dlg)
        bg_x.addButton(self._rb_x_sway); bg_x.addButton(self._rb_x_braced)
        vgx.addWidget(self._rb_x_sway); vgx.addWidget(self._rb_x_braced)
        vv.addWidget(gx)

        # ── Dir Z (eje debil, pandeo → Ky) ────────────────────────────────────
        gz = QGroupBox("Direccion Z  (pandeo eje debil — Ky)")
        vgz = QVBoxLayout(gz)
        self._rb_z_sway   = QRadioButton("Marco  (con desplazamiento lateral — sway)")
        self._rb_z_braced = QRadioButton("Contraventeado  (sin desplazamiento — braced)")
        self._rb_z_sway.setChecked(True)
        bg_z = QButtonGroup(dlg)
        bg_z.addButton(self._rb_z_sway); bg_z.addButton(self._rb_z_braced)
        vgz.addWidget(self._rb_z_sway); vgz.addWidget(self._rb_z_braced)
        vv.addWidget(gz)

        lbl_nota = QLabel(
            "Nota: El metodo usa las incidencias y propiedades de TODOS\n"
            "los miembros del modelo para calcular la rigidez relativa en\n"
            "cada nodo extremo de la columna.")
        lbl_nota.setStyleSheet("font-size:8pt; color:#777; font-style:italic;")
        vv.addWidget(lbl_nota)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        vv.addWidget(bb)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        sway_x = self._rb_x_sway.isChecked()    # Kz (eje fuerte)
        sway_z = self._rb_z_sway.isChecked()    # Ky (eje debil)
        self._k_sway = (sway_x, sway_z)
        self._k_overrides = {}      # nueva corrida: limpiar longitudes revisadas
        self._run_auto_k()

    # ── Longitud REAL de columnas partidas en varias barras ───────────────────
    def _edit_col_lengths(self):
        """Tabla con la longitud real de cada columna (suma de los tramos
        continuos hasta la trabe que restringe cada direccion). El usuario
        puede modificarla manualmente y aplicarla a Ly/Lz.

        Mapeo: L Dir.X (marco X, eje fuerte) -> Lz ;
               L Dir.Z (marco Z, eje debil)  -> Ly.
        """
        tbl = self.tbl_members
        if tbl.rowCount() == 0:
            QMessageBox.information(self, "Longitud de columnas",
                                    "Primero importe los miembros de STAAD.")
            return
        if not getattr(self._reader, "connected", False):
            QMessageBox.information(
                self, "Longitud de columnas",
                "Se requiere conexion a STAAD Pro para leer la geometria.")
            return

        ids = []
        for row in range(tbl.rowCount()):
            try:
                ids.append(int(tbl.item(row, self._TBL_COL_ID).text()))
            except Exception:
                continue

        self.sb.showMessage("Revisando la longitud real de las columnas...")
        self.pbar.setVisible(True); self.pbar.setValue(10)
        QApplication.processEvents()
        try:
            ok_conn, msg_conn = self._reader.build_connectivity()
            if not ok_conn:
                QMessageBox.critical(self, "Longitud de columnas", msg_conn)
                return
            from design.column_chain import FIN_TXT, longitudes_columnas
            datos = longitudes_columnas(
                self._reader, ids,
                overrides=getattr(self, "_col_len_overrides", {}))
        except Exception as exc:
            QMessageBox.critical(self, "Longitud de columnas",
                                 f"No se pudo calcular:\n{exc}")
            return
        finally:
            self.pbar.setValue(0); self.pbar.setVisible(False)
            self.sb.clearMessage()

        dlg = QDialog(self)
        dlg.setWindowTitle("Longitud real de columnas (barras encadenadas)")
        dlg.setMinimumSize(760, 460)
        dlg.setStyleSheet(MAIN_STYLE)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Cuando una columna esta modelada con 2 o mas barras, la longitud "
            "de pandeo es la del tramo CONTINUO, no la del segmento. Se suman "
            "los tramos verticales colineales hasta encontrar una trabe que "
            "restrinja cada direccion (las diagonales se descomponen: aportan "
            "ux^2 al marco X y uz^2 al marco Z).\n"
            "Edite 'L Dir.X' o 'L Dir.Z' si conoce el valor correcto y presione "
            "[Aplicar a Ly/Lz].   L Dir.X -> Lz (eje fuerte) ; "
            "L Dir.Z -> Ly (eje debil).")
        lbl.setWordWrap(True)
        v.addWidget(lbl)

        cols = ["Miembro", "Perfil", "L segmento (m)", "Barras Dir.X",
                "L Dir.X (m)", "Termina X", "Barras Dir.Z", "L Dir.Z (m)",
                "Termina Z"]
        tblC = QTableWidget(len(datos), len(cols))
        tblC.setHorizontalHeaderLabels(cols)
        orden = sorted(datos)
        for i, mid in enumerate(orden):
            d = datos[mid]
            fx = " / ".join(FIN_TXT.get(f, f) for f in d["fin_x"])
            fz = " / ".join(FIN_TXT.get(f, f) for f in d["fin_z"])
            vals = [str(mid), str(d.get("nombre", "")), f"{d['L_seg']:.3f}",
                    str(d["n_segs_x"]), f"{d['Lx']:.3f}", fx,
                    str(d["n_segs_z"]), f"{d['Lz']:.3f}", fz]
            for c, txt in enumerate(vals):
                it = QTableWidgetItem(txt)
                it.setTextAlignment(Qt.AlignCenter)
                if c not in (4, 7):          # solo las L son editables
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                if not d["ok"]:
                    it.setForeground(Qt.red)
                elif d.get("manual"):
                    it.setForeground(Qt.darkBlue)
                tblC.setItem(i, c, it)
        tblC.resizeColumnsToContents()
        v.addWidget(tblC)

        bb = QDialogButtonBox()
        btn_ap = bb.addButton("Aplicar a Ly/Lz", QDialogButtonBox.AcceptRole)
        btn_ap.setObjectName("btnGreen")
        bb.addButton(QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        # Leer la tabla: guardar los valores revisados y aplicarlos a Ly/Lz
        ov = dict(getattr(self, "_col_len_overrides", {}))
        finales = {}
        for i, mid in enumerate(orden):
            d = datos[mid]

            def _leer(col, calc):
                try:
                    return float(tblC.item(i, col).text().replace(",", "."))
                except (ValueError, AttributeError):
                    return calc

            Lx = _leer(4, d["Lx"])
            Lz = _leer(7, d["Lz"])
            if Lx <= 0 or Lz <= 0:
                continue
            manual = (abs(Lx - d["Lx"]) > 1e-4 or abs(Lz - d["Lz"]) > 1e-4)
            if manual:
                ov[mid] = (Lx, Lz)
            elif mid in ov:
                ov.pop(mid)
            finales[mid] = (Lx, Lz)
        self._col_len_overrides = ov

        tbl.blockSignals(True)
        n_ap = 0
        for row in range(tbl.rowCount()):
            try:
                mid = int(tbl.item(row, self._TBL_COL_ID).text())
            except Exception:
                continue
            if mid not in finales:
                continue
            Lx, Lz = finales[mid]
            # L Dir.X -> Lz (eje fuerte) ; L Dir.Z -> Ly (eje debil)
            for col, val in ((self._TBL_COL_LZ, Lx), (self._TBL_COL_LY, Lz)):
                it = tbl.item(row, col)
                if it is None:
                    it = QTableWidgetItem()
                    tbl.setItem(row, col, it)
                it.setText(f"{val:.2f}")
                it.setTextAlignment(Qt.AlignCenter)
            n_ap += 1
        tbl.blockSignals(False)
        self.sb.showMessage(
            f"Longitud real aplicada a Ly/Lz en {n_ap} miembro(s). "
            f"Vuelva a ejecutar [Auto K] si desea recalcular los factores K.",
            8000)

    def _edit_k_lengths(self):
        """Tabla editable con las longitudes de trabes usadas en Auto-K.
        El usuario corrige las que no sean correctas y recalcula K."""
        beams = getattr(self, "_k_beams", {})
        if not beams:
            QMessageBox.information(self, "Longitudes de trabes",
                                    "Ejecute primero  [Auto K — AISC App.7].")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Longitudes de trabes — calculo de K")
        dlg.setMinimumSize(560, 420)
        dlg.setStyleSheet(MAIN_STYLE)
        v = QVBoxLayout(dlg)
        lbl = QLabel(
            "Longitud REAL (columna a columna) usada para cada trabe en el "
            "calculo de K.\nEdite la columna 'L (m)' si detecta un valor "
            "incorrecto y presione  [Recalcular K].")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        tblL = QTableWidget(len(beams), 4)
        tblL.setHorizontalHeaderLabels(
            ["Trabe", "Perfil", "L (m)", "Terminacion"])
        fin_lbl = {"columna": "en columna", "libre": "VOLADO (excluida)",
                   "quiebre": "quiebre/no colineal"}
        overrides = getattr(self, "_k_overrides", {})
        for i, (bid, (nom, L, fin)) in enumerate(sorted(beams.items())):
            it0 = QTableWidgetItem(str(bid))
            it1 = QTableWidgetItem(str(nom))
            for it in (it0, it1):
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            L_show = overrides.get(bid, L)
            it2 = QTableWidgetItem(f"{L_show:.3f}")
            it3 = QTableWidgetItem(fin_lbl.get(fin, fin))
            it3.setFlags(it3.flags() & ~Qt.ItemIsEditable)
            for c, it in enumerate((it0, it1, it2, it3)):
                it.setTextAlignment(Qt.AlignCenter)
                tblL.setItem(i, c, it)
        tblL.resizeColumnsToContents()
        v.addWidget(tblL)
        bb = QDialogButtonBox()
        btn_rc = bb.addButton("Recalcular K", QDialogButtonBox.AcceptRole)
        bb.addButton(QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        # Leer longitudes revisadas → overrides (solo las que cambiaron)
        new_ov = dict(overrides)
        for i, (bid, (nom, L, fin)) in enumerate(sorted(beams.items())):
            try:
                L_new = float(tblL.item(i, 2).text().replace(",", "."))
            except (ValueError, AttributeError):
                continue
            if L_new > 0 and abs(L_new - L) > 1e-4:
                new_ov[bid] = L_new
            elif bid in new_ov and abs(L_new - L) <= 1e-4:
                new_ov.pop(bid)
        self._k_overrides = new_ov
        self._run_auto_k()

    def _run_auto_k(self):
        """Ejecuta (o re-ejecuta) el calculo de K con las opciones y las
        longitudes de trabes revisadas actuales."""
        tbl = self.tbl_members
        sway_x, sway_z = getattr(self, "_k_sway", (True, True))

        # ── Paso 1: construir conectividad ────────────────────────────────────
        self.sb.showMessage("Construyendo conectividad del modelo...")
        self.pbar.setVisible(True); self.pbar.setValue(5)
        QApplication.processEvents()

        def _progress(pct, msg):
            self.pbar.setValue(max(5, int(pct * 0.4)))  # 0-40 %
            self.sb.showMessage(msg)
            QApplication.processEvents()

        ok_conn, msg_conn = self._reader.build_connectivity(progress_cb=_progress)
        if not ok_conn:
            QMessageBox.critical(self, "Auto K — Error", msg_conn)
            self.pbar.setValue(0); self.pbar.setVisible(False)
            return

        # ── Paso 2: calcular K para cada miembro ──────────────────────────────
        self.sb.showMessage("Calculando factores K (AISC App.7)...")
        self.pbar.setValue(45)
        QApplication.processEvents()

        C            = self
        self._k_beams = {}      # {trabe_id: (nombre, L_usada, fin)}
        tbl.blockSignals(True)
        n_ok         = 0
        n_err        = 0
        total        = tbl.rowCount()
        detail_data  = []   # lista de (mid, perfil, Ky, Kz, texto_detalle)

        for row in range(total):
            try:
                mid = int(tbl.item(row, C._TBL_COL_ID).text())
            except Exception:
                continue

            # sway_y → pandeo eje debil  (Ky)  → Dir Z
            # sway_z → pandeo eje fuerte (Kz)  → Dir X
            # Calculo con longitud REAL de trabes encadenadas (columna a
            # columna); si faltan datos delega al metodo estandar del lector.
            from design.k_chain import compute_k_factors_chained
            kdata = compute_k_factors_chained(
                self._reader, mid,
                sway_y=sway_z,   # Dir Z controla Ky (eje debil)
                sway_z=sway_x,   # Dir X controla Kz (eje fuerte)
                length_overrides=getattr(self, "_k_overrides", {}),
            )
            for _bid, _info in kdata.get("beams_K", {}).items():
                self._k_beams[_bid] = _info
            self._tbl_set_k_row(row, kdata)

            # Obtener nombre de perfil para el reporte
            try:
                perfil = self._reader._section_names.get(mid, f"MBR-{mid}")
            except Exception:
                perfil = f"MBR-{mid}"

            if kdata["ok"]:
                n_ok += 1
                detail_data.append((
                    mid, perfil,
                    kdata["Ky"], kdata["Kz"],
                    kdata.get("detail", "Sin detalle disponible"),
                ))
            else:
                n_err += 1
                log.warning("Auto-K mid=%d: %s", mid, kdata["msg"])
                detail_data.append((
                    mid, perfil, 1.0, 1.0,
                    (
                        f"{'='*72}\n"
                        f"ERROR — MIEMBRO {mid}  {perfil}\n"
                        f"{'='*72}\n\n"
                        f"Mensaje: {kdata['msg']}\n\n"
                        f"K=1.0 asignado por defecto.\n\n"
                        f"Posibles causas:\n"
                        f"  1. El miembro tiene un tipo especial (resorte, cable,\n"
                        f"     tension-only) que no reporta nodos via API estandar.\n"
                        f"  2. El modelo fue cerrado o no esta abierto en STAAD Pro.\n"
                        f"  3. La version de openstaadpy no soporta el metodo de\n"
                        f"     incidencias para este tipo de elemento.\n\n"
                        f"Solucion: Asigne Ky y Kz manualmente en la tabla de\n"
                        f"miembros usando el boton 'Asignar K manual...',\n"
                        f"o consulte el archivo columnsteel.log para el detalle\n"
                        f"tecnico del error.\n"
                    ),
                ))

            pct = 45 + int((row + 1) / max(total, 1) * 50)
            self.pbar.setValue(pct)
            QApplication.processEvents()

        tbl.blockSignals(False)
        self._tbl_sync()

        self.pbar.setValue(100)
        self.pbar.setVisible(False)
        msg_final = (f"  ✔  Auto K completado: {n_ok}/{total} miembros calculados"
                     + (f"  ({n_err} con error — K=1.0)" if n_err else ""))
        self.sb.showMessage(msg_final)
        if hasattr(self, "btn_k_lengths"):
            self.btn_k_lengths.setEnabled(bool(self._k_beams))

        # ── Mensaje de aviso si hay errores ────────────────────────────────────
        if n_err > 0:
            QMessageBox.warning(
                self, "Auto K — Miembros con error",
                f"{n_err} miembro(s) no pudieron calcularse automaticamente "
                f"(K=1.0 asignado).\n\n"
                f"En el dialogo que se abrira a continuacion, los miembros\n"
                f"con error muestran el diagnostico tecnico.\n\n"
                f"Revise el archivo columnsteel.log para mas detalle."
            )

        # ── Mostrar memoria de calculo detallada ───────────────────────────────
        if detail_data:
            dlg_det = KDetailDialog(detail_data, self)
            dlg_det.exec()

    # ── Logica de STAAD ────────────────────────────────────────────────────────

    def _connect_staad(self):
        if self._reader is None:
            QMessageBox.warning(self,"STAAD","openstaadpy no disponible."); return
        self.sb.showMessage("Conectando a STAAD Pro...")
        ok, msg = self._reader.connect()
        if ok:
            self.lbl_conn.setText("Conectado")
            self.lbl_conn.setStyleSheet("color:#1E8449; font-weight:bold;")
            self._detect_lc()
        else:
            self.lbl_conn.setText("Error")
            self.lbl_conn.setStyleSheet("color:#C0392B; font-weight:bold;")
        self.sb.showMessage(msg)

    def _load_from_selection(self):
        if not (self._reader and self._reader.connected):
            QMessageBox.warning(self,"STAAD","Conecte primero."); return
        ids = self._reader.get_selected_members()
        if not ids:
            QMessageBox.information(self,"STAAD","No hay miembros seleccionados en STAAD."); return
        data = [self._make_mp(i) for i in ids]
        self._tbl_load(data)

    def _load_from_ids(self):
        txt = self.txt_ids.text().strip()
        if not txt:
            QMessageBox.warning(self,"IDs","Ingrese IDs en el campo de texto."); return
        ids = _parse_ids(txt)
        if not ids:
            QMessageBox.warning(self,"IDs","IDs invalidos."); return
        data = [self._make_mp(i) for i in ids]
        self._tbl_load(data)

    def _make_mp(self, mid: int) -> dict:
        """
        Solo llama GetBeamLength (seguro).
        Por defecto Ly = Lz = L_real, Ky = Kz = 1.0.
        La lectura de propiedades completa ocurre en pre_fetch.
        """
        L = 0.0
        if self._reader and self._reader.connected:
            try:
                L = float(self._reader._geo.GetBeamLength(mid))
            except Exception:
                L = 0.0
        Ly = L if L > 0 else 4.0
        Lz = L if L > 0 else 4.0   # ajuste 1: Lz = L_real por defecto
        return {
            "id":       mid,
            "length_m": max(L, Ly),
            "Ly_m":     Ly,
            "Lz_m":     Lz,
            "Ky":       1.0,
            "Kz":       1.0,
        }

    def _detect_lc(self):
        if not (self._reader and self._reader.connected): return
        lcs = self._reader.get_load_cases()
        if lcs:
            self.spn_lc_ini.setValue(min(lcs)); self.spn_lc_fin.setValue(max(lcs))
            self.lbl_lc.setText(f"{len(lcs)} combos detectados ({lcs[0]}-{lcs[-1]})")
        else:
            self.lbl_lc.setText("Sin deteccion — use rango manual.")

    # ── Calculo ────────────────────────────────────────────────────────────────

    def _run_design(self):
        self._tbl_sync()
        if not self._member_params:
            QMessageBox.warning(self,"Miembros","Cargue y configure miembros primero."); return
        if not (self._reader and self._reader.connected):
            QMessageBox.warning(self,"STAAD","Conecte primero a STAAD Pro."); return

        code  = "NTC 2023"  if self.rb_ntc.isChecked()  else "AISC 360-22"
        mtype = "Columna"   if self.rb_col.isChecked()   else "Contraviento"
        phi_b = NTC_FR_FLEX  if code=="NTC 2023" else AISC_PHI_B
        phi_c = NTC_FR_COMP  if code=="NTC 2023" else AISC_PHI_C
        phi_v = NTC_FR_SHEAR if code=="NTC 2023" else AISC_PHI_V

        lc_ids    = list(range(self.spn_lc_ini.value(), self.spn_lc_fin.value()+1))
        lc_labels = {lc: f"LC{lc}" for lc in lc_ids}

        mids = [mp["id"] for mp in self._member_params]
        self.pbar.setVisible(True)
        self.pbar.setValue(10)
        QApplication.processEvents()
        try:
            self._reader.pre_fetch(mids, lc_ids)
        except Exception as exc:
            QMessageBox.critical(self,"pre_fetch",str(exc)); return

        mat      = SteelMaterial("Acero STAAD", fy=3515.0, fu=4570.0)
        so_params = self._get_so_params()
        params = {
            "code": code, "member_type": mtype,
            "phi_b": phi_b, "phi_c": phi_c, "phi_v": phi_v,
            "lc_ids": lc_ids, "lc_labels": lc_labels,
            "members": self._member_params, "material": mat,
            "so_params": so_params,
        }
        self._thread = QThread()
        self._worker = DesignWorker(params, self._reader)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._thread.start()

    def _on_progress(self, pct, msg):
        self.pbar.setValue(pct)
        self.sb.showMessage(msg)

    def _on_finished(self, results: List[MemberDesignResult]):
        self._thread.quit(); self._thread.wait()
        self.pbar.setValue(100)
        self.pbar.setVisible(False)
        self._results = results
        self._populate_combos_table(results)
        self._populate_summary_table(results)
        self._populate_diagram_selector(results)
        if results: self._redraw_diagram(0)
        self.sb.showMessage(f"  ✔  Completado — {len(results)} miembro(s).")

    def _on_error(self, msg):
        self._thread.quit(); self._thread.wait()
        self.pbar.setValue(0)
        self.pbar.setVisible(False)
        QMessageBox.critical(self,"Error de cálculo", msg[:1200])

    # ── Poblar tablas ──────────────────────────────────────────────────────────

    def _sep_item(self, val: str) -> QTableWidgetItem:
        """Celda de fila separadora (fondo azul, texto blanco, negrita)."""
        it = QTableWidgetItem(val)
        it.setBackground(QBrush(C_SEP))
        it.setForeground(QBrush(QColor("white")))
        f = it.font(); f.setBold(True); it.setFont(f)
        it.setTextAlignment(Qt.AlignCenter)
        return it

    def _populate_combos_table(self, results: List[MemberDesignResult]):
        tbl  = self.tbl_combos
        tbl.setRowCount(0); tbl.setSortingEnabled(False)
        n_col = tbl.columnCount()  # 18 cols

        # Nombre dinámico de la columna de interacción según norma
        code = results[0].code if results else "NTC 2023"
        inter_lbl = ("Interaccion P-M-M" if "NTC" in code else "H1-1")
        tbl.horizontalHeaderItem(self._COMBO_COL_INTER).setText(inter_lbl)

        # Número de cols de encabezado por miembro
        N_HDR = len(self._COMBO_COLS_HEADER)   # 9

        for r in results:
            klr_y = r.comp.KLr_y if r.comp else 0.0
            klr_x = r.comp.KLr_x if r.comp else 0.0

            # ── Fila encabezado del miembro (cols 0-8 individuales) ───────────
            ri = tbl.rowCount(); tbl.insertRow(ri)
            sep_vals = [
                str(r.member_id),
                r.profile,
                f"{r.length_m:.2f} m",
                f"KLy/ry={klr_y:.1f}",
                f"KLz/rx={klr_x:.1f}",
                f"FRPn={r.comp.phi_Pn:.2f}t"   if r.comp  else "---",
                f"FRMnx={r.flex.phi_Mnx_tm:.2f}tm" if r.flex else "---",
                f"FRMny={r.flex.phi_Mny_tm:.2f}tm" if r.flex else "---",
                f"FRVn={r.shear.phi_Vn_x:.2f}t"  if r.shear else "---",
            ]
            for col, val in enumerate(sep_vals):
                tbl.setItem(ri, col, self._sep_item(val))
            # Cols N_HDR..fin: span con clasificacion
            tbl.setSpan(ri, N_HDR, 1, n_col - N_HDR)
            it_cls = self._sep_item(f"  {r.classification}  |  "
                                    f"Ky={r.Ky:.2f} Kz={r.Kz:.2f}")
            it_cls.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            tbl.setItem(ri, N_HDR, it_cls)

            # ── Filas de combinaciones (cols 0-8 vacías) ──────────────────────
            for cc in r.combos:
                ri2 = tbl.rowCount(); tbl.insertRow(ri2)
                ok  = cc.ok_H and cc.ok_V
                # Naranja cuando KL/r esta excedida pero los ratios cumplen:
                # el miembro "pasa" numericamente pero viola el limite de
                # esbeltez y el usuario debe revisarlo.
                if ok and not r.slenderness_ok:
                    bg = C_WARN
                else:
                    bg = C_OK if ok else C_FAIL

                # Cols 0-8: vacías (datos ya en encabezado del miembro)
                for col in range(N_HDR):
                    it_e = QTableWidgetItem("")
                    it_e.setFlags(it_e.flags() & ~Qt.ItemIsEditable)
                    tbl.setItem(ri2, col, it_e)

                # Cols 9-17: LC, Extr., Pu, Mux, Muy, Vux, Inter., V/Vn, Estado
                data_vals = [
                    cc.lc_label,
                    cc.node,
                    f"{cc.Pu:+.3f}",
                    f"{cc.Mux:.3f}",
                    f"{cc.Muy:.3f}",
                    f"{cc.Vux:.3f}",
                    f"{cc.H_ratio:.4f}",
                    f"{cc.V_ratio:.4f}",
                    "OK" if ok else "FALLA",
                ]
                for j, val in enumerate(data_vals):
                    col = N_HDR + j
                    it2 = QTableWidgetItem(val)
                    it2.setTextAlignment(Qt.AlignCenter)
                    it2.setBackground(QBrush(bg))
                    if not ok and j == len(data_vals) - 1:
                        it2.setForeground(QBrush(QColor("#C0392B")))
                        it2.setFont(QFont("", -1, QFont.Weight.Bold))
                    tbl.setItem(ri2, col, it2)

        tbl.resizeColumnsToContents()

    def _populate_summary_table(self, results: List[MemberDesignResult]):
        tbl  = self.tbl_summary
        tbl.setRowCount(0)
        n_col = tbl.columnCount()   # 15 columnas
        N_HDR = len(self._SUMM_COLS_HEADER)  # 6

        for r in results:
            klr_y   = r.comp.KLr_y if r.comp else 0.0
            klr_x   = r.comp.KLr_x if r.comp else 0.0
            phi_Pn  = r.comp.phi_Pn     if r.comp  else 0.0
            phi_Mnx = r.flex.phi_Mnx_tm if r.flex  else 0.0
            phi_Mny = r.flex.phi_Mny_tm if r.flex  else 0.0
            phi_Vn  = r.shear.phi_Vn_x  if r.shear else 0.0

            # ── Fila encabezado del miembro ───────────────────────────────────
            ri = tbl.rowCount(); tbl.insertRow(ri)
            sep_hdr = [
                str(r.member_id),
                r.profile,
                f"{r.length_m:.2f} m",
                f"KLy/ry={klr_y:.1f}",
                f"KLz/rx={klr_x:.1f}",
                r.classification,
            ]
            for col, val in enumerate(sep_hdr):
                tbl.setItem(ri, col, self._sep_item(val))
            # Cols N_HDR..fin: span con capacidades
            tbl.setSpan(ri, N_HDR, 1, n_col - N_HDR)
            cap_txt = (f"FRPn={phi_Pn:.2f}t  FRMnx={phi_Mnx:.2f}tm  "
                       f"FRMny={phi_Mny:.2f}tm  FRVn={phi_Vn:.2f}t")
            it_cap = self._sep_item(cap_txt)
            it_cap.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            tbl.setItem(ri, N_HDR, it_cap)

            # ── Filas de combinaciones gobernantes ────────────────────────────
            def _add_gov(caso: str, cc: Optional[ComboCheck]):
                ri2 = tbl.rowCount(); tbl.insertRow(ri2)

                # Cols 0-5: vacías (datos ya en encabezado)
                for col in range(N_HDR):
                    it_e = QTableWidgetItem("")
                    it_e.setFlags(it_e.flags() & ~Qt.ItemIsEditable)
                    tbl.setItem(ri2, col, it_e)

                if cc is None:
                    tbl.item(ri2, N_HDR) or tbl.setItem(ri2, N_HDR,
                        QTableWidgetItem(caso))
                    tbl.setItem(ri2, N_HDR, QTableWidgetItem(caso))
                    for c in range(N_HDR + 1, n_col):
                        tbl.setItem(ri2, c, QTableWidgetItem("—"))
                    return

                ok = cc.ok_H and cc.ok_V
                if ok and not r.slenderness_ok:
                    bg = C_WARN     # KL/r excedida con ratios <= 1
                else:
                    bg = C_OK if ok else C_FAIL

                # Valor de interacción en la columna "Interaccion" — solo numero
                if caso == "Cortante":
                    inter_val = f"{cc.V_ratio:.4f}"
                    pu_s = f"{cc.Pu:+.3f}"; mx_s = "—"; my_s = "—"
                    vx_s = f"{cc.Vux:.3f}"
                else:
                    inter_val = f"{cc.H_ratio:.4f}"
                    pu_s = f"{cc.Pu:+.3f}"; mx_s = f"{cc.Mux:.3f}"
                    my_s = f"{cc.Muy:.3f}";  vx_s = f"{cc.Vux:.3f}"

                data_vals = [
                    caso, cc.lc_label, cc.node,
                    pu_s, mx_s, my_s, vx_s,
                    inter_val,
                    "OK" if ok else "FALLA",
                ]
                for j, val in enumerate(data_vals):
                    col = N_HDR + j
                    it2 = QTableWidgetItem(val)
                    it2.setTextAlignment(Qt.AlignCenter)
                    it2.setBackground(QBrush(bg))
                    if not ok and j == len(data_vals) - 1:
                        it2.setForeground(QBrush(QColor("#C0392B")))
                        it2.setFont(QFont("", -1, QFont.Weight.Bold))
                    tbl.setItem(ri2, col, it2)

            _add_gov("Flexocompresion", r.gov_flexocomp)
            _add_gov("Flexotension",    r.gov_flexotens)
            _add_gov("Cortante",        r.gov_shear)

        tbl.resizeColumnsToContents()

    def _populate_diagram_selector(self, results: List[MemberDesignResult]):
        self.cmb_barra.blockSignals(True); self.cmb_barra.clear()
        for r in results:
            self.cmb_barra.addItem(f"Barra {r.member_id} — {r.profile}")
        self.cmb_barra.blockSignals(False)

    # ── Diagrama 3D (ajuste 7: signo Pu) ──────────────────────────────────────

    def _redraw_diagram(self, idx: int):
        if not self._results or idx < 0 or idx >= len(self._results):
            self._draw_empty_diag(); return
        r = self._results[idx]
        if r.comp is None or r.flex is None:
            self._draw_empty_diag(); return

        self.fig_d.clear()
        ax = self.fig_d.add_subplot(111, projection='3d')

        try:
            P_grid, Mx_grid, My_grid = build_3d_interaction_surface(
                r.comp, r.flex, n_angles=36, n_p=80,
                code=r.code, sp=r.sp, mat=r.mat,
                cls_label=r.classification)

            n_a = P_grid.shape[0]
            for i in range(n_a):
                ax.plot(Mx_grid[i], My_grid[i], P_grid[i],
                        color='#1B4F72', alpha=0.30, lw=0.8)

            n_p = P_grid.shape[1]
            for frac in (0.0, 0.25, 0.5, 0.75):
                j = int((frac + 0.5) * n_p)
                j = max(0, min(j, n_p-1))
                Mxr = np.append(Mx_grid[:,j], Mx_grid[0,j])
                Myr = np.append(My_grid[:,j], My_grid[0,j])
                Pr  = np.full(len(Mxr), P_grid[0,j])
                ax.plot(Mxr, Myr, Pr, color='#5D6D7E', alpha=0.35, lw=0.7)

            ax.plot_surface(Mx_grid, My_grid, P_grid,
                            alpha=0.12, color='#2874A6',
                            linewidth=0, antialiased=True)
        except Exception as exc:
            log.warning("Error generando superficie 3D: %s", exc)

        # Ajuste 7: multiplicar Pu * -1 para que compresion sea positiva en grafica
        for cc in r.combos:
            col = "#1E8449" if (cc.ok_H and cc.ok_V) else "#C0392B"
            ax.scatter([cc.Mux], [cc.Muy], [-cc.Pu],   # -Pu: + = compresion
                       color=col, s=60, zorder=6, depthshade=True,
                       edgecolors='white', linewidths=0.5)

        ax.set_xlabel("Mux (ton*m)", fontsize=8, labelpad=6)
        ax.set_ylabel("Muy (ton*m)", fontsize=8, labelpad=6)
        ax.set_zlabel("Pu (ton)\n(+ compresion)", fontsize=8, labelpad=6)
        ax.set_title(f"Superficie P-Mx-My — Barra {r.member_id}  {r.profile}\n{r.code}",
                     fontsize=9, fontweight='bold', color='#1B4F72')

        leg = [Line2D([0],[0],color='#1B4F72',lw=1.5,label='Envolvente H1-1'),
               Line2D([0],[0],marker='o',color='w',markerfacecolor='#1E8449',ms=8,label='OK'),
               Line2D([0],[0],marker='o',color='w',markerfacecolor='#C0392B',ms=8,label='FALLA')]
        ax.legend(handles=leg, fontsize=7, loc='upper left')

        if not r.slenderness_ok:
            ax.text2D(0.98, 0.02, r.slenderness_msg,
                      transform=ax.transAxes, fontsize=7, color='red',
                      va='bottom', ha='right',
                      bbox=dict(boxstyle='round,pad=0.3', fc='#FADBD8', alpha=0.8))

        self.can_d.draw()

    def _draw_empty_diag(self):
        self.fig_d.clear()
        ax = self.fig_d.add_subplot(111, projection='3d')
        ax.set_title("Diagrama de Interaccion P-Mx-My (3D)", fontsize=9,
                     fontweight='bold', color='#1B4F72')
        ax.set_xlabel("Mux (ton*m)"); ax.set_ylabel("Muy (ton*m)")
        ax.set_zlabel("Pu (ton)\n(+ compresion)")
        ax.text(0, 0, 0, "Presione Calcular", ha='center', va='center',
                fontsize=12, color='gray')
        self.can_d.draw()

    # ── Export Word ────────────────────────────────────────────────────────────

    def _export_word(self, kind: str):
        if not self._results:
            QMessageBox.information(self,"Word","Calcule primero."); return
        path, _ = QFileDialog.getSaveFileName(self,"Guardar Word","","Word (*.docx)")
        if not path: return
        try:
            from fileio.word_exporter import (export_combos_only,
                                               export_summary_only,
                                               export_diagrams_only)
            code = "NTC 2023" if self.rb_ntc.isChecked() else "AISC 360-22"
            if kind == "combos":
                from suite_shared.busy_progress import busy_progress
                with busy_progress(self, "Exportando combinaciones a Word…"):
                    export_combos_only(self._results, path, code)
            elif kind == "summary":
                export_summary_only(self._results, path, code)
            else:
                export_diagrams_only(self._results, path, code)
            QMessageBox.information(self,"Word",f"Exportado:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self,"Word Error", str(exc))

    def _print_memory(self):
        if not self._results:
            QMessageBox.information(self,"Memoria","Calcule primero."); return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Memoria de Calculo", "", "Word (*.docx)")
        if not path: return
        try:
            from fileio.word_exporter import export_memory
            code = "NTC 2023" if self.rb_ntc.isChecked() else "AISC 360-22"
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando memoria de cálculo…"):
                export_memory(self._results, path, code)
            QMessageBox.information(self, "Memoria", f"Memoria exportada:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "Error — Memoria", str(exc))


# ── Utilidades ────────────────────────────────────────────────────────────────

def _parse_ids(txt: str) -> List[int]:
    import re
    ids: List[int] = []
    for token in re.split(r"[,;\s]+", txt.strip()):
        if not token: continue
        m = re.match(r"(\d+)-(\d+)$", token)
        if m:
            ids.extend(range(int(m.group(1)), int(m.group(2))+1))
        else:
            try: ids.append(int(token))
            except ValueError: pass
    return sorted(set(ids))
