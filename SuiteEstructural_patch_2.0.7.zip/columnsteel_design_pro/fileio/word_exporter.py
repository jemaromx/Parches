# fileio/word_exporter.py
"""
Exportador Word para resultados de columnas y contravientos de acero.
Requiere: python-docx  (pip install python-docx)

Genera un documento .docx con:
  - Portada e identificacion
  - Tabla de resultados por combinacion por barra
  - Tabla de resumen (combinaciones gobernantes) por barra
  - Diagrama de interaccion P-M por barra (imagen incrustada)
  - Memoria de calculo detallada por barra
"""
from __future__ import annotations
import io, math, os, tempfile
from typing import List, Optional

try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
    from docx.oxml.ns import qn
    from docx.oxml  import OxmlElement
    _HAS_DOCX = True
except ImportError:
    _HAS_DOCX = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _HAS_MPL = True
except ImportError:
    _HAS_MPL = False

from design.column_design import (MemberDesignResult, ComboCheck,
                                   build_interaction_curve,
                                   build_3d_interaction_surface)

# ── Paleta ────────────────────────────────────────────────────────────────────
_BLUE   = RGBColor(0x1B, 0x4F, 0x72)   if _HAS_DOCX else None
_LBLUE  = RGBColor(0xD6, 0xEA, 0xF8)   if _HAS_DOCX else None
_GREEN  = RGBColor(0xD5, 0xF5, 0xE3)   if _HAS_DOCX else None
_RED    = RGBColor(0xFA, 0xDB, 0xD8)   if _HAS_DOCX else None
_WHITE  = RGBColor(0xFF, 0xFF, 0xFF)   if _HAS_DOCX else None


def _require():
    if not _HAS_DOCX:
        raise ImportError("Instale python-docx:  pip install python-docx")


def export_results(results: List[MemberDesignResult],
                   path: str,
                   code: str = "NTC 2023") -> bool:
    """
    Genera el documento Word completo con resultados, resumen e interaccion.
    """
    _require()
    doc = Document()
    _setup_styles(doc)
    _portada(doc, code)

    for r in results:
        _section_header(doc, r)
        _table_combos(doc, r)
        _table_summary(doc, r)
        if r.comp and r.flex:
            _interaction_chart(doc, r)
        _memory_section(doc, r)
        doc.add_page_break()

    doc.save(path)
    return True


def export_combos_only(results: List[MemberDesignResult],
                       path: str, code: str = "NTC 2023") -> bool:
    _require()
    doc = Document()
    _setup_styles(doc)
    _portada(doc, code, "Resultados por combinacion")
    for r in results:
        _section_header(doc, r)
        _table_combos(doc, r)
    doc.save(path)
    return True


def export_summary_only(results: List[MemberDesignResult],
                        path: str, code: str = "NTC 2023") -> bool:
    _require()
    doc = Document()
    _setup_styles(doc)
    _portada(doc, code, "Resumen de combinaciones gobernantes")
    for r in results:
        _section_header(doc, r)
        _table_summary(doc, r)
    doc.save(path)
    return True


def export_diagrams_only(results: List[MemberDesignResult],
                          path: str, code: str = "NTC 2023") -> bool:
    _require()
    doc = Document()
    _setup_styles(doc)
    _portada(doc, code, "Diagramas de interaccion P-M")
    for r in results:
        _section_header(doc, r)
        if r.comp and r.flex:
            _interaction_chart(doc, r)
    doc.save(path)
    return True


# ── Secciones del documento ───────────────────────────────────────────────────

def _portada(doc: "Document", code: str, subtitle: str = "Diseno de Columnas y Contravientos"):
    h = doc.add_heading("Column Steel Design Pro", 0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _fmt_heading(h, 16, bold=True)

    p = doc.add_paragraph(subtitle)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.runs[0].font.size  = Pt(13)
    p.runs[0].font.bold  = True
    p.runs[0].font.color.rgb = _BLUE

    p2 = doc.add_paragraph(f"Codigo: {code}")
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph()


def _section_header(doc, r: MemberDesignResult):
    """Separador tipo encabezado por barra."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    run = p.add_run(
        f"Barra {r.member_id}  |  {r.profile}  |  L = {r.length_m:.3f} m  |  "
        f"Ly={r.Ly_m:.2f}m  Ky={r.Ky:.3f}  Lz={r.Lz_m:.2f}m  Kz={r.Kz:.3f}"
    )
    run.font.size  = Pt(11)
    run.font.bold  = True
    run.font.color.rgb = _WHITE
    _shade_paragraph(p, "1B4F72")


def _table_combos(doc, r: MemberDesignResult):
    """Tabla completa de resultados por combinacion."""
    doc.add_heading("Resultados por Combinacion", level=2)
    _add_ref(doc, r.code)

    hdrs = ["Comb.","Extremo","Pu (t)","Mux (tm)","Muy (tm)",
            "Vux (t)","Pu/FRPn","Mux/FRMnx","Muy/FRMny",
            "H1-1","Ec.","V/FRVn","Estado"]
    tbl = doc.add_table(rows=1, cols=len(hdrs))
    tbl.style = "Table Grid"
    _set_header_row(tbl.rows[0], hdrs)

    for cc in r.combos:
        row = tbl.add_row().cells
        ok  = cc.ok_H and cc.ok_V
        bg  = "D5F5E3" if ok else "FADBD8"
        vals = [
            cc.lc_label, cc.node,
            f"{cc.Pu:+.3f}", f"{cc.Mux:.3f}", f"{cc.Muy:.3f}", f"{cc.Vux:.3f}",
            f"{cc.pn_ratio:.4f}", f"{cc.mx_ratio:.4f}", f"{cc.my_ratio:.4f}",
            f"{cc.H_ratio:.4f}", cc.H_eq,
            f"{cc.V_ratio:.4f}", "OK" if ok else "FALLA",
        ]
        for i, (cell, val) in enumerate(zip(row, vals)):
            cell.text = val
            _shade_cell(cell, bg)
            if not ok and i == len(vals)-1:
                cell.paragraphs[0].runs[0].font.bold  = True
                cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xC0,0x39,0x2B)

    doc.add_paragraph()


def _table_summary(doc, r: MemberDesignResult):
    """Tabla de combinaciones gobernantes."""
    doc.add_heading("Resumen — Combinaciones Gobernantes", level=2)

    hdrs = ["Caso","Combinacion","Extremo","Elemento mecanico gov.",
            "Relacion de esfuerzos","Estado"]
    tbl = doc.add_table(rows=1, cols=len(hdrs))
    tbl.style = "Table Grid"
    _set_header_row(tbl.rows[0], hdrs)

    def _add_gov(label: str, cc: Optional[ComboCheck]):
        if cc is None:
            row = tbl.add_row().cells
            row[0].text = label
            for i in range(1, len(hdrs)):
                row[i].text = "—"
            return
        ok  = cc.ok_H and cc.ok_V
        bg  = "D5F5E3" if ok else "FADBD8"
        if label == "Cortante":
            em_val = f"Vux = {cc.Vux:.3f} t"; ratio = f"{cc.V_ratio:.4f}"
        else:
            em_val = (f"Pu={cc.Pu:+.3f}t  Mux={cc.Mux:.3f}tm  Muy={cc.Muy:.3f}tm")
            ratio  = f"H = {cc.H_ratio:.4f}  ({cc.H_eq})"
        row = tbl.add_row().cells
        vals = [label, cc.lc_label, cc.node, em_val, ratio, "OK" if ok else "FALLA"]
        for cell, val in zip(row, vals):
            cell.text = val; _shade_cell(cell, bg)

    _add_gov("Flexocompresion", r.gov_flexocomp)
    _add_gov("Flexotension",    r.gov_flexotens)
    _add_gov("Cortante",        r.gov_shear)
    doc.add_paragraph()


def _interaction_chart(doc, r: MemberDesignResult):
    """Dibuja el diagrama P-M (2D) y lo incrusta. Ajuste 7: -Pu para+ = compresion."""
    if not _HAS_MPL:
        doc.add_paragraph("[matplotlib no disponible — diagrama omitido]")
        return
    doc.add_heading("Diagrama de Interaccion P-M", level=2)

    fig, ax = plt.subplots(figsize=(6, 4.5))
    P_env, M_env = build_interaction_curve(
        r.comp, r.flex, n_pts=300,
        code=r.code, sp=r.sp, mat=r.mat, cls_label=r.classification)
    ax.plot(M_env, P_env, color="#1B4F72", lw=2, label="Envolvente H1-1")

    # Ajuste 7: -cc.Pu para que compresion sea positiva en la grafica
    for cc in r.combos:
        color = "#1E8449" if (cc.ok_H and cc.ok_V) else "#C0392B"
        ax.scatter(cc.Mux, -cc.Pu, color=color, s=55, zorder=5,
                   edgecolors="white", linewidths=0.6)

    ax.axhline(0, color="gray", lw=0.7, ls=":")
    ax.axvline(0, color="gray", lw=0.7, ls=":")
    ax.set_xlabel("Mux  [ton*m]", fontsize=8)
    ax.set_ylabel("Pu  [ton]  (+ compresion)", fontsize=8)
    ax.set_title(f"P-Mx — Barra {r.member_id}  {r.profile}  |  {r.code}",
                 fontsize=9, fontweight="bold")
    ax.grid(True, ls="--", alpha=0.35)
    from matplotlib.lines import Line2D
    leg = [Line2D([0],[0], color="#1B4F72", lw=2, label="Envolvente H1-1"),
           Line2D([0],[0], marker="o", color="w", markerfacecolor="#1E8449",
                  markersize=8, label="OK"),
           Line2D([0],[0], marker="o", color="w", markerfacecolor="#C0392B",
                  markersize=8, label="FALLA")]
    ax.legend(handles=leg, fontsize=7)
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=120)
    buf.seek(0); plt.close(fig)
    doc.add_picture(buf, width=Inches(5.5))
    doc.add_paragraph()


def _memory_section(doc, r: MemberDesignResult):
    """Memoria de calculo."""
    doc.add_heading("Memoria de Calculo", level=2)
    para = doc.add_paragraph()
    run  = para.add_run("\n".join(r.calc_memory))
    run.font.name = "Consolas"
    run.font.size = Pt(7)


# ══════════════════════════════════════════════════════════════════════════════
# Memoria detallada — solo combinaciones gobernantes + diagrama
# ══════════════════════════════════════════════════════════════════════════════

def export_memory(results: List[MemberDesignResult],
                  path: str,
                  code: str = "NTC 2023") -> bool:
    """
    Genera memoria de calculo profesional en Word:
      - Solo combinaciones mas desfavorables con formulas y referencias normativas
      - Diagrama de interaccion P-M con todos los puntos de combinaciones
      - Numeracion de paginas y fecha
    """
    _require()
    from datetime import datetime
    doc = Document()
    _setup_styles(doc)

    # ── Portada ────────────────────────────────────────────────────────────────
    doc.add_paragraph()
    h = doc.add_heading("MEMORIA DE CÁLCULO", 0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _fmt_heading(h, 20)
    doc.add_paragraph()

    for txt, sz, bold, col in [
        ("Diseño de Columnas y Contravientos de Acero", 14, True, _BLUE),
        (f"Código de diseño:  {code}", 12, True, _BLUE),
        ("", 10, False, None),
        (f"Fecha:  {datetime.now().strftime('%d/%m/%Y   %H:%M hrs')}", 10, False, None),
        ("Software:  Column Steel Design Pro", 9, False, None),
        (f"Miembros revisados:  {len(results)}", 9, False, None),
    ]:
        p = doc.add_paragraph(txt)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if p.runs:
            p.runs[0].font.size = Pt(sz)
            p.runs[0].font.bold = bold
            if col: p.runs[0].font.color.rgb = col
    doc.add_page_break()

    for r in results:
        _mem_word_member(doc, r, code)
        doc.add_page_break()

    _add_page_numbers(doc)
    doc.save(path)
    return True


def _mem_word_member(doc, r: MemberDesignResult, code: str):
    """Escribe la memoria detallada de un miembro en el documento Word."""
    is_ntc = (code == "NTC 2023")

    # ── Encabezado del miembro ─────────────────────────────────────────────────
    _section_header(doc, r)

    # ── Datos generales ────────────────────────────────────────────────────────
    doc.add_heading("Datos Generales", level=2)
    tbl = doc.add_table(rows=1, cols=4)
    tbl.style = "Table Grid"
    _set_header_row(tbl.rows[0], ["Parámetro", "Valor", "Parámetro", "Valor"])
    rows_data = [
        ("Barra ID",      str(r.member_id),
         "Perfil",        r.profile),
        ("Longitud total", f"{r.length_m:.3f} m",
         "Tipo de miembro", r.member_type),
        ("Ly (eje débil)", f"{r.Ly_m:.3f} m",
         "Ky",             f"{r.Ky:.4f}"),
        ("Lz (eje fuerte)", f"{r.Lz_m:.3f} m",
         "Kz",              f"{r.Kz:.4f}"),
        ("KLy/ry",  f"{r.comp.KLr_y:.2f}" if r.comp else "—",
         "KLz/rx",  f"{r.comp.KLr_x:.2f}" if r.comp else "—"),
        ("Clasificación", r.classification if r.classification else "—",
         "Código",        code),
    ]
    for a, b, c, d in rows_data:
        row = tbl.add_row().cells
        row[0].text = a; _shade_cell(row[0], "EBF5FB")
        row[1].text = b
        row[2].text = c; _shade_cell(row[2], "EBF5FB")
        row[3].text = d
    doc.add_paragraph()

    # ── Extraer secciones de la memoria de texto ───────────────────────────────
    _mem_write_sections(doc, r, is_ntc)

    # ── Combinaciones gobernantes ──────────────────────────────────────────────
    h = doc.add_heading("Combinaciones Gobernantes y Verificación Final", level=2)
    _fmt_heading(h, 11)
    _mem_gov_combos_table(doc, r, code)

    # ── Diagrama de interaccion ────────────────────────────────────────────────
    if r.comp and r.flex:
        h = doc.add_heading("Diagrama de Interacción P-M", level=2)
        _fmt_heading(h, 11)
        p = doc.add_paragraph(
            "El diagrama muestra la envolvente H1-1 de capacidad y los puntos "
            "de demanda de todas las combinaciones de carga revisadas.")
        p.runs[0].font.size = Pt(9); p.runs[0].font.italic = True
        _interaction_chart_memory(doc, r)


def _mem_write_sections(doc, r: MemberDesignResult, is_ntc: bool):
    """
    Extrae y formatea las secciones de la memoria de calculo de texto.
    Omite la seccion de verificacion por combinacion (se muestra aparte
    con solo las combinaciones gobernantes).
    """
    lines = r.calc_memory
    # Cortar antes de la seccion VERIFICACION
    cut = len(lines)
    for i, ln in enumerate(lines):
        if "VERIFICACION POR COMBINACION" in ln:
            cut = i; break
    lines = lines[:cut]

    # Separar en secciones por encabezados "-- TITULO --"
    sections: list[tuple[str, list[str]]] = []
    cur_title = "Datos de Entrada"
    cur_body: list[str] = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("-- ") and " --" in s[3:]:
            end_idx = s.index(" --", 3)
            title = s[3:end_idx].strip()
            if cur_body:
                sections.append((cur_title, list(cur_body)))
            cur_title = title; cur_body = []
        elif set(s) <= {'='} and len(s) > 5:
            pass   # separadores horizontales → omitir
        else:
            cur_body.append(ln)
    if cur_body:
        sections.append((cur_title, list(cur_body)))

    # Nombres de sección SIN numeración (evita choque con la numeración de la
    # plantilla Word del cliente).
    sec_names = {
        "CLASIFICACION DE SECCION": "Clasificación de la Sección",
        "COMPRESION":               "Capacidad a Compresión",
        "FLEXION EJE FUERTE":       "Capacidad a Flexión",
        "CORTANTE EJE FUERTE":      "Capacidad a Cortante",
    }

    for i, (title, body) in enumerate(sections):
        # Titulo de seccion
        display_title = None
        for key, val in sec_names.items():
            if key in title.upper():
                display_title = val; break
        if display_title is None:
            display_title = title.strip()
        h = doc.add_heading(display_title, level=2)
        _fmt_heading(h, 11)
        # Cuerpo en fuente monoespaciada
        body_text = "\n".join(ln for ln in body if ln.strip())
        if body_text.strip():
            para = doc.add_paragraph()
            run  = para.add_run(body_text)
            run.font.name = "Consolas"; run.font.size = Pt(8)
        doc.add_paragraph()


def _mem_gov_combos_table(doc, r: MemberDesignResult, code: str):
    """Tabla de combinaciones gobernantes con formulas y referencias."""
    is_ntc = (code == "NTC 2023")
    FR = "FR" if is_ntc else "φ"

    ref_txt = ("NTC Acero CDMX 2024  Cap. 9  Art. 9.1.6.2"
               if is_ntc else "AISC 360-22  Cap. H  Art. H1-1a/b")
    p = doc.add_paragraph(f"Referencia normativa: {ref_txt}")
    p.runs[0].font.size = Pt(9); p.runs[0].font.italic = True
    p.runs[0].font.color.rgb = RGBColor(0x5D, 0x6D, 0x7E)

    # Capacidades de diseño
    phi_Pn   = r.comp.phi_Pn   if r.comp  else 0.0
    phi_Pnt  = r.comp.phi_Pn_t if r.comp  else 0.0
    phi_Mnx  = r.flex.phi_Mnx_tm if r.flex else 0.0
    phi_Mny  = r.flex.phi_Mny_tm if r.flex else 0.0
    phi_Vn   = r.shear.phi_Vn_x  if r.shear else 0.0

    p2 = doc.add_paragraph(
        f"  {FR}·Pn = {phi_Pn:.3f} t   |   "
        f"{FR}·Pnt = {phi_Pnt:.3f} t   |   "
        f"{FR}·Mnx = {phi_Mnx:.3f} t·m   |   "
        f"{FR}·Mny = {phi_Mny:.3f} t·m   |   "
        f"{FR}·Vn = {phi_Vn:.3f} t")
    p2.runs[0].font.name = "Consolas"; p2.runs[0].font.size = Pt(9)
    p2.runs[0].font.bold = True

    hdrs = ["Caso", "LC", "Extr.", "Tipo",
            "Pu (t)", "Mux (tm)", "Muy (tm)", "Vux (t)",
            f"Pu/{FR}Pn", f"Mux/{FR}Mnx", f"Muy/{FR}Mny",
            "Ecuación", "H ó V/Vn", "Ref. Normativa", "Estado"]
    tbl = doc.add_table(rows=1, cols=len(hdrs))
    tbl.style = "Table Grid"
    _set_header_row(tbl.rows[0], hdrs)

    def _add_row(label: str, cc: Optional[ComboCheck]):
        if cc is None:
            row = tbl.add_row().cells
            row[0].text = label
            for i in range(1, len(hdrs)):
                row[i].text = "—"
            return
        ok = cc.ok_H and cc.ok_V
        bg = "D5F5E3" if ok else "FADBD8"
        tipo = "TENSION" if cc.tension else "COMPRESION"
        if label == "Cortante":
            # El área de alma depende de la forma: los tubos OR y cajones
            # tienen DOS almas (NTC Art.8.6.1 / AISC G4).
            _n_alm = getattr(r.shear, "n_almas", 1) if r.shear else 1
            _aa    = "2·h·t" if _n_alm >= 2 else ("h·ta" if is_ntc else "d·tw")
            eq_str = (f"Vn = 0.6·Fy·Aa·Cv   (Aa = {_aa})" if is_ntc
                      else f"Vn = 0.6·Fy·Aw·Cv1   (Aw = {_aa})")
            _ref_v = (("NTC Art.8.6.1" if _n_alm >= 2 else "NTC Art.8.2.2")
                      if is_ntc else
                      ("AISC G4" if _n_alm >= 2 else "AISC G2.1"))
            rel = f"V/{FR}Vn = {cc.V_ratio:.4f}"
            vals = [label, cc.lc_label, cc.node, tipo,
                    f"{cc.Pu:+.3f}", "—", "—", f"{cc.Vux:.3f}",
                    "—", "—", "—", eq_str, rel,
                    cc.H_ref or _ref_v,
                    "OK" if ok else "FALLA"]
        else:
            if cc.H_eq == "H1-1a":
                eq_str = (f"Pu/{FR}Pn + (8/9)·(Mux/{FR}Mnx + Muy/{FR}Mny) ≤ 1.0"
                          f"  [Pu/{FR}Pn ≥ 0.20]")
            else:
                eq_str = (f"Pu/(2·{FR}Pn) + Mux/{FR}Mnx + Muy/{FR}Mny ≤ 1.0"
                          f"  [Pu/{FR}Pn < 0.20]")
            rel = f"H = {cc.H_ratio:.4f}"
            vals = [label, cc.lc_label, cc.node, tipo,
                    f"{cc.Pu:+.3f}", f"{cc.Mux:.3f}", f"{cc.Muy:.3f}", f"{cc.Vux:.3f}",
                    f"{cc.pn_ratio:.4f}", f"{cc.mx_ratio:.4f}", f"{cc.my_ratio:.4f}",
                    cc.H_eq, rel, cc.H_ref, "OK" if ok else "FALLA"]
        row = tbl.add_row().cells
        for i, (cell, val) in enumerate(zip(row, vals)):
            cell.text = val; _shade_cell(cell, bg)
            cell.paragraphs[0].runs[0].font.size = Pt(8)
            if not ok and i == len(vals) - 1:
                cell.paragraphs[0].runs[0].font.bold  = True
                cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xC0, 0x39, 0x2B)

    _add_row("Flexocompresión", r.gov_flexocomp)
    _add_row("Flexotensión",    r.gov_flexotens)
    _add_row("Cortante",        r.gov_shear)
    doc.add_paragraph()


def _interaction_chart_memory(doc, r: MemberDesignResult):
    """
    Diagramas de interaccion para la memoria:
      2D: P-Mx y P-My lado a lado
      3D: superficie P-Mx-My (ajuste 6)
    Ajuste 7: -cc.Pu para que compresion sea positiva en la grafica.
    """
    if not _HAS_MPL:
        doc.add_paragraph("[matplotlib no disponible — diagrama omitido]")
        return

    from matplotlib.lines import Line2D

    # ── Diagramas 2D (P-Mx y P-My) ────────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    ax  = axes[0]
    ax2 = axes[1]

    # P-Mx
    P_env, M_env = build_interaction_curve(
        r.comp, r.flex, n_pts=300,
        code=r.code, sp=r.sp, mat=r.mat, cls_label=r.classification)
    ax.plot(M_env, P_env, color="#1B4F72", lw=2)
    ax.axhline(0, color="gray", lw=0.7, ls=":"); ax.axvline(0, color="gray", lw=0.7, ls=":")
    for cc in r.combos:
        col = "#1E8449" if (cc.ok_H and cc.ok_V) else "#C0392B"
        ax.scatter(cc.Mux, -cc.Pu, color=col, s=40, zorder=5,    # ajuste 7
                   edgecolors="white", linewidths=0.5)
    ax.set_xlabel("Mux [ton*m]", fontsize=8)
    ax.set_ylabel("Pu [ton]  (+ compresion)", fontsize=8)
    ax.set_title(f"P-Mx  |  Barra {r.member_id}  {r.profile}", fontsize=8, fontweight="bold")
    ax.grid(True, ls="--", alpha=0.35)

    # P-My
    phi_Pn  = r.comp.phi_Pn;  phi_Pnt = r.comp.phi_Pn_t
    phi_Mny = r.flex.phi_Mny_tm
    P_list2, M_list2 = [], []
    for i in range(301):
        t = i / 300
        P = phi_Pn*(1-t) + (-phi_Pnt)*t
        rr = abs(P)/phi_Pn if P >= 0 else abs(P)/(phi_Pnt+1e-9)
        M = phi_Mny*(1-rr)*9/8 if (P >= 0 and rr >= 0.2) else phi_Mny*(1-rr/2)
        P_list2.append(P); M_list2.append(max(0.0, M))
    ax2.plot(M_list2, P_list2, color="#117A65", lw=2)
    ax2.axhline(0, color="gray", lw=0.7, ls=":"); ax2.axvline(0, color="gray", lw=0.7, ls=":")
    for cc in r.combos:
        col = "#1E8449" if (cc.ok_H and cc.ok_V) else "#C0392B"
        ax2.scatter(cc.Muy, -cc.Pu, color=col, s=40, zorder=5,   # ajuste 7
                    edgecolors="white", linewidths=0.5)
    ax2.set_xlabel("Muy [ton*m]", fontsize=8)
    ax2.set_ylabel("Pu [ton]  (+ compresion)", fontsize=8)
    ax2.set_title(f"P-My  |  Barra {r.member_id}  {r.profile}", fontsize=8, fontweight="bold")
    ax2.grid(True, ls="--", alpha=0.35)

    leg = [Line2D([0],[0], color="#1B4F72", lw=2, label="Envolvente H1-1"),
           Line2D([0],[0], marker="o", color="w", markerfacecolor="#1E8449",
                  markersize=7, label="OK"),
           Line2D([0],[0], marker="o", color="w", markerfacecolor="#C0392B",
                  markersize=7, label="FALLA")]
    fig.legend(handles=leg, fontsize=7, loc="lower center", ncol=3, bbox_to_anchor=(0.5,-0.02))
    fig.suptitle(f"Barra {r.member_id}  |  {r.profile}  |  {r.code}",
                 fontsize=9, fontweight="bold", color="#1B4F72")
    fig.tight_layout(rect=[0, 0.05, 1, 1])

    buf2d = io.BytesIO()
    fig.savefig(buf2d, format="png", dpi=130)
    buf2d.seek(0); plt.close(fig)
    doc.add_picture(buf2d, width=Inches(6.2))
    doc.add_paragraph()

    # ── Diagrama 3D P-Mx-My (ajuste 6) ────────────────────────────────────────
    try:
        import numpy as np
        from mpl_toolkits.mplot3d import Axes3D   # noqa
        from design.column_design import build_3d_interaction_surface

        fig3 = plt.figure(figsize=(7, 5))
        ax3  = fig3.add_subplot(111, projection='3d')
        P_grid, Mx_grid, My_grid = build_3d_interaction_surface(
            r.comp, r.flex, n_angles=24, n_p=60,
            code=r.code, sp=r.sp, mat=r.mat,
            cls_label=r.classification)

        for i in range(P_grid.shape[0]):
            ax3.plot(Mx_grid[i], My_grid[i], P_grid[i],
                     color='#1B4F72', alpha=0.25, lw=0.7)
        ax3.plot_surface(Mx_grid, My_grid, P_grid,
                         alpha=0.10, color='#2874A6', linewidth=0, antialiased=True)

        n_p = P_grid.shape[1]
        for frac in (0.0, 0.25, 0.5, 0.75):
            j = max(0, min(int((frac + 0.5) * n_p), n_p-1))
            Mxr = np.append(Mx_grid[:,j], Mx_grid[0,j])
            Myr = np.append(My_grid[:,j], My_grid[0,j])
            Pr  = np.full(len(Mxr), P_grid[0,j])
            ax3.plot(Mxr, Myr, Pr, color='#5D6D7E', alpha=0.4, lw=0.8)

        # Ajuste 7: -cc.Pu para que compresion sea positiva
        for cc in r.combos:
            col = "#1E8449" if (cc.ok_H and cc.ok_V) else "#C0392B"
            ax3.scatter([cc.Mux], [cc.Muy], [-cc.Pu],
                        color=col, s=50, zorder=6, depthshade=True,
                        edgecolors='white', linewidths=0.4)

        ax3.set_xlabel("Mux (ton*m)", fontsize=7, labelpad=4)
        ax3.set_ylabel("Muy (ton*m)", fontsize=7, labelpad=4)
        ax3.set_zlabel("Pu (ton) (+ comp.)", fontsize=7, labelpad=4)
        ax3.set_title(f"Superficie P-Mx-My — Barra {r.member_id}  {r.profile}",
                      fontsize=8, fontweight="bold", color="#1B4F72")
        leg3 = [Line2D([0],[0], color="#1B4F72", lw=1.5, label="Envolvente"),
                Line2D([0],[0], marker="o", color="w", markerfacecolor="#1E8449",
                       markersize=7, label="OK"),
                Line2D([0],[0], marker="o", color="w", markerfacecolor="#C0392B",
                       markersize=7, label="FALLA")]
        ax3.legend(handles=leg3, fontsize=6, loc="upper left")
        fig3.tight_layout()

        buf3d = io.BytesIO()
        fig3.savefig(buf3d, format="png", dpi=120)
        buf3d.seek(0); plt.close(fig3)
        doc.add_picture(buf3d, width=Inches(5.8))
        doc.add_paragraph()
    except Exception as exc:
        doc.add_paragraph(f"[Diagrama 3D no disponible: {exc}]")
        doc.add_paragraph()


def _add_page_numbers(doc):
    """Agrega numeros de pagina al pie de pagina."""
    try:
        section = doc.sections[0]
        footer = section.footer
        para = footer.paragraphs[0]
        para.clear()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run("Página ")
        run.font.size = Pt(8); run.font.color.rgb = RGBColor(0x5D, 0x6D, 0x7E)

        fldChar1 = OxmlElement("w:fldChar"); fldChar1.set(qn("w:fldCharType"), "begin")
        instrText = OxmlElement("w:instrText")
        instrText.set(qn("xml:space"), "preserve"); instrText.text = "PAGE"
        fldChar2 = OxmlElement("w:fldChar"); fldChar2.set(qn("w:fldCharType"), "end")
        r_el = OxmlElement("w:r")
        r_el.append(fldChar1); r_el.append(instrText); r_el.append(fldChar2)
        para._p.append(r_el)

        run2 = para.add_run(" de ")
        run2.font.size = Pt(8); run2.font.color.rgb = RGBColor(0x5D, 0x6D, 0x7E)
        fldChar3 = OxmlElement("w:fldChar"); fldChar3.set(qn("w:fldCharType"), "begin")
        instrText2 = OxmlElement("w:instrText")
        instrText2.set(qn("xml:space"), "preserve"); instrText2.text = "NUMPAGES"
        fldChar4 = OxmlElement("w:fldChar"); fldChar4.set(qn("w:fldCharType"), "end")
        r_el2 = OxmlElement("w:r")
        r_el2.append(fldChar3); r_el2.append(instrText2); r_el2.append(fldChar4)
        para._p.append(r_el2)
    except Exception:
        pass


# ── Utilidades de formato ─────────────────────────────────────────────────────

def _setup_styles(doc):
    # Hoja CARTA vertical + fuente base unificada + títulos sin numeración.
    try:
        from suite_shared.docx_style import aplicar_estilo_memoria
        aplicar_estilo_memoria(doc, apaisado=False)
    except Exception:
        from docx.shared import Pt
        style = doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(10)


def _fmt_heading(h, size: int, bold: bool = True):
    for run in h.runs:
        run.font.size  = Pt(size)
        run.font.bold  = bold
        run.font.color.rgb = _BLUE


def _add_ref(doc, code: str):
    ref = ("NTC Acero CDMX 2024  Cap. 9 (Art. 9.1)"
           if code == "NTC 2023"
           else "AISC 360-22 Capitulo H (H1-1a/b)")
    p = doc.add_paragraph(f"Referencia: {ref}")
    p.runs[0].font.size   = Pt(8)
    p.runs[0].font.italic = True
    p.runs[0].font.color.rgb = RGBColor(0x5D, 0x6D, 0x7E)


def _set_header_row(row, headers: list):
    for cell, hdr in zip(row.cells, headers):
        cell.text = hdr
        run = cell.paragraphs[0].runs[0]
        run.font.bold  = True
        run.font.color.rgb = _WHITE
        run.font.size  = Pt(8)
        _shade_cell(cell, "1B4F72")


def _shade_cell(cell, hex_color: str):
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _shade_paragraph(para, hex_color: str):
    pPr  = para._p.get_or_add_pPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_color)
    pPr.append(shd)
