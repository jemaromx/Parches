﻿"""Panel de entrada de parámetros de diseño — con barra de desplazamiento."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QLabel, QLineEdit, QPushButton,
    QComboBox, QDoubleSpinBox, QSpinBox, QFileDialog,
    QMessageBox, QCheckBox, QRadioButton,
    QScrollArea, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QSizePolicy,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor

try:
    from fileio.openstaad_reader import AVAILABLE as _OPENSTAAD_AVAILABLE
except Exception:
    _OPENSTAAD_AVAILABLE = False


class InputPanel(QWidget):
    """Panel lateral con scroll vertical — todos los parámetros de diseño."""

    # Señales
    run_requested    = Signal(object)
    anl_loaded       = Signal(str)
    staad_connected  = Signal()
    refresh_columns  = Signal()   # solicita leer columnas desde STAAD
    calc_k_requested = Signal()   # solicita calcular K desde STAAD
    col_len_requested = Signal()  # solicita revisar la longitud real de columnas

    def __init__(self, parent=None):
        super().__init__(parent)
        self._anl_path   = ""
        self._build_ui()

    # ── Construcción de la UI ─────────────────────────────────────────────────

    def _build_ui(self):
        # Layout exterior: fill completo del widget, sin márgenes
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── QScrollArea ──────────────────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)
        outer.addWidget(scroll)

        # Widget contenedor dentro del scroll
        content = QWidget()
        scroll.setWidget(content)

        # Layout del contenido
        lay = QVBoxLayout(content)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        lay.addWidget(self._group_anl())
        lay.addWidget(self._group_columnas())
        lay.addWidget(self._group_materials())
        lay.addWidget(self._group_cover())
        lay.addWidget(self._group_ratios())
        lay.addWidget(self._group_loadcases())
        lay.addWidget(self._group_code())
        lay.addWidget(self._group_col_length())
        lay.addWidget(self._group_second_order())
        lay.addWidget(self._group_dxf())
        lay.addStretch()

        # ── Pie fijo (fuera del scroll) ──────────────────────────────────────
        # El botón principal NO va dentro del área desplazable: así se ve
        # completo siempre, sin importar cuánto contenido haya arriba.
        pie = QWidget()
        pie.setObjectName("pie_acciones")
        pie_lay = QVBoxLayout(pie)
        pie_lay.setContentsMargins(8, 6, 8, 8)
        pie_lay.setSpacing(0)
        pie_lay.addWidget(self._build_run_button())
        outer.addWidget(pie)

    # ── Grupos de controles ───────────────────────────────────────────────────

    def _group_anl(self) -> QGroupBox:
        gb  = QGroupBox("Fuente de Datos STAAD Pro")
        lay = QVBoxLayout(gb)
        lay.setSpacing(6)

        # Selección de modo
        h_mode = QHBoxLayout()
        self.rb_api = QRadioButton("API OpenSTAAD")
        self.rb_anl = QRadioButton("Archivo .anl")
        if _OPENSTAAD_AVAILABLE:
            self.rb_api.setChecked(True)
        else:
            self.rb_api.setEnabled(False)
            self.rb_api.setToolTip("openstaadpy no está instalado")
            self.rb_anl.setChecked(True)
        h_mode.addWidget(self.rb_api)
        h_mode.addWidget(self.rb_anl)
        lay.addLayout(h_mode)

        # Sub-panel API
        self._frame_api = QWidget()
        lay_api = QVBoxLayout(self._frame_api)
        lay_api.setContentsMargins(0, 2, 0, 0)
        lay_api.setSpacing(4)
        self.btn_connect = QPushButton("Conectar a STAAD Pro")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.setToolTip("Establece conexión con STAAD Pro 2025\n(requiere ejecutar como Administrador)")
        self.btn_connect.clicked.connect(self._on_connect_staad)
        self.lbl_api_status = QLabel("Sin conectar")
        self.lbl_api_status.setStyleSheet(
            "color: #607D8B; font-size: 8pt;")
        self.lbl_api_status.setWordWrap(True)
        lay_api.addWidget(self.btn_connect)
        lay_api.addWidget(self.lbl_api_status)
        lay.addWidget(self._frame_api)

        # Sub-panel .anl
        self._frame_anl = QWidget()
        lay_anl = QVBoxLayout(self._frame_anl)
        lay_anl.setContentsMargins(0, 2, 0, 0)
        lay_anl.setSpacing(4)
        h = QHBoxLayout()
        h.setSpacing(4)
        self.le_anl = QLineEdit()
        self.le_anl.setPlaceholderText("Ruta del archivo .anl …")
        self.le_anl.setReadOnly(True)
        btn = QPushButton("…")
        btn.setFixedWidth(30)
        btn.clicked.connect(self._browse_anl)
        h.addWidget(self.le_anl)
        h.addWidget(btn)
        self.lbl_anl_info = QLabel("No cargado")
        self.lbl_anl_info.setStyleSheet(
            "color: #607D8B; font-size: 8pt;")
        self.lbl_anl_info.setWordWrap(True)
        lay_anl.addLayout(h)
        lay_anl.addWidget(self.lbl_anl_info)
        lay.addWidget(self._frame_anl)

        self.rb_api.toggled.connect(self._on_mode_changed)
        self._on_mode_changed()
        return gb

    def _group_columnas(self) -> QGroupBox:
        gb  = QGroupBox("Columnas a Diseñar")
        lay = QVBoxLayout(gb)
        lay.setSpacing(6)

        # Contador de columnas cargadas
        self.lbl_col_count = QLabel("Sin columnas cargadas")
        self.lbl_col_count.setAlignment(Qt.AlignCenter)
        self.lbl_col_count.setStyleSheet(
            "color: #607D8B; font-size: 8pt; padding: 4px;")
        lay.addWidget(self.lbl_col_count)

        # Botón para leer la selección activa en STAAD Pro (API)
        self.btn_refresh_cols = QPushButton("↻  Actualizar selección")
        self.btn_refresh_cols.setToolTip(
            "Lee los miembros actualmente seleccionados en STAAD Pro\n"
            "(requiere conexión activa vía API OpenSTAAD)\n\n"
            "En modo archivo .anl use los IDs manuales.")
        self.btn_refresh_cols.clicked.connect(self.refresh_columns)
        lay.addWidget(self.btn_refresh_cols)

        # Separador
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #AED6F1;")
        lay.addWidget(sep)

        # IDs manuales — respaldo cuando la selección automática no funciona
        lbl_manual = QLabel("IDs manuales (respaldo):")
        lbl_manual.setStyleSheet("font-size: 8pt;")
        lbl_manual.setToolTip(
            "Si la selección automática no detecta las columnas,\n"
            "escriba aquí los números de barra separados por coma.\n"
            "Se admiten rangos:  1, 3, 5-10, 15\n"
            "Presione '↻ Actualizar selección' después de editar.")
        lay.addWidget(lbl_manual)

        self.le_manual_ids = QLineEdit()
        self.le_manual_ids.setPlaceholderText("Ej: 1, 3, 5-10, 15")
        self.le_manual_ids.setToolTip(
            "Números de barra separados por coma o punto y coma.\n"
            "Rangos: 5-10 equivale a 5, 6, 7, 8, 9, 10.\n"
            "Aplica también para modo archivo .anl.")
        lay.addWidget(self.le_manual_ids)

        return gb

    def _group_materials(self) -> QGroupBox:
        gb   = QGroupBox("Materiales")
        grid = QGridLayout(gb)
        grid.setSpacing(6)
        grid.setColumnStretch(1, 1)

        self.sp_fc = QDoubleSpinBox()
        self.sp_fc.setRange(100, 1000)
        self.sp_fc.setValue(250)
        self.sp_fc.setSuffix(" kg/cm²")
        self.sp_fc.setDecimals(0)

        self.sp_fy = QDoubleSpinBox()
        self.sp_fy.setRange(2000, 8000)
        self.sp_fy.setValue(4200)
        self.sp_fy.setSuffix(" kg/cm²")
        self.sp_fy.setDecimals(0)

        grid.addWidget(QLabel("f'c"), 0, 0)
        grid.addWidget(self.sp_fc,   0, 1)
        grid.addWidget(QLabel("fy"), 1, 0)
        grid.addWidget(self.sp_fy,   1, 1)
        return gb

    def _group_cover(self) -> QGroupBox:
        gb   = QGroupBox("Recubrimientos")
        grid = QGridLayout(gb)
        grid.setSpacing(6)
        grid.setColumnStretch(1, 1)

        self.sp_rec1 = QDoubleSpinBox()
        self.sp_rec1.setRange(1, 20)
        self.sp_rec1.setValue(5.0)
        self.sp_rec1.setSuffix(" cm")
        self.sp_rec1.setToolTip("Recubrimiento al centroide del acero (dir. Z). Valor por defecto: 5 cm en ambas direcciones.")

        self.sp_rec2 = QDoubleSpinBox()
        self.sp_rec2.setRange(1, 20)
        self.sp_rec2.setValue(5.0)
        self.sp_rec2.setSuffix(" cm")
        self.sp_rec2.setToolTip("Recubrimiento al centroide del acero (dir. Y). Valor por defecto: 5 cm en ambas direcciones.")

        grid.addWidget(QLabel("rec1 (dir. Z, def. 5 cm)"), 0, 0)
        grid.addWidget(self.sp_rec1,            0, 1)
        grid.addWidget(QLabel("rec2 (dir. Y, def. 5 cm)"), 1, 0)
        grid.addWidget(self.sp_rec2,            1, 1)
        return gb

    def _group_ratios(self) -> QGroupBox:
        gb   = QGroupBox("Cuantías de Acero Longitudinal")
        grid = QGridLayout(gb)
        grid.setSpacing(6)
        grid.setColumnStretch(1, 1)

        self.sp_pmin = QDoubleSpinBox()
        self.sp_pmin.setRange(0.5, 4.0)
        self.sp_pmin.setValue(1.0)
        self.sp_pmin.setSingleStep(0.1)
        self.sp_pmin.setSuffix(" %")

        self.sp_pmax = QDoubleSpinBox()
        self.sp_pmax.setRange(1.0, 8.0)
        self.sp_pmax.setValue(6.0)
        self.sp_pmax.setSingleStep(0.5)
        self.sp_pmax.setSuffix(" %")

        grid.addWidget(QLabel("ρ mínima"), 0, 0)
        grid.addWidget(self.sp_pmin,       0, 1)
        grid.addWidget(QLabel("ρ máxima"), 1, 0)
        grid.addWidget(self.sp_pmax,       1, 1)
        return gb

    def _group_loadcases(self) -> QGroupBox:
        gb   = QGroupBox("Combinaciones de Diseño")
        grid = QGridLayout(gb)
        grid.setSpacing(6)
        grid.setColumnStretch(1, 1)

        self.sp_lc_ini = QSpinBox()
        self.sp_lc_ini.setRange(1, 99999)
        self.sp_lc_ini.setValue(200)

        self.sp_lc_fin = QSpinBox()
        self.sp_lc_fin.setRange(1, 99999)
        self.sp_lc_fin.setValue(241)

        grid.addWidget(QLabel("Inicial"),  0, 0)
        grid.addWidget(self.sp_lc_ini,     0, 1)
        grid.addWidget(QLabel("Final"),    1, 0)
        grid.addWidget(self.sp_lc_fin,     1, 1)
        return gb

    def _group_code(self) -> QGroupBox:
        gb  = QGroupBox("Código de Diseño")
        lay = QVBoxLayout(gb)
        lay.setSpacing(6)

        h1 = QHBoxLayout()
        h1.addWidget(QLabel("Norma:"))
        self.cb_code = QComboBox()
        self.cb_code.addItems(["ACI 318-25", "NTC 2023"])
        h1.addWidget(self.cb_code)

        h2 = QHBoxLayout()
        h2.addWidget(QLabel("Tipo estribo:"))
        self.cb_coltype = QComboBox()
        self.cb_coltype.addItems(["Estribos (tied)", "Espiral (spiral)"])
        h2.addWidget(self.cb_coltype)

        h3 = QHBoxLayout()
        h3.addWidget(QLabel("Factor Q:"))
        self.cb_Q = QComboBox()
        self.cb_Q.addItems(["Q = 1  (sin requisitos sísmicos)",
                             "Q = 2  (ductilidad baja)",
                             "Q = 3  (ductilidad media / IMF)",
                             "Q = 4  (ductilidad alta / SMF)"])
        self.cb_Q.setToolTip(
            "Factor de comportamiento sísmico:\n"
            "Q=1/2: sin requisitos sísmicos adicionales\n"
            "Q=3 NTC → Ductilidad Media (Cap.7), ACI → IMF (§18.4)\n"
            "Q=4 NTC → Ductilidad Alta  (Cap.8), ACI → SMF (§18.7)\n\n"
            "Al seleccionar Q=3 o Q=4 se habilitarán parámetros\n"
            "adicionales de diseño sísmico.")
        self.cb_Q.currentIndexChanged.connect(self._on_Q_changed)
        h3.addWidget(self.cb_Q)

        lay.addLayout(h1)
        lay.addLayout(h2)
        lay.addLayout(h3)
        lay.addWidget(self._group_seismic())
        return gb

    def _group_seismic(self) -> QWidget:
        """Panel de parámetros sísmicos — visible solo con Q=3 o Q=4."""
        self._frame_seismic = QGroupBox("Parámetros Sísmicos")
        self._frame_seismic.setStyleSheet(
            "QGroupBox{font-size:8pt; color:#C0392B; border:1px solid #E74C3C;"
            " border-radius:4px; margin-top:6px;}"
            "QGroupBox::title{subcontrol-origin:margin; left:6px;}")
        lay = QVBoxLayout(self._frame_seismic)
        lay.setSpacing(5)
        lay.setContentsMargins(6, 10, 6, 6)

        # Altura libre Hn
        row_hn = QHBoxLayout()
        lbl_hn = QLabel("Altura libre Hn (m):")
        lbl_hn.setStyleSheet("font-size: 8pt;")
        lbl_hn.setToolTip(
            "Altura libre de la columna entre caras de nudos (vigas/losas).\n"
            "Usada para calcular el cortante de capacidad:\n"
            "  Ve = (Mpr_ini + Mpr_fin) / Hn\n"
            "Si se activan los efectos de 2° orden, se usa Lu como respaldo.\n"
            "NTC Q=3 §7.4.2 / Q=4 §8.4.6.1 / ACI §18.7.6.1")
        self.sp_Hn = QDoubleSpinBox()
        self.sp_Hn.setRange(0.5, 30.0)
        self.sp_Hn.setValue(3.0)
        self.sp_Hn.setSingleStep(0.1)
        self.sp_Hn.setDecimals(2)
        self.sp_Hn.setSuffix(" m")
        row_hn.addWidget(lbl_hn)
        row_hn.addWidget(self.sp_Hn)
        lay.addLayout(row_hn)

        # Grado de acero transversal
        row_grado = QHBoxLayout()
        lbl_gr = QLabel("Grado barras transv.:")
        lbl_gr.setStyleSheet("font-size: 8pt;")
        lbl_gr.setToolTip(
            "Grado del refuerzo transversal (estribos / espiral).\n"
            "Afecta las separaciones máximas en la zona de confinamiento.\n"
            "NTC §7.4.4 / §8.4.5 / ACI §18.7.5")
        self.cb_grade = QComboBox()
        self.cb_grade.addItems(["Grado 42 (fy=4200 kg/cm²)",
                                  "Grado 56 (fy=5600 kg/cm²)",
                                  "Grado 70 (fy=7000 kg/cm²)"])
        self.cb_grade.setStyleSheet("font-size: 8pt;")
        row_grado.addWidget(lbl_gr)
        row_grado.addWidget(self.cb_grade)
        lay.addLayout(row_grado)

        # Fluencia del refuerzo transversal
        row_fyt = QHBoxLayout()
        lbl_fyt = QLabel("fy transv. (kg/cm²):")
        lbl_fyt.setStyleSheet("font-size: 8pt;")
        self.sp_fyt = QDoubleSpinBox()
        self.sp_fyt.setRange(2000, 8000)
        self.sp_fyt.setValue(4200)
        self.sp_fyt.setDecimals(0)
        self.sp_fyt.setSuffix(" kg/cm²")
        self.sp_fyt.setToolTip(
            "Resistencia a la fluencia del refuerzo transversal (f_yt).\n"
            "Se usa en el cálculo de cuantías mínimas de confinamiento.")
        row_fyt.addWidget(lbl_fyt)
        row_fyt.addWidget(self.sp_fyt)
        lay.addLayout(row_fyt)

        # Diámetro de barra longitudinal principal (para espaciamientos)
        row_db = QHBoxLayout()
        lbl_db = QLabel("d_b principal (cm):")
        lbl_db.setStyleSheet("font-size: 8pt;")
        self.sp_db = QDoubleSpinBox()
        self.sp_db.setRange(0.5, 4.0)
        self.sp_db.setValue(1.905)   # No. 6 = 19.05 mm
        self.sp_db.setSingleStep(0.1)
        self.sp_db.setDecimals(3)
        self.sp_db.setSuffix(" cm")
        self.sp_db.setToolTip(
            "Diámetro de barra longitudinal principal (cm).\n"
            "Usado para calcular la separación máxima de estribos:\n"
            "  s ≤ 8·d_b (Gr.42) / 6·d_b (Gr.56) / 5·d_b (Gr.70)\n"
            "Valores comunes: No.5=1.588, No.6=1.905, No.8=2.540 cm")
        row_db.addWidget(lbl_db)
        row_db.addWidget(self.sp_db)
        lay.addLayout(row_db)

        # Nota informativa según Q
        self._lbl_seismic_nota = QLabel("")
        self._lbl_seismic_nota.setStyleSheet(
            "color: #5D6D7E; font-size: 7pt; padding: 2px;")
        self._lbl_seismic_nota.setWordWrap(True)
        lay.addWidget(self._lbl_seismic_nota)

        self._frame_seismic.setVisible(False)
        return self._frame_seismic

    def _on_Q_changed(self, idx: int):
        Q = idx + 1   # índice 0 → Q=1, índice 2 → Q=3, etc.
        visible = (Q >= 3)
        self._frame_seismic.setVisible(visible)
        if Q == 3:
            self._lbl_seismic_nota.setText(
                "Q=3 — Ductilidad Media (NTC §7.4) / IMF (ACI §18.4)\n"
                "• Cortante de capacidad: Ve=(Mpr_ini+Mpr_fin)/Hn  (Mpr con fy)\n"
                "• Lo ≥ max(H_libre/6, dim_mayor, 60cm)\n"
                "• Se verifica condición de ignorar Vc:\n"
                "  Pu < Ag·f'c/20  Y  Vsismo ≥ 0.5·Ve")
        elif Q == 4:
            self._lbl_seismic_nota.setText(
                "Q=4 — Ductilidad Alta (NTC §8.4) / SMF (ACI §18.7)\n"
                "• Cortante de capacidad: Ve=(Mpr_ini+Mpr_fin)/Hn  (Mpr=1.25·Mn)\n"
                "• Lo ≥ max(peralte, H_libre/6, 60cm)\n"
                "• Se ignora Vc si Pu < Ag·f'c/20  Y  Vsismo ≥ 0.5·Ve\n"
                "• Cuantías mínimas de confinamiento: Tabla 8.4.5.4 NTC")

    # ── Longitud real de columnas partidas en varias barras ───────────────────

    def _group_col_length(self) -> QGroupBox:
        """Tabla independiente (fuera de 2° orden) con la longitud REAL de
        cada columna por dirección. Editable por el usuario."""
        gb  = QGroupBox("Longitud de columnas (barras encadenadas)")
        lay = QVBoxLayout(gb)
        lay.setSpacing(6)

        nota = QLabel(
            "Cuando una columna está modelada con 2 o más barras, la longitud "
            "de pandeo es la del tramo CONTINUO: se suman los tramos verticales "
            "hasta encontrar una trabe en Dir.X y/o Dir.Z (las diagonales se "
            "descomponen). Puede editar los valores manualmente.")
        nota.setStyleSheet("font-size: 7pt; color: #5D6D7E;")
        nota.setWordWrap(True)
        lay.addWidget(nota)

        self.tbl_len = QTableWidget(0, 4)
        self.tbl_len.setHorizontalHeaderLabels(
            ["ID\nBarra", "L Staad\n(m)", "L Dir.X\n(m)", "L Dir.Z\n(m)"])
        self.tbl_len.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl_len.verticalHeader().setVisible(False)
        self.tbl_len.setAlternatingRowColors(True)
        self.tbl_len.setMinimumHeight(100)
        self.tbl_len.setMaximumHeight(200)
        self.tbl_len.setToolTip(
            "L Staad = longitud de la barra tal como viene de STAAD.\n"
            "L Dir.X / L Dir.Z = longitud del tramo continuo de columna hasta "
            "la trabe que restringe esa dirección (editables).\n"
            "El diseño usa kz·L(Dir.X) y ky·L(Dir.Z) en los efectos de 2° orden.")
        lay.addWidget(self.tbl_len)

        self.btn_col_len = QPushButton("↕  Revisar longitud real desde STAAD Pro")
        self.btn_col_len.setToolTip(
            "Recorre el modelo y suma los tramos verticales continuos de cada "
            "columna hasta encontrar una trabe que restrinja cada dirección.\n"
            "Requiere conexión activa con STAAD Pro (modo API).")
        self.btn_col_len.clicked.connect(self.col_len_requested.emit)
        lay.addWidget(self.btn_col_len)
        return gb

    def update_col_length_table(self, datos: dict):
        """Llena la tabla con {mid: {"L_seg","Lx","Lz",...}}."""
        orden = sorted(datos)
        self.tbl_len.setRowCount(len(orden))
        for row, mid in enumerate(orden):
            d = datos[mid]
            id_item = QTableWidgetItem(str(mid))
            id_item.setFlags(Qt.ItemIsEnabled)
            id_item.setBackground(QColor("#EBF5FB"))
            seg_item = QTableWidgetItem(f"{d.get('L_seg', 0.0):.3f}")
            seg_item.setFlags(Qt.ItemIsEnabled)
            lx_item = QTableWidgetItem(f"{d.get('Lx', 0.0):.3f}")
            lz_item = QTableWidgetItem(f"{d.get('Lz', 0.0):.3f}")
            for it in (lx_item, lz_item):
                it.setBackground(QColor("#D6EAF8"))
            for c, it in enumerate((id_item, seg_item, lx_item, lz_item)):
                self.tbl_len.setItem(row, c, it)

    def get_col_lengths(self) -> dict:
        """{col_id: (Lx, Lz)} leído de la tabla (solo filas válidas)."""
        out = {}
        for row in range(self.tbl_len.rowCount()):
            try:
                cid = int(self.tbl_len.item(row, 0).text())
                Lx  = float(self.tbl_len.item(row, 2).text().replace(",", "."))
                Lz  = float(self.tbl_len.item(row, 3).text().replace(",", "."))
            except (AttributeError, ValueError, TypeError):
                continue
            if Lx > 0 and Lz > 0:
                out[cid] = (Lx, Lz)
        return out

    def _group_second_order(self) -> QGroupBox:
        """Grupo: Efectos de 2° orden — amplificacion de momentos por esbeltez."""
        gb  = QGroupBox("Efectos de 2° Orden (Esbeltez)")
        lay = QVBoxLayout(gb)
        lay.setSpacing(5)

        # ── Checkbox activador ──────────────────────────────────────────────
        self.chk_2orden = QCheckBox(
            "Amplificar momentos por efectos de esbeltez")
        self.chk_2orden.setToolTip(
            "Activa el método de amplificación de momentos\n"
            "(NTC 2023 §3.3.5.2 / ACI 318-25 §6.6.4).\n"
            "Los momentos de análisis se multiplican por δ ≥ 1.0.")
        lay.addWidget(self.chk_2orden)

        # ── Sub-panel (se oculta si el checkbox no está marcado) ───────────
        self._frame_2orden = QWidget()
        v2 = QVBoxLayout(self._frame_2orden)
        v2.setContentsMargins(0, 0, 0, 0)
        v2.setSpacing(6)

        # ── Tipo de marco ───────────────────────────────────────────────────
        grp_marco = QGroupBox("Tipo de Marco")
        grp_marco.setStyleSheet("QGroupBox{font-size:8pt;}")
        lay_marco = QVBoxLayout(grp_marco)
        lay_marco.setSpacing(3)
        # Arriostramiento POR DIRECCION PRINCIPAL (NTC 2023 §3.3.5 / ACI §6.6.4):
        # cada direccion puede ser restringida (arriostrada) o no.
        # Convención global (igual que columnsteel): el marco en dirección
        # global X flexiona la columna alrededor de Z (Mz) y el marco en
        # dirección global Z alrededor de Y (My).
        self.chk_arr_z = QCheckBox("Marco Arriostrado Dir. X")
        self.chk_arr_y = QCheckBox("Marco Arriostrado Dir. Z")
        self.chk_arr_y.setChecked(True)
        self.chk_arr_z.setChecked(True)
        for _c in (self.chk_arr_y, self.chk_arr_z):
            _c.setStyleSheet("font-size: 8pt;")
            _c.setToolTip(
                "Marcada = marco RESTRINGIDO lateralmente (arriostrado) en esa "
                "dirección global:\n  K por NTC 3.3.5.1.3, amplificación Fab "
                "(NTC 3.3.5.2.4), límite k·Lu/r < 34−12·M1/M2.\n"
                "Desmarcada = marco con traslación lateral:\n  K de nomograma "
                "sway, amplificación Fas/δs (NTC 3.3.5.2.5), límite k·Lu/r < 22.\n"
                "Dir. X ↔ flexión Mz  |  Dir. Z ↔ flexión My.")
        lay_marco.addWidget(self.chk_arr_z)   # Dir. X
        lay_marco.addWidget(self.chk_arr_y)   # Dir. Z
        # Compatibilidad: radios legados ocultos (algunas rutas los leen)
        self.rb_arriostr = QRadioButton(); self.rb_no_arr = QRadioButton()
        self.rb_arriostr.setChecked(True)
        self.rb_arriostr.setVisible(False); self.rb_no_arr.setVisible(False)
        v2.addWidget(grp_marco)

        # ── β_dns automático desde el caso de carga sostenida ───────────────
        # β_dns = Pu_sostenida_fact. / Pu_total_fact. (por combinación),
        # acotado a [0.60, 1.00]  (NTC 2023 §3.3.5.2.4 / ACI 318-25 §6.6.4.4.4).
        row_bdns = QHBoxLayout()
        lbl_bdns = QLabel("N° caso carga sostenida (PP+CM+CVma) fact.:")
        lbl_bdns.setStyleSheet("font-size: 8pt;")
        lbl_bdns.setWordWrap(True)
        self.sp_lc_sost = QSpinBox()
        self.sp_lc_sost.setRange(0, 100000)
        self.sp_lc_sost.setValue(0)
        self.sp_lc_sost.setMaximumWidth(80)
        self.sp_lc_sost.setToolTip(
            "Número del caso/combinación de carga axial SOSTENIDA factorizada\n"
            "(peso propio + carga muerta + carga viva media), tal como está\n"
            "en STAAD Pro.\n\n"
            "Con la carga axial de ese caso y la de cada combinación, el\n"
            "programa calcula automáticamente:\n"
            "    β_dns = Pu_sostenida / Pu_combinación   (acotado 0.60–1.00)\n"
            "NTC 2023 §3.3.5.2.4 / ACI 318-25 §6.6.4.4.4.\n\n"
            "0 = no definido → se usa β_dns = 0.60 (conservador).")
        row_bdns.addWidget(lbl_bdns)
        row_bdns.addWidget(self.sp_lc_sost)
        v2.addLayout(row_bdns)

        # ── Factor Cm (3 opciones) ──────────────────────────────────────────
        # δns = Cm / (1 − Pu/(0.75·Pc)).  El usuario elige cómo se toma Cm.
        grp_cm = QGroupBox("Cm:")
        grp_cm.setStyleSheet("QGroupBox{font-size:8pt;}")
        lay_cm = QVBoxLayout(grp_cm)
        lay_cm.setSpacing(3)
        self.rb_cm_auto   = QRadioButton("Cm = 0.6 − 0.4(M1/M2)  [auto]")
        self.rb_cm_uno    = QRadioButton("Cm = 1.0  [conservador]")
        self.rb_cm_manual = QRadioButton("Cm manual:")
        for _r in (self.rb_cm_auto, self.rb_cm_uno, self.rb_cm_manual):
            _r.setStyleSheet("font-size: 8pt;")
        self.rb_cm_auto.setChecked(True)
        self.rb_cm_auto.setToolTip(
            "Cm calculado por columna y combinación con los momentos reales\n"
            "de los dos extremos: Cm = 0.6 − 0.4·(M1/M2) ≥ 0.4\n"
            "(NTC 2023 §3.3.5.2.4 / ACI 318-25 §6.6.4.5.3).")
        self.rb_cm_uno.setToolTip("Cm = 1.0 fijo (conservador).")
        self.rb_cm_manual.setToolTip("Cm fijo indicado por el usuario.")
        lay_cm.addWidget(self.rb_cm_auto)
        lay_cm.addWidget(self.rb_cm_uno)

        row_cmman = QHBoxLayout()
        row_cmman.setContentsMargins(0, 0, 0, 0)
        row_cmman.addWidget(self.rb_cm_manual)
        self.sp_cm_manual = QDoubleSpinBox()
        self.sp_cm_manual.setRange(0.20, 1.00)
        self.sp_cm_manual.setValue(0.85)
        self.sp_cm_manual.setSingleStep(0.05)
        self.sp_cm_manual.setDecimals(2)
        self.sp_cm_manual.setEnabled(False)
        self.sp_cm_manual.setMaximumWidth(90)
        row_cmman.addWidget(self.sp_cm_manual)
        row_cmman.addStretch(1)
        lay_cm.addLayout(row_cmman)
        v2.addWidget(grp_cm)

        # El spinbox manual solo se habilita con la opción "Cm manual".
        self.rb_cm_manual.toggled.connect(self.sp_cm_manual.setEnabled)

        # ── λ_est → Fas por dirección (solo marco no arriostrado) ───────────
        # El usuario indica el índice de estabilidad de entrepiso λ_est de la
        # dirección no arriostrada y el programa calcula el Fas:
        #     Fas = δ_s = 1 / (1 − λ_est) ≥ 1.0   (NTC DEC 2023 §3.3.5.2.5)
        # Cada dirección se muestra sólo si su marco es sin arriostrar:
        #     Dir. X (flexión Mz)  ←  chk_arr_z desmarcado
        #     Dir. Z (flexión My)  ←  chk_arr_y desmarcado
        self._frame_delta_s = QWidget()
        ds_lay = QVBoxLayout(self._frame_delta_s)
        ds_lay.setContentsMargins(0, 0, 0, 0)
        ds_lay.setSpacing(2)

        def _mk_lambda_row(dir_txt):
            row = QWidget()
            rl = QHBoxLayout(row); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(4)
            lbl = QLabel(f"λ_est {dir_txt}:")
            lbl.setStyleSheet("font-size: 8pt;")
            sp = QDoubleSpinBox()
            sp.setRange(0.0, 0.95); sp.setValue(0.0)
            sp.setSingleStep(0.01); sp.setDecimals(3); sp.setMaximumWidth(80)
            sp.setToolTip(
                f"Índice de estabilidad de entrepiso en {dir_txt}.\n"
                "Aplica a ambas normas del programa:\n"
                "  • NTC DEC 2023 §3.3.5.2.5:  Fas = 1/(1 − λ_est) ≥ 1.0\n"
                "  • ACI 318-25 §6.6.4.6.2:    δs = 1/(1 − Q) ≥ 1.0\n"
                "    λ_est (= Q) = Σ(Pu · ΔP) / (Σ(Vu) · H)   (≤ 0.30 en NTC)")
            fas = QLabel("→ Fas = 1.000")
            fas.setStyleSheet("font-size: 7pt; color: #1B4F72; font-weight: bold;")
            rl.addWidget(lbl); rl.addWidget(sp); rl.addWidget(fas); rl.addStretch(1)
            return row, sp, fas

        self._row_lx, self.sp_lambda_x, self._lbl_fas_x = _mk_lambda_row("Dir. X (Mz)")
        self._row_lz, self.sp_lambda_z, self._lbl_fas_z = _mk_lambda_row("Dir. Z (My)")
        ds_lay.addWidget(self._row_lx)
        ds_lay.addWidget(self._row_lz)
        self.sp_lambda_x.valueChanged.connect(self._on_lambda_est_changed)
        self.sp_lambda_z.valueChanged.connect(self._on_lambda_est_changed)
        self._frame_delta_s.setVisible(False)
        v2.addWidget(self._frame_delta_s)

        # ── Tabla de K por columna ──────────────────────────────────────────
        lbl_ktab = QLabel("Factor de longitud efectiva por columna:")
        lbl_ktab.setStyleSheet("font-size: 8pt; font-weight: bold;")
        v2.addWidget(lbl_ktab)

        lbl_ktab_nota = QLabel(
            "Ky y Kz = 1.0 por defecto. Use 'Calcular K desde STAAD'\n"
            "para calcular automáticamente o edite los valores en la tabla.")
        lbl_ktab_nota.setStyleSheet("font-size: 7pt; color: #5D6D7E;")
        lbl_ktab_nota.setWordWrap(True)
        v2.addWidget(lbl_ktab_nota)

        # Tabla: ID barra | Longitud (m) | Ky | Kz
        self.tbl_k = QTableWidget(0, 4)
        self.tbl_k.setHorizontalHeaderLabels(["ID Barra", "Long. (m)", "Ky", "Kz"])
        self.tbl_k.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl_k.verticalHeader().setVisible(False)
        self.tbl_k.setAlternatingRowColors(True)
        self.tbl_k.setMinimumHeight(100)
        self.tbl_k.setMaximumHeight(200)
        self.tbl_k.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.tbl_k.setToolTip(
            "Columna 1: ID de la barra en STAAD Pro\n"
            "Columna 2: Longitud no soportada (m) — editable\n"
            "Columna 3: Ky — factor efectivo para flexión en plano Y (Muy)\n"
            "Columna 4: Kz — factor efectivo para flexión en plano Z (Muz)\n\n"
            "Los valores en Ky y Kz son editables después del cálculo.")
        v2.addWidget(self.tbl_k)

        # Botón calcular K
        self.btn_calc_k = QPushButton("⚙  Calcular K desde STAAD Pro")
        self.btn_calc_k.setToolTip(
            "Consulta STAAD Pro para obtener las propiedades de las trabes\n"
            "(vigas) conectadas a cada columna y calcula el factor K\n"
            "usando el nomograma de alineación.\n\n"
            "Requiere conexión activa con STAAD Pro (modo API).\n"
            "NTC DEC 2023 §3.3.5.1.3 / ACI 318-25 §6.2.5")
        self.btn_calc_k.clicked.connect(self._on_calc_k)
        v2.addWidget(self.btn_calc_k)

        lay.addWidget(self._frame_2orden)

        # Nota informativa
        self._lbl_2orden_nota = QLabel(
            "NTC 2023 §3.3.5.2 / ACI 318-25 §6.6.4\n"
            "Límite esbeltez arriostrado:     k·Lu/r < 34 − 12·(M1/M2)\n"
            "Límite esbeltez no arriostrado:  k·Lu/r < 22")
        self._lbl_2orden_nota.setStyleSheet(
            "color: #5D6D7E; font-size: 7pt; padding: 2px;")
        self._lbl_2orden_nota.setWordWrap(True)
        lay.addWidget(self._lbl_2orden_nota)

        # ── Conectar señales ────────────────────────────────────────────────
        self.chk_2orden.stateChanged.connect(self._on_2orden_changed)
        self.chk_arr_y.toggled.connect(self._on_marco_changed)
        self.chk_arr_z.toggled.connect(self._on_marco_changed)
        self._frame_2orden.setVisible(False)
        self._lbl_2orden_nota.setVisible(False)

        return gb

    def _on_2orden_changed(self, state):
        visible = (state == 2)   # Qt.Checked == 2
        self._frame_2orden.setVisible(visible)
        self._lbl_2orden_nota.setVisible(visible)

    def _on_marco_changed(self, checked=None):
        """Mostrar/ocultar los campos λ_est según el arriostramiento por dir.

        Dir. X (Mz) ← chk_arr_z ; Dir. Z (My) ← chk_arr_y.
        Cada fila se muestra sólo si su dirección es marco sin arriostrar;
        el contenedor aparece si CUALQUIER dirección es no arriostrada.
        """
        no_arr_x = not self.chk_arr_z.isChecked()   # Dir. X (Mz)
        no_arr_z = not self.chk_arr_y.isChecked()   # Dir. Z (My)
        self._row_lx.setVisible(no_arr_x)
        self._row_lz.setVisible(no_arr_z)
        self._frame_delta_s.setVisible(no_arr_x or no_arr_z)

    @staticmethod
    def _fas_from_lambda(lambda_est: float) -> float:
        """Fas = δ_s = 1 / (1 − λ_est) ≥ 1.0  (NTC DEC 2023 §3.3.5.2.5)."""
        le = max(0.0, min(0.95, float(lambda_est)))
        return 1.0 / (1.0 - le) if le < 1.0 else 10.0

    def _on_lambda_est_changed(self, _val=None):
        """Actualiza las etiquetas de Fas al cambiar λ_est de cada dirección."""
        self._lbl_fas_x.setText(
            f"→ Fas = {self._fas_from_lambda(self.sp_lambda_x.value()):.3f}")
        self._lbl_fas_z.setText(
            f"→ Fas = {self._fas_from_lambda(self.sp_lambda_z.value()):.3f}")

    def _on_calc_k(self):
        """Emite la señal para calcular K desde STAAD Pro."""
        self.calc_k_requested.emit()

    # ── Gestión de la tabla de K ──────────────────────────────────────────────

    def update_k_table(self, members: list):
        """
        Actualiza la tabla de K con los miembros dados.
        members: list of {"id": int, "Lu_m": float (opcional)}
        Mantiene los valores Ky/Kz actuales si el ID ya existía.
        """
        existing: dict = {}
        for row in range(self.tbl_k.rowCount()):
            id_item = self.tbl_k.item(row, 0)
            if id_item:
                try:
                    cid = int(id_item.text())
                    ky_item = self.tbl_k.item(row, 2)
                    kz_item = self.tbl_k.item(row, 3)
                    lu_item = self.tbl_k.item(row, 1)
                    existing[cid] = {
                        "Lu_m": float(lu_item.text()) if lu_item else 3.0,
                        "ky":   float(ky_item.text()) if ky_item else 1.0,
                        "kz":   float(kz_item.text()) if kz_item else 1.0,
                    }
                except (ValueError, AttributeError):
                    pass

        self.tbl_k.setRowCount(len(members))
        for row, m in enumerate(members):
            cid = m.get("id", 0) if isinstance(m, dict) else m
            prev = existing.get(cid, {})
            Lu   = m.get("Lu_m", prev.get("Lu_m", 3.0)) if isinstance(m, dict) else prev.get("Lu_m", 3.0)
            ky   = prev.get("ky",  1.0)
            kz   = prev.get("kz",  1.0)

            id_item = QTableWidgetItem(str(cid))
            id_item.setFlags(Qt.ItemIsEnabled)   # solo lectura
            id_item.setBackground(QColor("#EBF5FB"))

            lu_item = QTableWidgetItem(f"{Lu:.3f}")
            ky_item = QTableWidgetItem(f"{ky:.4f}")
            kz_item = QTableWidgetItem(f"{kz:.4f}")

            self.tbl_k.setItem(row, 0, id_item)
            self.tbl_k.setItem(row, 1, lu_item)
            self.tbl_k.setItem(row, 2, ky_item)
            self.tbl_k.setItem(row, 3, kz_item)

    def set_k_values(self, k_dict: dict):
        """
        Actualiza la tabla con los valores K calculados.
        k_dict: {col_id: {"ky": float, "kz": float, "Lu_m": float}}
        """
        for row in range(self.tbl_k.rowCount()):
            id_item = self.tbl_k.item(row, 0)
            if not id_item:
                continue
            try:
                cid = int(id_item.text())
            except ValueError:
                continue
            if cid not in k_dict:
                continue
            d  = k_dict[cid]
            ky = d.get("ky",  1.0)
            kz = d.get("kz",  1.0)
            Lu = d.get("Lu_m", 3.0)

            self.tbl_k.setItem(row, 1, QTableWidgetItem(f"{Lu:.3f}"))
            ky_item = QTableWidgetItem(f"{ky:.4f}")
            kz_item = QTableWidgetItem(f"{kz:.4f}")
            # Colorear celdas calculadas (azul claro) para distinguirlas de las editadas
            for item in (ky_item, kz_item):
                item.setBackground(QColor("#D6EAF8"))
            self.tbl_k.setItem(row, 2, ky_item)
            self.tbl_k.setItem(row, 3, kz_item)

    def get_k_per_col(self) -> dict:
        """
        Lee la tabla y devuelve dict {col_id: {"ky": float, "kz": float, "Lu_m": float}}.
        """
        result = {}
        # Longitud real por dirección (tabla "Longitud de columnas").
        # Ky ↔ Muy ↔ Dir.Z ;  Kz ↔ Muz ↔ Dir.X
        largos = self.get_col_lengths()
        for row in range(self.tbl_k.rowCount()):
            try:
                cid = int(self.tbl_k.item(row, 0).text())
                Lu  = float(self.tbl_k.item(row, 1).text())
                ky  = float(self.tbl_k.item(row, 2).text())
                kz  = float(self.tbl_k.item(row, 3).text())
                d = {"ky": ky, "kz": kz, "Lu_m": Lu}
                if cid in largos:
                    Lx, Lz = largos[cid]
                    d["Lu_y_m"] = Lz      # dir-Y (Muy) ← longitud en Dir.Z
                    d["Lu_z_m"] = Lx      # dir-Z (Muz) ← longitud en Dir.X
                result[cid] = d
            except (AttributeError, ValueError, TypeError):
                pass
        return result

    def _group_dxf(self) -> QGroupBox:
        gb  = QGroupBox("Exportar a DXF (opcional)")
        lay = QVBoxLayout(gb)
        lay.setSpacing(6)
        lay.setContentsMargins(8, 10, 8, 8)

        h = QHBoxLayout()
        h.setSpacing(4)
        self.le_dxf = QLineEdit()
        self.le_dxf.setPlaceholderText("Ruta del archivo .dxf …")
        btn_dxf = QPushButton("…")
        btn_dxf.setFixedWidth(30)
        btn_dxf.clicked.connect(self._browse_dxf)
        h.addWidget(self.le_dxf)
        h.addWidget(btn_dxf)

        h2 = QHBoxLayout()
        h2.setSpacing(4)
        h2.addWidget(QLabel("% Reducción de Línea:"))
        self.sp_reduce = QDoubleSpinBox()
        self.sp_reduce.setRange(0, 90)
        self.sp_reduce.setValue(20)
        self.sp_reduce.setSuffix(" %")
        h2.addWidget(self.sp_reduce)

        self.chk_export_dxf = QCheckBox("Actualizar DXF al ejecutar")
        self.chk_export_dxf.setChecked(True)
        self.chk_export_dxf.setToolTip(
            "Si está marcado, al finalizar el diseño se actualizan\n"
            "automáticamente las etiquetas de acero en el archivo DXF.\n"
            "Desmarque si solo desea ver los resultados sin modificar el DXF.")

        lay.addLayout(h)
        lay.addLayout(h2)
        lay.addWidget(self.chk_export_dxf)
        return gb

    def _build_run_button(self) -> QPushButton:
        btn = QPushButton("▶   EJECUTAR DISEÑO")
        btn.setObjectName("btn_run")
        btn.clicked.connect(self._on_run)
        return btn

    # ── Acciones ──────────────────────────────────────────────────────────────

    def _on_mode_changed(self):
        api = self.rb_api.isChecked()
        self._frame_api.setVisible(api)
        self._frame_anl.setVisible(not api)

    def _on_connect_staad(self):
        self.staad_connected.emit()

    def _browse_anl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar archivo .anl", "",
            "STAAD Analysis (*.anl *.ANL);;Todos (*.*)")
        if path:
            self._anl_path = path
            self.le_anl.setText(path)
            self.anl_loaded.emit(path)

    def _browse_dxf(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar archivo DXF", "", "DXF (*.dxf)")
        if path:
            self.le_dxf.setText(path)

    def _on_run(self):
        params = self.get_params()
        if params:
            self.run_requested.emit(params)

    # ── Datos públicos ────────────────────────────────────────────────────────

    def get_params(self) -> dict:
        code_str = "ACI" if self.cb_code.currentIndex() == 0 else "NTC"
        col_type = "tied" if self.cb_coltype.currentIndex() == 0 else "spiral"

        lc_ini = self.sp_lc_ini.value()
        lc_fin = self.sp_lc_fin.value()
        if lc_fin < lc_ini:
            QMessageBox.warning(self, "Error",
                                "La combinación final debe ser ≥ inicial.")
            return {}

        Q_idx = self.cb_Q.currentIndex()
        Q_val = Q_idx + 1  # 0→Q=1, 1→Q=2, 2→Q=3, 3→Q=4
        _grade_map = {0: 42, 1: 56, 2: 70}

        return {
            "fc":             self.sp_fc.value(),
            "fy":             self.sp_fy.value(),
            "rec1":           self.sp_rec1.value(),
            "rec2":           self.sp_rec2.value(),
            "p_min":          self.sp_pmin.value() / 100.0,
            "p_max":          self.sp_pmax.value() / 100.0,
            "lc_ini":         int(lc_ini),
            "lc_fin":         int(lc_fin),
            "code":           code_str,
            "col_type":       col_type,
            "manual_col_ids": self.le_manual_ids.text().strip(),
            "anl_path":       self._anl_path,
            "dxf_path":       self.le_dxf.text(),
            "reduce_pct":     self.sp_reduce.value(),
            "export_dxf":     self.chk_export_dxf.isChecked(),
            # Efectos de 2° orden
            "segundo_orden":  self.chk_2orden.isChecked(),
            # β_dns se calcula automáticamente desde el caso de carga sostenida
            "lc_sostenida":   self.sp_lc_sost.value(),
            "beta_dns":       0.60,   # respaldo si no hay caso sostenido válido
            "arriostrado":    (self.chk_arr_y.isChecked()
                               and self.chk_arr_z.isChecked()),
            "arriostrado_y":  self.chk_arr_y.isChecked(),
            "arriostrado_z":  self.chk_arr_z.isChecked(),
            # λ_est por dirección → Fas = 1/(1−λ_est) (NTC DEC 2023 §3.3.5.2.5)
            # Dir. X (Mz) sólo si no arriostrado en X; Dir. Z (My) idem.
            "lambda_est_x":   (self.sp_lambda_x.value()
                               if not self.chk_arr_z.isChecked() else 0.0),
            "lambda_est_z":   (self.sp_lambda_z.value()
                               if not self.chk_arr_y.isChecked() else 0.0),
            "lambda_est":     max(self.sp_lambda_x.value(), self.sp_lambda_z.value()),
            "delta_s":        max(self._fas_from_lambda(self.sp_lambda_x.value()),
                                  self._fas_from_lambda(self.sp_lambda_z.value())),
            "cm_mode":        ("uno"    if self.rb_cm_uno.isChecked()
                               else "manual" if self.rb_cm_manual.isChecked()
                               else "auto"),
            "cm_manual":      self.sp_cm_manual.value(),
            "k_per_col":      self.get_k_per_col(),
            # Respaldos globales (si k_per_col está vacío)
            "k_factor":       1.0,
            "Lu_m":           3.0,
            # Diseño sísmico
            "Q":              Q_val,
            "fy_transv":      self.sp_fyt.value() if Q_val >= 3 else self.sp_fy.value(),
            "rebar_grade":    _grade_map.get(self.cb_grade.currentIndex(), 42),
            "db_main_cm":     self.sp_db.value(),
            "Hn_global_m":    self.sp_Hn.value() if Q_val >= 3 else 3.0,
        }

    def set_anl_info(self, msg: str):
        self.lbl_anl_info.setText(msg)

    def set_api_info(self, msg: str):
        self.lbl_api_status.setText(msg)

    def set_column_count(self, n: int):
        """Actualiza el contador de columnas cargadas."""
        if n == 0:
            self.lbl_col_count.setText("Sin columnas cargadas")
            self.lbl_col_count.setStyleSheet(
                "color: #607D8B; font-size: 8pt; padding: 4px;")
        else:
            self.lbl_col_count.setText(f"✔  {n} columna(s) cargada(s)")
            self.lbl_col_count.setStyleSheet(
                "color: #1E8449; font-size: 8pt; font-weight: bold; padding: 4px;")

    def set_load_case_range(self, lc_min: int, lc_max: int):
        """Actualiza el rango de combinaciones desde el .anl o la API."""
        self.sp_lc_ini.setValue(lc_min)
        self.sp_lc_fin.setValue(lc_max)
