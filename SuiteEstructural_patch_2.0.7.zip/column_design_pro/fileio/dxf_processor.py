"""
Procesador de archivos DXF.

Funciones:
  1. update_beam_labels()  — Busca el número de barra en textos/entidades
     del DXF y los reemplaza con la cadena:
       "<barra>/<As_max_cm²>/<ρ_cortante_max>"
  2. reduce_line_lengths()  — Reduce (o amplía) la longitud de líneas
     seleccionadas por un porcentaje dado (análogo al LISP reducirlineas_v2).

Requiere: ezdxf >= 1.1.0
"""
from __future__ import annotations

import math
import logging
import re
from pathlib import Path
from typing import Optional

import ezdxf
from ezdxf.entities import Text, MText, Line, Insert

log = logging.getLogger(__name__)


# Una etiqueta de resultado ya escrita tiene la forma "<id>/<As>/<ρ>".
_RESULT_LABEL_RE = re.compile(r'^\s*(\d+)\s*/')


def _leading_result_id(text: str) -> Optional[int]:
    """Si `text` ya es una etiqueta de resultado ('ID/...'), devuelve su ID líder."""
    m = _RESULT_LABEL_RE.match(text)
    return int(m.group(1)) if m else None


def _is_member_id_in_text(text: str, mid: int) -> bool:
    """
    Devuelve True si `mid` aparece como número aislado en `text`.
    Evita falsos positivos: miembro 1 no coincide con "10" o "C-100".
    Acepta formatos comunes en DXF de STAAD:
      "1"  "  1  "  "Col 1"  "C1"  "C-1"  "1.00"
    """
    s = str(mid)
    raw = text.strip()
    # Coincidencia exacta (caso más común en DXF de STAAD)
    if raw == s or raw == s + ".00" or raw == s + ".0":
        return True
    # Si el texto YA es una etiqueta de resultado ('ID/As/ρ'), SOLO coincide si
    # `mid` es el ID líder. Sin esto, un id coincidía como subcadena de los
    # decimales de otro miembro (p.ej. 25 dentro del As "20.25"), inyectando una
    # segunda etiqueta y produciendo "19/20.25/20.25/0.0401/0.0401".
    lead = _leading_result_id(raw)
    if lead is not None:
        return lead == mid
    # Palabra entera con límites de palabra (evita 1→10)
    if re.search(rf'(?<!\d){re.escape(s)}(?!\d)', text):
        return True
    return False


def _replace_member_id_in_text(text: str, mid: int, new_label: str) -> str:
    """Reemplaza la etiqueta del miembro en el texto.

    Idempotente: si el texto YA es una etiqueta de resultado (formato
    'ID/As/cuantía', es decir contiene '/'), se reemplaza por completo en
    lugar de inyectar el nuevo rótulo dentro del número — de lo contrario
    una segunda corrida duplicaría los valores (ID/As/As/cuantía/cuantía).
    """
    s = str(mid)
    raw = text.strip()
    if raw == s or raw == s + ".00" or raw == s + ".0":
        return new_label
    # Ya es una etiqueta de resultado ('ID/...'): reemplazo TOTAL si `mid` es el
    # ID líder; si no lo es, no se toca (evita inyectar dentro de los decimales
    # de As/ρ de otro miembro, p.ej. 25 dentro de "20.25").
    lead = _leading_result_id(raw)
    if lead is not None:
        return new_label if lead == mid else text
    # Reemplazar solo la primera ocurrencia respetando límites de palabra
    return re.sub(rf'(?<!\d){re.escape(s)}(?!\d)', new_label, text, count=1)


class DXFProcessor:
    """Lee, modifica y guarda un archivo DXF."""

    def __init__(self, dxf_path: str):
        self.path = Path(dxf_path)
        self.doc: Optional[ezdxf.document.Drawing] = None

    def load(self) -> tuple[bool, str]:
        try:
            self.doc = ezdxf.readfile(str(self.path))
            return True, f"Archivo DXF cargado: {self.path.name}"
        except Exception as e:
            return False, f"Error al abrir DXF: {e}"

    def save(self, output_path: Optional[str] = None) -> tuple[bool, str]:
        out = Path(output_path) if output_path else self.path
        try:
            self.doc.saveas(str(out))
            return True, f"DXF guardado: {out}"
        except Exception as e:
            return False, f"Error al guardar DXF: {e}"

    # ── Etiquetas de barras ───────────────────────────────────────────────────

    def update_beam_labels(self,
                            members: list[dict],
                            results_summary: dict) -> dict:
        """
        Reemplaza textos en el DXF del tipo "<barra>" por la cadena:
          "<barra> / As=<As> cm² / ρv=<ρ>"

        Parámetros
        ----------
        members : lista de dicts {'id': int}
        results_summary : dict {member_id: {'As_max': float, 'p_v_max': float}}

        Retorna
        -------
        dict con {'found': int, 'replaced': int, 'not_found': list}
        """
        if self.doc is None:
            return {"found": 0, "replaced": 0, "not_found": []}

        msp = self.doc.modelspace()
        stats = {"found": 0, "replaced": 0, "not_found": []}
        labeled = []          # (entity, is_failing) para el acomodo automático

        # Ignorar textos en capas apagadas/congeladas (p.ej. numeración de
        # nodos oculta): sin este filtro se detecta su numeración y se
        # duplican valores en el DXF.
        try:
            from suite_shared.dxf_text_layout import hidden_layers
            ocultas = hidden_layers(self.doc)
        except Exception:
            ocultas = set()

        for member in members:
            mid = member["id"]
            if mid not in results_summary:
                stats["not_found"].append(mid)
                continue

            As_max = results_summary[mid].get("As_max", 0.0)
            p_v    = results_summary[mid].get("p_v_max", 0.0)
            falla  = not results_summary[mid].get("cumple", True)
            new_label = f"{mid}/{As_max:.2f}/{p_v:.4f}"

            found = False
            # Iterar todas las entidades del espacio modelo, incluyendo bloques
            for entity in msp:
                # Solo textos visibles: los de capas apagadas se ignoran
                if getattr(entity.dxf, "layer", "") in ocultas:
                    continue
                matched = self._try_replace_entity(
                    entity, mid, new_label)
                if matched:
                    found = True
                    stats["replaced"] += 1
                    if isinstance(entity, (Text, MText)):
                        labeled.append((entity, falla))

            if found:
                stats["found"] += 1
            else:
                log.debug(
                    "Miembro %d: no se encontró etiqueta en el DXF. "
                    "Textos disponibles: %s",
                    mid,
                    [e.dxf.text.strip() for e in msp
                     if isinstance(e, Text)][:20],
                )
                stats["not_found"].append(mid)

        # Acomodo automático: escala, posición, rotación y capa por
        # orientación (soporta columnas 3D verticales en Z)
        try:
            from suite_shared.dxf_text_layout import arrange_labels
            arrange_labels(self.doc, labeled)
        except Exception as exc:
            log.debug("Acomodo automático omitido: %s", exc)

        return stats

    def _try_replace_entity(self, entity, mid: int,
                             new_label: str) -> bool:
        """
        Intenta reemplazar el ID `mid` en la entidad dada.
        Devuelve True si realizó algún reemplazo.
        Maneja Text, MText e INSERT (bloque con atributos).
        """
        replaced = False

        if isinstance(entity, Text):
            if _is_member_id_in_text(entity.dxf.text, mid):
                entity.dxf.text = _replace_member_id_in_text(
                    entity.dxf.text, mid, new_label)
                replaced = True

        elif isinstance(entity, MText):
            raw = entity.plain_mtext() if hasattr(entity, "plain_mtext") \
                  else entity.text
            if _is_member_id_in_text(raw, mid):
                entity.text = _replace_member_id_in_text(
                    entity.text, mid, new_label)
                replaced = True

        elif isinstance(entity, Insert):
            # Bloque: verificar atributos (ATTRIB)
            for attrib in entity.attribs:
                if _is_member_id_in_text(attrib.dxf.text, mid):
                    attrib.dxf.text = _replace_member_id_in_text(
                        attrib.dxf.text, mid, new_label)
                    replaced = True

        return replaced

    # ── Reducción / ampliación de líneas ──────────────────────────────────────

    def reduce_line_lengths(self, percentage: float,
                             layer_filter: Optional[str] = None) -> int:
        """
        Reduce (o amplía) la longitud de TODAS las líneas LINE en el modelo
        manteniendo el punto medio fijo.

        percentage : porcentaje de REDUCCIÓN (positivo) o AMPLIACIÓN (negativo)
                     Ej. 10.0 → reduce 10% (factor = 0.90)
                        -20.0 → amplía 20% (factor = 1.20)
        layer_filter : si se especifica, sólo afecta líneas en esa capa.

        Retorna el número de líneas modificadas.
        """
        if self.doc is None:
            return 0

        factor = (100.0 - percentage) / 100.0
        if factor <= 0:
            log.warning("Factor de escala no válido: %.2f", factor)
            return 0

        msp = self.doc.modelspace()
        count = 0

        for entity in msp:
            if not isinstance(entity, Line):
                continue
            if layer_filter and entity.dxf.layer != layer_filter:
                continue

            p1 = entity.dxf.start
            p2 = entity.dxf.end

            # Punto medio
            mid = (
                (p1.x + p2.x) / 2.0,
                (p1.y + p2.y) / 2.0,
                (p1.z + p2.z) / 2.0,
            )

            # Nueva longitud
            half = factor / 2.0

            new_p1 = (
                mid[0] + (p1.x - mid[0]) * factor,
                mid[1] + (p1.y - mid[1]) * factor,
                mid[2] + (p1.z - mid[2]) * factor,
            )
            new_p2 = (
                mid[0] + (p2.x - mid[0]) * factor,
                mid[1] + (p2.y - mid[1]) * factor,
                mid[2] + (p2.z - mid[2]) * factor,
            )

            entity.dxf.start = new_p1
            entity.dxf.end   = new_p2
            count += 1

        return count

    def reduce_selected_lines(self, percentage: float,
                               handles: list[str]) -> int:
        """Reduce sólo las líneas cuyos handles (identificadores) se indiquen."""
        if self.doc is None:
            return 0
        factor = (100.0 - percentage) / 100.0
        count = 0
        for handle in handles:
            try:
                entity = self.doc.entitydb.get(handle)
                if entity and isinstance(entity, Line):
                    p1, p2 = entity.dxf.start, entity.dxf.end
                    mid = (
                        (p1.x + p2.x) / 2,
                        (p1.y + p2.y) / 2,
                        (p1.z + p2.z) / 2,
                    )
                    entity.dxf.start = (
                        mid[0] + (p1.x - mid[0]) * factor,
                        mid[1] + (p1.y - mid[1]) * factor,
                        mid[2] + (p1.z - mid[2]) * factor,
                    )
                    entity.dxf.end = (
                        mid[0] + (p2.x - mid[0]) * factor,
                        mid[1] + (p2.y - mid[1]) * factor,
                        mid[2] + (p2.z - mid[2]) * factor,
                    )
                    count += 1
            except Exception:
                continue
        return count

    # ── Información ───────────────────────────────────────────────────────────

    def get_all_text_entities(self) -> list[dict]:
        """Lista todos los textos en el modelo (para diagnóstico)."""
        if self.doc is None:
            return []
        result = []
        for e in self.doc.modelspace():
            if isinstance(e, Text):
                result.append({"type": "TEXT", "value": e.dxf.text,
                                "layer": e.dxf.layer})
            elif isinstance(e, MText):
                result.append({"type": "MTEXT", "value": e.text,
                                "layer": e.dxf.layer})
        return result
