"""
Lector de datos de STAAD Pro via API OpenSTAAD.

Drop-in replacement para ANLReader con la misma interfaz pública:
  connect() / load(), get_member_ids(), get_section(),
  get_forces(), get_load_cases()

NOTA DE HILOS (COM threading)
------------------------------
Los objetos COM de STAAD Pro tienen afinidad al hilo donde se crearon.
Llamar a get_section() / get_forces() desde un QThread secundario falla
silenciosamente (devuelve ceros).  Solución: llamar pre_fetch() en el hilo
principal ANTES de lanzar el QThread; a partir de ahí todos los accesos
leen el caché Python sin tocar COM.

Requiere: STAAD Pro 2025 abierto con el modelo analizado,
openstaadpy instalado y Python corriendo como Administrador.

── Métodos verificados en openstaadpy-25.0.1.1 ───────────────────────────
Geometry:
    GetBeamList()                                  → lista de IDs de barras
    GetBeamLength(beam)                            → longitud (unidades modelo)

Property:
    GetBeamSectionName(beam)                       → nombre del perfil (str)
    GetBeamMaterialName(beam)                      → nombre del material (str)
    GetBeamPropertyAll(beam)                       → (b, d, Ax, Ay, Az,
                                                        Iz, Iy, J, tf, tw)
                                                     b=ancho(ZD)  d=canto(YD)
                                                     unidades del modelo
    GetMaterialProperty(mat_name)                  → (E, ν, ρ, α, damp)

Output:
    AreResultsAvailable()                          → bool
    GetMemberEndForces(beam, end, lc, local)       → [Fx,Fy,Fz,Mx,My,Mz]
                                                     SIEMPRE en kN / kN·m
    GetIntermediateMemberForcesAtDistance(beam,
        dist, lc)                                  → [Fx,Fy,Fz,Mx,My,Mz]
    GetMinMaxAxialForce(beam, lc)                  → (mn, pmn, mx, pmx)
    GetMinMaxShearForce(beam, dir, lc)             → (mn, pmn, mx, pmx)
    GetMinMaxBendingMoment(beam, dir, lc)          → (mn, pmn, mx, pmx)
──────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

try:
    import openstaadpy  # noqa: F401
    AVAILABLE = True
except Exception:
    AVAILABLE = False

_ZERO = {"Pu": 0.0, "Vuy": 0.0, "Vuz": 0.0, "Ttor": 0.0, "Muy": 0.0, "Muz": 0.0}

# ── Conversión de unidades de longitud → metros ────────────────────────────────
# GetInputUnitForLength() devuelve un entero segun la convencion de STAAD Pro:
#   1 = foot   2 = inch   3 = centimeter   4 = millimeter   5 = meter
# Se incluyen aliases adicionales para robustez entre versiones de openstaadpy.
_LENGTH_TO_M: dict = {
    1: 0.3048,      # foot
    2: 0.0254,      # inch
    3: 0.01,        # centimeter
    4: 0.001,       # millimeter
    5: 1.0,         # meter
    # aliases adicionales observados en algunas versiones
    6: 1.0,         # meter (alias)
    7: 0.001,       # mm (alias)
}
_UNIT_NAME: dict = {
    1: "ft", 2: "in", 3: "cm", 4: "mm", 5: "m", 6: "m", 7: "mm",
}

# ── Utilidades de sección ──────────────────────────────────────────────────────

_prop_api_logged = False   # sólo logueamos los métodos disponibles una vez


def _first_positive(raw) -> "Optional[float]":
    """
    Extrae el primer valor positivo de un escalar, tupla o lista COM.
    Cubre el caso en que la API devuelve (0.45,) en lugar de 0.45.
    """
    if raw is None:
        return None
    try:
        if hasattr(raw, "__len__") and not isinstance(raw, (str, bytes)):
            if len(raw) == 0:
                return None
            raw = raw[0]
        v = float(raw)
        return v if v > 0.0 else None
    except (TypeError, ValueError):
        return None


def _log_prop_api(prop, geom) -> None:
    """Registra (una vez) los métodos del módulo Property y Geometry para diagnóstico."""
    global _prop_api_logged
    if _prop_api_logged:
        return
    _prop_api_logged = True
    for obj, label in [(prop, "Property"), (geom, "Geometry")]:
        try:
            methods = sorted(m for m in dir(obj) if not m.startswith("_"))
            log.warning("OpenSTAAD %s – métodos disponibles: %s", label, methods)
        except Exception:
            pass


class OpenSTAADReader:
    """Lee propiedades de sección y fuerzas de miembros via API OpenSTAAD."""

    def __init__(self, staad_instance=None):
        self._staad     = staad_instance
        self._geometry  = None
        self._output    = None
        self._prop      = None
        self._load_mod  = None
        self._member_ids: List[int] = []
        self._load_cases: List[int] = []

        # Factor de conversion longitud: unidades modelo → metros (detectado en connect)
        self._len_to_m: float = 1.0    # default = metros
        self._len_unit: str   = "m"    # nombre legible de la unidad

        # Caché pre-cargado en el hilo principal (ver pre_fetch)
        self._section_cache:    Dict[int, dict] = {}
        self._forces_ini_cache: Dict[int, Dict[int, dict]] = {}
        self._forces_fin_cache: Dict[int, Dict[int, dict]] = {}
        self._prefetched = False

        # Cachés de TOPOLOGÍA (ago-2026). Incidencias, coordenadas y el índice
        # nodo → barras se consultan miles de veces al encadenar columnas
        # partidas (column_chain) y trabes (k_chain_concrete); cada consulta
        # era una llamada COM y `get_beams_at_node` recorría TODOS los
        # miembros del modelo en cada nodo: ~4·C·N llamadas (C columnas,
        # N barras) → minutos. Ahora la topología se lee UNA vez.
        self._incid_cache: Dict[int, Tuple[int, int]] = {}
        self._coord_cache: Dict[int, Tuple[float, float, float]] = {}
        self._node_map: Optional[Dict[int, List[int]]] = None

    # ── Conexión ──────────────────────────────────────────────────────────────

    def connect(self) -> Tuple[bool, str]:
        """Conecta a STAAD Pro via openstaadpy. Retorna (ok, mensaje)."""
        try:
            from openstaadpy import os_analytical
            if self._staad is None:
                self._staad = os_analytical.connect()
            self._geometry = self._staad.Geometry
            self._output   = self._staad.Output
            self._prop     = self._staad.Property
            try:
                self._load_mod = self._staad.Load
            except Exception:
                self._load_mod = None
        except Exception as exc:
            log.exception("Error conectando a STAAD Pro")
            msg_raw = str(exc)
            # Detectar el error mas comun: STAAD Pro no esta abierto
            if ("not found" in msg_raw.lower() or
                    "not available" in msg_raw.lower() or
                    "2147221021" in msg_raw or
                    "OsErrorBase" in msg_raw):
                return False, (
                    "No se pudo conectar a STAAD Pro.\n\n"
                    "PASOS REQUERIDOS antes de conectar:\n"
                    "  1. Abrir STAAD Pro 2025\n"
                    "  2. Abrir el archivo STD del modelo\n"
                    "  3. Ejecutar el analisis (Analyze > Run Analysis)\n"
                    "  4. Cerrar la ventana de resultados del analisis\n"
                    "  5. Volver a presionar 'Conectar STAAD Pro'\n\n"
                    "NOTA: Python debe ejecutarse como Administrador.\n"
                    f"Detalle tecnico: {msg_raw}"
                )
            return False, f"No se pudo conectar a STAAD Pro: {exc}"

        try:
            if not self._output.AreResultsAvailable():
                return False, ("STAAD Pro no tiene resultados calculados. "
                               "Analice el modelo primero.")
        except Exception:
            pass

        # ── Detectar unidades de longitud del modelo ──────────────────────────
        self._detect_length_unit()

        try:
            self._member_ids = list(self._geometry.GetBeamList())
            # Modelo (re)cargado: la topología cacheada ya no vale
            self._incid_cache = {}
            self._coord_cache = {}
            self._node_map = None
        except Exception as exc:
            return False, f"Error obteniendo lista de miembros: {exc}"

        self._load_cases = self._fetch_load_cases()

        n_mem = len(self._member_ids)
        n_lc  = len(self._load_cases)
        if n_lc:
            rng = f" ({self._load_cases[0]}–{self._load_cases[-1]})"
            msg = f"{n_mem} miembros, {n_lc} combinaciones{rng}"
        else:
            msg = (f"{n_mem} miembros — use el rango manual de "
                   "combinaciones (p.ej. 200–241)")
        return True, msg

    def load(self) -> Tuple[bool, str]:
        """Alias de connect() para compatibilidad con ANLReader."""
        return self.connect()

    @property
    def connected(self) -> bool:
        return self._staad is not None and self._geometry is not None

    # ── Pre-carga en hilo principal ────────────────────────────────────────────

    def pre_fetch(self, member_ids: List[int], lc_ids: List[int]) -> None:
        """
        Extrae secciones y fuerzas de STAAD Pro en el hilo actual.

        Debe llamarse ANTES de mover el reader a un QThread.
        A partir de aquí get_section() y get_forces() leen del caché Python
        y no tocan COM, eliminando problemas de afinidad de hilos.
        """
        self._section_cache    = {}
        self._forces_ini_cache = {}
        self._forces_fin_cache = {}
        self._prefetched       = False
        self._incid_cache      = {}
        self._coord_cache      = {}
        self._node_map         = None

        for mid in member_ids:
            self._section_cache[mid] = self._read_section(mid)
            ini_map: Dict[int, dict] = {}
            fin_map: Dict[int, dict] = {}
            for lc in lc_ids:
                ini_map[lc] = self._fetch_end_forces(mid, 0, lc)
                fin_map[lc] = self._fetch_end_forces(mid, 1, lc)
            self._forces_ini_cache[mid] = ini_map
            self._forces_fin_cache[mid] = fin_map

        self._prefetched = True

    # ── API pública ────────────────────────────────────────────────────────────

    def get_member_ids(self) -> List[int]:
        return sorted(self._member_ids)

    def get_section(self, member_id: int) -> dict:
        """{'width': m, 'depth': m, 'tipo': 1=rect|2=circ}"""
        if self._prefetched and member_id in self._section_cache:
            return dict(self._section_cache[member_id])
        return self._read_section(member_id)

    def get_forces(self,
                   member_id: int,
                   lc_ids: List[int]) -> Tuple[List[dict], List[dict]]:
        """
        Retorna (forces_ini, forces_fin) alineadas con lc_ids.
        Cada elemento: {"Pu":ton, "Vuy":ton, "Vuz":ton,
                        "Ttor":ton·m, "Muy":ton·m, "Muz":ton·m}
        """
        if self._prefetched:
            ini_map = self._forces_ini_cache.get(member_id, {})
            fin_map = self._forces_fin_cache.get(member_id, {})
            ini = [dict(ini_map.get(lc) or _ZERO) for lc in lc_ids]
            fin = [dict(fin_map.get(lc) or _ZERO) for lc in lc_ids]
            return ini, fin

        if not self.connected:
            empty = [dict(_ZERO) for _ in lc_ids]
            return empty, empty

        ini, fin = [], []
        for lc in lc_ids:
            ini.append(self._fetch_end_forces(member_id, 0, lc))
            fin.append(self._fetch_end_forces(member_id, 1, lc))
        return ini, fin

    def get_load_cases(self) -> List[int]:
        return list(self._load_cases)

    # ── Detección de unidades ─────────────────────────────────────────────────

    def _detect_length_unit(self) -> None:
        """
        Detecta la unidad de longitud del modelo STAAD Pro y establece
        self._len_to_m (factor para convertir a metros) y self._len_unit.

        GetInputUnitForLength() devuelve entero:
          1=ft  2=in  3=cm  4=mm  5=m  (puede variar según versión de openstaadpy)

        Si no puede detectarse, asume metros (factor=1.0) y registra aviso.
        También aplica una heurística de seguridad basada en la sección del
        primer miembro disponible.
        """
        # Intento 1: GetInputUnitForLength en el wrapper raíz
        for obj in (self._staad,):
            fn = getattr(obj, "GetInputUnitForLength", None)
            if fn is None:
                continue
            try:
                code = int(fn())
                factor = _LENGTH_TO_M.get(code)
                if factor is not None:
                    self._len_to_m = factor
                    self._len_unit = _UNIT_NAME.get(code, str(code))
                    log.info("Unidad de longitud del modelo: %s (code=%d, factor=%.4f)",
                             self._len_unit, code, self._len_to_m)
                    return
                else:
                    log.warning("GetInputUnitForLength devolvio code=%d desconocido; "
                                "asumiendo metros.", code)
            except Exception as exc:
                log.debug("GetInputUnitForLength: %s", exc)

        # Intento 2: GetBaseUnit
        fn2 = getattr(self._staad, "GetBaseUnit", None)
        if fn2:
            try:
                raw = fn2()
                log.debug("GetBaseUnit devolvio: %s", raw)
            except Exception:
                pass

        # Fallback heuristico: leer un miembro y si la dimension > 5 → probablemente inches
        try:
            ids = list(self._geometry.GetBeamList())
            if ids:
                mid = ids[0]
                raw = self._prop.GetBeamPropertyAll(mid)
                if raw is not None and len(raw) >= 2:
                    d_raw = float(raw[1])
                    if d_raw > 5.0:
                        # Probablemente pulgadas (columna 20"-24" tipica)
                        self._len_to_m = 0.0254
                        self._len_unit = "in (detectado heuristicamente)"
                        log.warning(
                            "Unidad NO detectada via API; dimension cruda=%.3f > 5 → "
                            "asumiendo PULGADAS (factor=0.0254 m/in). "
                            "Verificar con GetInputUnitForLength.", d_raw)
                        return
                    elif d_raw > 0.1:
                        # Probablemente metros (0.2–2.0 m tipico para columna)
                        self._len_to_m = 1.0
                        self._len_unit = "m (detectado heuristicamente)"
                        log.info(
                            "Unidad NO detectada via API; dimension cruda=%.4f "
                            "parece metros (factor=1.0).", d_raw)
                        return
        except Exception as exc:
            log.debug("Heuristica de unidades: %s", exc)

        log.warning("No se pudo detectar la unidad de longitud del modelo; "
                    "asumiendo metros. Si las dimensiones parecen incorrectas, "
                    "revisar GetInputUnitForLength().")
        self._len_to_m = 1.0
        self._len_unit = "m (asumido)"

    # ── Sección transversal ────────────────────────────────────────────────────

    def _read_section(self, member_id: int) -> dict:
        if not self.connected:
            return {"width": 0.30, "depth": 0.50, "tipo": 1}

        # ── Método principal verificado: GetBeamPropertyAll ───────────────────
        # Devuelve (b, d, Ax, Ay, Az, Iz, Iy, J, tf, tw)
        #   b = ancho / ZD   d = canto(peralte) / YD   [unidades del modelo]
        # IMPORTANTE: se multiplica por self._len_to_m para convertir a metros.
        f = self._len_to_m   # factor de conversion a metros
        # ── Verificar nombre de sección para detectar circulares ─────────
        # Algunas versiones de STAAD devuelven ZD=YD para circulares; la
        # forma más robusta es revisar el nombre de la sección primero.
        _is_circular_by_name = False
        try:
            sec_name = str(self._prop.GetBeamSectionName(member_id) or "")
            _CIRC_KEYS = ("CIRCLE", "CIRCULAR", "ROUND", "CIR", "SOLID CIRCLE")
            if any(k in sec_name.upper() for k in _CIRC_KEYS):
                _is_circular_by_name = True
                log.debug("Miembro %d: nombre de sección '%s' → circular",
                          member_id, sec_name)
        except Exception:
            pass

        try:
            raw = self._prop.GetBeamPropertyAll(member_id)
            if raw is not None and len(raw) >= 2:
                b_raw = float(raw[0])   # ancho  (ZD) — en unidades del modelo
                d_raw = float(raw[1])   # peralte (YD) — en unidades del modelo
                b = b_raw * f           # convertido a metros
                d = d_raw * f
                if d > 0.0:
                    # Circular si: (a) ZD=0 o (b) nombre indica circular
                    # STAAD Pro circular: ZD=0 d=diámetro  ó  ZD=YD=diámetro
                    if b <= 0.0 or _is_circular_by_name:
                        diam = max(b, d)
                        log.debug(
                            "Miembro %d: circular D=%.4f m (crudo: b=%.4f d=%.4f %s)",
                            member_id, diam, b_raw, d_raw, self._len_unit)
                        return {"width": diam, "depth": diam, "tipo": 2}
                    log.debug(
                        "Miembro %d: rectangular b=%.4f m  d=%.4f m  "
                        "(crudo: b=%.4f d=%.4f %s)",
                        member_id, b, d, b_raw, d_raw, self._len_unit,
                    )
                    return {"width": b, "depth": d, "tipo": 1}
        except Exception as exc:
            log.debug("GetBeamPropertyAll(%d): %s", member_id, exc)

        # ── Fallback: métodos individuales YD / ZD ────────────────────────────
        yd = self._get_yd(member_id)
        zd = self._get_zd(member_id)
        if yd is None:
            log.warning(
                "Miembro %d: no se pudo leer sección (ni GetBeamPropertyAll "
                "ni métodos YD/ZD); usando 0.30×0.50 m por defecto. "
                "Revise el log WARNING para ver los métodos disponibles.",
                member_id,
            )
            return {"width": 0.30, "depth": 0.50, "tipo": 1}
        if _is_circular_by_name:
            diam = float(yd)
            log.debug("Miembro %d: circular (por nombre) D=%.4f m", member_id, diam)
            return {"width": diam, "depth": diam, "tipo": 2}
        if zd is not None and float(zd) > 0.0:
            log.debug(
                "Miembro %d: rectangular %.4f × %.4f m (ZD × YD)",
                member_id, zd, yd,
            )
            return {"width": float(zd), "depth": float(yd), "tipo": 1}
        log.debug("Miembro %d: circular D=%.4f m", member_id, yd)
        return {"width": float(yd), "depth": float(yd), "tipo": 2}

    def _get_yd(self, beam_id: int) -> Optional[float]:
        """
        Lee YD (peralte en dirección Y) de un miembro y convierte a metros.
        Intenta múltiples nombres de método y maneja retornos escalares o tuplas/listas.
        """
        if self._prop is None:
            return None
        f = self._len_to_m

        # ── GetBeamPropertyAll: (b, d, Ax, Ay, Az, Iz, Iy, J, tf, tw) ──────────
        # d (índice 1) = YD = peralte  — método verificado en openstaadpy-25.0.1.1
        try:
            raw = self._prop.GetBeamPropertyAll(beam_id)
            if raw is not None and len(raw) >= 2:
                val = _first_positive(raw[1])   # d = YD en unidades del modelo
                if val is not None:
                    val_m = val * f
                    log.debug("_get_yd: GetBeamPropertyAll(%d)[1] = %.4f m (crudo: %.4f %s)",
                              beam_id, val_m, val, self._len_unit)
                    return val_m
        except Exception as exc:
            log.debug("_get_yd: GetBeamPropertyAll(%d): %s", beam_id, exc)

        # ── Métodos directos (escalar o tupla/lista) ──────────────────────────
        for name in (
            "GetPrismaticYD", "GetRectangularYD", "GetBeamYD",
            "GetSectionYD", "GetMemberYD", "GetYD",
            "GetColumnYD", "GetConcreteYD",
        ):
            fn = getattr(self._prop, name, None)
            if fn is None:
                continue
            try:
                val = _first_positive(fn(beam_id))
                if val is not None:
                    val_m = val * f
                    log.debug("_get_yd: %s(%d) = %.4f m (crudo: %.4f %s)",
                              name, beam_id, val_m, val, self._len_unit)
                    return val_m
            except Exception as exc:
                log.debug("_get_yd: %s(%d) → excepcion: %s", name, beam_id, exc)

        # ── GetMemberPropertyValue con distintas claves ───────────────────────
        for key in ("YD", "yd", "DEPTH", "depth", "D", "H"):
            try:
                val = _first_positive(
                    self._prop.GetMemberPropertyValue(beam_id, key)
                )
                if val is not None:
                    val_m = val * f
                    log.debug(
                        "_get_yd: GetMemberPropertyValue(%d, %r) = %.4f m (crudo: %.4f %s)",
                        beam_id, key, val_m, val, self._len_unit,
                    )
                    return val_m
            except Exception:
                pass

        # ── Métodos que devuelven array [YD, ZD, …] → índice 0 ───────────────
        for name in (
            "GetMemberProperties", "GetPrismaticProperties",
            "GetBeamProperties", "GetMemberGeometricProperties",
        ):
            fn = getattr(self._prop, name, None)
            if fn is None:
                continue
            try:
                arr = fn(beam_id)
                if arr is not None and hasattr(arr, "__len__") and len(arr) >= 1:
                    val = _first_positive(arr[0])
                    if val is not None:
                        val_m = val * f
                        log.debug("_get_yd: %s(%d)[0] = %.4f m (crudo: %.4f %s)",
                                  name, beam_id, val_m, val, self._len_unit)
                        return val_m
            except Exception:
                pass

        # ── Módulo Geometry como fallback ─────────────────────────────────────
        if self._geometry is not None:
            for name in (
                "GetMemberSectionDimensions",
                "GetBeamSectionDimensions",
                "GetMemberDimensions",
            ):
                fn = getattr(self._geometry, name, None)
                if fn is None:
                    continue
                try:
                    arr = fn(beam_id)
                    val = _first_positive(arr)
                    if val is not None:
                        val_m = val * f
                        log.debug("_get_yd: geometry.%s(%d) = %.4f m (crudo: %.4f %s)",
                                  name, beam_id, val_m, val, self._len_unit)
                        return val_m
                except Exception:
                    pass

        # ── Nada funcionó → volcar métodos disponibles (una sola vez) ─────────
        _log_prop_api(self._prop, self._geometry)
        return None

    def _get_zd(self, beam_id: int) -> Optional[float]:
        """
        Lee ZD (ancho en direccion Z) de un miembro y convierte a metros.
        Intenta multiples nombres de metodo y maneja retornos escalares o tuplas/listas.
        """
        if self._prop is None:
            return None
        f = self._len_to_m

        # ── GetBeamPropertyAll: (b, d, Ax, Ay, Az, Iz, Iy, J, tf, tw) ──────────
        # b (indice 0) = ZD = ancho  — metodo verificado en openstaadpy-25.0.1.1
        try:
            raw = self._prop.GetBeamPropertyAll(beam_id)
            if raw is not None and len(raw) >= 1:
                val = _first_positive(raw[0])   # b = ZD en unidades del modelo
                if val is not None:
                    val_m = val * f
                    log.debug("_get_zd: GetBeamPropertyAll(%d)[0] = %.4f m (crudo: %.4f %s)",
                              beam_id, val_m, val, self._len_unit)
                    return val_m
        except Exception as exc:
            log.debug("_get_zd: GetBeamPropertyAll(%d): %s", beam_id, exc)

        # ── Métodos directos (escalar o tupla/lista) ──────────────────────────
        for name in (
            "GetPrismaticZD", "GetRectangularZD", "GetBeamZD",
            "GetSectionZD", "GetMemberZD", "GetZD",
            "GetColumnZD", "GetConcreteZD",
        ):
            fn = getattr(self._prop, name, None)
            if fn is None:
                continue
            try:
                val = _first_positive(fn(beam_id))
                if val is not None:
                    log.debug("_get_zd: %s(%d) = %.4f m", name, beam_id, val)
                    return val * f
            except Exception as exc:
                log.debug("_get_zd: %s(%d) → excepción: %s", name, beam_id, exc)

        # ── GetMemberPropertyValue con distintas claves ───────────────────────
        for key in ("ZD", "zd", "WIDTH", "width", "B", "W"):
            try:
                val = _first_positive(
                    self._prop.GetMemberPropertyValue(beam_id, key)
                )
                if val is not None:
                    log.debug(
                        "_get_zd: GetMemberPropertyValue(%d, %r) = %.4f m",
                        beam_id, key, val,
                    )
                    return val
            except Exception:
                pass

        # ── Métodos que devuelven array [YD, ZD, …] → índice 1 ───────────────
        for name in (
            "GetMemberProperties", "GetPrismaticProperties",
            "GetBeamProperties", "GetMemberGeometricProperties",
        ):
            fn = getattr(self._prop, name, None)
            if fn is None:
                continue
            try:
                arr = fn(beam_id)
                if arr is not None and hasattr(arr, "__len__") and len(arr) >= 2:
                    val = _first_positive(arr[1])
                    if val is not None:
                        log.debug(
                            "_get_zd: %s(%d)[1] = %.4f m", name, beam_id, val
                        )
                        return val
            except Exception:
                pass

        # ── Módulo Geometry como fallback ─────────────────────────────────────
        if self._geometry is not None:
            for name in (
                "GetMemberSectionDimensions",
                "GetBeamSectionDimensions",
                "GetMemberDimensions",
            ):
                fn = getattr(self._geometry, name, None)
                if fn is None:
                    continue
                try:
                    arr = fn(beam_id)
                    if arr is not None and hasattr(arr, "__len__") and len(arr) >= 2:
                        val = _first_positive(arr[1])
                        if val is not None:
                            log.debug(
                                "_get_zd: geometry.%s(%d)[1] = %.4f m",
                                name, beam_id, val,
                            )
                            return val
                except Exception:
                    pass

        return None

    # ── Fuerzas en extremos ────────────────────────────────────────────────────

    def _fetch_end_forces(self, beam_id: int, end: int, lc: int) -> dict:
        """
        end=0 → nodo inicial, end=1 → nodo final, local=0 → sistema local.
        Mapeo: Fx→Pu, Fy→Vuy, Fz→Vuz, Mx→Ttor, My→Muy, Mz→Muz.

        Unidades: OpenSTAAD devuelve siempre en kN / kN·m.
        El diseño trabaja en ton / ton·m  →  se divide por 9.80665.
        """
        _KN_TO_TON = 1.0 / 9.80665
        try:
            vals = self._output.GetMemberEndForces(beam_id, end, lc, 0)
            if vals is None or len(vals) < 6:
                return dict(_ZERO)
            # Nodo FIN (end=1): la acción de extremo trae el momento con signo
            # OPUESTO al del nodo inicial (convención interna). Se invierte para
            # unificar el signo entre extremos (correcto para M1/M2 del factor
            # Cm; la interacción usa |M| y no cambia).
            _msgn = -1.0 if end == 1 else 1.0
            return {
                "Pu":   float(vals[0]) * _KN_TO_TON,
                "Vuy":  float(vals[1]) * _KN_TO_TON,
                "Vuz":  float(vals[2]) * _KN_TO_TON,
                "Ttor": float(vals[3]) * _KN_TO_TON,
                "Muy":  float(vals[4]) * _KN_TO_TON * _msgn,
                "Muz":  float(vals[5]) * _KN_TO_TON * _msgn,
            }
        except Exception as exc:
            log.debug("GetMemberEndForces(beam=%d, end=%d, lc=%d): %s",
                      beam_id, end, lc, exc)
            return dict(_ZERO)

    # ── Combinaciones de carga ─────────────────────────────────────────────────

    def _fetch_load_cases(self) -> List[int]:
        """
        Detecta todos los casos de carga: tanto LOAD (primarios)
        como LOAD COMBINATION, probando múltiples nombres de método.
        """
        lcs: List[int] = []
        if self._load_mod is None:
            return lcs

        # ── Casos primarios (LOAD n) ───────────────────────────────────────────
        for count_name in ("GetLoadCaseCount", "GetNumberOfLoadCases",
                           "GetNoOfPrimaryLoadCases", "GetPrimaryLoadCaseCount"):
            try:
                n = int(getattr(self._load_mod, count_name)())
                if n <= 0:
                    break
                for i in range(n):
                    for id_name in ("GetLoadCaseID", "GetPrimaryLoadCaseID",
                                    "GetLoadCaseNumber"):
                        try:
                            lcs.append(int(getattr(self._load_mod, id_name)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue

        # ── LOAD COMBINATION ──────────────────────────────────────────────────
        for count_name in ("GetLoadCombinationCount", "GetLoadComboCount",
                           "GetNoOfLoadCombinations", "GetCombinationCaseCount"):
            try:
                n = int(getattr(self._load_mod, count_name)())
                if n <= 0:
                    break
                for i in range(n):
                    for id_name in ("GetLoadCombinationID", "GetLoadComboID",
                                    "GetCombinationCaseID",
                                    "GetLoadCombinationNumber"):
                        try:
                            lcs.append(int(getattr(self._load_mod, id_name)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue

        return sorted(set(lcs))

    # ── Miembros seleccionados en el modelo ───────────────────────────────────

    def get_selected_members(self) -> List[int]:
        """
        IDs de los miembros actualmente seleccionados en STAAD Pro.

        Prueba varios nombres de método de la API OpenSTAAD.  En la primera
        llamada vuelca en el log la lista completa de métodos de Geometry para
        facilitar el diagnóstico si ningún candidato funciona.
        """
        if not self.connected:
            return []

        geo = self._geometry

        # ── Diagnóstico único: lista todos los métodos de OSGeometry ──────────
        if not getattr(self, '_sel_diag_done', False):
            self._sel_diag_done = True
            try:
                metodos_geo = sorted(m for m in dir(geo) if not m.startswith('_'))
                log.info("OSGeometry — métodos disponibles: %s", metodos_geo)
            except Exception:
                pass
            try:
                metodos_st = sorted(m for m in dir(self._staad) if not m.startswith('_'))
                log.info("StaadWrapper — atributos raíz: %s", metodos_st)
            except Exception:
                pass

        # ── Candidatos en orden de probabilidad ──────────────────────────────
        _candidates = [
            # Geometry sub-objeto
            (geo,          "GetSelectedBeamList"),
            (geo,          "GetSelectedBeams"),
            (geo,          "GetSelectedMemberList"),
            (geo,          "GetSelectedMembers"),
            # Objeto raíz del wrapper
            (self._staad,  "GetSelectedBeamList"),
            (self._staad,  "GetSelectedBeams"),
            (self._staad,  "GetSelectedMemberList"),
            (self._staad,  "GetSelectedMembers"),
        ]

        for obj, name in _candidates:
            fn = getattr(obj, name, None)
            if fn is None:
                continue
            try:
                raw = fn()
                ids = [int(b) for b in raw if b]
                log.info("get_selected_members vía '%s': %d miembro(s)", name, len(ids))
                return ids
            except Exception as exc:
                log.debug("get_selected_members/%s: %s", name, exc)

        log.warning("get_selected_members: ningún método de selección funcionó. "
                    "Revise el log INFO para ver los métodos disponibles en OSGeometry.")
        return []

    def build_members_from_staad(self) -> List[dict]:
        """
        Construye la lista de miembros desde los miembros seleccionados en STAAD Pro.

        Determina el tipo (rectangular / circular) leyendo la sección de cada
        miembro con _read_section().

        Returns
        -------
        list[dict] — cada dict: {"id": int, "tipo": 1|2}
                     tipo 1 = rectangular,  tipo 2 = circular
        """
        ids = self.get_selected_members()
        if not ids:
            log.warning("build_members_from_staad: no hay miembros seleccionados.")
            return []
        members = []
        for mid in ids:
            try:
                sec  = self._read_section(mid)
                tipo = sec.get("tipo", 1)
            except Exception:
                tipo = 1
            members.append({"id": mid, "tipo": tipo})
        log.info("build_members_from_staad: %d miembro(s) cargados.", len(members))
        return members

    def build_members_for_ids(self, ids: List[int]) -> List[dict]:
        """
        Construye la lista de miembros para los IDs dados explícitamente.

        Respaldo para cuando la selección automática no está disponible y el
        usuario ingresa los números de barra a mano.

        Returns
        -------
        list[dict] — cada dict: {"id": int, "tipo": 1|2}
        """
        members = []
        for mid in ids:
            try:
                sec  = self._read_section(mid)
                tipo = sec.get("tipo", 1)
            except Exception:
                tipo = 1
            members.append({"id": mid, "tipo": tipo})
        log.info("build_members_for_ids: %d miembro(s) cargados.", len(members))
        return members

    # ── Longitud de barra ──────────────────────────────────────────────────────

    def get_beam_length(self, beam_id: int) -> float:
        """Longitud de la barra en metros. Retorna 0.0 si no disponible."""
        if not self.connected:
            return 0.0
        try:
            raw = self._geometry.GetBeamLength(beam_id)
            if raw is not None:
                return float(raw) * self._len_to_m
        except Exception as exc:
            log.debug("GetBeamLength(%d): %s", beam_id, exc)
        return 0.0

    # ── Incidencias (nodos extremo de una barra) ───────────────────────────────

    def get_beam_incidence(self, beam_id: int) -> Tuple[int, int]:
        """
        Retorna (node_a, node_b) para la barra dada.
        node_a = nodo inicial,  node_b = nodo final.
        Retorna (0, 0) si no disponible.
        """
        if not self.connected:
            return 0, 0
        hit = self._incid_cache.get(beam_id)
        if hit is not None:
            return hit
        geo = self._geometry
        res = (0, 0)
        for obj, name in [
            (geo,          "GetBeamIncidence"),
            (geo,          "GetMemberIncidence"),
            (geo,          "GetBeamNodeNumbers"),
            (geo,          "GetMemberNodeNumbers"),
            (geo,          "GetBeamEndNodes"),
            (self._staad,  "GetBeamIncidence"),
            (self._staad,  "GetMemberIncidence"),
        ]:
            fn = getattr(obj, name, None)
            if fn is None:
                continue
            try:
                raw = fn(beam_id)
                if raw is not None and hasattr(raw, "__len__") and len(raw) >= 2:
                    res = (int(raw[0]), int(raw[1]))
                    break
            except Exception as exc:
                log.debug("get_beam_incidence/%s(%d): %s", name, beam_id, exc)
        if res != (0, 0):
            self._incid_cache[beam_id] = res
        return res

    def get_node_coordinates(self, node_id: int) -> Tuple[float, float, float]:
        """
        Retorna (x, y, z) del nodo en metros.  Y = vertical (convención STAAD).
        Retorna (0,0,0) si no disponible.
        """
        if not self.connected or node_id == 0:
            return 0.0, 0.0, 0.0
        hit = self._coord_cache.get(node_id)
        if hit is not None:
            return hit
        geo = self._geometry
        for name in ("GetNodeCoordinates", "GetNodeCoordinate"):
            fn = getattr(geo, name, None)
            if fn is None:
                continue
            try:
                raw = fn(node_id)
                if raw is not None and hasattr(raw, "__len__") and len(raw) >= 3:
                    xyz = (float(raw[0]) * self._len_to_m,
                           float(raw[1]) * self._len_to_m,
                           float(raw[2]) * self._len_to_m)
                    self._coord_cache[node_id] = xyz
                    return xyz
            except Exception as exc:
                log.debug("get_node_coordinates/%s(%d): %s", name, node_id, exc)
        return 0.0, 0.0, 0.0

    def get_beam_plan_angle_deg(self, beam_id: int, node_id: int) -> float:
        """
        Ángulo (0°-90°) en planta entre el eje longitudinal de la trabe
        `beam_id` (vista en planta, plano X-Z global, con Y = vertical) y el
        eje local Z de la columna.

        El ángulo se mide SIEMPRE respecto al eje X GLOBAL. Si la columna se
        modeló con beta ≠ 0° (sección girada sobre su eje longitudinal), quien
        consume este valor debe restarle beta para referirlo a los ejes reales
        de la sección; eso lo hace `design.k_chain_concrete` en el cálculo de K.

        Retorna 0.0 si no se puede determinar (trabe paralela al eje X
        global / al eje local Z supuesto de la columna).
        """
        if not self.connected or node_id == 0:
            return 0.0
        na, nb = self.get_beam_incidence(beam_id)
        far = nb if na == node_id else na
        if far == 0 or na == 0 or nb == 0:
            return 0.0
        x0, _, z0 = self.get_node_coordinates(node_id)
        x1, _, z1 = self.get_node_coordinates(far)
        dx, dz = (x1 - x0), (z1 - z0)
        if abs(dx) < 1e-6 and abs(dz) < 1e-6:
            return 0.0
        ang = math.degrees(math.atan2(dz, dx))
        ang = abs(ang) % 180.0
        if ang > 90.0:
            ang = 180.0 - ang
        return ang

    def get_beams_at_node(self, node_id: int,
                          exclude_id: Optional[int] = None) -> List[int]:
        """
        Lista de IDs de barras conectadas al nodo node_id.
        exclude_id: ID de barra a excluir (p.ej. la columna principal).

        Estrategia: la PRIMERA llamada construye el índice nodo → barras
        recorriendo los miembros una sola vez (N llamadas COM, cacheadas en
        `_incid_cache`); las siguientes son búsquedas en diccionario.
        Antes se recorrían todos los miembros EN CADA consulta.
        """
        if not self.connected or node_id == 0:
            return []
        if self._node_map is None:
            node_map: Dict[int, List[int]] = {}
            for bid in self._member_ids:
                na, nb = self.get_beam_incidence(bid)
                if na:
                    node_map.setdefault(na, []).append(bid)
                if nb and nb != na:
                    node_map.setdefault(nb, []).append(bid)
            self._node_map = node_map
        result = list(self._node_map.get(node_id, []))
        if exclude_id is not None:
            result = [b for b in result if b != exclude_id]
        return result

    # ── Inercias de sección ────────────────────────────────────────────────────

    def get_beam_iy_iz(self, beam_id: int) -> Tuple[float, float]:
        """
        Retorna (Iy_m4, Iz_m4) en m⁴ para la barra.

        GetBeamPropertyAll devuelve:
          (b, d, Ax, Ay, Az, Iz, Iy, J, tf, tw)
          índice 5 = Iz,  índice 6 = Iy  — en unidades del modelo.
        Se convierte a m⁴ multiplicando por len_to_m⁴.
        Si los índices de inercia son cero o no están disponibles,
        se calcula desde b y d de la sección rectangular.
        """
        if not self.connected:
            return 0.0, 0.0
        f4 = self._len_to_m ** 4   # factor de conversión: unidades_modelo⁴ → m⁴
        try:
            raw = self._prop.GetBeamPropertyAll(beam_id)
            if raw is not None and len(raw) >= 7:
                Iz = float(raw[5]) * f4
                Iy = float(raw[6]) * f4
                if Iy > 0.0 and Iz > 0.0:
                    return Iy, Iz
        except Exception as exc:
            log.debug("get_beam_iy_iz(%d): %s", beam_id, exc)

        # Fallback: calcular desde dimensiones b × d
        try:
            raw = self._prop.GetBeamPropertyAll(beam_id)
            if raw is not None and len(raw) >= 2:
                b = float(raw[0]) * self._len_to_m
                d = float(raw[1]) * self._len_to_m
                if b > 0.0 and d > 0.0:
                    Iy = b * d**3 / 12.0
                    Iz = d * b**3 / 12.0
                    return Iy, Iz
        except Exception:
            pass
        return 0.0, 0.0

    # ── Cálculo del factor K desde STAAD ──────────────────────────────────────

    def compute_k_factors(self,
                           col_id:  int,
                           node_a:  int,
                           node_b:  int,
                           Bc_m:    float,
                           Hc_m:    float,
                           braced:  bool = True,
                           code:    str  = "NTC") -> "object":
        """
        Calcula los factores Ky y Kz para una columna consultando STAAD Pro.

        Parámetros
        ----------
        col_id : ID de la barra columna en STAAD Pro
        node_a : nodo inferior (inicio)
        node_b : nodo superior (fin)
        Bc_m   : ancho de la sección (m)
        Hc_m   : altura de la sección (m)
        braced : True = marco arriostrado
        code   : 'NTC' | 'ACI'

        Retorna KFactorResult con Ky, Kz y memoria de cálculo.
        """
        from design.k_factor_concrete import compute_k_for_column, KFactorResult

        # Longitud libre de la columna
        Lc_m = self.get_beam_length(col_id)
        if Lc_m < 0.01:
            Lc_m = 3.0
            log.warning("compute_k_factors: longitud col %d no disponible; usando 3.0 m",
                        col_id)

        def _beams_info(node_id: int) -> List[dict]:
            """
            Devuelve la lista de trabes (vigas HORIZONTALES) conectadas al
            nodo.  Se excluyen:
              1. La barra columna actual (col_id).
              2. Miembros cuya inclinación sobre la horizontal supera 45°
                 (i.e., otras columnas o diagonales empinadas).
                 Criterio: L_horiz / L_3d < cos(45°) ≈ 0.707 → excluir.
            """
            bids = self.get_beams_at_node(node_id, exclude_id=col_id)
            info = []
            for bid in bids:
                L_m = self.get_beam_length(bid)
                if L_m < 0.01:
                    continue

                # ── Filtro de verticalidad ──────────────────────────────────
                # Determinar si el miembro es predominantemente vertical (otra
                # columna) comparando la proyección horizontal con la longitud
                # total en 3-D.  Threshold: inclinación > 45° sobre horizontal
                # → se excluye del cálculo de G (no aporta restricción a la
                # rotación de la viga como lo haría una trabe real).
                na_b, nb_b = self.get_beam_incidence(bid)
                far_node = nb_b if na_b == node_id else na_b
                if far_node != 0:
                    x0, y0, z0 = self.get_node_coordinates(node_id)
                    x1, y1, z1 = self.get_node_coordinates(far_node)
                    L_3d   = math.sqrt((x1-x0)**2 + (y1-y0)**2 + (z1-z0)**2)
                    L_horiz= math.sqrt((x1-x0)**2 + (z1-z0)**2)
                    if L_3d > 1e-6 and (L_horiz / L_3d) < 0.707:
                        # Miembro inclinado más de 45° → es columna/diagonal;
                        # no se incluye como trabe en la suma Σ(I/L)_vigas.
                        log.debug(
                            "compute_k_factors: barra %d excluida en nodo %d "
                            "(inclinación vertical %.1f°, no es trabe)",
                            bid, node_id,
                            math.degrees(math.acos(max(0.0, L_horiz / L_3d))))
                        continue

                Iy, Iz = self.get_beam_iy_iz(bid)
                if Iy <= 0.0 or Iz <= 0.0:
                    # Reconstruir desde sección
                    sec = self._read_section(bid)
                    b   = sec.get("width",  0.30)
                    d   = sec.get("depth",  0.50)
                    Iy  = b * d**3 / 12.0
                    Iz  = d * b**3 / 12.0

                # ── Proyección por inclinación en planta ──────────────────
                # Si la trabe NO llega alineada con los ejes locales de la
                # columna (caso ortogonal ideal), su rigidez a flexión debe
                # proyectarse sobre los planos Y-Z de la columna mediante
                # cosenos directores:  Iz_eff = I·cos²θ ,  Iy_eff = I·sin²θ
                # con θ = ángulo en planta entre el eje de la trabe y el eje
                # local Z de la columna (supuesto ‖ eje global X si beta=0).
                theta_deg = self.get_beam_plan_angle_deg(bid, node_id)
                theta_rad = math.radians(theta_deg)
                c2, s2    = math.cos(theta_rad) ** 2, math.sin(theta_rad) ** 2
                I_flex    = max(Iy, Iz)   # inercia de flexión gobernante
                Iz_eff    = I_flex * c2
                Iy_eff    = I_flex * s2

                info.append({
                    "beam_id":    bid,
                    "L_m":        L_m,
                    "Iy_m4":      Iy,
                    "Iz_m4":      Iz,
                    "I_m4":       (Iy + Iz) / 2.0,
                    "angle_deg":  theta_deg,
                    "Iy_eff_m4":  Iy_eff,
                    "Iz_eff_m4":  Iz_eff,
                })
            return info

        beams_A = _beams_info(node_a) if node_a != 0 else []
        beams_B = _beams_info(node_b) if node_b != 0 else []

        method = "ntc" if (braced and code == "NTC") else "nomogram"
        return compute_k_for_column(
            col_id  = col_id,
            Bc_m    = Bc_m,
            Hc_m    = Hc_m,
            Lc_m    = Lc_m,
            beams_A = beams_A,
            beams_B = beams_B,
            braced  = braced,
            code    = code,
            method  = method,
        )
