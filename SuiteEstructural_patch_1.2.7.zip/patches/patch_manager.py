"""
Sistema de parches para la Suite de Diseño Estructural.

Flujo:
  1. El launcher llama a PatchManager.check_on_startup() al iniciar.
  2. Si hay conexión a internet, consulta el servidor de parches (JSON).
  3. Si la versión remota > versión local, muestra diálogo de actualización.
  4. El usuario acepta → se descarga el parche (.zip) y se aplica en caliente.
  5. No requiere reinstalar la suite completa.

Formato del parche (.zip):
  patch_1.0.1/
  ├── manifest.json          ← lista de archivos a reemplazar
  ├── beam_design_pro/
  │   └── gui/main_window.py ← archivo corregido
  └── suite_shared/
      └── error_reporter.py

Formato manifest.json:
  {
    "version": "1.0.1",
    "date": "2026-07-01",
    "notes": "Corrección en exportación Word de trabes.",
    "files": [
      "beam_design_pro/gui/main_window.py",
      "suite_shared/error_reporter.py"
    ]
  }
"""

import base64
import hashlib
import json
import shutil
import zipfile
import logging
from pathlib import Path
from typing   import Optional

from suite_shared.version import SUITE_VERSION

log = logging.getLogger(__name__)

# Clave PÚBLICA Ed25519 (raw, base64) — la misma raíz de confianza que el
# licenciamiento. Todo parche descargado debe venir firmado con la privada.
_PUBKEY_B64 = "7cirnMjx3NtjYzEJn4UTHuV9XqQ1yRbNqGNdDAptjKU="

# URL del manifest de parches (JSON con {"version": "x.y.z", "url": "...zip"}).
# Opción recomendada: GitHub Releases — sube latest.json como release asset.
# Ejemplo:  https://raw.githubusercontent.com/TU_USUARIO/suite-estructural/master/patches/latest.json
PATCH_SERVER_URL = "https://raw.githubusercontent.com/jemaromx/Parches/main/latest.json"
SUITE_ROOT       = Path(__file__).resolve().parent.parent


class PatchManager:

    def __init__(self, suite_root: Path = SUITE_ROOT):
        self.suite_root = suite_root

    # ── API pública ──────────────────────────────────────────────────────────

    def check_on_startup(self, parent_widget=None) -> None:
        """Verificar parches disponibles; mostrar diálogo si los hay."""
        try:
            info = self._fetch_patch_info()
        except Exception as exc:
            log.debug("Sin acceso al servidor de parches: %s", exc)
            return

        if info is None:
            return

        remote_version = info.get("version", "")
        if not self._is_newer(remote_version, SUITE_VERSION):
            log.info("Suite actualizada (%s).", SUITE_VERSION)
            return

        log.info("Parche disponible: %s → %s", SUITE_VERSION, remote_version)
        self._prompt_and_apply(info, parent_widget)

    def apply_patch_file(self, zip_path: Path) -> bool:
        """Aplica un archivo .zip de parche descargado manualmente."""
        return self._apply_zip(zip_path)

    # ── Internos ─────────────────────────────────────────────────────────────

    def _fetch_patch_info(self) -> Optional[dict]:
        import urllib.request
        with urllib.request.urlopen(PATCH_SERVER_URL, timeout=5) as resp:
            return json.loads(resp.read().decode())

    @staticmethod
    def _is_newer(remote: str, local: str) -> bool:
        def _parts(v): return tuple(int(x) for x in v.split("."))
        try:
            return _parts(remote) > _parts(local)
        except ValueError:
            return False

    def _prompt_and_apply(self, info: dict, parent=None) -> None:
        from PySide6.QtWidgets import QMessageBox
        version = info.get("version", "?")
        notes   = info.get("notes", "Sin notas.")

        ans = QMessageBox.question(
            parent,
            "Actualización disponible",
            f"Versión {version} disponible.\n\n{notes}\n\n¿Desea instalar ahora?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if ans != QMessageBox.Yes:
            return

        url = info.get("download_url")
        if not url:
            QMessageBox.warning(parent, "Error", "URL de descarga no disponible.")
            return

        zip_path = self.suite_root / "_patches_tmp" / f"patch_{version}.zip"
        zip_path.parent.mkdir(exist_ok=True)

        try:
            import urllib.request
            urllib.request.urlretrieve(url, zip_path)
            # Verificación de integridad y autenticidad ANTES de aplicar:
            # el parche debe traer sha256 + firma Ed25519 válidos en el
            # manifest remoto. Sin ellos (o inválidos) NO se aplica.
            err = self._verify_download(zip_path, info)
            if err:
                log.error("Parche rechazado: %s", err)
                QMessageBox.critical(
                    parent, "Actualización rechazada",
                    "La actualización descargada no pasó la verificación de "
                    f"autenticidad y NO se instaló.\n\nDetalle: {err}\n\n"
                    "Por seguridad, descargue la suite únicamente del canal "
                    "oficial o contacte a soporte.")
                return
            ok = self._apply_zip(zip_path)
        except Exception as exc:
            QMessageBox.critical(parent, "Error al descargar", str(exc))
            return
        finally:
            shutil.rmtree(zip_path.parent, ignore_errors=True)

        if ok:
            QMessageBox.information(
                parent,
                "Parche aplicado",
                f"La suite se actualizó a la versión {version}.\n"
                "Los cambios se aplican al reiniciar cada módulo.",
            )
        else:
            QMessageBox.warning(parent, "Error", "No se pudo aplicar el parche.")

    @staticmethod
    def _verify_download(zip_path: Path, info: dict) -> str:
        """
        Verifica SHA-256 y firma Ed25519 del zip contra el manifest remoto.
        Regresa "" si todo es válido; un mensaje de error en caso contrario
        (falla cerrada: sin sha256/firma el parche se rechaza).
        """
        sha_esp   = str(info.get("sha256", "")).lower().strip()
        firma_b64 = str(info.get("signature", "")).strip()
        if not sha_esp or not firma_b64:
            return "el manifest no incluye sha256/firma"

        data = zip_path.read_bytes()
        sha_real = hashlib.sha256(data).hexdigest()
        if sha_real != sha_esp:
            return "el hash SHA-256 no coincide"

        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey)
            pub = Ed25519PublicKey.from_public_bytes(
                base64.b64decode(_PUBKEY_B64))
            pub.verify(base64.b64decode(firma_b64), data)
        except Exception:
            return "la firma Ed25519 no es válida"
        return ""

    def _apply_zip(self, zip_path: Path) -> bool:
        try:
            suite_base = self.suite_root.resolve()
            with zipfile.ZipFile(zip_path) as zf:
                manifest_raw = zf.read("manifest.json")
                manifest = json.loads(manifest_raw)
                files_to_patch = manifest.get("files", [])

                backup_dir = self.suite_root / "_backup" / manifest["version"]
                backup_dir.mkdir(parents=True, exist_ok=True)

                for rel_path in files_to_patch:
                    dest = (self.suite_root / rel_path).resolve()
                    # Anti Zip-Slip: el destino DEBE quedar dentro de la suite
                    # (rechaza rutas absolutas o con '..' en el manifest).
                    if not dest.is_relative_to(suite_base):
                        log.error("Ruta fuera del árbol de la suite "
                                  "rechazada: %s", rel_path)
                        return False
                    if dest.exists():
                        # Crear respaldo antes de sobrescribir
                        backup = backup_dir / rel_path
                        backup.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(dest, backup)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(rel_path) as src, open(dest, "wb") as out:
                        out.write(src.read())

                log.info("Parche %s aplicado: %d archivo(s).",
                         manifest["version"], len(files_to_patch))
            return True
        except Exception as exc:
            log.error("Error al aplicar parche: %s", exc)
            return False
