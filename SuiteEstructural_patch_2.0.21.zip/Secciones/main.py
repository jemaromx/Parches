#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Seccion Design Pro — Propiedades Geométricas y Diseño de Secciones Compuestas
NTC DEA 2023 / NTC DEC 2023 / AISC 360-22  ·  Unidades MKS (kg, m, cm, kg/cm²)
"""
import sys
from pathlib import Path

# ── suite_shared ──────────────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ── Gate de licencia (seguridad, auditoría #1/#3): cada punto de entrada
#    verifica la licencia ANTES de ejecutar. La decisión vive en license_core (.pyd).
try:
    from suite_shared.licensing.license_core import gate_o_salir as _gate
    _gate("Secciones", gui=("--batch" not in sys.argv))
except ImportError as _sin_licencia:
    from suite_shared.arranque import licencia_ausente
    licencia_ausente(_sin_licencia, gui=("--batch" not in sys.argv))

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook
from suite_shared.splash import make_splash

log = setup_logging("secciones")
install_excepthook("secciones")

from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import QTimer
from PySide6.QtGui     import QFont
from ui.main_window    import MainWindow
from config.settings   import APP_NAME, APP_VERSION

def _make_splash():
    return make_splash(APP_NAME, "Propiedades Geométricas de Secciones", APP_VERSION, "")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 9))
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    splash = _make_splash()
    splash.show()
    app.processEvents()
    win = MainWindow()
    def _show():
        splash.finish(win)
        win.showMaximized()
    # Sin espera fija: el splash se cierra en cuanto la ventana
    # está construida (antes +400 ms, 26-oct-2026).
    QTimer.singleShot(0, _show)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
