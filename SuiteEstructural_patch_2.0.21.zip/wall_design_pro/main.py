﻿"""
WallDesignPro — Punto de entrada.

Uso:
    python main.py

Requiere:
    PySide6, openpyxl, python-docx, matplotlib
"""
import sys
from pathlib import Path

# ── suite_shared — paquete compartido de la suite ────────────────────────────

_HERE = Path(__file__).resolve().parent
_SUITE_ROOT = _HERE.parent
for _p in (_SUITE_ROOT, _HERE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ── Gate de licencia (seguridad, auditoría #1/#3): cada punto de entrada
#    verifica la licencia ANTES de ejecutar. La decisión vive en license_core (.pyd).
try:
    from suite_shared.licensing.license_core import gate_o_salir as _gate
    _gate("wall_design_pro", gui=("--batch" not in sys.argv))
except ImportError as _sin_licencia:
    from suite_shared.arranque import licencia_ausente
    licencia_ausente(_sin_licencia, gui=("--batch" not in sys.argv))

# ── matplotlib debe configurarse ANTES de cualquier import de la GUI ───────────
import matplotlib
matplotlib.use("QtAgg")

from suite_shared.logging_setup import setup_logging
from suite_shared.error_reporter import install_excepthook

log = setup_logging("wall_design_pro")
install_excepthook("wall_design_pro")

# ── PySide6 ─────────────────────────────────────────────────────────────────────
from PySide6.QtWidgets import QApplication
from PySide6.QtCore    import Qt, QTimer
from PySide6.QtGui     import QPixmap, QColor, QPainter, QFont

from config.settings import APP_NAME, APP_VERSION, APP_SUBTITLE, COLORS
from gui.main_window import MainWindow

from suite_shared.splash import make_splash

def _make_splash():
    return make_splash(APP_NAME, "Diseño de Muros — STAAD Pro en vivo o archivo .anl", APP_VERSION, "NTC 2023")

# ── Estilo unificado de gráficas de la suite (antes de crear figuras) ────────
try:
    from suite_shared.plot_style import install_rcparams
    install_rcparams()
except Exception:  # noqa: BLE001
    pass

def main():
    # Asegurar DPI correcto en Windows con pantallas de alta resolución

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("WallDesignPro")

    log.info("Iniciando %s v%s", APP_NAME, APP_VERSION)

    # Splash
    splash = _make_splash()
    splash.show()
    app.processEvents()

    # Ventana principal (construcción diferida para que el splash se vea)
    window = MainWindow()

    def _show_window():
        splash.finish(window)
        window.show()
        log.info("Ventana principal lista.")

    # Sin espera fija: el splash se cierra en cuanto la ventana
    # está construida (antes +400 ms, 26-oct-2026).
    QTimer.singleShot(0, _show_window)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
