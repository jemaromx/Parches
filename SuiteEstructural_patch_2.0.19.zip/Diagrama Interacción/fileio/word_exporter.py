"""
Exportación de la memoria de cálculo a Word (.docx).

Genera un documento detallado con:
  - Datos de la sección y materiales
  - Normativa aplicada (NTC 2023 / ACI 318-25)
  - Fórmulas y referencias
  - Tabla de resultados del diagrama de interacción
  - Tabla de verificación de combinaciones
  - Resultados M-φ y M-θ
"""
import math
import datetime
from pathlib import Path
from typing import Optional

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from core.section import SectionData
from core.materials import ConcreteModel, SteelModel
from core.interaction_3d import InteractionResult
from core.moment_curvature import MCResult, MRResult

import numpy as np


def _set_cell_bg(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.lstrip("#"))
    tcPr.append(shd)


def _heading(doc: Document, text: str, level: int = 1):
    p = doc.add_heading(text, level=level)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return p


def _para(doc: Document, text: str, bold=False, italic=False, size=10):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    return p


def _formula(doc: Document, formula: str, ref: str = ""):
    p = doc.add_paragraph()
    run = p.add_run(f"    {formula}")
    run.font.size = Pt(10)
    run.italic = True
    run.font.color.rgb = RGBColor(0x1D, 0x4E, 0xD8)
    if ref:
        r2 = p.add_run(f"   [{ref}]")
        r2.font.size = Pt(9)
        r2.font.color.rgb = RGBColor(0x64, 0x74, 0x8B)
    return p


def _table_header(table, headers, bg="1E3A5F", fg="FFFFFF"):
    row = table.rows[0]
    for i, h in enumerate(headers):
        cell = row.cells[i]
        cell.text = h
        _set_cell_bg(cell, bg)
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.color.rgb = RGBColor(int(fg[0:2], 16), int(fg[2:4], 16), int(fg[4:6], 16))
            run.font.size = Pt(9)


def export_word(
    output_path: str,
    section: SectionData,
    concrete: ConcreteModel,
    steel: SteelModel,
    code,
    result: InteractionResult,
    mc_result: Optional[MCResult] = None,
    mr_result: Optional[MRResult] = None,
    loads_data: Optional[dict] = None,
    inside: Optional[np.ndarray] = None,
    tied: bool = True,
):
    """Genera el archivo Word de memoria de cálculo."""

    doc = Document()
    try:
        from suite_shared.docx_style import aplicar_estilo_memoria
        aplicar_estilo_memoria(doc, apaisado=False)
    except Exception:
        pass

    # Márgenes
    for section_obj in doc.sections:
        section_obj.top_margin    = Cm(2.0)
        section_obj.bottom_margin = Cm(2.0)
        section_obj.left_margin   = Cm(2.5)
        section_obj.right_margin  = Cm(2.5)

    # ── Portada ──────────────────────────────────────────────────────────────
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("MEMORIA DE CÁLCULO")
    run.bold = True; run.font.size = Pt(18)
    run.font.color.rgb = RGBColor(0x1E, 0x3A, 0x5F)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run("Diagrama de Interacción 3D — Sección de Concreto Reforzado")
    r2.font.size = Pt(13)

    _para(doc, f"Fecha: {datetime.date.today().strftime('%d de %B de %Y')}")
    _para(doc, f"Normativa aplicada: {code.NAME}")
    doc.add_paragraph()

    # ── 1. Datos de la sección ────────────────────────────────────────────────
    _heading(doc, "1. Datos de la sección", 1)

    _para(doc, f"Tipo de sección: {section.section_type.capitalize()}")
    _para(doc, f"Área bruta Ag = {section.Ag:.2f} cm²")
    _para(doc, f"Área de acero Ast = {section.Ast:.3f} cm²")
    _para(doc, f"Cuantía de acero ρ = {section.rho*100:.3f} %")
    if section.b > 0 and section.h > 0:
        _para(doc, f"Dimensiones: b = {section.b:.1f} cm,  h = {section.h:.1f} cm")
    if section.D > 0:
        _para(doc, f"Diámetro: D = {section.D:.1f} cm")
    _para(doc, f"Número de varillas: {len(section.rebars)}")
    _para(doc, "Coordenadas de varillas (cm):", bold=True)

    if section.rebars:
        tbl = doc.add_table(rows=len(section.rebars) + 1, cols=4)
        tbl.style = "Table Grid"
        _table_header(tbl, ["ID", "X (cm)", "Y (cm)", "As (cm²)"])
        for i, bar in enumerate(section.rebars):
            r = tbl.rows[i + 1]
            r.cells[0].text = str(i + 1)
            r.cells[1].text = f"{bar.x:.3f}"
            r.cells[2].text = f"{bar.y:.3f}"
            r.cells[3].text = f"{bar.As:.3f}"

    doc.add_paragraph()

    # ── 2. Propiedades de materiales ──────────────────────────────────────────
    _heading(doc, "2. Propiedades de materiales", 1)

    _heading(doc, "2.1 Concreto", 2)
    _para(doc, f"Resistencia a compresión: f'c = {concrete.fc:.1f} kg/cm²")
    _para(doc, f"Módulo de elasticidad:    Ec = {concrete.Ec:,.0f} kg/cm²")
    if "NTC" in code.NAME:
        _formula(doc, "Ec = 14 000 √f'c", "NTC 2023 Art. 3.4.2")
    else:
        _formula(doc, "Ec = 15 100 √f'c", "ACI 318-25 Sec. 19.2.2.1")
    _para(doc, f"Deformación última:       εcu = {concrete.eps_cu:.4f}")
    _para(doc, f"Factor f'': 0.85 f'c = {0.85*concrete.fc:.2f} kg/cm²")

    _heading(doc, "2.2 Acero de refuerzo", 2)
    _para(doc, f"Límite de fluencia:   fy  = {steel.fy:,.0f} kg/cm²")
    _para(doc, f"Resistencia última:   fsu = {steel.fsu:,.0f} kg/cm²")
    _para(doc, f"Módulo de elasticidad: Es = {steel.Es:,.0f} kg/cm²")
    _para(doc, f"Deformación de fluencia: εy = fy/Es = {steel.eps_y:.6f}")
    _para(doc, f"Inicio endurecimiento:   εsh = {steel.eps_sh:.4f}")
    _para(doc, f"Deformación última:      εsu = {steel.eps_su:.4f}")
    _para(doc, "Diagrama de interacción: acero elastoplástico, fs = Es·εs ≤ fy "
               + ("(NTC 2023 Art. 2.4.2.2.1)" if "NTC" in code.NAME
                  else "(ACI 318-25 Sec. 20.2.2.1)")
               + "; fsu y el endurecimiento sólo en el M-φ.",
          italic=True, size=9)

    doc.add_paragraph()

    # ── 3. Parámetros normativos ──────────────────────────────────────────────
    _heading(doc, "3. Parámetros normativos", 1)

    beta1 = code.beta1(concrete.fc)
    _para(doc, f"Factor β₁ = {beta1:.4f}")
    if "NTC" in code.NAME:
        if concrete.fc <= 300:
            _formula(doc, f"β₁ = 0.85  (f'c ≤ 300 kg/cm²)", "NTC 2023 Art. 3.5.5")
        else:
            _formula(doc, f"β₁ = 1.05 − f'c/1400 = 1.05 − {concrete.fc:.0f}/1400 = {beta1:.4f}",
                     "NTC 2023 Art. 3.5.5")
    else:
        _formula(doc, f"β₁ = 0.85 − 0.05·(f'c−281)/70.3 = {beta1:.4f}", "ACI 318-25 Ec. 22.2.2.4.3")

    # Los límites salen del MISMO `limites_fr` con que el motor calculó la
    # superficie: la memoria es su espejo, no una segunda copia de la tabla
    # (hallazgo D-8: narraba «εt ≤ 0.003 / ≥ 0.006» con el motor en εty).
    ntc = "NTC" in code.NAME
    eps_ty, eps_hi, fr_lo, fr_hi = code.limites_fr(steel.fy, steel.Es, tied)
    nombre = "F_R" if ntc else "φ"
    tabla = "NTC 2023 Tabla 3.8.2.2" if ntc else "ACI 318-25 Table 21.2.2"
    if tied:
        refuerzo = "estribos"
    else:
        refuerzo = "zunchos" if ntc else "espiral"
    _para(doc, f"Factor de reducción de resistencia {nombre} ({refuerzo}), en "
               "función de εt, la deformación de tensión de la varilla más "
               "alejada del borde comprimido:")
    _formula(doc, f"εty = fy/Es = {steel.fy:,.0f}/{steel.Es:,.0f} = {eps_ty:.5f}",
             "NTC 2023 Art. 3.8.2.4" if ntc else "ACI 318-25 Sec. 21.2.2.1")
    _formula(doc, f"{nombre} = {fr_lo:.2f}  (controlada por compresión: "
                  f"εt ≤ εty = {eps_ty:.5f})", tabla)
    _formula(doc, f"{nombre} = {fr_lo:.2f} + {fr_hi - fr_lo:.2f}·(εt − εty)/"
                  f"{eps_hi - eps_ty:.3f}  (transición)", tabla)
    _formula(doc, f"{nombre} = {fr_hi:.2f}  (controlada por tensión: "
                  f"εt ≥ εty + {eps_hi - eps_ty:.3f} = {eps_hi:.5f})", tabla)

    Pmax_n = code.Pmax_nom(concrete.fc, section.Ast, section.Ag, steel.fy) / 1000.0
    Pmax_r = code.phi_Pmax(concrete.fc, section.Ast, section.Ag, steel.fy,
                           tied) / 1000.0
    _para(doc, f"Carga axial máxima nominal:  Pn_max = {Pmax_n:.2f} ton")
    _formula(doc, "Pn_max = 0.85 f'c·(Ag−Ast) + fy·Ast",
             "NTC 2023 Art. 9.3.2.2" if ntc else "ACI 318-25 Ec. 22.4.2.2")
    _para(doc, f"Carga axial máxima reducida: φPn_max = {Pmax_r:.2f} ton")
    _formula(doc, f"φPn_max = {fr_lo:.2f}·{0.80 if tied else 0.85:.2f}·Pn_max  ({refuerzo})",
             "NTC 2023 Art. 9.3.2.2" if ntc else "ACI 318-25 Tabla 22.4.2.1")

    doc.add_paragraph()

    # ── 4. Resultados del diagrama de interacción ─────────────────────────────
    _heading(doc, "4. Resultados — Diagrama de Interacción 3D", 1)

    _para(doc, "Metodología: Análisis de fibras (sección discretizada en fibras de concreto).")
    _para(doc, "Para cada ángulo θ del eje neutro (0° a 360°), se varía la profundidad c "
               "del eje neutro desde compresión pura hasta tensión pura.")
    _para(doc, "Las fuerzas internas se calculan como:")
    _formula(doc, "P  = Σ σci·Ai + Σ (σsi − σci)·As,i", "")
    _formula(doc, "Mx = Σ σci·Ai·yi + Σ (σsi − σci)·As,i·yi", "")
    _formula(doc, "My = Σ σci·Ai·xi + Σ (σsi − σci)·As,i·xi", "")
    _para(doc, f"N° de ángulos: {result.n_angles}  |  Puntos por curva: {result.n_points}")
    _para(doc, f"Pmax nominal:  {result.Pmax_nom:.2f} ton")
    _para(doc, f"φ·Pmax reducida: {result.Pmax_red:.2f} ton")

    doc.add_paragraph()

    # ── 5. Verificación de combinaciones ──────────────────────────────────────
    if loads_data and inside is not None:
        _heading(doc, "5. Verificación de combinaciones de carga", 1)
        ids, Pus, Mxus, Muys = (
            loads_data["ids"], loads_data["Pu"],
            loads_data["Mxu"], loads_data["Muy"],
        )
        if len(ids) > 0:
            tbl2 = doc.add_table(rows=len(ids) + 1, cols=6)
            tbl2.style = "Table Grid"
            _table_header(tbl2, ["ID", "Pu (ton)", "Mxu (t·m)", "Muy (t·m)", "Mu (t·m)", "Estado"])
            for i, (cid, P, Mx, My) in enumerate(zip(ids, Pus, Mxus, Muys)):
                r = tbl2.rows[i + 1]
                Mu = math.sqrt(Mx**2 + My**2)
                ok = bool(inside[i]) if i < len(inside) else False
                r.cells[0].text = str(cid)
                r.cells[1].text = f"{P:.3f}"
                r.cells[2].text = f"{Mx:.3f}"
                r.cells[3].text = f"{My:.3f}"
                r.cells[4].text = f"{Mu:.3f}"
                r.cells[5].text = "✓ CUMPLE" if ok else "✗ NO CUMPLE"
                if ok:
                    _set_cell_bg(r.cells[5], "064E3B")
                else:
                    _set_cell_bg(r.cells[5], "450A0A")
        doc.add_paragraph()

    # ── 6. M-φ ────────────────────────────────────────────────────────────────
    if mc_result and mc_result.points:
        _heading(doc, "6. Diagrama Momento-Curvatura", 1)
        _para(doc, f"Fuerza axial: N = {mc_result.N_ext:.2f} ton")
        _para(doc, f"Ángulo de análisis: {mc_result.angle_deg:.1f}°")
        _para(doc, f"Curvatura de fluencia:   φy = {mc_result.phi_y:.4e} 1/cm")
        _para(doc, f"Momento de fluencia:      My = {mc_result.My_val:.3f} ton·m")
        _para(doc, f"Curvatura última:          φu = {mc_result.phi_u:.4e} 1/cm")
        _para(doc, f"Momento último:            Mu = {mc_result.Mu_val:.3f} ton·m")
        _para(doc, f"Ductilidad de curvatura:   μφ = {mc_result.mu_phi:.2f}")

        # Tabla de puntos
        n_show = min(len(mc_result.points), 20)
        step = max(1, len(mc_result.points) // n_show)
        pts_show = mc_result.points[::step][:n_show]
        tbl3 = doc.add_table(rows=len(pts_show) + 1, cols=5)
        tbl3.style = "Table Grid"
        _table_header(tbl3, ["φ (1/cm)", "M (ton·m)", "εtop", "εbot", "NA (tendencia)"])
        for i, pt in enumerate(pts_show):
            r = tbl3.rows[i + 1]
            r.cells[0].text = f"{pt.phi:.4e}"
            r.cells[1].text = f"{abs(pt.M):.4f}"
            r.cells[2].text = f"{pt.eps_top:.5f}"
            r.cells[3].text = f"{pt.eps_bot:.5f}"
            r.cells[4].text = "Comp." if pt.eps_top > 0 else "Tensión"
        doc.add_paragraph()

    # ── 7. M-θ ────────────────────────────────────────────────────────────────
    if mr_result:
        _heading(doc, "7. Diagrama Momento-Rotación (Haselton 2008)", 1)
        _formula(doc, "θy = My·Lv/(3·EIeff) + 0.0014·(1 + 1.5·h/Lv)",
                 "Haselton 2008, Ec. 4-6")
        _formula(doc,
                 "ln(θcap,pl) = 1.24 − 1.72ν + 0.28·asp − 0.43·ln(s/db) + 0.69·ln(ρsh/0.01)",
                 "Haselton 2008, Table 5-1")
        _para(doc, f"EI efectiva:         EIeff = {mr_result.EI_eff:.3e} kg·cm²")
        _para(doc, f"Rotación de fluencia: θy   = {mr_result.theta_y:.5f} rad")
        _para(doc, f"Rotación de colapso:  θcap = {mr_result.theta_cap:.5f} rad")
        _para(doc, f"Rotación post-cap.:   θpc  = {mr_result.theta_pc:.5f} rad")
        _para(doc, f"Mc/My:                     = {mr_result.Mc_My:.3f}")
        _para(doc, f"Deterioro cíclico λ:       = {mr_result.lambda_val:.1f}")
        _para(doc, f"Ductilidad de rotación μθ  = {mr_result.mu_theta:.2f}")

    doc.add_paragraph()

    # ── Pie de página ─────────────────────────────────────────────────────────
    section_w = doc.sections[0]
    footer = section_w.footer
    fp = footer.paragraphs[0]
    fp.text = f"Interaction Design Pro — {datetime.date.today()} — {code.NAME}"
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.save(output_path)
    return output_path
