"""
Panel de combinaciones de carga.

Permite:
  • Tabla compatible con Excel (copiar/pegar).
  • Importación de elementos mecánicos de las barras seleccionadas en STAAD Pro.
  • Configuración de parámetros para M-φ / M-θ, incluido confinamiento Mander.
"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QGroupBox, QLabel, QDoubleSpinBox, QSpinBox,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QAbstractItemView,
)
from PySide6.QtCore import Signal, Qt
from PySide6.QtGui import QColor

import numpy as np


# ──────────────────────────────────────────────────────────────────────────────
# Tabla de combinaciones
# ──────────────────────────────────────────────────────────────────────────────

class LoadsTable(QTableWidget):
    """Tabla de combinaciones: ID, Pu (ton), Mxu (ton·m), Muy (ton·m)."""

    def __init__(self, parent=None):
        super().__init__(0, 4, parent)
        self.setHorizontalHeaderLabels(["ID Combinación", "Pu (ton)", "Mxu (ton·m)", "Muy (ton·m)"])
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QAbstractItemView.AllEditTriggers)
        self.setSelectionMode(QAbstractItemView.ContiguousSelection)
        self.add_row()

    def add_row(self, combo_id="", Pu=0.0, Mxu=0.0, Muy=0.0):
        r = self.rowCount()
        self.insertRow(r)
        self.setItem(r, 0, QTableWidgetItem(combo_id or f"C{r+1}"))
        self.setItem(r, 1, QTableWidgetItem(f"{Pu:.4f}"))
        self.setItem(r, 2, QTableWidgetItem(f"{Mxu:.4f}"))
        self.setItem(r, 3, QTableWidgetItem(f"{Muy:.4f}"))

    def remove_selected(self):
        rows = sorted({i.row() for i in self.selectedItems()}, reverse=True)
        for r in rows:
            self.removeRow(r)

    def clear_table(self):
        self.setRowCount(0)

    def get_loads(self):
        ids, Pus, Mxus, Muys = [], [], [], []
        for r in range(self.rowCount()):
            try:
                ids.append(self.item(r, 0).text() if self.item(r, 0) else f"C{r+1}")
                Pus.append(float(self.item(r, 1).text()))
                Mxus.append(float(self.item(r, 2).text()))
                Muys.append(float(self.item(r, 3).text()))
            except (AttributeError, ValueError):
                pass
        return ids, np.array(Pus), np.array(Mxus), np.array(Muys)

    def set_loads(self, ids, Pus, Mxus, Muys):
        self.setRowCount(0)
        for i, P, Mx, My in zip(ids, Pus, Mxus, Muys):
            self.add_row(str(i), float(P), float(Mx), float(My))

    def mark_inside(self, inside: np.ndarray):
        for r, ok in enumerate(inside):
            clr = QColor("#064e3b") if ok else QColor("#450a0a")
            for c in range(4):
                it = self.item(r, c)
                if it:
                    it.setBackground(clr)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_C and event.modifiers() & Qt.ControlModifier:
            self._copy()
        elif event.key() == Qt.Key_V and event.modifiers() & Qt.ControlModifier:
            self._paste()
        elif event.key() == Qt.Key_Delete:
            for it in self.selectedItems():
                it.setText("")
        else:
            super().keyPressEvent(event)

    def _copy(self):
        from PySide6.QtWidgets import QApplication
        ranges = self.selectedRanges()
        if not ranges:
            return
        rng = ranges[0]
        rows = []
        for r in range(rng.topRow(), rng.bottomRow() + 1):
            cols = []
            for c in range(rng.leftColumn(), rng.rightColumn() + 1):
                it = self.item(r, c)
                cols.append(it.text() if it else "")
            rows.append("\t".join(cols))
        QApplication.clipboard().setText("\n".join(rows))

    def _paste(self):
        from PySide6.QtWidgets import QApplication
        text = QApplication.clipboard().text()
        if not text:
            return
        lines = text.strip().split("\n")
        r0 = self.currentRow() if self.currentRow() >= 0 else 0
        for i, line in enumerate(lines):
            cells = line.split("\t")
            r = r0 + i
            while r >= self.rowCount():
                self.add_row()
            for c, val in enumerate(cells):
                if c < self.columnCount():
                    self.setItem(r, c, QTableWidgetItem(val.strip()))


# ──────────────────────────────────────────────────────────────────────────────
# Panel completo
# ──────────────────────────────────────────────────────────────────────────────

class LoadsPanel(QWidget):
    loads_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self._connect()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(8)

        # ── Tabla de combinaciones ────────────────────────────────────────────
        grp_tbl = QGroupBox("Combinaciones de carga (ton, ton·m)")
        vt = QVBoxLayout(grp_tbl)
        self.tbl = LoadsTable()
        vt.addWidget(self.tbl)

        hbtn = QHBoxLayout()
        self.btn_add = QPushButton("+ Agregar fila")
        self.btn_del = QPushButton("− Eliminar selección")
        self.btn_del.setProperty("accent", "red")
        self.btn_clr = QPushButton("✕ Limpiar tabla")
        self.btn_clr.setProperty("accent", "red")
        hbtn.addWidget(self.btn_add)
        hbtn.addWidget(self.btn_del)
        hbtn.addWidget(self.btn_clr)
        hbtn.addStretch()
        vt.addLayout(hbtn)
        root.addWidget(grp_tbl)

        # ── Importar desde STAAD ──────────────────────────────────────────────
        # Se importan TODOS los elementos mecánicos de las barras seleccionadas
        # en el modelo STAAD activo; no se pide número de miembro manualmente.
        grp_st = QGroupBox("Importar desde STAAD Pro 2024/2025")
        vs = QVBoxLayout(grp_st)

        fl = QFormLayout()
        fl.setSpacing(6)
        self.cb_lc_from = QSpinBox()
        self.cb_lc_from.setRange(1, 9999)
        self.cb_lc_from.setValue(1)
        self.cb_lc_to = QSpinBox()
        self.cb_lc_to.setRange(1, 9999)
        self.cb_lc_to.setValue(9999)
        fl.addRow("LC desde:", self.cb_lc_from)
        fl.addRow("LC hasta:", self.cb_lc_to)
        vs.addLayout(fl)

        hst = QHBoxLayout()
        self.btn_staad = QPushButton("📥  Seleccionar barras de STAAD")
        self.btn_staad.setProperty("accent", "green")
        self.lbl_staad_status = QLabel("STAAD: sin conexión")
        hst.addWidget(self.btn_staad)
        hst.addWidget(self.lbl_staad_status)
        hst.addStretch()
        vs.addLayout(hst)
        root.addWidget(grp_st)

        # ── Parámetros M-φ / M-θ  +  Confinamiento Mander ────────────────────
        grp_mc = QGroupBox("Parámetros Diagrama M-C (M-φ / M-θ)")
        fm = QFormLayout(grp_mc)
        fm.setSpacing(6)

        self.sb_N_ext   = self._dspin(-5000, 10000, 0.0,   "ton")
        self.sb_angle   = self._dspin(0,     360,   0.0,   "°")
        self.sb_Lv      = self._dspin(10,    2000,  150.0, "cm")
        self.sb_rho_sh  = self._dspin(0.0001, 0.05, 0.003, "")
        self.sb_db_long = self._dspin(0.5,   4.0,   2.54,  "cm")
        self.sb_s_v     = self._dspin(2,     50,    10.0,  "cm")
        fm.addRow("Carga axial N (ton, + compr.):", self.sb_N_ext)
        fm.addRow("Ángulo de flexión (°):",         self.sb_angle)
        fm.addRow("Longitud de cortante Lv (cm):",  self.sb_Lv)
        fm.addRow("Cuantía transversal ρsh:",        self.sb_rho_sh)
        fm.addRow("Diámetro barra longit. db (cm):", self.sb_db_long)
        fm.addRow("Separación estribos s (cm):",     self.sb_s_v)

        # Sub-grupo Confinamiento Mander (opcional, desmarcado por defecto)
        import math
        self.grp_conf = QGroupBox("Confinamiento — Mander (opcional)")
        self.grp_conf.setCheckable(True)
        self.grp_conf.setChecked(False)
        fl3 = QFormLayout(self.grp_conf)
        fl3.setSpacing(6)
        self.sb_fl   = self._dspin(0, 200, 5.0, "kg/cm²")
        self.lbl_fcc = QLabel("f'cc = —")
        fl3.addRow("Presión lateral confinante fl (kg/cm²):", self.sb_fl)
        fl3.addRow("", self.lbl_fcc)

        fm.addRow(self.grp_conf)
        root.addWidget(grp_mc)

        root.addStretch()
        self._update_fcc()

    def _connect(self):
        self.btn_add.clicked.connect(self.tbl.add_row)
        self.btn_del.clicked.connect(self.tbl.remove_selected)
        self.btn_clr.clicked.connect(self.tbl.clear_table)
        self.btn_staad.clicked.connect(self._import_staad)
        self.tbl.itemChanged.connect(self.loads_changed)
        self.sb_fl.valueChanged.connect(self._update_fcc)
        self.grp_conf.toggled.connect(self._update_fcc)

    # ── Lógica Mander ─────────────────────────────────────────────────────────

    def _update_fcc(self, *_):
        import math
        if not self.grp_conf.isChecked():
            self.lbl_fcc.setText("f'cc = —")
            return
        # fl/fc ratio: necesitamos fc del panel de materiales; usamos placeholder.
        fl = self.sb_fl.value()
        self.lbl_fcc.setText(f"fl = {fl:.1f} kg/cm²  (f'cc se calcula al generar M-φ)")

    def update_fcc_with_fc(self, fc: float):
        """Llamado por main_window cuando cambian los materiales."""
        import math
        if not self.grp_conf.isChecked() or fc <= 0:
            self.lbl_fcc.setText("f'cc = —")
            return
        fl = self.sb_fl.value()
        ratio = 7.94 * fl / fc
        fcc = fc * (2.254 * math.sqrt(1 + ratio) - 2 * fl / fc - 1.254)
        self.lbl_fcc.setText(f"f'cc = {fcc:.1f} kg/cm²  (Mander 1988)")

    # ── Importar STAAD ────────────────────────────────────────────────────────

    def _import_staad(self):
        """Importa fuerzas de TODAS las barras seleccionadas en el modelo STAAD."""
        try:
            from fileio.openstaad_reader import OpenSTAADReader
            reader = OpenSTAADReader()

            members = reader.get_selected_members()
            if not members:
                QMessageBox.warning(self, "STAAD",
                                    "No hay barras seleccionadas en el modelo.\n"
                                    "Seleccione al menos una barra en STAAD Pro y vuelva a intentarlo.")
                return

            lc_from = self.cb_lc_from.value()
            lc_to   = self.cb_lc_to.value()
            all_lcs = reader.get_load_case_numbers()
            lcs = [lc for lc in all_lcs if lc_from <= lc <= lc_to] if all_lcs else None

            ids, Pus, Mxus, Muys = [], [], [], []
            for member in members:
                forces = reader.get_member_forces(member, load_cases=lcs)
                for lc_id, (P_i, Mx_i, My_i, P_j, Mx_j, My_j) in forces.items():
                    for tag, P, Mx, My in [
                        (f"M{member}_LC{lc_id}i",  P_i,  Mx_i,  My_i),
                        (f"M{member}_LC{lc_id}j", -P_j, -Mx_j, -My_j),
                    ]:
                        ids.append(tag)
                        Pus.append(P)
                        Mxus.append(Mx)
                        Muys.append(My)

            if not ids:
                QMessageBox.warning(self, "STAAD", "No se encontraron fuerzas en las barras seleccionadas.")
                return

            self.tbl.set_loads(ids, Pus, Mxus, Muys)
            n_members = len(members)
            self.lbl_staad_status.setText(
                f"✓ STAAD v{reader.version}: {len(ids)} combinaciones "
                f"de {n_members} barra(s) importadas"
            )
            self.loads_changed.emit()

        except Exception as e:
            QMessageBox.critical(self, "STAAD Error",
                                 f"No se pudo conectar a STAAD Pro:\n{e}")
            self.lbl_staad_status.setText("✗ STAAD: error de conexión")

    # ── Getters ───────────────────────────────────────────────────────────────

    def get_loads(self):
        return self.tbl.get_loads()

    def get_mc_params(self) -> dict:
        return dict(
            N_ext     = self.sb_N_ext.value(),
            angle_deg = self.sb_angle.value(),
            Lv        = self.sb_Lv.value(),
            rho_sh    = self.sb_rho_sh.value(),
            db_long   = self.sb_db_long.value(),
            s_v       = self.sb_s_v.value(),
        )

    def get_confinement(self) -> tuple:
        """Retorna (use_confined: bool, fl: float kg/cm²)."""
        return self.grp_conf.isChecked(), self.sb_fl.value()

    def mark_loads(self, inside: np.ndarray):
        self.tbl.mark_inside(inside)

    @staticmethod
    def _dspin(lo, hi, val, suffix=""):
        sb = QDoubleSpinBox()
        # Los DECIMALES PRIMERO: con los 2 de fábrica, `setValue(0.003)`
        # redondeaba a 0.00 y el spin se pegaba a su mínimo, así que ρsh
        # nacía en 0.0001 y no en 0.003 (D-11, HALLAZGOS_DIAGRAMA.md).
        sb.setDecimals(4)
        sb.setRange(lo, hi)
        sb.setValue(val)
        sb.setStepType(QDoubleSpinBox.AdaptiveDecimalStepType)
        if suffix:
            sb.setSuffix(f"  {suffix}")
        return sb
