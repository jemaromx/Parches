"""Panel de materiales: f'c, fy, Ec, Es con selección de norma."""
import math
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QGroupBox,
    QLabel, QDoubleSpinBox, QComboBox, QCheckBox, QPushButton,
)
from PySide6.QtCore import Signal

from config.settings import DEFAULT_FC, DEFAULT_FY, DEFAULT_ES
from core.code_parameters import NTC2023, ACI318_25, CODE_NAMES
from core.materials import ConcreteModel, SteelModel


class MaterialPanel(QWidget):
    """Panel de propiedades de materiales y selección de norma."""

    params_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self._connect()
        self._on_auto_ec(True)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(8)

        # Norma
        grp_code = QGroupBox("Normativa")
        fl0 = QFormLayout(grp_code)
        self.cb_code = QComboBox()
        self.cb_code.addItems(CODE_NAMES)
        fl0.addRow("Método de cálculo:", self.cb_code)
        root.addWidget(grp_code)

        # Concreto
        grp_c = QGroupBox("Concreto")
        fl = QFormLayout(grp_c)
        fl.setSpacing(6)
        self.sb_fc = self._dspin(100, 1500, DEFAULT_FC, "kg/cm²")
        fl.addRow("f'c (kg/cm²):", self.sb_fc)

        self.chk_auto_ec = QCheckBox("Calcular Ec según norma")
        self.chk_auto_ec.setChecked(True)
        fl.addRow("", self.chk_auto_ec)
        self.sb_Ec = self._dspin(1e4, 5e6, 14000*math.sqrt(DEFAULT_FC), "kg/cm²")
        self.lbl_Ec_formula = QLabel("")
        fl.addRow("Ec (kg/cm²):", self.sb_Ec)
        fl.addRow("", self.lbl_Ec_formula)
        root.addWidget(grp_c)

        # Acero
        grp_s = QGroupBox("Acero de refuerzo")
        fl2 = QFormLayout(grp_s)
        fl2.setSpacing(6)
        self.sb_fy  = self._dspin(2000, 7000, DEFAULT_FY, "kg/cm²")
        self.sb_fsu = self._dspin(2000, 9000, DEFAULT_FY * 1.25, "kg/cm²")
        self.sb_Es  = self._dspin(1e5, 3e6, DEFAULT_ES, "kg/cm²")
        self.sb_eps_sh = self._dspin(0.001, 0.05, 0.010, "", decimales=4)
        self.sb_eps_su = self._dspin(0.01, 0.20, 0.090, "", decimales=4)
        fl2.addRow("fy (kg/cm²):", self.sb_fy)
        fl2.addRow("fsu (kg/cm²):", self.sb_fsu)
        fl2.addRow("Es (kg/cm²):", self.sb_Es)
        fl2.addRow("εsh (inic. endurec.):", self.sb_eps_sh)
        fl2.addRow("εsu (deform. última):", self.sb_eps_su)
        root.addWidget(grp_s)

        root.addStretch()

    def _connect(self):
        self.sb_fc.valueChanged.connect(self._on_fc_change)
        self.sb_fy.valueChanged.connect(self._auto_fsu)
        self.chk_auto_ec.toggled.connect(self._on_auto_ec)
        self.cb_code.currentTextChanged.connect(self._on_fc_change)
        for sb in [self.sb_fc, self.sb_Ec, self.sb_fy, self.sb_fsu,
                   self.sb_Es, self.sb_eps_sh, self.sb_eps_su]:
            sb.valueChanged.connect(self.params_changed)
        self.cb_code.currentTextChanged.connect(self.params_changed)

    def _on_fc_change(self, *_):
        if self.chk_auto_ec.isChecked():
            self._on_auto_ec(True)

    def _on_auto_ec(self, checked: bool):
        self.sb_Ec.setEnabled(not checked)
        if checked:
            fc  = self.sb_fc.value()
            code_name = self.cb_code.currentText()
            if "NTC" in code_name:
                Ec = 14_000 * math.sqrt(fc)
                formula = f"Ec = 14 000 √{fc:.0f} = {Ec:,.0f} kg/cm²  [NTC Art. 3.4.2]"
            else:
                Ec = 15_100 * math.sqrt(fc)
                formula = f"Ec = 15 100 √{fc:.0f} = {Ec:,.0f} kg/cm²  [ACI 19.2.2.1]"
            self.sb_Ec.setValue(Ec)
            self.lbl_Ec_formula.setText(formula)

    def _auto_fsu(self, fy: float):
        self.sb_fsu.setValue(fy * 1.25)

    # ── Getters ──────────────────────────────────────────────────────────────
    def get_code_class(self):
        name = self.cb_code.currentText()
        return NTC2023 if "NTC" in name else ACI318_25

    def get_concrete(self, use_confined: bool = False, fl: float = 0.0) -> ConcreteModel:
        """
        use_confined / fl provienen del panel de cargas (confinamiento Mander).
        Si use_confined=False devuelve concreto sin confinar.
        """
        from core.materials import ConcreteConfinedModel
        fc   = self.sb_fc.value()
        Ec   = self.sb_Ec.value()
        code = self.get_code_class()
        if use_confined and fl > 0:
            return ConcreteConfinedModel(fc=fc, fl=fl, Ec=Ec)
        return ConcreteModel(fc=fc, Ec=Ec, eps_cu=code.EPS_CU,
                             code_name=code.NAME)

    def get_steel(self) -> SteelModel:
        return SteelModel(
            fy=self.sb_fy.value(),
            Es=self.sb_Es.value(),
            fsu=self.sb_fsu.value(),
            eps_sh=self.sb_eps_sh.value(),
            eps_su=self.sb_eps_su.value(),
        )

    def get_params(self) -> dict:
        return dict(
            fc=self.sb_fc.value(), Ec=self.sb_Ec.value(),
            fy=self.sb_fy.value(), fsu=self.sb_fsu.value(),
            Es=self.sb_Es.value(), eps_sh=self.sb_eps_sh.value(),
            eps_su=self.sb_eps_su.value(),
            code=self.cb_code.currentText(),
        )

    @staticmethod
    def _dspin(lo, hi, val, suffix="", decimales=1):
        sb = QDoubleSpinBox()
        # Los DECIMALES PRIMERO y los de cada campo: con 1 decimal fijo,
        # εsh = 0.010 se leía 0.0 —el acero endurecía desde la fluencia— y
        # εsu = 0.090 como 0.1 (D-12, HALLAZGOS_DIAGRAMA.md).
        sb.setDecimals(decimales)
        sb.setRange(lo, hi)
        sb.setValue(val)
        sb.setStepType(QDoubleSpinBox.AdaptiveDecimalStepType)
        if suffix:
            sb.setSuffix(f"  {suffix}")
        return sb
