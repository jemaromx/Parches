﻿# -*- coding: utf-8 -*-
"""
Ventana principal — WallDesignPro.

Arquitectura:
  ┌─ Header (logo + título) ──────────────────────────────────────────┐
  ├─ Left Panel (380px) ───────┬─ Right Panel (QTabWidget) ───────────┤
  │  • Archivo .anl            │  • Resultados                        │
  │  • Cargas / Ductilidad     │  • Resumen                           │
  │  • Niveles                 │  • Cort. Res. Ent.                   │
  │  • Materiales              │  • Gráficas                          │
  │  • Cortantes de entrepiso  │                                      │
  │  • Grupos de placas        │                                      │
  │  • Acciones (botones)      │                                      │
  │  • Log de cálculo          │                                      │
  ├────────────────────────────┴──────────────────────────────────────┤
  │  Barra de progreso (fina)                                          │
  └─ StatusBar ────────────────────────────────────────────────────────┘

Modo de operación: únicamente Archivo .anl

Y los parámetros del proyecto se introducen en las tablas del cuadro de
control izquierdo —cargas, ductilidad, niveles, materiales y cortantes de
entrepiso—, igual que en `wall_design_pro`: **ya no hay plantilla de
Excel**. Los muros a diseñar se eligen de los grupos que el propio .anl
trae en su sección GROUP DEFINITION, que es lo que antes se declaraba en
la hoja MUROS de la plantilla.
"""
from __future__ import annotations

import logging
import math
import os
import re
import sys
import traceback
from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import (
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavToolbar,
)

from PySide6.QtCore    import Qt, QThread, Signal
from PySide6.QtGui     import QColor, QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QSplitter, QLabel, QPushButton, QLineEdit, QComboBox,
    QFileDialog, QMessageBox, QProgressBar, QStatusBar,
    QFrame, QGroupBox, QTabWidget, QTextEdit, QScrollArea,
    QSizePolicy,
    # Los que pide el cuadro de control desde que captura los parámetros
    # en vez de leerlos del Excel.
    QAbstractItemView, QApplication, QCheckBox, QDoubleSpinBox, QHeaderView,
    QListWidget, QSpinBox, QTableWidget, QTableWidgetItem,
)

from config.settings import (
    APP_NAME, APP_VERSION, APP_SUBTITLE,
    COLORS, LOG_COLORS, CRIT_BG, SOURCE_DIR,
)
from gui.styles import MAIN_STYLE, HEADER_STYLE, LOG_STYLE

log = logging.getLogger(__name__)


# ── Widget de texto con colores ───────────────────────────────────────────────


def _flexion_ok(r) -> bool:
    """`cond_flexion` cuenta como veredicto, igual que axial y cortante.

    Punto 6 de CAMBIOS_PENDIENTES_MUROS.md: hasta ahora un muro que fallaba
    flexion -acero de borde/castillo topado- contaba como OK, salia en verde
    y solo se enteraba quien abriera la memoria Word. Eso vaciaba el titulo
    del commit de la v2.0.8 ("ya no trunca EN SILENCIO"): en la memoria no,
    en pantalla si.

    Se usa `getattr` con "Si Pasa" por omision para no romper resultados
    viejos que no tengan el campo.
    """
    return getattr(r, "cond_flexion", "Si Pasa") != "No Pasa"


class ColoredLog(QTextEdit):
    """QTextEdit de sólo lectura con soporte de colores por segmento."""

    FG = LOG_COLORS
    BG = CRIT_BG

    def __init__(self, parent=None, wrap: bool = False):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setStyleSheet(LOG_STYLE)
        font = QFont("Consolas", 8)
        self.setFont(font)
        self.setLineWrapMode(QTextEdit.WidgetWidth if wrap else QTextEdit.NoWrap)

    def put(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto sin salto de línea con color fg y fondo opcional bg."""
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(self.FG.get(fg, self.FG[""])))
        if bg in self.BG:
            fmt.setBackground(QColor(self.BG[bg]))
        if fg in ("hdr", "sec"):
            fmt.setFontWeight(QFont.Weight.Bold)
        cursor.setCharFormat(fmt)
        cursor.insertText(text)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()

    def putln(self, text: str, fg: str = "", bg: str = ""):
        """Inserta texto + salto de línea."""
        self.put(text + "\n", fg, bg)

    def clear_log(self):
        self.clear()

    def scroll_top(self):
        self.moveCursor(QTextCursor.Start)


# ── Hilo de diseño ────────────────────────────────────────────────────────────

class DesignWorker(QThread):
    """Ejecuta todo el cálculo de diseño en un hilo secundario."""

    sig_log      = Signal(str, str)    # (texto, tag)
    sig_progress = Signal(int, str)    # (pct, mensaje)
    sig_done     = Signal(object)      # dict con todos los resultados
    sig_error    = Signal(str)         # traceback completo

    def __init__(self, user_inputs: object, anl_path: str,
                 wall_plate_ids: dict, source_dir: str, parent=None):
        super().__init__(parent)
        #: `UserInputs` ya construido desde el cuadro de control. Antes
        #: llegaba la ruta del Excel y lo construía este hilo; ahora lo
        #: arma la ventana, que es quien tiene los widgets, y el hilo solo
        #: lo consume. Leer widgets desde un QThread no es seguro.
        self.user_inputs    = user_inputs
        self.anl_path       = anl_path
        #: {nombre de muro: [placas]} de los grupos elegidos en el panel.
        self.wall_plate_ids = wall_plate_ids
        self.source_dir     = source_dir

    def _log(self, text: str, tag: str = ""):
        self.sig_log.emit(text, tag)

    def run(self):  # noqa: C901
        try:
            sd = self.source_dir
            if sd not in sys.path:
                sys.path.insert(0, sd)

            from staad_anl_parser      import ANLParser
            from wall_models           import WallData, UserInputs
            from wall_geometry         import build_plate_data, determine_direction, build_wall_levels
            from wall_design_ntc2023   import (
                design_masonry_level, design_concrete_level, contexto_hcr,
                interaction_diagram_masonry, interaction_diagram_concrete,
            )

            # 1. Parámetros del cuadro de control ───────────────────────────
            self._log("Usando los parámetros del cuadro de control...", "sec")
            inputs = self.user_inputs
            self._log(
                f"  {len(inputs.floor_levels)} niveles  |  "
                f"{len(inputs.materials)} material(es)  |  "
                f"combos diseño: {inputs.first_design_combo}–"
                f"{inputs.last_design_combo}  |  Q={inputs.Q_duct}"
            )

            # 2. Cargar ANL ─────────────────────────────────────────────────
            self._log(f"\nCargando archivo .anl...", "sec")
            parser = ANLParser(self.anl_path)
            parser.load()
            self._log(f"  {len(parser.lines):,} líneas leídas.", "dim")

            # 3. Los grupos elegidos en el panel son la fuente de verdad ────
            #
            # Antes esto resolvía nombres de grupo declarados en la hoja
            # MUROS contra el GROUP DEFINITION del .anl, y un nombre mal
            # escrito en la plantilla daba un muro sin placas que se
            # saltaba con un aviso. Ahora los nombres SALEN del propio
            # archivo —la lista de disponibles se llenó con ellos—, así que
            # no pueden discrepar.
            self._log("\n  Muros a diseñar (grupos del .anl):", "sec")
            inputs.wall_plate_ids = {}
            for wname, pids in self.wall_plate_ids.items():
                inputs.wall_plate_ids[wname] = pids
                if pids:
                    self._log(f"    {wname:<14}: {len(pids)} placas", "dim")
                else:
                    self._log(
                        f"    [AVISO] {wname}: sin placas (se omitirá)", "warn")

            found = sum(len(v) for v in inputs.wall_plate_ids.values())
            if found == 0:
                raise ValueError(
                    "Ningún grupo seleccionado tiene placas.\n"
                    "Vuelva a leer los grupos del .anl y seleccione al "
                    "menos uno en el cuadro de control.")

            # 4. Espesores (ELEMENT PROPERTY) ───────────────────────────────
            all_pids = list({pid for pids in inputs.wall_plate_ids.values()
                             for pid in pids})
            self._log(f"\n  Leyendo espesores ({len(all_pids)} placas)...", "dim")
            element_prop: dict = {}
            try:
                element_prop = parser.find_element_property(all_pids)
                self._log(
                    f"  {len(element_prop)}/{len(all_pids)} placas con espesor.", "dim")
                for tv, cnt in sorted(
                    Counter(round(v['thick'], 6)
                            for v in element_prop.values()).items()
                ):
                    self._log(f"    t={tv:.4f} m  →  {cnt} placas", "dim")
            except Exception as exc:
                self._log(f"  [AVISO] Espesores no disponibles: {exc}", "warn")

            # 5. Asignaciones de material (CONSTANTS) ───────────────────────
            self._log("  Leyendo asignaciones de material...", "dim")
            mat_assign: dict = {}
            try:
                mat_assign = parser.find_material_assignments(all_pids)
                if mat_assign:
                    for mname, cnt in sorted(Counter(mat_assign.values()).items()):
                        # El nombre del material del modelo contra los de
                        # la tabla del cuadro de control. El aviso importa:
                        # un material del .anl que no esta capturado deja
                        # sus muros con el primer material de la lista.
                        mat_tbl = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mname.strip().upper()),
                            None,
                        )
                        flag = "✓" if mat_tbl else "?"
                        tag  = "ok"  if mat_tbl else "warn"
                        self._log(
                            f"    {flag} MATERIAL {mname:<14}  {cnt:>4} placas  "
                            + (f"→ tabla: {mat_tbl.name}" if mat_tbl else
                               "→ NO capturado en la tabla de materiales"),
                            tag,
                        )
                else:
                    self._log(
                        "  [AVISO] Sin asignaciones CONSTANTS. "
                        "Usando correlación por módulo E.", "warn")
            except Exception as exc:
                self._log(f"  [AVISO] Material no disponible: {exc}", "warn")

            # 6. Combinaciones ──────────────────────────────────────────────
            design_combos  = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            service_combos = list(range(
                inputs.first_service_combo, inputs.last_service_combo + 1))
            pp_combo   = inputs.pp_cm_cvacc_combo
            all_combos = sorted(set(design_combos + service_combos + [pp_combo]))

            walls_out    : List[WallData]            = []
            results_all  : Dict[str, Dict[str, list]] = {}
            diagrams_all : Dict[str, Dict[str, list]] = {}
            total_walls  = max(len(inputs.wall_plate_ids), 1)

            # 7. Procesar cada muro ─────────────────────────────────────────
            for wi, (wall_name, plate_ids) in enumerate(
                    inputs.wall_plate_ids.items()):

                self.sig_progress.emit(
                    int(wi / total_walls * 90),
                    f"Muro {wall_name}  ({wi+1}/{total_walls})",
                )
                self._log(
                    f"\n{'='*55}\nMuro: {wall_name}  ({len(plate_ids)} placas)",
                    "sec")

                if not plate_ids:
                    self._log("  Sin placas asignadas. Saltando.", "warn")
                    continue

                # Espesor
                # 0.15 m es el respaldo de último recurso: con el Excel
                # este dato venía declarado por muro, y ahora sale del
                # ELEMENT PROPERTY del .anl. Si el modelo no lo trae, el
                # log lo dice en vez de callarlo.
                thickness_dato = inputs.wall_thickness.get(wall_name, 0.15)
                if element_prop:
                    wt = [
                        element_prop[pid]["thick"]
                        for pid in plate_ids
                        if pid in element_prop
                        and element_prop[pid]["thick"] > 0
                    ]
                    if wt:
                        thickness = sum(wt) / len(wt)
                        self._log(
                            f"  Espesor (ELEMENT PROPERTY): {thickness:.4f} m  "
                            f"(respaldo: {thickness_dato:.4f} m)", "dim")
                    else:
                        thickness = thickness_dato
                        self._log(
                            f"  Espesor (respaldo): {thickness:.4f} m", "warn")
                else:
                    thickness = thickness_dato
                    self._log(
                        f"  Espesor (respaldo, sin ELEMENT PROPERTY): "
                        f"{thickness:.4f} m", "warn")

                # Material
                mat = None
                if mat_assign and inputs.materials:
                    wm = [mat_assign[pid] for pid in plate_ids
                          if pid in mat_assign]
                    if wm:
                        mc = Counter(wm).most_common(1)[0][0]
                        mat = next(
                            (m for m in inputs.materials
                             if m.name.strip().upper() == mc.strip().upper()),
                            None,
                        )
                        if mat:
                            self._log(
                                f"  Material (CONSTANTS): {mat.name} ✓", "dim")
                        else:
                            self._log(
                                f"  [AVISO] Material STAAD '{mc}' "
                                "no está en la tabla de materiales.",
                                "warn")

                if mat is None:
                    mat_name = inputs.wall_material.get(wall_name, "")
                    mat = next(
                        (m for m in inputs.materials
                         if m.name == mat_name), None)
                    if mat:
                        self._log(
                            f"  Material (por nombre): {mat.name}", "dim")
                    elif inputs.materials:
                        mat = inputs.materials[0]
                        self._log(
                            f"  [AVISO] Usando primer material: {mat.name}", "warn")

                if mat is None:
                    self._log(
                        f"  [ERROR] Sin material para {wall_name}. Saltando.", "err")
                    continue

                position = inputs.wall_positions.get(wall_name, 1)

                # PlateData
                combined: dict = {
                    pid: {'thick': element_prop[pid]['thick']}
                    for pid in plate_ids
                    if pid in element_prop
                } if element_prop else {}

                self._log("  Extrayendo geometría y esfuerzos...", "dim")
                plates = build_plate_data(
                    parser, plate_ids, all_combos, thickness,
                    combined or None,
                    material_assignments=mat_assign,
                )
                if not plates:
                    self._log("  [ERROR] No se obtuvieron placas.", "err")
                    continue

                direction = determine_direction(plates)
                self._log(
                    f"  {len(plates)} placas procesadas.  "
                    f"Dirección: {direction}  "
                    f"t_prom: {thickness:.4f} m", "dim")

                # RelTan
                sdx = sum(p.x_max - p.x_min for p in plates)
                sdz = sum(p.z_max - p.z_min for p in plates)
                den = math.sqrt(sdx**2 + sdz**2)
                if den > 1e-9:
                    rt1, rt2 = sdx / den, sdz / den
                else:
                    rt1 = 1.0 if direction == "X" else 0.0
                    rt2 = 1.0 if direction == "Z" else 0.0
                reltan = {"reltan1": rt1, "reltan2": rt2}
                inputs.wall_reltan[wall_name] = reltan
                self._log(
                    f"  reltan: {rt1:.4f} (Dir X) / {rt2:.4f} (Dir Z)", "dim")

                # Niveles
                Ht = inputs.floor_levels[0] - inputs.floor_levels[-1]
                levels = build_wall_levels(
                    plates=plates,
                    floor_levels=inputs.floor_levels,
                    direction=direction,
                    thickness=thickness,
                    all_design_combos=design_combos,
                    pp_combo=pp_combo,
                    story_shears=inputs.story_shears,
                    wall_name=wall_name,
                    reltan=reltan,
                    materials=inputs.materials,
                    service_combos=service_combos,
                    slab_thickness=getattr(inputs, "slab_thickness", None),
                )
                self._log(f"  {len(levels)} niveles construidos.", "dim")

                # L' del cuadro de control [m]. Cero = el motor usa su
                # hipótesis por omisión, `lp_por_omision(Lm)`.
                lp_muro = float(
                    getattr(inputs, "wall_lp", {}).get(wall_name, 0.0) or 0.0)
                wall = WallData(
                    name=wall_name, position=position,
                    plate_ids=plate_ids, direction=direction,
                    levels=levels, material=mat, Ht=Ht, thickness=thickness,
                    Lp=lp_muro,
                )
                if lp_muro > 1e-9:
                    self._log(
                        f"  L' no arriostrada (capturada): {lp_muro:.2f} m",
                        "dim")
                walls_out.append(wall)

                # Diseñar niveles
                results_w: dict  = {}
                diagrams_w: dict = {}

                for lv in levels:
                    lv_mat   = lv.material if lv.material is not None else mat
                    mat_src  = "nivel" if lv.material is not None else "muro↓"
                    tipo_str = "Mamp." if lv_mat.tipo_material == 1 else "Conc."
                    E_lv     = [p.modulo_E for p in lv.plates if p.modulo_E > 0]
                    E_prom   = sum(E_lv) / len(E_lv) if E_lv else 0.0
                    e_tag    = "ok" if lv.material is not None else "warn"
                    self._log(
                        f"  Nivel {lv.nivel_name}: "
                        f"Lm={lv.lm:.2f}m  t={lv.thickness:.4f}m  "
                        f"Hi={lv.hi:.2f}m  E_prom={E_prom:,.0f}  "
                        f"Mat={lv_mat.name} [{tipo_str}] ({mat_src})",
                        e_tag)

                    if lv_mat.tipo_material == 1:
                        res_list = design_masonry_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, Q_duct=inputs.Q_duct,
                            position=position, service_combos=service_combos,
                            # Sin esto la llamada del worker —la que de
                            # verdad se usa— nunca pasaba L', y la
                            # hipótesis `min(Lm, 3.50)` se aplicaba
                            # SIEMPRE, incluso con el dato capturado.
                            Lp=wall.Lp,
                        )
                        diag_pts = (
                            interaction_diagram_masonry(
                                fm=lv_mat.fm, fc=lv_mat.fc_castillos,
                                fy=lv_mat.fy_vert, Lm=lv.lm, t=lv.thickness,
                                # Sin piso artificial: el acero minimo
                                # normativo (AsminCast, 6.2.1.1) ya va dentro
                                # de r.Asc1. El default solo cubre la lista
                                # vacia.
                                As_castillo=max(
                                    (r.Asc1 for r in res_list), default=4.0),
                                n_castillos=2,
                                # F-1: la cabeza del diagrama es P_R de
                                # 6.4.1.1 y lleva F_E; el que uso el motor.
                                Fe=(res_list[0].Fe if res_list else 1.0),
                                # el mismo P_R del motor: si no, la rama alta
                                # de la curva queda por encima del diseno
                                PR_ton=(res_list[0].Pr if res_list else 0.0),
                            ) if res_list else []
                        )
                    else:
                        res_list = design_concrete_level(
                            level=lv, material=lv_mat,
                            design_combos=design_combos,
                            pp_combo=pp_combo, position=position, Ht=wall.Ht,
                            hcr_ctx=contexto_hcr(wall, design_combos),
                            n_niveles=len(wall.levels),
                        )
                        if res_list:
                            asext_max = max((r.AsExt1 for r in res_list), default=4.0)
                            asv_max   = max((r.Asv   for r in res_list), default=0.0)
                            secc_tc   = res_list[0].SeccTC if res_list else 0.15 * lv.lm
                            diag_pts  = interaction_diagram_concrete(
                                fc=lv_mat.fc, fy=lv_mat.fy_vert,
                                Lm=lv.lm, t=lv.thickness, SeccTC=secc_tc,
                                AsExt=asext_max,   # sin piso artificial
                                Asv_total=max(asv_max * lv.lm, 0.0),
                            )
                        else:
                            diag_pts = []

                    n_ok = sum(
                        1 for r in res_list
                        if getattr(r, "cond_axial", "") in ("Si Pasa", "Tension")
                        and getattr(r, "cond_cortante", "") == "Si Pasa"
                        and _flexion_ok(r)          # punto 6: tambien cuenta
                    )
                    self._log(
                        f"    {len(res_list)} combos  |  {n_ok} OK",
                        "ok" if (n_ok == len(res_list) and res_list) else "warn")

                    results_w[lv.nivel_name]  = res_list
                    diagrams_w[lv.nivel_name] = diag_pts

                results_all[wall_name]  = results_w
                diagrams_all[wall_name] = diagrams_w

            self.sig_progress.emit(100, "Completado")
            self.sig_done.emit({
                "walls":    walls_out,
                "results":  results_all,
                "diagrams": diagrams_all,
                "inputs":   inputs,
            })

        except Exception:
            self.sig_error.emit(traceback.format_exc())


# ── Ventana principal ─────────────────────────────────────────────────────────

def clave_natural(nombre: str) -> list:
    """Clave de orden para nombres con números dentro.

    Los grupos del .anl son texto, y el orden alfabético los deja en
    1, 10, 11, 12, 2, 20…, que para muros numerados M1..M40 es ilegible.
    Se parte el nombre en tramos de dígitos y de letras, y los dígitos se
    comparan como NÚMEROS.

    Cada tramo va etiquetado con 0 o 1 antes de compararse: en Python un
    `int` y un `str` no se comparan entre sí, y sin la etiqueta «M1»
    contra «10» reventaría con un `TypeError` en vez de ordenar.
    """
    return [(0, int(t), "") if t.isdigit() else (1, 0, t.lower())
            for t in re.split(r"(\d+)", nombre) if t]


def _texto_asv(r, ancho: int) -> str:
    """`texto_asv` del motor, con respaldo si el motor es anterior a B-5."""
    try:
        from wall_design_ntc2023 import texto_asv
        return texto_asv(r, ancho)
    except ImportError:
        return f"{r.Asv:>{ancho}.2f}"


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._walls:    list = []
        self._results:  dict = {}
        self._diagrams: dict = {}
        self._inputs         = None
        self._shear_data     = {}
        self._plot_paths     = {}
        self._worker: Optional[DesignWorker] = None
        self._plot_canvas: Optional[FigureCanvas]  = None
        self._plot_toolbar: Optional[NavToolbar]   = None

        # Grupos leídos del .anl. `_all_groups` es lo que alimenta la lista
        # de disponibles; `_anl_groups` guarda sus placas para pasárselas al
        # worker sin volver a abrir el archivo.
        self._all_groups: list = []
        self._anl_groups: dict = {}
        self._staad_connected  = False

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1360, 820)
        self.setStyleSheet(MAIN_STYLE)
        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────



        # ── Corrección de recortes de la UI (ancho de panel y botón fijo) ──
        try:
            from suite_shared.layout_fix import corregir_recortes
            corregir_recortes(self)
        except Exception:
            pass

        # ── Guardar / Abrir proyecto (gestor común de la suite) ──────────
        try:
            from suite_shared.project_io import instalar_gestor_proyecto
            instalar_gestor_proyecto(self, "wall_design_pro_anl")
        except Exception:
            pass
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_right_tabs())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        # El cuadro de control ya no son dos cajas y un log, sino las
        # tablas de niveles, materiales y cortantes; pero con los topes de
        # ancho del bloque de grupos le bastan 380 px y el resto se va a
        # los resultados. Mismo reparto que el arbol `_mejorados`.
        splitter.setSizes([380, 1050])
        root.addWidget(splitter, 1)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(5)
        root.addWidget(self.progress)

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.lbl_badge = QLabel("  NTC 2023  ")
        self.lbl_badge.setStyleSheet(
            "background:#2874A6; color:white; padding:0 8px; border-radius:3px;")
        self.status.addPermanentWidget(self.lbl_badge)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    def _build_header(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(HEADER_STYLE)
        frame.setFixedHeight(60)
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)

        lbl_title = QLabel(f"  {APP_NAME}")
        lbl_title.setStyleSheet(
            "color:white; font-size:15pt; font-weight:bold;")
        lay.addWidget(lbl_title)

        lbl_sub = QLabel(APP_SUBTITLE)
        lbl_sub.setStyleSheet("color:#AED6F1; font-size:9pt;")
        lay.addWidget(lbl_sub)

        lay.addStretch()

        lbl_ver = QLabel(f"v{APP_VERSION}")
        lbl_ver.setStyleSheet("color:#AED6F1; font-size:8pt;")
        lay.addWidget(lbl_ver)
        return frame

    # ── Medidas del cuadro de control ────────────────────────────────────
    #
    # Salen de MEDIR la ventana montada, no del `fontMetrics`: el renglon
    # lo estira el estilo de la suite, no la fuente. Vienen del arbol
    # `_mejorados`, donde ya se habian calibrado.

    #: Ancho minimo del area de configuracion, px. Con 500 el cuadro se
    #: comia un tercio de la ventana; los 110 px que suelta se los queda
    #: la zona de resultados.
    ANCHO_CUADRO = 390

    #: Topes del bloque de grupos de placas, px. `suite_shared.layout_fix`
    #: dimensiona el cuadro por el sizeHint de su contenido, y una lista
    #: sin tope pide los 256 px de fabrica: este bloque era el UNICO que
    #: pasaba de 400 px y por el el panel entero medi­a 600.
    ANCHO_LISTA_GRUPOS = 140
    #: La tabla de seleccion lleva CUATRO columnas —grupo, Int., Ext. y
    #: L' no arriostrada—, de ahi que sean 270 y no los 210 del arbol
    #: mejorado, que tiene tres.
    #: 400 y no 270: con la columna de L' mostrando su titulo completo
    #: (135 px) el tope anterior recortaba «Grupo / Muro», que pide 157.
    #: 36 + 36 + 135 + 157 + barra = 400. El bloque de
    #: grupos sigue muy por debajo de la caja «Materiales», que es la que
    #: manda el ancho del cuadro de control.
    ANCHO_TABLA_GRUPOS = 400

    #: Renglones de grupo que se ven sin desplazar. Con cuatro, elegir
    #: treinta muros era una tirada de barra por muro.
    FILAS_GRUPOS = 8
    #: Alto de renglon en px, medido en la ventana montada: 16 px de
    #: letra y 30 de fila.
    ALTO_FILA_GRUPOS = 30
    #: Alto de la cabecera de la tabla, px. Va como constante y no leido
    #: del `horizontalHeader()`: al construir todavia dice 15 y solo
    #: llega a 34 cuando la ventana ya se mostro, asi que preguntarselo
    #: ahi dejaba SIETE renglones a la vista.
    ALTO_CABECERA_GRUPOS = 34

    #: Ancho de los spin de combinaciones, px. Con 70 se recortaban los
    #: numeros de tres cifras: este modelo llega al combo 332.
    ANCHO_SPIN = 95

    def _build_left_panel(self) -> QWidget:
        """Cuadro de control: toda la configuración, los grupos y las acciones.

        Las cajas son las de `wall_design_pro`. Antes aquí solo había la
        ruta del Excel, la del .anl y los botones: los parámetros del
        proyecto —combinaciones, Q, niveles, materiales y cortantes—
        vivían en la plantilla, y para cambiar un f'm había que abrir
        Excel, guardar y volver a calcular.

        El área de configuración va con SCROLL y el log DEBAJO, fuera de
        ella: un log dentro del scroll se va hacia abajo conforme crece y
        hay que perseguirlo con la barra justo mientras el cálculo
        escribe. Es el sitio que el log tiene en este módulo y no se
        mueve.
        """
        contenedor = QWidget()
        cont_lay = QVBoxLayout(contenedor)
        cont_lay.setContentsMargins(0, 0, 0, 0)
        cont_lay.setSpacing(4)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setMinimumWidth(self.ANCHO_CUADRO)

        panel = QWidget()
        panel.setFont(QFont("Segoe UI", 8))
        vlay = QVBoxLayout(panel)
        vlay.setContentsMargins(8, 8, 8, 8)
        vlay.setSpacing(6)

        # ── Archivo de resultados .anl ────────────────────────────────────
        grp_staad = QGroupBox("Archivo de resultados (.anl)")
        slay = QVBoxLayout(grp_staad)
        slay.setSpacing(4)

        self._ver_pref = "anl"
        self.edit_anl = QLineEdit()
        self.edit_anl.setPlaceholderText(
            "Ruta del archivo .anl generado por el análisis de STAAD")
        slay.addWidget(self.edit_anl)

        row_btn = QHBoxLayout()
        btn_examinar = QPushButton("Examinar…")
        btn_examinar.clicked.connect(self._browse_anl)
        row_btn.addWidget(btn_examinar)

        self.btn_connect = QPushButton("Leer grupos del .anl")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.setToolTip(
            "Lee la sección GROUP DEFINITION del archivo. No hace falta\n"
            "tener STAAD abierto ni ejecutar como administrador: el .anl\n"
            "ya trae la geometría y los esfuerzos.")
        self.btn_connect.clicked.connect(self._on_staad_connect)
        row_btn.addWidget(self.btn_connect)

        self.lbl_conn_st = QLabel("● Sin archivo")
        self.lbl_conn_st.setStyleSheet("color:#C0392B; font-weight:bold;")
        row_btn.addWidget(self.lbl_conn_st)
        row_btn.addStretch()
        slay.addLayout(row_btn)

        self.lbl_conn_info = QLabel("")
        self.lbl_conn_info.setStyleSheet("color:#607D8B; font-size:7pt;")
        slay.addWidget(self.lbl_conn_info)
        vlay.addWidget(grp_staad)

        # ── Cargas ────────────────────────────────────────────────────────
        grp_loads = QGroupBox("Cargas")
        gload = QGridLayout(grp_loads)
        gload.setSpacing(4)
        gload.setColumnMinimumWidth(1, self.ANCHO_SPIN)
        gload.setColumnMinimumWidth(3, self.ANCHO_SPIN)

        def _spn(mn=1, mx=999, val=1):
            sp = QSpinBox()
            sp.setRange(mn, mx)
            sp.setValue(val)
            sp.setFixedWidth(self.ANCHO_SPIN)
            return sp

        gload.addWidget(QLabel("PP+CM+CVacc (CL):"), 0, 0)
        self.spn_pp_combo = _spn(1, 999, 1)
        self.spn_pp_combo.setToolTip(
            "Número de caso de carga permanente PP+CM+CVacc")
        gload.addWidget(self.spn_pp_combo, 0, 1)

        gload.addWidget(QLabel("Comb. Servicio:"), 1, 0)
        self.spn_svc_start = _spn(1, 999, 2)
        self.spn_svc_start.setToolTip("Inicio combinaciones de servicio")
        gload.addWidget(self.spn_svc_start, 1, 1)
        gload.addWidget(QLabel("hasta:"), 1, 2)
        self.spn_svc_end = _spn(1, 999, 5)
        self.spn_svc_end.setToolTip("Fin combinaciones de servicio")
        gload.addWidget(self.spn_svc_end, 1, 3)

        gload.addWidget(QLabel("Comb. Diseño:"), 2, 0)
        self.spn_des_start = _spn(1, 999, 6)
        self.spn_des_start.setToolTip("Inicio combinaciones de diseño")
        gload.addWidget(self.spn_des_start, 2, 1)
        gload.addWidget(QLabel("hasta:"), 2, 2)
        self.spn_des_end = _spn(1, 999, 20)
        self.spn_des_end.setToolTip("Fin combinaciones de diseño")
        gload.addWidget(self.spn_des_end, 2, 3)

        vlay.addWidget(grp_loads)

        # ── Ductilidad ────────────────────────────────────────────────────
        grp_duct = QGroupBox("Ductilidad")
        dl = QHBoxLayout(grp_duct)
        dl.setSpacing(6)
        dl.addWidget(QLabel("Factor Q:"))
        self.spn_ductility = QDoubleSpinBox()
        self.spn_ductility.setRange(1.0, 4.0)
        self.spn_ductility.setSingleStep(0.5)
        self.spn_ductility.setValue(2.0)
        self.spn_ductility.setFixedWidth(self.ANCHO_SPIN)
        self.spn_ductility.setDecimals(1)
        dl.addWidget(self.spn_ductility)
        lbl_q = QLabel("  1.5 = Media ductilidad  ·  2.0 = Alta ductilidad")
        lbl_q.setStyleSheet("color:#607D8B; font-size:7pt;")
        dl.addWidget(lbl_q)
        dl.addStretch()
        vlay.addWidget(grp_duct)

        # ── Niveles ───────────────────────────────────────────────────────
        grp_niv = QGroupBox("Niveles")
        nl = QVBoxLayout(grp_niv)
        nl.setSpacing(4)

        lbl_note = QLabel(
            "Elevación (m) desde el nivel de desplante (cota 0.00 = desplante).\n"
            "Incluir todas las losas: base, intermedias y azotea.\n"
            "e losa = peralte promedio de la losa de ESE nivel; se resta de "
            "la altura del entrepiso que cubre para obtener la altura LIBRE. "
            "0 = no restar nada (conservador).")
        lbl_note.setStyleSheet(
            "color:#607D8B; font-size:7pt; font-style:italic;")
        lbl_note.setWordWrap(True)
        nl.addWidget(lbl_note)

        lbl_note_desc = QLabel(
            "⚠  NOTA: Ingrese los niveles en orden DESCENDENTE de elevación\n"
            "   (azotea → pisos intermedios → desplante).\n"
            "   La fila superior = nivel más alto (mayor elevación).")
        lbl_note_desc.setStyleSheet(
            "color:#E67E22; font-size:7pt; font-weight:bold; "
            "background:#1A1A00; border:1px solid #E67E22; padding:4px; "
            "border-radius:3px;")
        lbl_note_desc.setWordWrap(True)
        nl.addWidget(lbl_note_desc)

        row_btn_n = QHBoxLayout()
        btn_add_n = QPushButton("＋ Nivel")
        btn_add_n.clicked.connect(self._add_nivel_row)
        btn_del_n = QPushButton("－ Eliminar")
        btn_del_n.clicked.connect(lambda: self._del_tbl_row(self.tbl_niveles))
        row_btn_n.addWidget(btn_add_n)
        row_btn_n.addWidget(btn_del_n)
        row_btn_n.addStretch()
        nl.addLayout(row_btn_n)

        # TRES columnas: la de «e losa» se añadió sin ensanchar el cuadro de
        # control. La del nombre es la que se estira, así que los 60 px que
        # ocupan las dos fijas nuevas los suelta ella.
        self.tbl_niveles = QTableWidget(0, 3)
        self.tbl_niveles.setFont(QFont("Consolas", 7))
        self.tbl_niveles.setHorizontalHeaderLabels(
            ["Nombre del Nivel", "Elevación (m)", "e losa (m)"])
        self.tbl_niveles.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        for _c in (self.COL_NIV["elev"], self.COL_NIV["e_losa"]):
            self.tbl_niveles.horizontalHeader().setSectionResizeMode(
                _c, QHeaderView.Fixed)
        self.tbl_niveles.setColumnWidth(
            self.COL_NIV["elev"], self.ANCHO_COL_ELEV)
        self.tbl_niveles.setColumnWidth(
            self.COL_NIV["e_losa"], self.ANCHO_COL_ELOSA)
        self.tbl_niveles.setMaximumHeight(180)
        nl.addWidget(self.tbl_niveles)
        vlay.addWidget(grp_niv)

        # ── Materiales ────────────────────────────────────────────────────
        grp_mat = QGroupBox("Materiales")
        ml = QVBoxLayout(grp_mat)
        ml.setSpacing(4)

        row_type = QHBoxLayout()
        row_type.addWidget(QLabel("Tipo(s) de material:"))
        self.chk_mamp = QCheckBox("Mampostería")
        self.chk_mamp.setChecked(True)
        self.chk_conc = QCheckBox("Concreto")
        self.chk_mamp.toggled.connect(self._toggle_material_tables)
        self.chk_conc.toggled.connect(self._toggle_material_tables)
        row_type.addWidget(self.chk_mamp)
        row_type.addWidget(self.chk_conc)
        row_type.addStretch()
        ml.addLayout(row_type)

        # Sub-tabla Mampostería
        self.grp_mamp_tbl = QGroupBox("Mampostería")
        mamp_l = QVBoxLayout(self.grp_mamp_tbl)
        mamp_l.setSpacing(3)

        hint_mamp = QLabel(
            "Nombre Material Staad debe coincidir exactamente con "
            "CONSTANTS MATERIAL en STAAD Pro.\n"
            "Esta variante diseña mampostería CONFINADA (NTC DEM Cap. 6). "
            "La ruta de mampostería reforzada interiormente (Cap. 7) solo "
            "está en la variante de STAAD Pro 2025.")
        hint_mamp.setStyleSheet("color:#607D8B; font-size:7pt;")
        hint_mamp.setWordWrap(True)
        mamp_l.addWidget(hint_mamp)

        row_btn_m = QHBoxLayout()
        btn_add_m = QPushButton("＋ Material")
        btn_add_m.clicked.connect(self._add_mamp_row)
        btn_del_m = QPushButton("－ Eliminar")
        btn_del_m.clicked.connect(lambda: self._del_tbl_row(self.tbl_mamp))
        row_btn_m.addWidget(btn_add_m)
        row_btn_m.addWidget(btn_del_m)
        row_btn_m.addStretch()
        mamp_l.addLayout(row_btn_m)

        # LAS COLUMNAS SON LAS QUE EL MOTOR DE ESTA VARIANTE LEE, y por eso
        # son ocho y no las doce de `wall_design_pro`. Faltan a propósito
        # «Tipo Muro», «Descripción», «Tipo Pieza» y «h pieza»: este módulo
        # no declara `tipo_muro`, `descripcion` ni `h_pieza` en
        # `MaterialProps`, y `tipo_pieza` lo declara pero no lo lee nadie
        # en `calc/`. Ponerlas daría cuatro controles que el usuario llena
        # y el cálculo ignora; el grave sería «Tipo Muro», donde elegir
        # Cap. 7 daría un diseño de Cap. 6 sin decirlo.
        #
        # Si algún día se porta la ruta del Cap. 7 y la propuesta de
        # varillín, estas columnas vuelven — junto con los campos del
        # modelo, no antes.
        _mamp_hdrs = [
            "Nombre\nStaad",
            "v'm\n(kg/cm²)", "f'm\n(kg/cm²)",
            "f_an\n(f_nm)", "Pes.Vol\n(t/m³)", "f'c Cast\n(kg/cm²)",
            "fyCast\n(kg/cm²)", "fyhor\n(kg/cm²)",
        ]
        self.tbl_mamp = QTableWidget(0, len(_mamp_hdrs))
        self.tbl_mamp.setFont(QFont("Consolas", 7))
        self.tbl_mamp.setHorizontalHeaderLabels(_mamp_hdrs)
        for i in range(len(_mamp_hdrs)):
            self.tbl_mamp.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.Interactive)
        self.tbl_mamp.horizontalHeader().setMinimumSectionSize(60)
        self.tbl_mamp.setMinimumHeight(100)
        self.tbl_mamp.setMaximumHeight(200)
        mamp_l.addWidget(self.tbl_mamp)
        ml.addWidget(self.grp_mamp_tbl)

        # Sub-tabla Concreto
        self.grp_conc_tbl = QGroupBox("Concreto")
        conc_l = QVBoxLayout(self.grp_conc_tbl)
        conc_l.setSpacing(3)

        row_btn_c = QHBoxLayout()
        btn_add_c = QPushButton("＋ Material")
        btn_add_c.clicked.connect(self._add_conc_row)
        btn_del_c = QPushButton("－ Eliminar")
        btn_del_c.clicked.connect(lambda: self._del_tbl_row(self.tbl_conc))
        row_btn_c.addWidget(btn_add_c)
        row_btn_c.addWidget(btn_del_c)
        row_btn_c.addStretch()
        conc_l.addLayout(row_btn_c)

        _conc_hdrs = [
            "Nombre\nStaad", "f'c\n(kg/cm²)",
            "fy Vert.\n(kg/cm²)", "fy Hor.\n(kg/cm²)", "Pes.Vol\n(t/m³)",
        ]
        self.tbl_conc = QTableWidget(0, len(_conc_hdrs))
        self.tbl_conc.setFont(QFont("Consolas", 7))
        self.tbl_conc.setHorizontalHeaderLabels(_conc_hdrs)
        for i in range(len(_conc_hdrs)):
            self.tbl_conc.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.Stretch)
        self.tbl_conc.setMinimumHeight(90)
        self.tbl_conc.setMaximumHeight(160)
        conc_l.addWidget(self.tbl_conc)
        ml.addWidget(self.grp_conc_tbl)
        self.grp_conc_tbl.setVisible(False)

        vlay.addWidget(grp_mat)

        # ── Cortantes de Entrepiso ────────────────────────────────────────
        grp_cort = QGroupBox("Cortantes de Entrepiso  (ΣVr ≥ 0.8·Vu)")
        cort_l = QVBoxLayout(grp_cort)
        cort_l.setSpacing(4)

        hint_cort = QLabel(
            "Cortante de diseño por entrepiso para cada dirección. "
            "El nombre del nivel debe coincidir con el generado por la "
            "geometría.")
        hint_cort.setStyleSheet("color:#607D8B; font-size:7pt;")
        hint_cort.setWordWrap(True)
        cort_l.addWidget(hint_cort)

        row_btn_crt = QHBoxLayout()
        btn_add_crt = QPushButton("＋ Entrepiso")
        btn_add_crt.clicked.connect(self._add_cortante_row)
        btn_del_crt = QPushButton("－ Eliminar")
        btn_del_crt.clicked.connect(
            lambda: self._del_tbl_row(self.tbl_cortantes))
        row_btn_crt.addWidget(btn_add_crt)
        row_btn_crt.addWidget(btn_del_crt)
        row_btn_crt.addStretch()
        cort_l.addLayout(row_btn_crt)

        self.tbl_cortantes = QTableWidget(0, 3)
        self.tbl_cortantes.setFont(QFont("Consolas", 7))
        self.tbl_cortantes.setHorizontalHeaderLabels(
            ["Nombre Entrepiso", "Vx (ton)", "Vz (ton)"])
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Fixed)
        self.tbl_cortantes.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.Fixed)
        self.tbl_cortantes.setColumnWidth(1, self.ANCHO_COL_CORTANTE)
        self.tbl_cortantes.setColumnWidth(2, self.ANCHO_COL_CORTANTE)
        self.tbl_cortantes.setMaximumHeight(160)
        cort_l.addWidget(self.tbl_cortantes)
        vlay.addWidget(grp_cort)

        # ── Selección de Grupos de Placas ─────────────────────────────────
        grp_groups = QGroupBox(
            "Grupos de Placas  [PLC] — Seleccionar para diseño")
        ggrp = QVBoxLayout(grp_groups)
        ggrp.setSpacing(4)

        row_flt = QHBoxLayout()
        row_flt.addWidget(QLabel("Filtrar:"))
        self.edit_grp_filter = QLineEdit()
        self.edit_grp_filter.setPlaceholderText("nombre...")
        self.edit_grp_filter.textChanged.connect(self._on_group_filter)
        row_flt.addWidget(self.edit_grp_filter, 1)
        btn_clr = QPushButton("✕")
        btn_clr.setFixedWidth(26)
        btn_clr.clicked.connect(lambda: self.edit_grp_filter.clear())
        row_flt.addWidget(btn_clr)
        self.chk_only_plates = QCheckBox("Solo [PLC]")
        self.chk_only_plates.setChecked(True)
        self.chk_only_plates.toggled.connect(self._refresh_group_list)
        row_flt.addWidget(self.chk_only_plates)
        ggrp.addLayout(row_flt)

        lists_lay = QHBoxLayout()
        lists_lay.setSpacing(4)

        left_col = QVBoxLayout()
        left_col.addWidget(QLabel("Disponibles:"))
        self.lst_avail = QListWidget()
        self.lst_avail.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_avail.setFont(QFont("Consolas", 7))
        self.lst_avail.setFixedHeight(
            self.FILAS_GRUPOS * self.ALTO_FILA_GRUPOS + 6)
        self.lst_avail.setMaximumWidth(self.ANCHO_LISTA_GRUPOS)
        self.lst_avail.doubleClicked.connect(self._on_grp_add)
        left_col.addWidget(self.lst_avail)
        lists_lay.addLayout(left_col, 1)

        mid_col = QVBoxLayout()
        mid_col.addStretch()
        for txt, slot, tip in [
            ("▶",  self._on_grp_add,    "Agregar seleccionados"),
            ("◀",  self._on_grp_remove, "Quitar seleccionados"),
        ]:
            b = QPushButton(txt); b.setFixedWidth(32); b.setToolTip(tip)
            b.clicked.connect(slot); mid_col.addWidget(b)
        mid_col.addSpacing(6)
        for txt, slot, tip in [
            ("▶▶", self._on_grp_add_all,    "Agregar todos"),
            ("◀◀", self._on_grp_remove_all, "Quitar todos"),
        ]:
            b = QPushButton(txt); b.setFixedWidth(32); b.setToolTip(tip)
            b.clicked.connect(slot); mid_col.addWidget(b)
        mid_col.addStretch()
        lists_lay.addLayout(mid_col)

        right_col = QVBoxLayout()
        lbl_sel = QLabel(
            "Para diseño  [doble-clic = quitar]  "
            "  <b>Int</b> = Interior  <b>Ext</b> = Exterior<br>"
            "<b>L' no arr.</b> = longitud NO arriostrada, m (0 = la del muro)")
        lbl_sel.setStyleSheet("font-size:7pt; color:#607D8B;")
        # En una sola linea esta leyenda pedia 240 px de ancho ELLA sola,
        # y el panel entero se dimensionaba para que cupiera.
        lbl_sel.setWordWrap(True)
        right_col.addWidget(lbl_sel)
        # CUATRO columnas: la de L' la pidió el titular para no depender
        # de la hipótesis `min(Lm, 3.50)`. Ver `COL_SEL` y `_build_user_inputs_from_ui`.
        self.tbl_sel = QTableWidget(0, 4)
        self.tbl_sel.setHorizontalHeaderLabels(
            ["Grupo / Muro", "Int.", "Ext.", "L' no arr.\n(m)"])
        self.tbl_sel.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        self.tbl_sel.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Fixed)
        self.tbl_sel.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.Fixed)
        self.tbl_sel.horizontalHeader().setSectionResizeMode(
            self.COL_SEL["lp"], QHeaderView.Fixed)
        self.tbl_sel.setColumnWidth(1, 36)
        self.tbl_sel.setColumnWidth(2, 36)
        self.tbl_sel.setColumnWidth(self.COL_SEL["lp"], self.ANCHO_COL_LP)
        self.tbl_sel.setFont(QFont("Consolas", 7))
        # La cabecera no es un renglon de dato: sin sumarla se verian
        # siete.
        self.tbl_sel.setFixedHeight(
            self.FILAS_GRUPOS * self.ALTO_FILA_GRUPOS
            + self.ALTO_CABECERA_GRUPOS + 6)
        self.tbl_sel.setMaximumWidth(self.ANCHO_TABLA_GRUPOS)
        self.tbl_sel.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_sel.doubleClicked.connect(self._on_grp_remove)
        right_col.addWidget(self.tbl_sel)
        lists_lay.addLayout(right_col, 2)

        ggrp.addLayout(lists_lay)
        vlay.addWidget(grp_groups)

        # ── Acciones ──────────────────────────────────────────────────────
        grp_actions = QGroupBox("Acciones")
        alay = QGridLayout(grp_actions)
        alay.setSpacing(5)

        self.btn_run = QPushButton("▶   Calcular")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.clicked.connect(self._start_calculation)
        alay.addWidget(self.btn_run, 0, 0, 1, 2)

        btn_word = QPushButton("Resultados + Gráficas  (Word)")
        btn_word.setObjectName("btn_word")
        btn_word.clicked.connect(self._export_word)
        alay.addWidget(btn_word, 1, 0)

        btn_mem = QPushButton("Memoria de Cálculo  (Word)")
        btn_mem.setObjectName("btn_memory")
        btn_mem.clicked.connect(self._export_calc_memory)
        alay.addWidget(btn_mem, 1, 1)

        btn_plots = QPushButton("Guardar Gráficas  (PNG)")
        btn_plots.setObjectName("btn_plots")
        btn_plots.clicked.connect(self._save_plots)
        alay.addWidget(btn_plots, 2, 0)

        btn_clear = QPushButton("Limpiar")
        btn_clear.setObjectName("btn_clear")
        btn_clear.clicked.connect(self._clear_all)
        alay.addWidget(btn_clear, 2, 1)

        vlay.addWidget(grp_actions)
        vlay.addStretch()

        scroll.setWidget(panel)
        cont_lay.addWidget(scroll, 1)

        # ── Log de cálculo, FUERA del scroll ──────────────────────────────
        grp_log = QGroupBox("Log de cálculo")
        llay = QVBoxLayout(grp_log)
        llay.setContentsMargins(4, 4, 4, 4)
        self.log_widget = ColoredLog(wrap=True)
        llay.addWidget(self.log_widget)
        grp_log.setMinimumHeight(150)
        cont_lay.addWidget(grp_log)

        return contenedor

    def _build_right_tabs(self) -> QTabWidget:
        self.tabs = QTabWidget()

        # Tab: Resultados
        self.tab_results = QWidget()
        self.tabs.addTab(self.tab_results, "  Resultados  ")
        self._init_tab_results()

        # Tab: Resumen
        self.tab_summary = QWidget()
        self.tabs.addTab(self.tab_summary, "  Resumen  ")
        self._init_tab_summary()

        # Tab: Cort. Res. Ent.
        self.tab_shear = QWidget()
        self.tabs.addTab(self.tab_shear, "  Cort. Res. Ent.  ")
        self._init_tab_shear()

        # Tab: Gráficas
        self.tab_plots = QWidget()
        self.tabs.addTab(self.tab_plots, "  Gráficas  ")
        self._init_tab_plots()

        return self.tabs

    # ── Pestañas ──────────────────────────────────────────────────────────────

    def _wall_selector_row(self, parent_lay: QHBoxLayout, combo_attr: str,
                           extra_btn_text: str = "", extra_slot=None):
        """Crea la barra de selección de muro + botón exportar opcional."""
        parent_lay.addWidget(QLabel("Muro:"))
        cb = QComboBox()
        cb.setFixedWidth(120)
        setattr(self, combo_attr, cb)
        parent_lay.addWidget(cb)
        parent_lay.addStretch()
        if extra_btn_text:
            btn = QPushButton(extra_btn_text)
            btn.setObjectName("btn_word")
            if extra_slot:
                btn.clicked.connect(extra_slot)
            parent_lay.addWidget(btn)

    def _init_tab_results(self):
        vlay = QVBoxLayout(self.tab_results)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        self._wall_selector_row(
            bar, "cb_res_wall",
            "Exportar Word", self._export_results_word)
        self.cb_res_wall.currentTextChanged.connect(
            lambda name: self._populate_results(name))
        vlay.addLayout(bar)

        self.res_log = ColoredLog()
        vlay.addWidget(self.res_log, 1)

    def _init_tab_summary(self):
        vlay = QVBoxLayout(self.tab_summary)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "Combinaciones críticas por nivel  "
            "(compresión · tensión · cortante · Mu · refuerzo)")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_summary_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.cb_sum_wall = QComboBox()
        self.cb_sum_wall.setFixedWidth(120)
        self.cb_sum_wall.currentTextChanged.connect(
            lambda name: self._populate_summary(name))
        # small row
        row = QHBoxLayout()
        row.addWidget(QLabel("Muro:"))
        row.addWidget(self.cb_sum_wall)
        row.addStretch()
        vlay.addLayout(row)

        self.sum_log = ColoredLog()
        vlay.addWidget(self.sum_log, 1)

    def _init_tab_shear(self):
        vlay = QVBoxLayout(self.tab_shear)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        bar = QHBoxLayout()
        lbl = QLabel(
            "NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso")
        lbl.setStyleSheet("color:#607D8B; font-size:8pt; font-style:italic;")
        bar.addWidget(lbl)
        bar.addStretch()
        btn_exp = QPushButton("Exportar Word")
        btn_exp.setObjectName("btn_word")
        btn_exp.clicked.connect(self._export_shear_word)
        bar.addWidget(btn_exp)
        vlay.addLayout(bar)

        self.shear_log = ColoredLog()
        vlay.addWidget(self.shear_log, 1)

    def _init_tab_plots(self):
        vlay = QVBoxLayout(self.tab_plots)
        vlay.setContentsMargins(4, 4, 4, 4)
        vlay.setSpacing(4)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Muro:"))
        self.cb_plot_wall = QComboBox()
        self.cb_plot_wall.setFixedWidth(110)
        self.cb_plot_wall.currentTextChanged.connect(self._on_plot_wall_change)
        ctrl.addWidget(self.cb_plot_wall)

        ctrl.addWidget(QLabel("Nivel:"))
        self.cb_plot_nivel = QComboBox()
        self.cb_plot_nivel.setFixedWidth(100)
        ctrl.addWidget(self.cb_plot_nivel)

        ctrl.addWidget(QLabel("Gráfica:"))
        self.cb_plot_type = QComboBox()
        self.cb_plot_type.addItems([
            "Interacción", "Envolvente Momentos", "Envolvente Cortantes"])
        self.cb_plot_type.setFixedWidth(180)
        ctrl.addWidget(self.cb_plot_type)

        btn_show = QPushButton("Mostrar")
        btn_show.clicked.connect(self._show_plot)
        ctrl.addWidget(btn_show)
        ctrl.addStretch()

        vlay.addLayout(ctrl)

        self.plot_container = QWidget()
        self.plot_layout    = QVBoxLayout(self.plot_container)
        self.plot_layout.setContentsMargins(0, 0, 0, 0)
        placeholder = QLabel("Ejecute el cálculo y seleccione muro + tipo de gráfica.")
        placeholder.setAlignment(Qt.AlignCenter)
        placeholder.setStyleSheet("color:#607D8B; font-size:11pt;")
        self.plot_layout.addWidget(placeholder)
        self.plot_placeholder = placeholder
        vlay.addWidget(self.plot_container, 1)

    # ── Navegación / Slots de UI ──────────────────────────────────────────────

    # ── Helpers para tablas de configuración ─────────────────────────────────

    def _toggle_material_tables(self):
        self.grp_mamp_tbl.setVisible(self.chk_mamp.isChecked())
        self.grp_conc_tbl.setVisible(self.chk_conc.isChecked())

    #: Columnas de `tbl_niveles`, por nombre. Igual que en las otras
    #: tablas: los indices literales son donde agregar una columna se
    #: cobra en silencio.
    COL_NIV = {"nombre": 0, "elev": 1, "e_losa": 2}

    #: Anchos de columna que hacen que el TITULO se lea completo, px.
    #: Medidos sobre la ventana montada con `sectionSizeHint()`; van a mano
    #: porque al construir la tabla la cabecera aun no tiene el estilo de
    #: la suite y devuelve valores que no son los finales —la misma trampa
    #: de `ALTO_CABECERA_GRUPOS`—.
    #:
    #: En las tablas donde la primera columna es `Stretch`, ensanchar estas
    #: se lo quita a ella, que es lo que se busca: «Nombre del Nivel» pide
    #: 205 px y se quedaba con 585.
    ANCHO_COL_ELEV = 170        # "Elevación (m)"
    ANCHO_COL_ELOSA = 135       # "e losa (m)"
    ANCHO_COL_CORTANTE = 110    # "Vx (ton)" / "Vz (ton)"
    ANCHO_COL_LP = 135          # "L' no arr.\n(m)"

    def _add_nivel_row(self):
        row = self.tbl_niveles.rowCount()
        self.tbl_niveles.insertRow(row)
        self.tbl_niveles.setItem(
            row, self.COL_NIV["nombre"], QTableWidgetItem(f"N{row+1}"))
        self.tbl_niveles.setItem(
            row, self.COL_NIV["elev"], QTableWidgetItem("0.00"))
        # CERO, no un peralte de oficio: cero significa «no restar nada»,
        # que es el lado conservador. Un 0.20 puesto por el programa se
        # leeria como dato del proyecto y nadie lo revisaria.
        item_losa = QTableWidgetItem("0.00")
        item_losa.setToolTip(
            "Peralte promedio de la losa de este nivel [m].\n\n"
            "Se resta de la altura del entrepiso que esta losa CUBRE para\n"
            "obtener la altura LIBRE, que es la que piden:\n"
            "  · PR del muro de concreto   (NTC DEC 6.5.5.2.1)\n"
            "  · espesor minimo del muro   (NTC DEC 6.5.3.2)\n"
            "  · amplificacion por esbeltez (NTC DEC 3.3.5)\n"
            "  · factor F_E de mamposteria  (NTC DEM 3.1.2.3.1)\n"
            "  · H0 de estribos de castillo (NTC DEM 6.2.3.2)\n\n"
            "0 = no restar nada (conservador).")
        self.tbl_niveles.setItem(row, self.COL_NIV["e_losa"], item_losa)

    #: Columnas de `tbl_mamp`, por nombre. Los índices estaban escritos a
    #: mano en el alta de fila y en la lectura, y son el sitio donde un
    #: cambio de columnas se cobra en silencio: la fila se llena bien y el
    #: valor se lee de la de al lado.
    COL_MAMP = {
        "nombre": 0, "vm": 1, "fm": 2, "fan": 3,
        "peso_vol": 4, "fc_cast": 5, "fy_cast": 6, "fy_hor": 7,
    }

    def _add_mamp_row(self):
        row = self.tbl_mamp.rowCount()
        self.tbl_mamp.insertRow(row)
        # Valores por omisión de la Norma, no ceros: una fila recién
        # agregada tiene que poder calcularse tal cual.
        defaults = {
            "nombre": "MAMP1", "vm": "7.0", "fm": "35.0", "fan": "1.0",
            "peso_vol": "2.0", "fc_cast": "200.0",
            "fy_cast": "4200.0", "fy_hor": "4200.0",
        }
        for campo, col in self.COL_MAMP.items():
            self.tbl_mamp.setItem(row, col,
                                  QTableWidgetItem(defaults[campo]))

    def _add_conc_row(self):
        row = self.tbl_conc.rowCount()
        self.tbl_conc.insertRow(row)
        defaults = ["CONC1", "250.0", "4200.0", "4200.0", "2.4"]
        for c, v in enumerate(defaults):
            self.tbl_conc.setItem(row, c, QTableWidgetItem(v))

    def _add_cortante_row(self):
        row = self.tbl_cortantes.rowCount()
        self.tbl_cortantes.insertRow(row)
        self.tbl_cortantes.setItem(row, 0, QTableWidgetItem(f"Nivel-{row+1}"))
        self.tbl_cortantes.setItem(row, 1, QTableWidgetItem("0.0"))
        self.tbl_cortantes.setItem(row, 2, QTableWidgetItem("0.0"))

    @staticmethod
    def _del_tbl_row(tbl: QTableWidget):
        rows = sorted(set(idx.row() for idx in tbl.selectedIndexes()),
                      reverse=True)
        for r in rows:
            tbl.removeRow(r)

    # ── Helpers para la tabla de grupos (tbl_sel) ────────────────────────────

    @staticmethod
    def _center_widget(w: QWidget) -> QWidget:
        c = QWidget()
        hl = QHBoxLayout(c)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setAlignment(Qt.AlignCenter)
        hl.addWidget(w)
        return c

    def _get_chk_from_cell(self, row: int, col: int) -> Optional[QCheckBox]:
        container = self.tbl_sel.cellWidget(row, col)
        if container:
            return container.findChild(QCheckBox)
        return None

    #: Columnas de `tbl_sel`, por nombre. Los índices estaban escritos a
    #: mano en el alta de fila y en la lectura, y son el sitio donde
    #: agregar una columna se cobra en silencio: la casilla se pone bien
    #: y se lee la de al lado.
    COL_SEL = {"grupo": 0, "int": 1, "ext": 2, "lp": 3}

    #: Lo que aparece en la celda de L' al agregar un muro. CERO quiere
    #: decir «usa la longitud del propio muro», que es lo que el usuario
    #: espera si no toca nada. NO se pone 3.50 aunque sea la hipótesis
    #: por omisión del motor: un número puesto de oficio se lee como un
    #: dato del proyecto y nadie lo revisa.
    LP_EN_BLANCO = "0"

    def _add_group_to_sel(self, label: str):
        """Agrega un grupo a tbl_sel con casillas Interior (default)/Exterior."""
        row = self.tbl_sel.rowCount()
        self.tbl_sel.insertRow(row)

        item = QTableWidgetItem(label)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        self.tbl_sel.setItem(row, 0, item)

        chk_int = QCheckBox()
        chk_int.setChecked(True)
        chk_ext = QCheckBox()
        chk_ext.setChecked(False)

        # Mutuamente excluyentes: un muro es interior o exterior.
        chk_int.toggled.connect(
            lambda checked, ce=chk_ext: ce.setChecked(False) if checked else None)
        chk_ext.toggled.connect(
            lambda checked, ci=chk_int: ci.setChecked(False) if checked else None)

        self.tbl_sel.setCellWidget(
            row, self.COL_SEL["int"], self._center_widget(chk_int))
        self.tbl_sel.setCellWidget(
            row, self.COL_SEL["ext"], self._center_widget(chk_ext))

        item_lp = QTableWidgetItem(self.LP_EN_BLANCO)
        item_lp.setToolTip(
            "Longitud NO arriostrada del muro L' [m], NTC DEM 3.1.2.4.1: la\n"
            "separación de los elementos que lo rigidizan\n"
            "transversalmente. Entra en el factor F_E de esbeltez y\n"
            "excentricidad (3.1.2.3.1), y sólo aplica a mampostería.\n\n"
            "0 = usar la longitud del propio muro.")
        self.tbl_sel.setItem(row, self.COL_SEL["lp"], item_lp)

    @staticmethod
    def _group_label(name: str, gtype: int) -> str:
        tag = {1: "[NOD]", 2: "[MBR]", 3: "[PLC]", 4: "[SOL]"}.get(gtype, "[?]")
        return f"{tag}  {name}"

    @staticmethod
    def _name_from_label(label: str) -> str:
        return label.split("]  ", 1)[1] if "]  " in label else label

    # ── Helpers de lectura de tablas ─────────────────────────────────────────

    @staticmethod
    def _tbl_text(tbl: QTableWidget, row: int, col: int) -> str:
        item = tbl.item(row, col)
        return item.text().strip() if item else ""

    @staticmethod
    def _tbl_float(tbl: QTableWidget, row: int, col: int,
                   default: float = 0.0) -> float:
        try:
            return float(tbl.item(row, col).text().strip())
        except (AttributeError, ValueError, TypeError):
            return default

    def _build_user_inputs_from_ui(self) -> object:
        """Construye un `UserInputs` completo a partir de los widgets.

        Es lo que sustituye a `wall_excel_reader.read_user_inputs`: los
        mismos campos, leídos de las tablas del cuadro de control. Los
        `default` de `_tbl_float` son los de la Norma, para que una celda
        que el usuario dejó vacía no se convierta en un cero silencioso
        que el motor tomaría como dato.

        Lo que NO se llena aquí, a propósito: `wall_thickness` y
        `wall_material` por muro. En la plantilla se declaraban a mano; el
        .anl los trae en ELEMENT PROPERTY y en CONSTANTS MATERIAL, y el
        worker los resuelve desde ahí. Que queden vacíos es lo que hace
        que el worker use el modelo en vez de un dato repetido.
        """
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        from wall_models import UserInputs, MaterialProps

        inp = UserInputs()

        # Combinaciones de carga
        inp.pp_cm_cvacc_combo   = self.spn_pp_combo.value()
        inp.first_service_combo = self.spn_svc_start.value()
        inp.last_service_combo  = self.spn_svc_end.value()
        inp.first_design_combo  = self.spn_des_start.value()
        inp.last_design_combo   = self.spn_des_end.value()
        inp.n_service_combos = max(
            0, inp.last_service_combo - inp.first_service_combo + 1)
        inp.n_design_combos = max(
            0, inp.last_design_combo - inp.first_design_combo + 1)

        # Ductilidad
        inp.Q_duct = self.spn_ductility.value()

        # Niveles (elevaciones ordenadas de mayor a menor)
        levels = []
        inp.slab_thickness = {}
        for row in range(self.tbl_niveles.rowCount()):
            txt = self._tbl_text(self.tbl_niveles, row, self.COL_NIV["elev"])
            try:
                elev = float(txt)
            except ValueError:
                continue
            levels.append(elev)
            # Peralte de la losa de ESE nivel. Se indexa por elevacion
            # porque es lo que viaja en `floor_levels`; el nombre del
            # nivel lo reescribe la geometria.
            e_losa = self._tbl_float(
                self.tbl_niveles, row, self.COL_NIV["e_losa"], 0.0)
            if e_losa > 1e-9:
                inp.slab_thickness[elev] = e_losa
        inp.floor_levels = sorted(set(levels), reverse=True) if levels else []

        # Materiales — Mampostería
        inp.materials = []
        if self.chk_mamp.isChecked():
            C = self.COL_MAMP
            for row in range(self.tbl_mamp.rowCount()):
                name = self._tbl_text(self.tbl_mamp, row, C["nombre"])
                if not name:
                    # Una fila sin nombre no es un material: es una fila que
                    # el usuario agregó y no llenó. No se inventa.
                    continue
                m = MaterialProps(
                    name=name,
                    tipo_material=1,
                    vm=self._tbl_float(self.tbl_mamp, row, C["vm"], 7.0),
                    fm=self._tbl_float(self.tbl_mamp, row, C["fm"], 35.0),
                    fan=self._tbl_float(self.tbl_mamp, row, C["fan"], 1.0),
                    peso_vol=self._tbl_float(
                        self.tbl_mamp, row, C["peso_vol"], 2.0),
                    fc_castillos=self._tbl_float(
                        self.tbl_mamp, row, C["fc_cast"], 200.0),
                    fc=self._tbl_float(self.tbl_mamp, row, C["fc_cast"], 200.0),
                    fy_vert=self._tbl_float(
                        self.tbl_mamp, row, C["fy_cast"], 4200.0),
                    fy_hor=self._tbl_float(
                        self.tbl_mamp, row, C["fy_hor"], 4200.0),
                )
                inp.materials.append(m)

        # Materiales — Concreto
        if self.chk_conc.isChecked():
            for row in range(self.tbl_conc.rowCount()):
                name = self._tbl_text(self.tbl_conc, row, 0)
                if not name:
                    continue
                m = MaterialProps(
                    # Sin `tipo_muro` ni `tipo_pieza`: el primero no existe
                    # en el modelo de esta variante y el segundo no lo lee
                    # nadie. Ver la nota de `_mamp_hdrs`.
                    name=name, tipo_material=2,
                    fc=self._tbl_float(self.tbl_conc, row, 1, 250.0),
                    fc_castillos=self._tbl_float(self.tbl_conc, row, 1, 250.0),
                    fy_vert=self._tbl_float(self.tbl_conc, row, 2, 4200.0),
                    fy_hor=self._tbl_float(self.tbl_conc, row, 3, 4200.0),
                    peso_vol=self._tbl_float(self.tbl_conc, row, 4, 2.4),
                )
                inp.materials.append(m)

        # Cortantes de entrepiso
        inp.story_shears = {}
        for row in range(self.tbl_cortantes.rowCount()):
            niv = self._tbl_text(self.tbl_cortantes, row, 0)
            if niv:
                vx = self._tbl_float(self.tbl_cortantes, row, 1, 0.0)
                vz = self._tbl_float(self.tbl_cortantes, row, 2, 0.0)
                inp.story_shears[niv] = {"Vx": vx, "Vz": vz}

        # Posiciones de muros desde tbl_sel (Interior=2, Exterior=1)
        for row in range(self.tbl_sel.rowCount()):
            item = self.tbl_sel.item(row, self.COL_SEL["grupo"])
            if not item:
                continue
            gname = self._name_from_label(item.text())
            chk_int = self._get_chk_from_cell(row, self.COL_SEL["int"])
            inp.wall_positions[gname] = 2 if (chk_int and chk_int.isChecked()) else 1

            # L' del usuario [m]. El default 0.0 es el correcto: una celda
            # vacía, con basura o con un negativo significa «no lo sé», y
            # el motor cae en su hipótesis por omisión. Un L' inventado
            # aquí subiría F_E sin que nadie lo hubiera pedido.
            lp = self._tbl_float(self.tbl_sel, row, self.COL_SEL["lp"], 0.0)
            inp.wall_lp[gname] = lp if lp > 1e-9 else 0.0

        return inp

    def _plate_ids_seleccionados(self) -> dict:
        """{nombre de muro: [placas]} de los grupos elegidos en el panel.

        Sale de lo que ya leyó `_on_staad_connect`, no de volver a abrir el
        .anl: el archivo pasa de las cien mil líneas y releerlo aquí
        duplicaría el trabajo y abriría la puerta a que la lista de la
        tabla y las placas del cálculo no sean del mismo archivo, si el
        usuario cambió la ruta después de leer los grupos.
        """
        salida: dict = {}
        for row in range(self.tbl_sel.rowCount()):
            item = self.tbl_sel.item(row, 0)
            if not item:
                continue
            gname = self._name_from_label(item.text())
            salida[gname] = list(self._anl_groups.get(gname.upper(), []))
        return salida

    # ── Lectura de los grupos del .anl ───────────────────────────────────────

    def _on_staad_connect(self):
        """Lee la sección GROUP DEFINITION del .anl.

        Es lo que en `wall_design_pro` hace la conexión con STAAD Pro: con
        el archivo de resultados los grupos ya están escritos, así que no
        hace falta tener STAAD abierto ni ejecutar como administrador.
        """
        ruta = self.edit_anl.text().strip()
        if not ruta or not os.path.isfile(ruta):
            QMessageBox.warning(
                self, "Archivo .anl",
                "Seleccione el archivo .anl que generó el análisis.")
            return

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from staad_anl_parser import ANLParser

            self.btn_connect.setEnabled(False)
            self.lbl_conn_st.setText("● Leyendo…")
            self.lbl_conn_st.setStyleSheet("color:#E67E22; font-weight:bold;")
            QApplication.processEvents()

            parser = ANLParser(ruta)
            parser.load()
            grupos = parser.list_groups()
            self._anl_groups = grupos

            if not grupos:
                self.lbl_conn_st.setText("● Sin grupos")
                self.lbl_conn_st.setStyleSheet(
                    "color:#C0392B; font-weight:bold;")
                # El mensaje dice QUÉ hacer, porque el caso frecuente no es
                # un archivo sin grupos: es un archivo LLENO de grupos que
                # no son de placas. En un modelo real había 131 —los
                # castillos, las cargas de piso y los nudos— y ni uno de
                # placas. Decir solo «sin grupos» manda al usuario a buscar
                # un bloque que sí está ahí.
                QMessageBox.warning(
                    self, "Sin grupos de placas",
                    "El archivo no trae ningún grupo DE PLACAS.\n\n"
                    "Los muros se toman de los grupos de placas: el "
                    "sub-bloque FLOOR del GROUP DEFINITION, con los números "
                    "de las placas que forman cada muro.\n\n"
                    "Los grupos de barras (MEMBER) y de nudos (JOINT) "
                    "pueden existir en el archivo y NO son muros; tampoco "
                    "lo son los grupos de FLOOR que definen cargas de piso "
                    "sobre barras.\n\n"
                    "Defina los muros como grupos de placas en STAAD y "
                    "vuelva a correr el análisis.")
                return

            # Solo llegan aquí los grupos que `list_groups` ya verificó como
            # de placas: se etiquetan con el tipo 3 para reutilizar el mismo
            # panel de selección que la versión con conexión COM.
            self._all_groups = [(n, 3) for n in grupos]
            self._staad_connected = True

            n_placas = sum(len(v) for v in grupos.values())
            self.lbl_conn_st.setText("● Archivo leído")
            self.lbl_conn_st.setStyleSheet("color:#27AE60; font-weight:bold;")
            self.lbl_conn_info.setText(
                f"{os.path.basename(ruta)}  |  Grupos: {len(grupos)}  |  "
                f"Placas en grupos: {n_placas}  |  "
                f"{len(parser.lines):,} líneas")

            self._refresh_group_list()

        except Exception as exc:                    # noqa: BLE001
            self.lbl_conn_st.setText("● Error")
            self.lbl_conn_st.setStyleSheet("color:#C0392B; font-weight:bold;")
            QMessageBox.critical(self, "Error leyendo el .anl", str(exc))
        finally:
            self.btn_connect.setEnabled(True)

    def _refresh_group_list(self):
        flt         = self.edit_grp_filter.text().upper()
        only_plates = self.chk_only_plates.isChecked()
        sel_labels = {
            self.tbl_sel.item(r, 0).text()
            for r in range(self.tbl_sel.rowCount())
            if self.tbl_sel.item(r, 0)
        }

        self.lst_avail.clear()
        # Se ordena AQUÍ y no donde se leen los grupos porque este es el
        # único sitio por el que pasan todos: la lectura del .anl, el
        # filtro de texto y el devolver un grupo a la lista al quitarlo de
        # la selección.
        for name, gtype in sorted(self._all_groups,
                                  key=lambda g: clave_natural(g[0])):
            if only_plates and gtype != 3:
                continue
            if flt and flt not in name.upper():
                continue
            label = self._group_label(name, gtype)
            if label in sel_labels:
                continue
            self.lst_avail.addItem(label)

    def _on_group_filter(self):
        self._refresh_group_list()

    def _on_grp_add(self):
        for item in self.lst_avail.selectedItems():
            self._add_group_to_sel(item.text())
            self.lst_avail.takeItem(self.lst_avail.row(item))

    def _on_grp_remove(self):
        rows = sorted(
            set(idx.row() for idx in self.tbl_sel.selectedIndexes()),
            reverse=True)
        for row in rows:
            self.tbl_sel.removeRow(row)
        # Se reconstruye en vez de añadir al final: `_refresh_group_list`
        # ya sabe qué grupos NO están en la tabla, y así el que vuelve cae
        # en su orden en lugar de al pie de la lista.
        self._refresh_group_list()

    def _on_grp_add_all(self):
        while self.lst_avail.count() > 0:
            lbl = self.lst_avail.item(0).text()
            self._add_group_to_sel(lbl)
            self.lst_avail.takeItem(0)

    def _on_grp_remove_all(self):
        self.tbl_sel.setRowCount(0)
        self._refresh_group_list()

    def _browse_excel(self):
        # Sin efecto: los parámetros se capturan en el cuadro de control.
        # Se conserva el nombre porque `suite_shared.project_io` y el
        # gestor de proyectos guardado pueden invocarlo en archivos
        # anteriores a este cambio.
        pass

    def _browse_anl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccione el archivo de análisis STAAD Pro",
            "", "STAAD output (*.anl *.out *.ANL *.OUT);;Todos (*.*)")
        if path:
            self.edit_anl.setText(path)

    def _preview_excel(self):
        # Sin efecto: ya no hay plantilla que previsualizar. Lo que antes
        # resumía este botón está ahora a la vista en las propias tablas.
        pass

    # ── Cálculo ───────────────────────────────────────────────────────────────

    def _start_calculation(self):
        anl = self.edit_anl.text().strip()

        if not anl or not os.path.isfile(anl):
            QMessageBox.critical(
                self, "Error",
                "Seleccione el archivo de análisis STAAD Pro (.anl).")
            return
        if not self._staad_connected:
            QMessageBox.critical(
                self, "Grupos sin leer",
                "Pulse «Leer grupos del .anl» antes de calcular.")
            return
        if self.tbl_sel.rowCount() == 0:
            QMessageBox.critical(
                self, "Sin grupos",
                "Seleccione al menos un grupo de placas para diseñar.")
            return

        # ── Validar los parámetros del cuadro de control ──────────────────
        #
        # Se valida AQUÍ y no dentro del worker: un error de captura tiene
        # que salir como un diálogo antes de arrancar, no como un traceback
        # en el log después de veinte segundos de cálculo.
        try:
            ui_inputs = self._build_user_inputs_from_ui()
        except Exception as exc:                    # noqa: BLE001
            QMessageBox.critical(self, "Error en parámetros", str(exc))
            return

        if not ui_inputs.floor_levels or len(ui_inputs.floor_levels) < 2:
            QMessageBox.critical(
                self, "Niveles insuficientes",
                "Capture al menos DOS niveles en la tabla: un muro necesita "
                "la elevación de su base y la de su remate.")
            return
        if not ui_inputs.materials:
            QMessageBox.critical(
                self, "Sin materiales",
                "Capture al menos un material en la tabla de Mampostería o "
                "de Concreto.")
            return

        wall_plate_ids = self._plate_ids_seleccionados()

        self.btn_run.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.log_widget.clear_log()
        self.status.showMessage("  Calculando…")
        self.tabs.setCurrentWidget(self.tab_results)

        self._worker = DesignWorker(ui_inputs, anl, wall_plate_ids,
                                    SOURCE_DIR, self)
        self._worker.sig_log.connect(self._on_log)
        self._worker.sig_progress.connect(self._on_progress)
        self._worker.sig_done.connect(self._on_done)
        self._worker.sig_error.connect(self._on_error)
        self._worker.finished.connect(lambda: self.btn_run.setEnabled(True))
        self._worker.start()

    def _on_log(self, text: str, tag: str):
        self.log_widget.putln(text, tag)

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        self.status.showMessage(f"  {msg}")

    def _on_done(self, result: dict):
        self._walls    = result["walls"]
        self._results  = result["results"]
        self._diagrams = result["diagrams"]
        self._inputs   = result["inputs"]

        self.progress.setVisible(False)
        ts = datetime.now().strftime("%H:%M:%S")
        n  = len(self._walls)
        self.status.showMessage(
            f"  ✔  Diseño completado  ·  {n} muro(s)  ·  {ts}")
        self.log_widget.putln("\n✔  Cálculo completado exitosamente.", "ok")

        wall_names = [w.name for w in self._walls]

        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.blockSignals(True)
            cb.clear()
            cb.addItems(wall_names)
            cb.blockSignals(False)

        if wall_names:
            for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
                cb.setCurrentIndex(0)
            first = wall_names[0]
            self._populate_results(first)
            self._populate_summary(first)
            self._on_plot_wall_change(first)

        self._populate_shear()

    def _on_error(self, msg: str):
        self.progress.setVisible(False)
        self.status.showMessage("  ✗  Error en el cálculo.")
        self.log_widget.putln("\n✗  Error durante el cálculo:", "err")
        last = [l for l in msg.strip().splitlines() if l.strip()]
        if last:
            self.log_widget.putln(f"  {last[-1]}", "err")
        self.log_widget.putln("\nDetalle:", "dim")
        self.log_widget.putln(msg, "dim")

    # ── Poblar pestañas ───────────────────────────────────────────────────────

    def _populate_results(self, wall_name: str):
        self.res_log.clear_log()
        if not wall_name:
            return
        wall   = next((w for w in self._walls if w.name == wall_name), None)
        inputs = self._inputs
        if not wall or not inputs:
            return
        reltan       = inputs.wall_reltan.get(wall_name, {"reltan1": 0.0, "reltan2": 0.0})
        position_str = "Exterior" if wall.position == 1 else "Interior"
        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat = lv.material if lv.material is not None else wall.material
            if isinstance(res_list[0].__class__.__name__, str):
                pass  # won't happen
            try:
                from wall_models import DesignResultMasonry
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_masonry_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
                else:
                    self._write_concrete_level(
                        self.res_log, wall, lv, res_list, lv_mat,
                        position_str, reltan)
            except ImportError:
                pass
        self.res_log.scroll_top()

    def _populate_summary(self, wall_name: str):
        self.sum_log.clear_log()
        if not wall_name:
            return
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            from wall_models import DesignResultMasonry
        except ImportError:
            return

        for lv in wall.levels:
            res_list = self._results.get(wall_name, {}).get(lv.nivel_name, [])
            if not res_list:
                continue
            lv_mat   = lv.material if lv.material is not None else wall.material
            tipo_str = "Mampostería" if (lv_mat and lv_mat.tipo_material == 1) else "Concreto"
            SEP = "=" * 120
            self.sum_log.putln(f"\n{SEP}", "hdr")
            self.sum_log.putln(
                f"  NIVEL: {lv.nivel_name}    Hi={lv.hi:.2f} m    "
                f"Lm={lv.lm:.2f} m    [{tipo_str}]    Muro: {wall.name}", "sec")
            self.sum_log.putln(f"{SEP}", "hdr")
            crit = get_critical_combos(res_list)
            if crit:
                if isinstance(res_list[0], DesignResultMasonry):
                    self._write_critical_block_masonry(self.sum_log, crit)
                else:
                    self._write_critical_block_concrete(self.sum_log, crit)
        self.sum_log.scroll_top()

    def _populate_shear(self):
        self.shear_log.clear_log()
        if not self._walls or not self._inputs:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_shear_check import compute_shear_resistente
            shear_data = compute_shear_resistente(
                self._walls, self._results, self._inputs)
            self._shear_data = shear_data
            self._render_shear(shear_data)
        except Exception:
            self.shear_log.putln(
                f"Error al calcular cortante:\n{traceback.format_exc()}", "err")

    def _render_shear(self, shear_data: dict):
        W = self.shear_log
        SEP = "=" * 155
        sep = "-" * 155
        _c = ["Muro","Material","t(m)","Lm(m)","A(m2)",
              "sCalc","3.33vm","si","0.5vm","0.3si","n*rh*fy",
              "Vr(t)","Rel.","Vres(t)"]
        _w = [10,12,6,7,7,8,8,8,7,7,9,8,6,9]
        HDR = "  " + " ".join(c.rjust(w) for c, w in zip(_c, _w))

        for direction in ('X', 'Z'):
            level_list = shear_data.get(direction, [])
            if not level_list:
                W.putln(f"\n  Dirección {direction}: sin muros contribuyentes.", "dim")
                continue
            W.putln(f"\n{SEP}", "hdr")
            W.putln(f"  DIRECCIÓN {direction}  —  Cortante Resistente por Entrepiso",
                    "sec")
            W.putln(f"  NTC 2023: Σ Vr_muros ≥ 0.80 × V_entrepiso", "dim")
            W.putln(f"{SEP}", "hdr")
            for lev in level_list:
                W.putln(
                    f"\n  NIVEL: {lev['nivel_name']}    "
                    f"V_entrepiso {direction} = {lev['story_shear']:.2f} ton", "sec")
                W.putln(f"{HDR}", "hdr")
                W.putln(f"{'─'*155}", "dim")
                for w in lev['walls']:
                    if w['tipo'] == 'Mamposteria':
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{w['sigcalc']:>8.4f} {w['sigma_lim']:>8.4f} "
                            f"{w['sigma_i']:>8.4f} "
                            f"{w['vm05']:>7.4f} {w['sig03']:>7.4f} "
                            f"{w['nph_fyh']:>9.4f} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                    else:
                        W.putln(
                            f"  {w['wall_name']:<9} {w['tipo']:<12} "
                            f"{w['t']:>6.3f} {w['Lm']:>7.3f} {w['area']:>7.4f} "
                            f"{'—':>8} {'—':>8} {'—':>8} "
                            f"{'—':>7} {'—':>7} {'—':>9} "
                            f"{w['VrTotal']:>8.2f} {w['reltan']:>6.4f} "
                            f"{w['Vres']:>9.2f}"
                        )
                W.putln(f"{'─'*155}", "dim")
                cumple   = lev['cumple']
                cond_str = "✓  CUMPLE" if cumple else "✗  NO CUMPLE"
                cond_tag = "ok" if cumple else "fail"
                W.put(
                    f"  {'Σ Vres':>20} = {lev['sum_vres']:>8.2f} ton    "
                    f"V_ent = {lev['story_shear']:>8.2f} ton    "
                    f"Ratio = {lev['ratio']:>6.3f}    "
                )
                W.putln(cond_str, cond_tag)
                W.putln(f"{sep}", "dim")

    # ── Resultados por nivel ──────────────────────────────────────────────────

    def _build_crit_map(self, res_list: list) -> dict:
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
        except ImportError:
            return {}
        if not crit:
            return {}
        crit_map: dict = {}
        for key, tag in [
            ("max_refs","crit_refs"), ("max_refv","crit_refv"),
            ("max_refc","crit_refc"), ("max_mu","crit_mu"),
            ("max_shear","crit_shear"), ("max_tens","crit_tens"),
            ("max_comp","crit_comp"),
        ]:
            r = crit.get(key)
            if r is not None:
                crit_map[r.combo] = tag
        return crit_map

    def _write_masonry_level(self, W: ColoredLog, wall, lv, res_list,
                             mat, position_str, reltan):
        r0 = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Ht_t = lv.hi / lv.thickness if lv.thickness > 0 else 0.0
        fiel1 = reltan.get("reltan1", 0.0)
        fiel2 = reltan.get("reltan2", 0.0)
        SEP = "=" * 165
        sep = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            # L del NIVEL y H TOTAL del muro. Antes había que despejar la
            # longitud de `L/t` y la altura total no aparecía.
            f"L={lv.lm:.2f} m   H={getattr(wall, 'Ht', 0.0):.2f} m   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Mampostería   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Fiel: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   Hcr={lv.hi:.2f} m   "
            f"h libre={lv.h_libre:.2f} m (e losa={lv.espesor_losa:.2f})   "
            f"H/t={Ht_t:.2f}   H/L={HL:.4f}   "
            f"Asmin(Cast.)={r0.AsminCast:.2f} cm²   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        # L' NO ARRIOSTRADA: la que entra en F_E (NTC DEM 3.1.2.3.1). Se
        # imprime SIEMPRE y se dice de dónde sale, porque el valor por
        # omisión —min(Lm, 3.50)— es una hipótesis sobre la planta, no un
        # dato del modelo, y sube F_E hasta un 30 % en muros largos.
        lp_usada = getattr(r0, "Lp", 0.0) or 0.0
        lp_origen = ("capturada" if getattr(wall, "Lp", 0.0) > 1e-9
                     else "por omisión: min(L, 3.50)")
        W.putln(
            f"  L' no arriostrada={lp_usada:.2f} m ({lp_origen})   "
            f"F_E={r0.Fe:.4f}   H/L'="
            f"{(lv.hi / lp_usada if lp_usada > 1e-9 else 0.0):.4f}")
        W.putln(
            f"  v'm={mat.vm:.2f} kg/cm²   f'm={mat.fm:.2f} kg/cm²   "
            f"f'c(Cast.)={mat.fc_castillos:.2f} kg/cm²   "
            f"fy(Vert.)={mat.fy_vert:.0f} kg/cm²   "
            f"fy(Hor.)={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            # Pr(t) y no Pres(t): aqui el valor SIEMPRE fue `r.Pr`, la
            # resistencia de 6.4.1.1. El rotulo sugeria el `0.85·f'c·Ag`
            # que la tabla de concreto mostraba con el mismo nombre.
            f"{'FrFlC':>6} {'Pr(t)':>9} {'AscCal':>7} {'C.P':>9} "
            f"{'Asc(cm2)':>9} {'Pt(t)':>8} {'Vres(t)':>8} "
            f"{'k0':>5} {'k1':>5} {'ns':>5} {'nEfic':>6} "
            f"{'AshH':>7} {'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            fx_ok = _flexion_ok(r)
            cp_fg = "ok" if (r.cond_axial in ("Si Pasa","Tension") and fx_ok) else "fail"
            cv_fg = "ok" if (r.cond_cortante == "Si Pasa" and fx_ok)          else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                f"{r.Frflcomp:>6.2f} {r.Pr:>9.2f} {r.Asc1_calc:>7.2f} ",
                bg=bg)
            W.put(f"{r.cond_axial:>9} ", cp_fg, bg)
            W.put(
                f"{r.Asc1:>9.2f} {r.Pt_svc:>8.2f} {r.Vr:>8.2f} "
                f"{r.k0:>5.2f} {r.k11:>5.2f} {r.ns:>5.2f} {r.n:>6.2f} "
                f"{r.Ash:>7.2f} {r.Vras:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.put(f"{r.cond_cortante:>9}", cv_fg, bg)
            W.putln("" if fx_ok else "  FLEXION: No Pasa",
                    "fail", bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_masonry(W, crit)
        except ImportError:
            pass

    def _write_concrete_level(self, W: ColoredLog, wall, lv, res_list,
                              mat, position_str, reltan):
        r0   = res_list[0]
        HL   = lv.hi / lv.lm        if lv.lm > 0        else 0.0
        Lt   = lv.lm / lv.thickness if lv.thickness > 0 else 0.0
        L3   = lv.lm / 3.0
        fiel1= reltan.get("reltan1", 0.0)
        fiel2= reltan.get("reltan2", 0.0)
        SEP  = "=" * 165
        sep  = "-" * 165

        W.putln(f"\n{SEP}", "hdr")
        W.putln(
            f"  MURO: {wall.name:<10}   "
            # L del NIVEL y H TOTAL del muro. Antes había que despejar la
            # longitud de `L/t` y la altura total no aparecía.
            f"L={lv.lm:.2f} m   H={getattr(wall, 'Ht', 0.0):.2f} m   "
            f"Nivel  {lv.nivel_sup:.2f} → {lv.nivel_inf:.2f} m   "
            f"  Material: Concreto   [{mat.name}]", "sec")
        W.putln(f"{SEP}", "hdr")
        W.putln(
            f"  Dirección: {lv.direction:<4}   Posición: {position_str:<10}   "
            f"P(cm+cvcinst): {r0.Pt:+8.2f} ton   Rel.: {fiel1:.2f}/{fiel2:.2f}")
        W.putln(
            f"  t={lv.thickness:.4f} m   H/L={HL:.4f}   L/t={Lt:.2f}   "
            f"L/3={L3:.2f} m   Asmin(Ver.)={r0.Asvmin:.2f} cm²/m   "
            f"Asmin(Hor.)={r0.Ashmin:.2f} cm²/m")
        W.putln(
            f"  Hi={lv.hi:.2f} m   h libre={lv.h_libre:.2f} m "
            f"(e losa={lv.espesor_losa:.2f})   "
            f"An.Sec.Ext.={r0.SeccTC:.2f} m   "
            f"Vmax={r0.Vmax:.2f} ton   "
            f"f'c={mat.fc:.2f} kg/cm²   "
            f"fyVert.={mat.fy_vert:.0f} kg/cm²   "
            f"fyHor.={mat.fy_hor:.0f} kg/cm²")
        W.putln(f"{sep}", "dim")
        H = (
            f"{'Comb':>6} {'Pu(t)':>8} {'Vu(t)':>8} "
            f"{'e(m)':>7} {'Mu(tm)':>8} {'Mfp(tm)':>8} "
            # PR(t), no Pres(t): la que decide C.P. Ver la nota del
            # renglón de datos.
            f"{'PR(t)':>9} {'RefVCent':>9} {'C.P':>9} "
            f"{'AsExt1':>9} {'SecTC(m)':>9} "
            f"{'Vcr(t)':>8} {'Sep3(cm)':>9} {'Sep4(cm)':>9} "
            f"{'Vs(t)':>7} {'VrVs(t)':>8} {'C.V':>9}"
        )
        W.putln(H, "hdr")
        W.putln(f"{sep}", "dim")

        crit_map = self._build_crit_map(res_list)
        for r in res_list:
            rc    = lv.resultantes_by_combo.get(r.combo, {})
            e_val = rc.get("e", 0.0)
            mfp   = rc.get("Mfp", 0.0)
            bg    = crit_map.get(r.combo, "")
            fx_ok = _flexion_ok(r)
            cp_fg = "ok" if (r.cond_axial in ("Si Pasa","Tension") and fx_ok) else "fail"
            cv_fg = "ok" if (r.cond_cortante == "Si Pasa" and fx_ok)          else "fail"

            W.put(
                f"{r.combo:>6} {r.Pu:>8.2f} {r.Vu:>8.2f} "
                f"{e_val:>7.3f} {r.Mu:>8.2f} {mfp:>8.2f} "
                # `PR_axial` y NO `Pres`. `Pres = 0.85·f'c·Ag` es el
                # aplastamiento del área BRUTA —sin F_R, sin esbeltez y
                # sin excentricidad mínima— y no es lo que compara
                # `cond_axial`: en un muro del modelo de Sorata valía
                # 5 036 t contra los 354 t de PR, 14 veces más. Leerlo
                # junto a un «No Pasa» parecía un error del programa.
                # «n/d» si el Asv no se pudo dimensionar (B-5): el
                # numero serian solo los minimos.
                f"{r.PR_axial:>9.2f} {_texto_asv(r, 9)} ",
                bg=bg)
            # La marca «esb» dice que ESE renglón reprobó por esbeltez.
            # Va aquí y no sólo en el resumen porque el resumen trae la
            # combinación crítica y puede haber otras en el mismo caso.
            _cp = (r.cond_axial + " esb"
                   if getattr(r, "axial_por_esbeltez", False)
                   else r.cond_axial)
            W.put(f"{_cp:>9} ", cp_fg, bg)
            W.put(
                f"{r.AsExt1:>9.2f} {r.SeccTC:>9.2f} "
                f"{r.Vcr:>8.2f} {r.Sep1:>9.2f} {r.Sep2:>9.2f} "
                f"{r.Vs:>7.2f} {r.VrTotal:>8.2f} ",
                bg=bg)
            W.put(f"{r.cond_cortante:>9}", cv_fg, bg)
            W.putln("" if fx_ok else "  FLEXION: No Pasa",
                    "fail", bg)

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        # B-5: si alguna combinacion tiene el Asv NO dimensionable, la
        # tabla muestra «n/d» y aqui se dice POR QUE. Sin la nota, «n/d»
        # seria un hueco sin explicacion.
        try:
            from wall_design_ntc2023 import motivos_asv
            for _mot in motivos_asv(res_list):
                W.putln(f"  n/d (Asv): {_mot}", "fail")
        except ImportError:
            pass
        # Las combinaciones que reprueban por ESBELTEZ, todas —la
        # explicacion larga del bloque critico cubre solo a la de maxima
        # compresion, y puede no ser una de estas—.
        _esb = [rr for rr in res_list
                if getattr(rr, "axial_por_esbeltez", False)]
        if _esb:
            _inest = [rr for rr in _esb
                      if not (math.isfinite(getattr(rr, "Fab_fuera", 1.0))
                              and math.isfinite(getattr(rr, "Fab_plano", 1.0)))]
            _combos = ", ".join(str(rr.combo) for rr in _esb[:12])
            _mas = " …" if len(_esb) > 12 else ""
            W.putln(
                f"  No Pasa esb: {len(_esb)} combinación(es) reprueban por "
                f"ESBELTEZ en 6.5.5.2.1 (combos {_combos}{_mas}).", "warn")
            if _inest:
                W.putln(
                    f"               {len(_inest)} de ellas son INESTABLES "
                    f"fuera del plano (Pu >= 0.75·Pc): tampoco pasan por "
                    f"flexocompresión; hay que cambiar la geometría.", "fail")
            else:
                W.putln(
                    "               La ruta de flexocompresión (6.5.5.1 -> "
                    "5.3), la del diagrama de interacción, puede aprobarlas.",
                    "dim")
        try:
            from wall_design_ntc2023 import get_critical_combos
            crit = get_critical_combos(res_list)
            if crit:
                self._write_critical_block_concrete(W, crit)
        except ImportError:
            pass

    def _write_critical_block_masonry(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        # Igual que en concreto: el renglón dictamina COMPRESIÓN, así que
        # la resistencia que se muestra es Pr (6.4.1.1) y no VrTotal.
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   Pr={r.Pr:>8.2f} ton   "
              f"Asc1={r.Asc1:>7.2f} cm²   ")
        W.putln(f"[{r.cond_axial}]", cp)
        # punto 6: el veredicto de flexion tambien se ve aqui. Sin esto, la
        # combinacion critica salia "[Si Pasa]" en verde aunque el acero de
        # borde/castillo estuviera topado.
        if not _flexion_ok(r):
            W.putln(f"  {'':<20}  ^ esta combinacion NO PASA por FLEXION "
                    f"(6.4.2.2 / 6.5.5.1.2)", "fail")
        self._aviso_no_pasan(W, crit, "axial", r.combo)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   Asc1={r.Asc1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        self._aviso_no_pasan(W, crit, "cortante", r.combo)
        r = crit['max_mu']
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   Asc1={r.Asc1:>7.2f} cm²")
        self._aviso_no_pasan(W, crit, "flexion")
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Ash={r.Ash:>6.2f} cm²/m   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        W.putln(f"{sep}", "dim")

    def _aviso_no_pasan(self, W: ColoredLog, crit: dict, clave: str,
                        mostrada=None) -> None:
        """Las combinaciones del nivel que no pasan `clave` y no son la que
        el renglón acaba de dictaminar. Sin esto el resumen decía «Si Pasa»
        con «No Pasa» en la tabla de arriba (M085, 16-oct-2026). El texto
        lo arma el motor (`aviso_no_pasan`), el mismo que el Word."""
        from wall_design_ntc2023 import aviso_no_pasan
        texto = aviso_no_pasan(crit, clave, mostrada)
        if texto:
            W.putln(f"  {'':<20}  ^ {texto}", "fail")

    def _explicar_fallo_axial(self, W: ColoredLog, r) -> None:
        """POR QUÉ no pasó la revisión axial, debajo del veredicto.

        Sin esto, un «No Pasa» con 360 t de demanda contra un
        aplastamiento de 2 118 t se lee como un error del programa: el
        número que lo decide —PR— sale de multiplicar por el paréntesis
        de esbeltez, que en un muro delgado se come tres cuartas partes de
        la resistencia.

        NO cambia ningún veredicto: explica el que ya se emitió.
        """
        if r.PR_axial <= 1e-9:
            # PR = 0 es Ag = 0: el muro no tiene sección en este
            # entrepiso. Imprimir «|Pu|/PR» aquí daría una división por
            # cero o, con guarda, un 0.000 que se lee como lo contrario de
            # lo que pasa.
            W.putln(
                f"  {'':<20}  ^ PR = 0: el muro no tiene sección en este "
                f"entrepiso (L = 0). Revise la geometría del modelo.",
                "fail")
            return

        W.putln(
            f"  {'':<20}  ^ {r.ruta_axial}:  |Pu|/PR = "
            f"{abs(r.Pu) / r.PR_axial:.3f}", "fail")

        if not getattr(r, "axial_por_esbeltez", False):
            return

        # Lo hunde el PANDEO y no la sección: sin el paréntesis cabría.
        W.putln(
            f"  {'':<20}    LO DECIDE LA ESBELTEZ: el factor "
            f"[1-(k*lc/32h)^2] = {r.red_esbeltez:.4f} reduce PR de "
            f"{r.PR_sin_esbeltez:.2f} a {r.PR_axial:.2f} ton "
            f"(k = {r.k_esbeltez:.1f}).", "warn")
        if getattr(r, "motivo_asv_no_dimensionable", "") and not (
                math.isfinite(getattr(r, "Fab_fuera", 1.0))
                and math.isfinite(getattr(r, "Fab_plano", 1.0))):
            # INESTABLE: la ruta de flexocompresion tampoco lo salva —ahi
            # Fab = inf y ningun acero lo resuelve—. Decir «puede
            # aprobarlo» prometia una salida que no existe (B-5).
            W.putln(
                f"  {'':<20}    Y TAMPOCO pasa por la ruta de "
                f"flexocompresión (6.5.5.1 -> 5.3): el muro es INESTABLE "
                f"fuera del plano (Pu >= 0.75·Pc, Fab = ∞, 3.3.5). Ningún "
                f"acero lo resuelve; hay que cambiar la geometría.", "fail")
        else:
            W.putln(
                f"  {'':<20}    Sin esa reducción la demanda SÍ cabría "
                f"({abs(r.Pu):.2f} <= {r.PR_sin_esbeltez:.2f} ton). El "
                f"método simplificado 6.5.5.2.1 es OPCIONAL: la ruta de "
                f"flexocompresión (6.5.5.1 -> 5.3), que es la del diagrama "
                f"de interacción, mete el pandeo amplificando el momento y "
                f"puede aprobarlo.", "warn")
        W.putln(
            f"  {'':<20}    Para pasar por ESTA ruta: más espesor, menos "
            f"altura libre de entrepiso, o restringir el giro del borde "
            f"(k = 0.8, Tabla 6.5.5.2.2).", "dim")

    def _write_critical_block_concrete(self, W: ColoredLog, crit: dict):
        sep = "-" * 165
        W.putln(f"{sep}", "dim")
        W.putln("  COMBINACIONES CRÍTICAS DEL NIVEL", "sec")
        r  = crit['max_comp']
        cp = "ok" if r.cond_axial in ("Si Pasa","Tension") else "fail"
        # PR, no VrTotal. Este renglón dictamina COMPRESIÓN y mostraba la
        # resistencia a CORTANTE: quien leía «Pu = -360 t / VrTotal = 374 t
        # / No Pasa» veía dos números que sí cuadraban y un veredicto que
        # los contradecía, sin la cifra que lo decide (PR = 354.5 t).
        W.put(f"  {'Max. Compresión':<20}: Combo {r.combo:>4}   "
              f"Pu={r.Pu:>9.2f} ton   PR={r.PR_axial:>8.2f} ton   "
              f"Asv={_texto_asv(r, 7)} cm²/m   ")
        W.putln(f"[{r.cond_axial}]", cp)
        if r.cond_axial == "No Pasa":
            self._explicar_fallo_axial(W, r)
        # punto 6: el veredicto de flexion tambien se ve aqui. Sin esto, la
        # combinacion critica salia "[Si Pasa]" en verde aunque el acero de
        # borde/castillo estuviera topado.
        if not _flexion_ok(r):
            W.putln(f"  {'':<20}  ^ esta combinacion NO PASA por FLEXION "
                    f"(6.4.2.2 / 6.5.5.1.2)", "fail")
        self._aviso_no_pasan(W, crit, "axial", r.combo)
        if crit['max_tens']:
            r = crit['max_tens']
            W.putln(f"  {'Max. Tensión':<20}: Combo {r.combo:>4}   "
                    f"Pu=+{r.Pu:>8.2f} ton   AsExt1={r.AsExt1:>7.2f} cm²", "warn")
        else:
            W.putln(f"  {'Max. Tensión':<20}: No se presenta.", "dim")
        r  = crit['max_shear']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vu={r.Vu:>+9.2f} ton   VrTotal={r.VrTotal:>7.2f} ton   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        self._aviso_no_pasan(W, crit, "cortante", r.combo)
        r = crit['max_mu']
        req_ext = r.AsExt1 > r.Asvmin * r.SeccTC * 1.01
        mu_tag  = "warn" if req_ext else "dim"
        ext_str = (f"AsExt1={r.AsExt1:.2f} cm²"
                   if req_ext else "No se req. ref. de borde adicional")
        W.putln(f"  {'Max. Momento Mu':<20}: Combo {r.combo:>4}   "
                f"Mu={r.Mu:>+9.2f} ton·m   SeccTC={r.SeccTC:.3f} m   "
                f"{ext_str}", mu_tag)
        self._aviso_no_pasan(W, crit, "flexion")
        self._aviso_no_pasan(W, crit, "flexocomp")
        r  = crit['max_refs']
        cv = "ok" if r.cond_cortante == "Si Pasa" else "fail"
        W.put(f"  {'Max. Ref. Cortante':<20}: Combo {r.combo:>4}   "
              f"Vs={r.Vs:>7.2f} ton   ph={r.ph:.5f}   "
              f"Sep #3={r.Sep1:>6.1f} cm   Sep #4={r.Sep2:>6.1f} cm   ")
        W.putln(f"[{r.cond_cortante}]", cv)
        W.putln(f"{sep}", "dim")

    # ── Gráficas ──────────────────────────────────────────────────────────────

    def _on_plot_wall_change(self, wall_name: str = ""):
        if not wall_name:
            wall_name = self.cb_plot_wall.currentText()
        wall = next((w for w in self._walls if w.name == wall_name), None)
        if wall:
            niveles = [lv.nivel_name for lv in wall.levels]
            self.cb_plot_nivel.blockSignals(True)
            self.cb_plot_nivel.clear()
            self.cb_plot_nivel.addItems(niveles)
            self.cb_plot_nivel.blockSignals(False)
            if niveles:
                self.cb_plot_nivel.setCurrentIndex(0)

    def _show_plot(self):
        wall_name  = self.cb_plot_wall.currentText()
        nivel      = self.cb_plot_nivel.currentText()
        plot_type  = self.cb_plot_type.currentText()

        wall = next((w for w in self._walls if w.name == wall_name), None)
        if not wall:
            QMessageBox.warning(self, "Aviso", "Seleccione un muro válido.")
            return

        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)

        try:
            from wall_design_plots import (
                plot_interaction_masonry, plot_interaction_concrete,
                plot_moment_envelope, plot_shear_envelope,
            )
            mat       = wall.material
            tipo      = mat.tipo_material if mat else 1
            results_w = self._results.get(wall_name, {})
            diag_w    = self._diagrams.get(wall_name, {})

            if plot_type == "Interacción":
                diag_pts = diag_w.get(nivel, [])
                demand   = [(r.Pu, r.Mu) for r in results_w.get(nivel, [])]
                fig = (plot_interaction_masonry(diag_pts, demand, nivel, wall_name)
                       if tipo == 1
                       else plot_interaction_concrete(diag_pts, demand, nivel, wall_name))
            elif plot_type == "Envolvente Momentos":
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_moment_envelope(
                    wall.levels, results_w, floor_levels, wall_name)
            else:
                floor_levels = (
                    [lv.nivel_sup for lv in wall.levels]
                    + [wall.levels[-1].nivel_inf]
                )
                fig = plot_shear_envelope(
                    wall.levels, results_w, floor_levels, wall_name)

            self._embed_figure(fig)

        except Exception:
            self.log_widget.putln(
                f"Error al generar gráfica:\n{traceback.format_exc()}", "err")

    def _embed_figure(self, fig):
        # Limpiar contenedor
        if self._plot_canvas:
            self._plot_canvas.setParent(None)
            self._plot_canvas = None
        if self._plot_toolbar:
            self._plot_toolbar.setParent(None)
            self._plot_toolbar = None
        if self.plot_placeholder:
            self.plot_placeholder.setParent(None)
            self.plot_placeholder = None

        while self.plot_layout.count():
            item = self.plot_layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)

        canvas  = FigureCanvas(fig)
        toolbar = NavToolbar(canvas, self.plot_container)
        self.plot_layout.addWidget(toolbar)
        self.plot_layout.addWidget(canvas)
        canvas.draw()
        self._plot_canvas  = canvas
        self._plot_toolbar = toolbar

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _require_results(self) -> bool:
        if not self._walls:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return False
        return True

    def _export_word(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione la carpeta de salida")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            fname = os.path.join(
                output_dir,
                f"Diseno_Muros_{datetime.now():%Y%m%d_%H%M}.docx")
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall=self._plot_paths,
                output_path=fname, design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Word exportado: {os.path.basename(fname)}")
            QMessageBox.information(
                self, "Listo", f"Documento exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error exportando Word", str(exc))

    def _export_results_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resultados Word", "",
            "Word Documents (*.docx)",
            options=QFileDialog.DontConfirmOverwrite)
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_results_word
            inputs = self._inputs
            design_combos = list(range(
                inputs.first_design_combo, inputs.last_design_combo + 1))
            from suite_shared.busy_progress import busy_progress
            with busy_progress(self, "Generando documento Word…"):
                export_results_word(
                walls=self._walls, results_by_wall=self._results,
                plot_paths_by_wall={}, output_path=fname,
                design_combos=design_combos, inputs=inputs)
            self.status.showMessage(f"  Exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_summary_word(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resumen Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_summary_word
            export_summary_word(
                walls=self._walls, results_by_wall=self._results,
                output_path=fname)
            self.status.showMessage(f"  Resumen exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_shear_word(self):
        if not self._require_results() or not self._shear_data:
            QMessageBox.warning(self, "Aviso", "Primero ejecute el cálculo.")
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Cortante Resistente Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_word import export_shear_check_word
            export_shear_check_word(
                self._shear_data, self._inputs, fname)
            self.status.showMessage(f"  Cortante exportado: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Exportado:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _export_calc_memory(self):
        if not self._require_results():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Guardar Memoria de Cálculo Word", "",
            "Word Documents (*.docx)")
        if not fname:
            return
        if not fname.lower().endswith(".docx"):
            fname += ".docx"
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_calc_memory import export_calc_memory_word
            export_calc_memory_word(
                walls=self._walls, results_by_wall=self._results,
                inputs=self._inputs, output_path=fname)
            self.status.showMessage(
                f"  Memoria exportada: {os.path.basename(fname)}")
            QMessageBox.information(self, "Listo", f"Memoria exportada:\n{fname}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", str(exc))

    def _save_plots(self):
        if not self._require_results():
            return
        output_dir = QFileDialog.getExistingDirectory(
            self, "Seleccione carpeta para gráficas")
        if not output_dir:
            return
        sd = SOURCE_DIR
        if sd not in sys.path:
            sys.path.insert(0, sd)
        try:
            from wall_design_plots import save_all_plots
            for wall in self._walls:
                paths = save_all_plots(
                    wall=wall,
                    results_by_level=self._results.get(wall.name, {}),
                    output_dir=output_dir,
                    diagram_points_by_level=self._diagrams.get(wall.name, {}),
                )
                self._plot_paths[wall.name] = paths
                self.log_widget.putln(
                    f"  {wall.name}: {len(paths)} gráficas guardadas.", "ok")
            self.status.showMessage(f"  Gráficas guardadas en: {output_dir}")
            QMessageBox.information(
                self, "Listo", f"Gráficas guardadas en:\n{output_dir}")
        except Exception as exc:
            QMessageBox.critical(self, "Error guardando gráficas", str(exc))

    # ── Limpiar ───────────────────────────────────────────────────────────────

    def _clear_all(self):
        self._walls    = []
        self._results  = {}
        self._diagrams = {}
        self._inputs   = None
        self._shear_data  = {}
        self._plot_paths  = {}
        for w in (self.res_log, self.sum_log, self.shear_log, self.log_widget):
            w.clear_log()
        for cb in (self.cb_res_wall, self.cb_sum_wall, self.cb_plot_wall):
            cb.clear()
        self.progress.setVisible(False)
        self.status.showMessage(f"  {APP_NAME} v{APP_VERSION}  |  Listo")

    # ── Cierre ────────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        if self._worker and self._worker.isRunning():
            resp = QMessageBox.question(
                self, "Cálculo en progreso",
                "El cálculo está en ejecución. ¿Desea cancelar y salir?",
                QMessageBox.Yes | QMessageBox.No)
            if resp == QMessageBox.No:
                event.ignore()
                return
            self._worker.terminate()
            self._worker.wait()
        event.accept()
