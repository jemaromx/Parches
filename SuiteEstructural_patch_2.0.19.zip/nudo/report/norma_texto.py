# -*- coding: utf-8 -*-
"""Textos de norma para la memoria de nudos: cita SOLO la(s) norma(s) elegida(s).

El motor calcula NTC 2023 DEC y ACI 318-25 a la vez y sus advertencias citan
ambas ("NTC §x / ACI §y").  La memoria impresa debe citar solo lo que el
usuario selecciono; lo que se tome de la otra norma (porque la elegida no lo
trata o porque el programa solo implementa una de las dos) se rotula
explicitamente como prestamo.
"""
from __future__ import annotations

import re

_TOK_NTC = r"NTC(?: 2023)?(?: DEC)?\s*(?:Tabla |Ec\. |§)?R?\d[\d.]*\d?"
_TOK_ACI = r"ACI(?: 318-25)?\s*(?:Tabla |Ec\. |§)?R?\d[\d.]*\d?"
_PAR_NA = re.compile(rf"({_TOK_NTC})\s*/\s*({_TOK_ACI})")
_PAR_AN = re.compile(rf"({_TOK_ACI})\s*/\s*({_TOK_NTC})")

# Mensajes conocidos del motor: (texto, version solo-NTC, version solo-ACI)
_FIJOS = [
    ("(NTC §14.4.3; en Q4 rige la Ec. 8.5.6.1 = ACI 18.8.5.1)",
     "(NTC 2023 §14.4.3; en Q4 rige la Ec. 8.5.6.1)",
     # Con solo ACI este aviso (L_dh de la NTC) se omite: el motor emite
     # su propio aviso «ℓdh (ACI) …» con ACI 318-25 (ver Normas.omitir).
     "(ACI 318-25 Ec. 18.8.5.1 en Q4; §25.4.3.1 en Q2/Q3)"),
    ("(zona de rótula plástica = 2h_trabe). ACI §18.8.5.1.",
     "(zona de rótula plástica = 2h_trabe). Tomado de ACI 318-25 §18.8.5.1; "
     "la NTC no lo trata.",
     "(zona de rótula plástica = 2h_trabe). ACI 318-25 §18.8.5.1."),
    ("(ACI §18.8.2.1)",
     "(tomado de ACI 318-25 §18.8.2.1; la NTC no lo trata)",
     "(ACI 318-25 §18.8.2.1)"),
    ("— NTC 2023 §8.3.1.",
     "— NTC 2023 §8.3.1.",
     "— tomado de NTC 2023 DEC §8.3.1; ACI 318-25 no lo trata."),
]


class Normas:
    """Selector de citas segun las normas elegidas por el usuario."""

    def __init__(self, use_ntc: bool = True, use_aci: bool = True):
        if not (use_ntc or use_aci):
            use_ntc = use_aci = True
        self.ntc = bool(use_ntc)
        self.aci = bool(use_aci)

    @property
    def solo_ntc(self) -> bool:
        return self.ntc and not self.aci

    @property
    def solo_aci(self) -> bool:
        return self.aci and not self.ntc

    def ref(self, ntc: str | None = None, aci: str | None = None,
            sep: str = " / ") -> str:
        """Cita de la(s) norma(s) elegida(s); "—" si no hay ninguna."""
        partes = []
        if self.ntc and ntc:
            partes.append(ntc)
        if self.aci and aci:
            partes.append(aci)
        return sep.join(partes) or "—"

    def omitir(self, texto: str) -> bool:
        """True si el aviso del motor es propio de la norma NO elegida.

        Los avisos de espacio para ℓdh existen uno por norma (NTC §14.4.3 /
        Ec. 8.5.6.1 y ACI 318-25 §25.4.3.1 / Ec. 18.8.5.1); con una sola
        norma elegida se imprime solo el suyo."""
        if not texto or (self.ntc and self.aci):
            return False
        if self.solo_aci and texto.startswith("L_dh = ") and "NTC §14.4.3" in texto:
            return True
        if self.solo_ntc and texto.startswith("ℓdh (ACI)"):
            return True
        return False

    def adaptar(self, texto: str) -> str:
        """Reescribe un texto del motor para que cite solo lo elegido."""
        if not texto or (self.ntc and self.aci):
            return texto
        for orig, v_ntc, v_aci in _FIJOS:
            if orig in texto:
                texto = texto.replace(orig, v_ntc if self.ntc else v_aci)
        keep_ntc = self.ntc
        texto = _PAR_NA.sub(lambda m: m.group(1) if keep_ntc else m.group(2),
                            texto)
        texto = _PAR_AN.sub(lambda m: m.group(2) if keep_ntc else m.group(1),
                            texto)
        return texto


def textos_desarrollo_aci(lap) -> list[str]:
    """Líneas de la memoria para ℓd, ℓdh y ℓst según ACI 318-25."""
    q4 = getattr(lap, "ductility", "") == "Q4"
    ec_dh = ("Ec. 18.8.5.1: ℓdh = fy·db/(5.4λ√f'c)" if q4 else
             "§25.4.3.1: ℓdh = fy·ψe·ψs·ψcc·ψr·db^1.5/(21λ√f'c)")
    ec_d = ("Ec. 25.4.2.4a con (cb+Ktr)/db = 2.5"
            + ("; ≥ 2.5·ℓdh por §18.8.5.3(a)" if q4 else ""))
    return [
        "Longitudes de desarrollo (ACI 318-25 §25.4.2, §25.4.3"
        + (", §18.8.5" if q4 else "") + " y §25.5.2; f'c y fy convertidos "
        "a MPa con 1 kg/cm² = 0.0980665 MPa):",
        f"ℓd ({ec_d}; ≥ 300 mm) = {lap.Ld_ACI_cm:.1f} cm  |  "
        f"ℓdh ({ec_dh}; ≥ máx(8db, 150 mm)) = {lap.Ldh_ACI_cm:.1f} cm  |  "
        f"ℓst (Clase B, Tabla 25.5.2.1: máx(1.3ℓd, 300 mm)) = "
        f"{lap.Ls_ACI_cm:.1f} cm",
    ]
