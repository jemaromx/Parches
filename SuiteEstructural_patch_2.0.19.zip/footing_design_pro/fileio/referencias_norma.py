"""Referencias normativas de las memorias y documentos, UNA por norma.

Decisión del titular (03-oct-2026): «en la memoria impresa se deben indicar
sólo las referencias a la norma con la que se realiza el diseño». Antes cada
revisión citaba «NTC 2023 … / ACI 318-25 …» —y la memoria de aisladas citaba
la NTC siempre, y a veces el ACI 318-19—, de modo que con un diseño por ACI el
documento nombraba artículos de una norma que no se había aplicado.

Cada clave dice DE DÓNDE sale la revisión en cada norma. Los artículos se
cotejaron contra el texto de `ref/NTC 2023 DEC/NTC2023 DEC.md` y
`ref/ACI/ACI 318M-25.md` el 03-oct-2026. Un artículo nuevo se añade aquí, con
las dos normas, y no escrito a mano en el exportador.

Las referencias que no son de concreto (MDOC CFE, Meyerhof, Bowles) no
dependen de la norma de diseño y las escribe el exportador tal cual. El
método rígido de losas YA NO cita ACI 336.2R (decisión del titular,
03-oct-2026: «se debe indicar la norma utilizada»): cita el artículo de la
norma de diseño sobre la reacción del suelo.
"""
from __future__ import annotations

NTC = "NTC 2023 DEC"
ACI = "ACI 318-25"

#: clave → (NTC, ACI), sin el nombre de la norma.
_REF = {
    "seccion_critica_flexion": ("§9.4.7.4 (tabla 9.4.7.4)",
                                "§13.2.7.1 (Tabla 13.2.7.1)"),
    "flexion": ("§5.2.2.1.1.1 y §9.4.7", "§22.2, §22.3 y §13.3"),
    "as_min": ("§6.3.5.1.2", "§9.6.1.2"),
    "as_temp": ("§6.6.6.1.1", "§7.6.1.1 y §24.4.3.2"),
    "beta1": ("ec. 3.6.1", "Tabla 22.2.2.4.3"),
    "fr_flexion": ("tabla 3.8.2.2", "Tabla 21.2.2"),
    "fr_cortante": ("tabla 3.8.2.1", "Tabla 21.2.1"),
    "cortante_una_dir": ("ec. 5.5.3.2.1.a y §9.4.8",
                         "Tabla 22.5.5.1 (c) y §13.3.2"),
    "seccion_critica_cortante": ("§9.4.8.2", "§13.2.7.2 y §7.4.3.2"),
    "tope_seccion": ("ec. 5.5.2.2", "ec. 22.5.1.2"),
    "estribos": ("ec. 5.5.3.6.1.a", "§22.5.8.5.3"),
    "separacion_estribos": ("§6.3.7.6.2.2", "§9.7.6.2.2"),
    "punzonamiento": ("tabla 5.6.2.1.1 y §9.4.9", "Tabla 22.6.5.2 y §22.6.1"),
    "seccion_critica_punz": ("§9.4.9.3.1 y §6.7.4.4.1",
                             "§22.6.4.1 y §13.2.7.2"),
    "punz_refuerzo": ("tablas 5.6.2.2.2 a) y 5.6.2.2.4 a), ec. 5.6.2.2.5",
                      "Tablas 22.6.6.1 (a) y 22.6.6.3 (a), ec. 22.6.7.2"),
    "transferencia_momento": ("§6.7.4.2.2.6 y §6.7.4.4.2", "§8.4.4.2"),
    "refuerzo_lateral": ("§6.3.7.2.3 y §13.6.2", "§9.7.2.3 y §24.3.2"),
    "recubrimiento": ("tabla 9.2.2.2", "Tabla 20.5.1.3.1"),
    "ganchos": ("tabla 14.3.1", "Tabla 25.3.1"),
    "dobleces_grapas": ("tabla 14.3.2", "Tabla 25.3.2"),
    "distribucion_refuerzo": ("§9.4.7.7 y §9.4.7.8", "§13.3.3.3"),
    "espesor_minimo": ("§9.4.6.1", "§13.3.1.2"),
    "carga_excentrica": ("§9.3.2.4", "§13.2.6.1"),
    "modulo_elasticidad": ("tabla 2.2.1, clase 1 con agregado calizo",
                           "ec. 19.2.2.1.b"),
    # Reacción del suelo y método de análisis de losas y corridas: el
    # rígido (reacción en un plano) y el de placa sobre resortes (ISE).
    "reaccion_suelo": ("§9.3.2", "§13.2.6.4"),
    "analisis_ise": ("§9.3.2.5", "§13.2.6.4"),
}


def es_aci(code: str) -> bool:
    return str(code or "").upper().startswith("ACI")


def norma(code: str) -> str:
    """El nombre de la norma de diseño, como se imprime."""
    return ACI if es_aci(code) else NTC


def ref(code: str, *claves: str) -> str:
    """La referencia de una o varias revisiones en la norma de diseño.

    >>> ref("ACI 318-25", "tope_seccion")
    'ACI 318-25 ec. 22.5.1.2'
    """
    i = 1 if es_aci(code) else 0
    return norma(code) + " " + "; ".join(_REF[c][i] for c in claves)


def fr(code: str) -> str:
    """El símbolo del factor de resistencia: F_R en NTC, φ en ACI."""
    return "φ" if es_aci(code) else "F_R"
