"""
Widget de resultados — BeamDesignPro v1.4.

Muestra los resultados de diseño organizados en 3 grupos por tipo de efecto:
  • Flexión  — Mu+/Mu−, áreas de acero, factor φ, momento resistente
  • Cortante — Vu, Vc, Vmax, Vcr, Vsr, Avs, separaciones de estribos
  • Torsión  — Mt, Tch, At/s, (Av+At/s)Tot, Ast, acero total

Estructura de pestañas:
  Tab principal "Por Combinación"
    └─ sub-tabs: Flexión  |  Cortante  |  Torsión
  Tab principal "Envolvente"
    └─ sub-tabs: Flexión  |  Cortante  |  Torsión

Copiado a Excel:
  Ctrl+C en cualquier tabla copia las filas visibles (o sólo las seleccionadas
  si hay una selección activa) al portapapeles como texto TSV, listo para
  pegar directamente en Excel.

Nombres de atributos (beam_design.py):
  BeamResult    : beam_id, L, b, h, d, direccion, by_comb, envelope
  SectionResult : flex_pos, flex_neg, shear, torsion,
                  As_inf_tot, As_sup_tot, cumple,
                  comb_flex_pos, comb_flex_neg, comb_shear, comb_torsion
  FlexResult    : Mu, As, phi, Mr, cond, ok
  ShearResult   : Vu, Vc, Vmax, Vcr, Vsr, Avs, S3, S4, S5, Smax, cond, ok
  TorsionResult : Tu, Tch, req_design, At_s, Avtotal, Ast, Ast_min, cond_sec, ok
"""
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QLabel, QPushButton, QComboBox,
    QAbstractItemView, QApplication, QMenu
)
from PySide6.QtCore import Qt, QObject, QEvent, Signal
from PySide6.QtGui import QColor, QFont, QBrush


# ─────────────────────────────────────────────────────────────────────────────
# Filtro de teclado: Ctrl+C → copiar tabla al portapapeles (formato Excel/TSV)
# ─────────────────────────────────────────────────────────────────────────────

class _TableCopyFilter(QObject):
    """
    Intercepta Ctrl+C sobre QTableWidget y copia el contenido al portapapeles
    en formato TSV (tab-separated values) listo para pegar en Excel.

    Reglas de selección:
      • Si hay filas seleccionadas → copia sólo esas filas.
      • Si no hay nada seleccionado → copia todas las filas visibles.
      • La primera fila copiada es siempre el encabezado de columnas.
    """

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # type: ignore[override]
        if (isinstance(obj, QTableWidget)
                and event.type() == QEvent.KeyPress          # type: ignore[attr-defined]
                and event.key() == Qt.Key_C                  # type: ignore[attr-defined]
                and event.modifiers() == Qt.ControlModifier): # type: ignore[attr-defined]
            self._copy_to_clipboard(obj)
            return True
        return False

    @staticmethod
    def _copy_to_clipboard(tbl: QTableWidget) -> None:
        """Construye el texto TSV y lo envía al portapapeles del sistema."""
        # Encabezados (quitar saltos de línea internos)
        headers = []
        for c in range(tbl.columnCount()):
            it = tbl.horizontalHeaderItem(c)
            headers.append((it.text() if it else "").replace("\n", " "))

        # Filas a exportar: seleccionadas o todas las visibles
        sel_rows = sorted({idx.row() for idx in tbl.selectedIndexes()})
        if not sel_rows:
            sel_rows = [r for r in range(tbl.rowCount())
                        if not tbl.isRowHidden(r)]

        lines = ["\t".join(headers)]
        for row in sel_rows:
            if tbl.isRowHidden(row):
                continue
            cells = []
            for col in range(tbl.columnCount()):
                item = tbl.item(row, col)
                cells.append(item.text() if item else "")
            lines.append("\t".join(cells))

        QApplication.clipboard().setText("\n".join(lines))

# ── Paleta de colores ─────────────────────────────────────────────────────────
_PASS_BG  = QColor("#D5F5E3")   # verde claro:   sección cumple
_FAIL_BG  = QColor("#FADBD8")   # rojo claro:    sección no cumple
_NOREQ_BG = QColor("#FDFEFE")   # casi blanco:   torsión no requerida
_SEP_BG   = QColor("#1A5276")   # azul oscuro:   fila separador de barra
_SEP_FG   = QColor("#FFFFFF")
_WARN_TXT = QColor("#7D6608")   # texto aviso torsión deshabilitada

# ── Etiquetas de sección ──────────────────────────────────────────────────────
_SECS = ["Inicio", "Mitad", "Fin"]

# ── Columnas por grupo ────────────────────────────────────────────────────────
_FLEX_COLS = [
    "Sección",
    "Comb Mu+", "Mu+ (t·m)", "As flex(+) (cm²)", "φ(+)", "Mr(+) (t·m)", "Cond.Mu+",
    "Comb Mu−", "Mu− (t·m)", "As flex(−) (cm²)", "φ(−)", "Mr(−) (t·m)", "Cond.Mu−",
]

_SHEAR_COLS = [
    "Sección",
    "Comb Vu", "Vu (t)", "Vc (t)", "Vmax (t)", "Cond.Sec",
    "Vcr (t)", "Vsr (t)", "Av/s (cm²/cm)",
    "S(#3) (cm)", "S(#4) (cm)", "S(#5) (cm)", "Smax (cm)",
]

_TOR_COLS = [
    "Sección",
    "Comb(V+T)", "Mt (t·m)", "Tch (t·m)", "Cond.Dis",
    "At/s (cm²/cm)", "(Av+At/s)Tot", "Ast (cm²)", "Ast,min (cm²)",
    "As(+)Tot (cm²)", "As(−)Tot (cm²)",
]

_SEISMIC_COLS = [
    "Barra", "Marco",
    "lc (cm)", "Sc zona (cm)", "S fuera (cm)", "1er Est. (cm)",
    "Mpr,i (t·m)", "Mpr,j (t·m)", "Vg (t)", "Ve (t)", "Vc = 0",
    "rho <= 0.025", "Mr+ >= 1/2 Mr-", "Mr >= 1/4 Mx", "Observaciones",
]

_CHECK_OK  = QColor("#1E8449")
_CHECK_FAIL = QColor("#C0392B")


class ResultsWidget(QWidget):
    """Panel derecho con tablas de resultados y botones de exportación."""

    sig_export_word   = Signal()
    sig_export_memory = Signal()
    sig_export_dxf    = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._beam_results: list = []
        self._params: dict = {}

        # Metadatos de filas para filtrado: (row_idx, beam_id, comb_id, is_sep)
        self._meta_comb_flex  : list = []
        self._meta_comb_shear : list = []
        self._meta_comb_tor   : list = []
        self._meta_env_flex   : list = []
        self._meta_env_shear  : list = []
        self._meta_env_tor    : list = []
        self._meta_env_seismic: list = []

        self._build_ui()

        # Instalar filtro Ctrl+C y menú contextual en todas las tablas
        self._copy_filter = _TableCopyFilter(self)
        for tbl in self._all_tables():
            tbl.installEventFilter(self._copy_filter)
            tbl.setContextMenuPolicy(Qt.CustomContextMenu)
            tbl.customContextMenuRequested.connect(
                lambda pos, t=tbl: self._show_table_menu(pos, t))

    # ═════════════════════════════════════════════════════════════════════════
    # Construcción de la UI
    # ═════════════════════════════════════════════════════════════════════════

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        lay.addWidget(self._build_toolbar())

        self.main_tabs = QTabWidget()
        self.main_tabs.addTab(self._build_comb_tab(),  "Por Combinación")
        self.main_tabs.addTab(self._build_env_tab(),   "Envolvente")
        lay.addWidget(self.main_tabs, 1)

        self.lbl_status = QLabel("Sin resultados.")
        self.lbl_status.setStyleSheet("color:#7F8C8D; padding:2px 4px;")
        lay.addWidget(self.lbl_status)

    # ── Toolbar ───────────────────────────────────────────────────────────────

    def _build_toolbar(self) -> QWidget:
        w   = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)

        lay.addWidget(QLabel("Barra:"))
        self.cmb_barra = QComboBox()
        self.cmb_barra.setMinimumWidth(90)
        self.cmb_barra.addItem("Todas")
        self.cmb_barra.currentIndexChanged.connect(self._apply_filters)
        lay.addWidget(self.cmb_barra)

        lay.addWidget(QLabel("Comb.:"))
        self.cmb_comb = QComboBox()
        self.cmb_comb.setMinimumWidth(80)
        self.cmb_comb.addItem("Todas")
        self.cmb_comb.setToolTip("Filtro de combinación (aplica sólo a la pestaña Por Combinación)")
        self.cmb_comb.currentIndexChanged.connect(self._apply_filters)
        lay.addWidget(self.cmb_comb)

        # Aviso de copiado a Excel
        lbl_ctrl = QLabel("⌨ Ctrl+C → copiar a Excel")
        lbl_ctrl.setStyleSheet(
            "color: #5D6D7E; font-size: 8pt; padding: 0 6px;")
        lbl_ctrl.setToolTip(
            "Ctrl+C copia al portapapeles en formato Excel (TSV).\n"
            "Si hay filas seleccionadas → copia sólo la selección.\n"
            "Si no hay selección → copia todas las filas visibles.\n"
            "La primera fila siempre incluye los encabezados de columna.")
        lay.addWidget(lbl_ctrl)

        lay.addStretch()

        self.btn_word = QPushButton("📄 Resultados Word")
        self.btn_word.setObjectName("btn_word")
        self.btn_word.setToolTip("Exportar tabla de resultados a Word (.docx)")
        self.btn_word.clicked.connect(self.sig_export_word)
        self.btn_word.setEnabled(False)
        lay.addWidget(self.btn_word)

        self.btn_memory = QPushButton("📋 Memoria de Cálculo")
        self.btn_memory.setObjectName("btn_memory")
        self.btn_memory.setToolTip(
            "Exportar envolvente de resultados a Word (.docx)\n"
            "Máximos por sección con su combinación controladora")
        self.btn_memory.clicked.connect(self.sig_export_memory)
        self.btn_memory.setEnabled(False)
        lay.addWidget(self.btn_memory)

        self.btn_dxf = QPushButton("📐 Actualizar DXF")
        self.btn_dxf.setObjectName("btn_dxf")
        self.btn_dxf.setToolTip("Actualizar archivos DXF con los resultados de diseño")
        self.btn_dxf.clicked.connect(self.sig_export_dxf)
        self.btn_dxf.setEnabled(False)
        lay.addWidget(self.btn_dxf)

        # Exportar para Joint Design Pro
        self.btn_joint_json = QPushButton("Exportar a Nudos (JSON)")
        self.btn_joint_json.setObjectName("btn_joint")
        self.btn_joint_json.setToolTip(
            "Exporta las areas de acero de trabes a JSON\n"
            "para importarlas en Joint Design Pro."
        )
        self.btn_joint_json.setStyleSheet(
            "background:#1E8449; color:white; border-radius:4px; "
            "padding:5px; font-weight:bold;"
        )
        self.btn_joint_json.setEnabled(False)
        lay.addWidget(self.btn_joint_json)

        return w

    # ── Pestaña "Por Combinación" ─────────────────────────────────────────────

    def _build_comb_tab(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(2, 4, 2, 2)

        subtabs = QTabWidget()
        subtabs.setTabPosition(QTabWidget.South)

        self.tbl_comb_flex,  self._cc_flex  = self._make_table(_FLEX_COLS)
        self.tbl_comb_shear, self._cc_shear = self._make_table(_SHEAR_COLS)
        self.tbl_comb_tor,   self._cc_tor   = self._make_table(_TOR_COLS)

        subtabs.addTab(self._wrap(self.tbl_comb_flex),  "📐 Flexión")
        subtabs.addTab(self._wrap(self.tbl_comb_shear), "⚡ Cortante")
        subtabs.addTab(self._wrap(self.tbl_comb_tor),   "🔄 Torsión")

        lay.addWidget(subtabs)
        return w

    # ── Pestaña "Envolvente" ──────────────────────────────────────────────────

    def _build_env_tab(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(2, 4, 2, 2)

        subtabs = QTabWidget()
        subtabs.setTabPosition(QTabWidget.South)

        # Reutilizar los mismos mapas de columnas (columnas idénticas)
        self.tbl_env_flex,  _ = self._make_table(_FLEX_COLS)
        self.tbl_env_shear, _ = self._make_table(_SHEAR_COLS)
        self.tbl_env_tor,   _ = self._make_table(_TOR_COLS)
        self.tbl_env_seismic, self._cc_seismic = self._make_table(_SEISMIC_COLS)

        subtabs.addTab(self._wrap(self.tbl_env_flex),    "📐 Flexión")
        subtabs.addTab(self._wrap(self.tbl_env_shear),   "⚡ Cortante")
        subtabs.addTab(self._wrap(self.tbl_env_tor),     "🔄 Torsión")
        self._tab_seismic_idx = subtabs.count()
        subtabs.addTab(self._wrap(self.tbl_env_seismic), "🏗 Sísmico ACI §18")
        self._env_subtabs = subtabs

        lay.addWidget(subtabs)
        return w

    # ── Helpers de construcción ───────────────────────────────────────────────

    @staticmethod
    def _make_table(cols: list) -> tuple[QTableWidget, dict]:
        tbl = QTableWidget()
        tbl.setColumnCount(len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setAlternatingRowColors(False)
        tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setSortingEnabled(False)      # deshabilitado: filas separadoras
        hdr = tbl.horizontalHeader()
        # Todas las columnas auto-ajustan su ancho al contenido …
        hdr.setSectionResizeMode(QHeaderView.ResizeToContents)
        # … excepto la columna 0 ("Sección"): contenido corto fijo
        # para que el texto largo del separador no agrande esa columna.
        hdr.setSectionResizeMode(0, QHeaderView.Fixed)
        tbl.setColumnWidth(0, 68)
        hdr.setStretchLastSection(False)
        tbl.verticalHeader().setVisible(False)
        col_map = {c: i for i, c in enumerate(cols)}
        return tbl, col_map

    @staticmethod
    def _wrap(tbl: QTableWidget) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.addWidget(tbl)
        return w

    # ═════════════════════════════════════════════════════════════════════════
    # Carga de resultados (API pública)
    # ═════════════════════════════════════════════════════════════════════════

    def load_results(self, beam_results: list, params: dict):
        """Carga todos los resultados en las 6 tablas."""
        self._beam_results = beam_results
        self._params       = params
        with_tor           = params.get("diseno_torsion", True)

        # Limpiar tablas y metadatos
        for tbl in self._all_tables():
            tbl.setRowCount(0)
        self._clear_meta()

        # Reconstruir filtros
        self._rebuild_filters(beam_results, params)

        # Llenar tablas
        self._fill_comb(beam_results, params, with_tor)
        self._fill_env(beam_results, params, with_tor)
        has_seismic = any(getattr(br, "seismic_applicable", False) for br in beam_results)
        self._fill_env_seismic(beam_results)
        self._env_subtabs.setTabVisible(self._tab_seismic_idx, has_seismic)

        # Mensaje de torsión deshabilitada
        if not with_tor:
            self._insert_tor_disabled()

        # Habilitar botones
        has = bool(beam_results)
        self.btn_word.setEnabled(has)
        self.btn_memory.setEnabled(has)
        self.btn_dxf.setEnabled(has)
        self.btn_joint_json.setEnabled(has)

        n  = len(beam_results)
        nr = self.tbl_comb_flex.rowCount()
        self.lbl_status.setText(
            f"{n} barra(s) diseñada(s)  ·  {nr} filas (Por Combinación / Flexión)")
        self.lbl_status.setStyleSheet(
            "color:#1E8449; padding:2px 4px; font-weight:bold;")

    # ═════════════════════════════════════════════════════════════════════════
    # Llenado "Por Combinación"
    # ═════════════════════════════════════════════════════════════════════════

    def _fill_comb(self, beam_results: list, params: dict, with_tor: bool):
        for br in beam_results:
            bid  = br.beam_id
            stxt = self._sep_text(br, params)

            # Fila separador en los 3 sub-tabs
            rf = self._insert_sep(self.tbl_comb_flex,  stxt); self._meta_comb_flex .append((rf, bid, 0, True))
            rs = self._insert_sep(self.tbl_comb_shear, stxt); self._meta_comb_shear.append((rs, bid, 0, True))
            rt = self._insert_sep(self.tbl_comb_tor,   stxt); self._meta_comb_tor  .append((rt, bid, 0, True))

            for cid, sec_list in sorted(br.by_comb.items()):
                for si, _lbl in enumerate(_SECS):
                    if si >= len(sec_list):
                        continue
                    sr = sec_list[si]

                    r = self._row_flex(self.tbl_comb_flex, si, cid, cid, sr)
                    self._meta_comb_flex.append((r, bid, cid, False))

                    r = self._row_shear(self.tbl_comb_shear, si, cid, sr)
                    self._meta_comb_shear.append((r, bid, cid, False))

                    if with_tor:
                        r = self._row_tor(self.tbl_comb_tor, si, cid, sr)
                        self._meta_comb_tor.append((r, bid, cid, False))

    # ═════════════════════════════════════════════════════════════════════════
    # Llenado "Envolvente"
    # ═════════════════════════════════════════════════════════════════════════

    def _fill_env(self, beam_results: list, params: dict, with_tor: bool):
        for br in beam_results:
            bid  = br.beam_id
            stxt = self._sep_text(br, params)
            env  = br.envelope

            rf = self._insert_sep(self.tbl_env_flex,  stxt); self._meta_env_flex .append((rf, bid, 0, True))
            rs = self._insert_sep(self.tbl_env_shear, stxt); self._meta_env_shear.append((rs, bid, 0, True))
            rt = self._insert_sep(self.tbl_env_tor,   stxt); self._meta_env_tor  .append((rt, bid, 0, True))

            for si, _lbl in enumerate(_SECS):
                if si >= len(env):
                    continue
                sr = env[si]

                # Para envolvente las combs son las controladoras
                r = self._row_flex(self.tbl_env_flex, si,
                                   sr.comb_flex_pos, sr.comb_flex_neg, sr)
                self._meta_env_flex.append((r, bid, 0, False))

                r = self._row_shear(self.tbl_env_shear, si, sr.comb_shear, sr)
                self._meta_env_shear.append((r, bid, 0, False))

                if with_tor:
                    r = self._row_tor(self.tbl_env_tor, si, sr.comb_torsion, sr)
                    self._meta_env_tor.append((r, bid, 0, False))

    # ═════════════════════════════════════════════════════════════════════════
    # Llenado "Envolvente — Sísmico ACI §18"
    # ═════════════════════════════════════════════════════════════════════════

    def _fill_env_seismic(self, beam_results: list):
        tbl = self.tbl_env_seismic
        for br in beam_results:
            if not getattr(br, "seismic_applicable", False):
                continue
            # SeismicResult is identical in all 3 envelope sections; take first
            seis = br.envelope[0].seismic if br.envelope else None
            if seis is None:
                continue

            # Separator row
            sep_txt = (
                f"  BARRA {br.beam_id}  •  Dir {br.direccion}  •  "
                f"b = {br.b:.0f} cm   h = {br.h:.0f} cm   "
                f"L = {br.L:.2f} m  •  {getattr(br, 'frame_type', '?')}"
            )
            rs = self._insert_sep(tbl, sep_txt)
            self._meta_env_seismic.append((rs, br.beam_id, 0, True))

            # Data row
            row = tbl.rowCount()
            tbl.insertRow(row)
            self._meta_env_seismic.append((row, br.beam_id, 0, False))

            def _s(col, val):
                self._set(tbl, row, col, val, self._cc_seismic)

            def _ok(val: bool) -> str:
                return "OK" if val else "NO cumple"

            _s("Barra",           br.beam_id)
            _s("Marco",           seis.frame_type)
            _s("lc (cm)",         f"{seis.lc:.1f}")
            _s("Sc zona (cm)",    f"{seis.Sc:.1f}")
            _s("S fuera (cm)",    f"{seis.S_fuera:.1f}")
            _s("1er Est. (cm)",   f"{seis.primer_estribo:.1f}")
            _s("Mpr,i (t·m)",     f"{seis.Mpr_i:.3f}")
            _s("Mpr,j (t·m)",     f"{seis.Mpr_j:.3f}")
            _s("Vg (t)",          f"{seis.Vg:.3f}")
            _s("Ve (t)",          f"{seis.Ve:.3f}")
            _s("Vc = 0",          "SI" if seis.Vc_cero else "no")
            _s("rho <= 0.025",    _ok(seis.rho_max_ok))
            _s("Mr+ >= 1/2 Mr-",  _ok(seis.Mr_pos_ok))
            _s("Mr >= 1/4 Mx",    _ok(seis.Mr_min_ok))
            _s("Observaciones",   "; ".join(seis.warnings) if seis.warnings else "—")

            all_ok = seis.rho_max_ok and seis.Mr_pos_ok and seis.Mr_min_ok
            bg = _PASS_BG if all_ok else _FAIL_BG
            self._color_row(tbl, row, bg)

            # Color the check cells
            for col_name, ok_val in [
                ("rho <= 0.025",   seis.rho_max_ok),
                ("Mr+ >= 1/2 Mr-", seis.Mr_pos_ok),
                ("Mr >= 1/4 Mx",   seis.Mr_min_ok),
            ]:
                col_idx = self._cc_seismic.get(col_name)
                if col_idx is not None:
                    it = tbl.item(row, col_idx)
                    if it:
                        it.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
                        it.setForeground(QBrush(_CHECK_OK if ok_val else _CHECK_FAIL))

            # Vc=0 highlight
            vc_col = self._cc_seismic.get("Vc = 0")
            if vc_col is not None and seis.Vc_cero:
                it = tbl.item(row, vc_col)
                if it:
                    it.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
                    it.setForeground(QBrush(QColor("#884400")))

            # Warning row if needed
            if seis.warnings:
                wr = tbl.rowCount()
                tbl.insertRow(wr)
                self._meta_env_seismic.append((wr, br.beam_id, 0, True))
                nc = tbl.columnCount()
                for c in range(nc):
                    it2 = QTableWidgetItem("")
                    it2.setBackground(QBrush(QColor("#FEF9E7")))
                    it2.setFlags(Qt.ItemIsEnabled)
                    tbl.setItem(wr, c, it2)
                warn_item = QTableWidgetItem(
                    "  Advertencias:  " + "   |   ".join(seis.warnings))
                warn_item.setBackground(QBrush(QColor("#FEF9E7")))
                warn_item.setForeground(QBrush(QColor("#7D6608")))
                warn_item.setFont(QFont("Segoe UI", 8))
                warn_item.setFlags(Qt.ItemIsEnabled)
                tbl.setItem(wr, 0, warn_item)
                tbl.setSpan(wr, 0, 1, nc)
                tbl.setRowHeight(wr, 22)

    # ═════════════════════════════════════════════════════════════════════════
    # Métodos de escritura de filas
    # ═════════════════════════════════════════════════════════════════════════

    def _row_flex(self, tbl: QTableWidget, si: int,
                  cid_pos, cid_neg, sr) -> int:
        """Una fila de flexión.  cid_pos/neg pueden diferir en la envolvente."""
        cc   = self._cc_flex
        fpos = sr.flex_pos
        fneg = sr.flex_neg
        ok   = fpos.ok and fneg.ok

        row = tbl.rowCount()
        tbl.insertRow(row)
        s = lambda col, val: self._set(tbl, row, col, val, cc)

        s("Sección",           _SECS[si])
        s("Comb Mu+",          cid_pos)
        s("Mu+ (t·m)",         f"{fpos.Mu:.3f}")
        s("As flex(+) (cm²)",  f"{fpos.As:.2f}")
        s("φ(+)",               f"{fpos.phi:.3f}")
        s("Mr(+) (t·m)",        f"{fpos.Mr:.3f}")
        s("Cond.Mu+",           fpos.cond)
        s("Comb Mu−",           cid_neg)
        s("Mu− (t·m)",          f"{fneg.Mu:.3f}")
        s("As flex(−) (cm²)",   f"{fneg.As:.2f}")
        s("φ(−)",                f"{fneg.phi:.3f}")
        s("Mr(−) (t·m)",         f"{fneg.Mr:.3f}")
        s("Cond.Mu−",            fneg.cond)

        self._color_row(tbl, row, _PASS_BG if ok else _FAIL_BG)
        self._style_cond(tbl, row, "Cond.Mu+", fpos.cond, cc)
        self._style_cond(tbl, row, "Cond.Mu−", fneg.cond, cc)
        return row

    def _row_shear(self, tbl: QTableWidget, si: int, cid: int, sr) -> int:
        cc = self._cc_shear
        sh = sr.shear
        ok = sh.ok

        row = tbl.rowCount()
        tbl.insertRow(row)
        s = lambda col, val: self._set(tbl, row, col, val, cc)

        s("Sección",       _SECS[si])
        s("Comb Vu",       cid)
        s("Vu (t)",        f"{sh.Vu:.3f}")
        s("Vc (t)",        f"{sh.Vc:.3f}")
        s("Vmax (t)",      f"{sh.Vmax:.3f}")
        s("Cond.Sec",      sh.cond)
        s("Vcr (t)",       f"{sh.Vcr:.3f}")
        s("Vsr (t)",       f"{sh.Vsr:.3f}")
        s("Av/s (cm²/cm)", f"{sh.Avs:.4f}")
        s("S(#3) (cm)",    f"{sh.S3:.1f}")
        s("S(#4) (cm)",    f"{sh.S4:.1f}")
        s("S(#5) (cm)",    f"{sh.S5:.1f}")
        s("Smax (cm)",     f"{sh.Smax:.1f}")

        self._color_row(tbl, row, _PASS_BG if ok else _FAIL_BG)
        self._style_cond(tbl, row, "Cond.Sec", sh.cond, cc)
        return row

    def _row_tor(self, tbl: QTableWidget, si: int, cid: int, sr) -> int:
        cc  = self._cc_tor
        tor = sr.torsion

        # Condición y color
        if not tor.req_design:
            cond_str = "No req. diseño"
            bg       = _NOREQ_BG
        elif tor.cond_sec == "OK":
            cond_str = "OK"
            bg       = _PASS_BG
        else:
            cond_str = "Aumentar sección"
            bg       = _FAIL_BG

        row = tbl.rowCount()
        tbl.insertRow(row)
        s = lambda col, val: self._set(tbl, row, col, val, cc)

        s("Sección",          _SECS[si])
        s("Comb(V+T)",        cid)
        s("Mt (t·m)",         f"{tor.Tu:.3f}")
        s("Tch (t·m)",        f"{tor.Tch:.3f}")
        s("Cond.Dis",         cond_str)
        s("At/s (cm²/cm)",    f"{tor.At_s:.4f}")
        s("(Av+At/s)Tot",     f"{tor.Avtotal:.4f}")
        s("Ast (cm²)",        f"{tor.Ast:.2f}")
        s("Ast,min (cm²)",    f"{tor.Ast_min:.2f}")
        # Rotulados por SIGNO: As(+) es Mu+, que arma el lecho SUPERIOR.
        s("As(+)Tot (cm²)",   f"{sr.As_sup_tot:.2f}")
        s("As(−)Tot (cm²)",   f"{sr.As_inf_tot:.2f}")

        self._color_row(tbl, row, bg)
        self._style_cond(tbl, row, "Cond.Dis", cond_str, cc)
        return row

    # ═════════════════════════════════════════════════════════════════════════
    # Fila separador de barra
    # ═════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _insert_sep(tbl: QTableWidget, text: str) -> int:
        """
        Inserta una fila separador que ocupa TODAS las columnas.

        Estrategia doble:
          1. Pone items con el fondo azul en TODAS las columnas (garantiza
             que cada celda tenga el color aunque setSpan no funcione en
             alguna versión de Qt).
          2. Llama a setSpan() para fusionar visualmente la fila entera.
             Con esto el texto aparece una sola vez, a la izquierda, y no
             agranda ninguna columna de datos.
        """
        n   = tbl.columnCount()
        row = tbl.rowCount()
        tbl.insertRow(row)

        # Rellenar TODAS las celdas con el fondo del separador (texto vacío)
        for c in range(n):
            blank = QTableWidgetItem("")
            blank.setBackground(QBrush(_SEP_BG))
            blank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            tbl.setItem(row, c, blank)

        # Sobrescribir la celda 0 con el texto real
        item = QTableWidgetItem(text)
        item.setBackground(QBrush(_SEP_BG))
        item.setForeground(QBrush(_SEP_FG))
        item.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        tbl.setItem(row, 0, item)

        # Fusionar la fila completa (el texto del span no afecta el ancho
        # de la columna 0 porque está fijada con setSectionResizeMode Fixed)
        tbl.setSpan(row, 0, 1, n)
        tbl.setRowHeight(row, 24)
        return row

    @staticmethod
    def _sep_text(br, params: dict) -> str:
        """Texto completo del separador: geometría + materiales + recubrimientos."""
        fc  = params.get("fc",          250.0)
        fy  = params.get("fy",         4200.0)
        fys = params.get("fy_s",       4200.0)
        rf  = params.get("rec_flex",     6.0)
        rc  = params.get("rec_comp",     4.0)
        rl  = params.get("rec_lateral",  4.0)
        return (
            f"  BARRA {br.beam_id}  •  Dir {br.direccion}  •  "
            f"b = {br.b:.0f} cm   h = {br.h:.0f} cm   d = {br.d:.1f} cm   "
            f"L = {br.L:.2f} m  │  "
            f"f'c = {fc:.0f} kg/cm²   fy = {fy:.0f} kg/cm²   fy,s = {fys:.0f} kg/cm²  │  "
            f"Rec:  flex = {rf:.1f} cm   comp = {rc:.1f} cm   lateral = {rl:.1f} cm"
        )

    def _insert_tor_disabled(self):
        """Mensaje informativo cuando el diseño por torsión está deshabilitado."""
        for tbl in (self.tbl_comb_tor, self.tbl_env_tor):
            row = tbl.rowCount()
            tbl.insertRow(row)
            item = QTableWidgetItem(
                "  ⓘ  Diseño por torsión no habilitado "
                "— active la opción en el panel de entrada")
            item.setBackground(QBrush(QColor("#FEF9E7")))
            item.setForeground(QBrush(_WARN_TXT))
            item.setFont(QFont("Segoe UI", 9))
            item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            tbl.setItem(row, 0, item)
            tbl.setSpan(row, 0, 1, tbl.columnCount())
            tbl.setRowHeight(row, 28)

    # ═════════════════════════════════════════════════════════════════════════
    # Filtros
    # ═════════════════════════════════════════════════════════════════════════

    def _rebuild_filters(self, beam_results: list, params: dict):
        self.cmb_barra.blockSignals(True)
        self.cmb_comb.blockSignals(True)

        self.cmb_barra.clear()
        self.cmb_barra.addItem("Todas")
        for br in beam_results:
            self.cmb_barra.addItem(str(br.beam_id))

        self.cmb_comb.clear()
        self.cmb_comb.addItem("Todas")
        for cid in params.get("comb_ids", []):
            self.cmb_comb.addItem(str(cid))

        self.cmb_barra.blockSignals(False)
        self.cmb_comb.blockSignals(False)

    def _apply_filters(self):
        bsel = self.cmb_barra.currentText()
        csel = self.cmb_comb.currentText()

        # Tablas comb: se aplica filtro de combinación en filas de datos
        # Tablas env:  solo filtro de barra (no hay filtro por combinación)
        _pairs = [
            (self.tbl_comb_flex,    self._meta_comb_flex,   True),
            (self.tbl_comb_shear,   self._meta_comb_shear,  True),
            (self.tbl_comb_tor,     self._meta_comb_tor,    True),
            (self.tbl_env_flex,     self._meta_env_flex,    False),
            (self.tbl_env_shear,    self._meta_env_shear,   False),
            (self.tbl_env_tor,      self._meta_env_tor,     False),
            (self.tbl_env_seismic,  self._meta_env_seismic, False),
        ]
        for tbl, meta, use_comb in _pairs:
            for (row, bid, cid, is_sep) in meta:
                show = True
                if bsel != "Todas" and str(bid) != bsel:
                    show = False
                elif use_comb and not is_sep and csel != "Todas":
                    if str(cid) != csel:
                        show = False
                tbl.setRowHidden(row, not show)

    # ═════════════════════════════════════════════════════════════════════════
    # Helpers de escritura en celdas
    # ═════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _set(tbl: QTableWidget, row: int, col_name: str, value, col_map: dict):
        col = col_map.get(col_name)
        if col is None:
            return
        if isinstance(value, (int, float)):
            item = QTableWidgetItem()
            item.setData(Qt.DisplayRole, value)
        else:
            item = QTableWidgetItem(str(value))
        item.setTextAlignment(Qt.AlignCenter)
        tbl.setItem(row, col, item)

    @staticmethod
    def _color_row(tbl: QTableWidget, row: int, color: QColor):
        for c in range(tbl.columnCount()):
            it = tbl.item(row, c)
            if it:
                it.setBackground(QBrush(color))

    @staticmethod
    def _style_cond(tbl: QTableWidget, row: int,
                    col_name: str, cond_str: str, col_map: dict):
        """Aplica color de texto a la celda de condición."""
        col = col_map.get(col_name)
        if col is None:
            return
        it = tbl.item(row, col)
        if it is None:
            return
        it.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        if cond_str == "OK":
            it.setForeground(QBrush(QColor("#1E8449")))
        elif "Aumentar" in cond_str:
            it.setForeground(QBrush(QColor("#C0392B")))
        elif "No req" in cond_str:
            it.setForeground(QBrush(QColor("#7D6608")))

    # ═════════════════════════════════════════════════════════════════════════
    # Limpiar / estado
    # ═════════════════════════════════════════════════════════════════════════

    def _show_table_menu(self, pos, tbl: QTableWidget):
        """Menú contextual con opción Copiar para cualquier tabla."""
        menu = QMenu(self)
        act_copy = menu.addAction("📋  Copiar selección  (Ctrl+C)")
        act_all  = menu.addAction("📋  Copiar toda la tabla")
        action   = menu.exec(tbl.viewport().mapToGlobal(pos))
        if action == act_copy:
            _TableCopyFilter._copy_to_clipboard(tbl)
        elif action == act_all:
            # Forzar copia de todas las filas visibles sin importar la selección
            old_sel = tbl.selectedIndexes()
            tbl.clearSelection()
            _TableCopyFilter._copy_to_clipboard(tbl)
            # restaurar selección
            for idx in old_sel:
                tbl.setCurrentIndex(idx)

    def clear_results(self):
        for tbl in self._all_tables():
            tbl.setRowCount(0)
        self._clear_meta()
        self.btn_word.setEnabled(False)
        self.btn_memory.setEnabled(False)
        self.btn_dxf.setEnabled(False)
        self.lbl_status.setText("Sin resultados.")
        self.lbl_status.setStyleSheet("color:#7F8C8D; padding:2px 4px;")
        self._beam_results = []
        self._params = {}

    def _all_tables(self):
        return (self.tbl_comb_flex, self.tbl_comb_shear, self.tbl_comb_tor,
                self.tbl_env_flex,  self.tbl_env_shear,  self.tbl_env_tor,
                self.tbl_env_seismic)

    def _clear_meta(self):
        self._meta_comb_flex   = []
        self._meta_comb_shear  = []
        self._meta_comb_tor    = []
        self._meta_env_flex    = []
        self._meta_env_shear   = []
        self._meta_env_tor     = []
        self._meta_env_seismic = []
