# config/settings.py
APP_NAME    = "Column Steel Design Pro"
APP_VERSION = "1.0.0"
APP_AUTHOR  = "Structural Engineering"

# ── Propiedades elasticas del acero ──────────────────────────────────────────
E_STEEL = 2_039_000.0   # kg/cm2  (200 000 MPa)
G_STEEL =   784_000.0   # kg/cm2  ( 76 900 MPa)

# ── Factores de resistencia ───────────────────────────────────────────────────
#  NTC Acero CDMX 2023
NTC_FR_FLEX  = 0.90   # FR_b  — Cap. 7
NTC_FR_SHEAR = 0.90   # FR_v  — Cap. 8  (1.00 cuando h/tw<=2.24*sqrt(E/Fy))
NTC_FR_COMP  = 0.90   # FR_c  — Cap. 6
NTC_FR_TENS  = 0.90   # FR_t  — Cap. 5

#  AISC 360-22
AISC_PHI_B = 0.90     # phi_b — F1
AISC_PHI_V = 1.00     # phi_v — G1 (laminados I; 0.90 canales/cajon)
AISC_PHI_C = 0.90     # phi_c — E1
AISC_PHI_T = 0.90     # phi_t — D2

# ── Limite de esbeltez ────────────────────────────────────────────────────────
#  NTC Art. 3.3.2.1 / AISC E2
MAX_SLENDERNESS_COLUMN = 200   # columnas en compresion
MAX_SLENDERNESS_BRACE  = 200   # contravientos en compresion
MAX_SLENDERNESS_TENS   = 300   # miembros en tension

# ── Materiales (Fy y Fu en kg/cm2) ────────────────────────────────────────────
STEEL_MATERIALS = [
    {"name": "A-36  (Fy=2530, Fu=4080)",         "fy": 2530.0, "fu": 4080.0},
    {"name": "A-42  (Fy=2950, Fu=4200) NMX",     "fy": 2950.0, "fu": 4200.0},
    {"name": "A-52  (Fy=3660, Fu=5200) NMX",     "fy": 3660.0, "fu": 5200.0},
    {"name": "A572 Gr50 (Fy=3515, Fu=4570)",      "fy": 3515.0, "fu": 4570.0},
    {"name": "A572 Gr60 (Fy=4220, Fu=5275)",      "fy": 4220.0, "fu": 5275.0},
    {"name": "A572 Gr65 (Fy=4570, Fu=5500)",      "fy": 4570.0, "fu": 5500.0},
    {"name": "A992     (Fy=3515, Fu=4570)",       "fy": 3515.0, "fu": 4570.0},
    {"name": "A500 Gr B (Fy=3170, Fu=4010)",      "fy": 3170.0, "fu": 4010.0},
    {"name": "A500 Gr C (Fy=3520, Fu=4290)",      "fy": 3520.0, "fu": 4290.0},
    {"name": "A913 Gr65 (Fy=4570, Fu=5500)",      "fy": 4570.0, "fu": 5500.0},
    {"name": "A913 Gr70 (Fy=4920, Fu=5840)",      "fy": 4920.0, "fu": 5840.0},
    {"name": "Manual / Definido por usuario",      "fy":    0.0, "fu":    0.0},
]

# ── Colores UI ────────────────────────────────────────────────────────────────
COLOR_PRIMARY   = "#1B4F72"
COLOR_SECONDARY = "#2874A6"
COLOR_ACCENT    = "#E74C3C"
COLOR_OK        = "#1E8449"
COLOR_WARN      = "#D68910"
COLOR_FAIL      = "#C0392B"
COLOR_BG        = "#EBF5FB"
COLOR_PANEL     = "#FFFFFF"
COLOR_TEXT      = "#1C2833"
COLOR_HEADER    = "#FFFFFF"

COLORS = {
    "primary":   COLOR_PRIMARY,
    "secondary": COLOR_SECONDARY,
    "accent":    COLOR_ACCENT,
    "success":   COLOR_OK,
    "warning":   COLOR_WARN,
    "bg":        COLOR_BG,
    "panel":     COLOR_PANEL,
    "text":      COLOR_TEXT,
    "header_fg": COLOR_HEADER,
}
