﻿# config/settings.py  — Seccion Design Pro
APP_NAME     = "Seccion Design Pro"
APP_VERSION  = "1.0.0"
APP_SUBTITLE = "Propiedades Geométricas · Secciones Compuestas · Trabe Compuesta"
CODE_BADGE   = "NTC DEA 2023 / NTC DEC 2023 / AISC 360-22"

COLORS = {
    "primary":   "#1B4F72",
    "secondary": "#2874A6",
    "bg":        "#EBF5FB",
    "panel":     "#FFFFFF",
    "text":      "#1C2833",
    "accent":    "#E74C3C",
    "success":   "#1E8449",
    "warning":   "#D68910",
}
TABLE_OK   = "#D5F5E3"
TABLE_WARN = "#FDEBD0"
TABLE_FAIL = "#FADBD8"
TABLE_SEP  = "#D4E6F1"

E_STEEL = 2_039_000   # kg/cm²

STEEL_MATERIALS = {
    "A36   (Fy=2530 kg/cm²)":         {"Fy": 2530,  "Fu": 4080,  "E": E_STEEL},
    "A572 Gr.42 (Fy=2950 kg/cm²)":    {"Fy": 2950,  "Fu": 4220,  "E": E_STEEL},
    "A572 Gr.50 (Fy=3515 kg/cm²)":    {"Fy": 3515,  "Fu": 4570,  "E": E_STEEL},
    "A992  (Fy=3515 kg/cm²)":         {"Fy": 3515,  "Fu": 4500,  "E": E_STEEL},
    "A572 Gr.60 (Fy=4218 kg/cm²)":    {"Fy": 4218,  "Fu": 5274,  "E": E_STEEL},
    "A913 Gr.50 (Fy=3515 kg/cm²)":    {"Fy": 3515,  "Fu": 4570,  "E": E_STEEL},
    "A913 Gr.65 (Fy=4570 kg/cm²)":    {"Fy": 4570,  "Fu": 5630,  "E": E_STEEL},
    "A500 Gr.B Rect (Fy=3163 kg/cm²)":{"Fy": 3163,  "Fu": 4000,  "E": E_STEEL},
    "A500 Gr.B Circ (Fy=2812 kg/cm²)":{"Fy": 2812,  "Fu": 4000,  "E": E_STEEL},
    "A500 Gr.C Rect (Fy=3515 kg/cm²)":{"Fy": 3515,  "Fu": 4336,  "E": E_STEEL},
    "A53 Gr.B PIPE (Fy=2460 kg/cm²)": {"Fy": 2460,  "Fu": 4218,  "E": E_STEEL},
    "A-248 IMCA (Fy=2530 kg/cm²)":    {"Fy": 2530,  "Fu": 4080,  "E": E_STEEL},
}

# Pernos Nelson (Asa cm², Fu kg/cm²)
NELSON_STUDS = {
    '1/2" ø 12.7 mm': {"Asa": 1.27, "Fu": 4285},
    '5/8" ø 15.9 mm': {"Asa": 1.98, "Fu": 4285},
    '3/4" ø 19.1 mm': {"Asa": 2.85, "Fu": 4285},
    '7/8" ø 22.2 mm': {"Asa": 3.87, "Fu": 4285},
    '1"   ø 25.4 mm': {"Asa": 5.07, "Fu": 4285},
}

# Canales conectores CE soldados (tf, tw en cm, Lc en cm)
CE_CONNECTORS = {
    "C3x4.1  Lc=75 mm":  {"tf": 0.694, "tw": 0.432, "Lc": 7.5},
    "C4x5.4  Lc=75 mm":  {"tf": 0.752, "tw": 0.467, "Lc": 7.5},
    "C4x5.4  Lc=100 mm": {"tf": 0.752, "tw": 0.467, "Lc": 10.0},
    "C5x6.7  Lc=100 mm": {"tf": 0.813, "tw": 0.482, "Lc": 10.0},
    "C6x8.2  Lc=100 mm": {"tf": 0.871, "tw": 0.508, "Lc": 10.0},
    "C6x8.2  Lc=150 mm": {"tf": 0.871, "tw": 0.508, "Lc": 15.0},
    "C8x11.5 Lc=150 mm": {"tf": 0.991, "tw": 0.559, "Lc": 15.0},
}

# Hilti X-ENP HVB — altura de clavo en cm (Qn aproximado, verificar con fabricante)
HILTI_HVB = {
    "HVB 75  (ø 4.5 mm, h=75 mm)":  {"h_nail": 7.5,  "d_nail": 0.45},
    "HVB 95  (ø 4.5 mm, h=95 mm)":  {"h_nail": 9.5,  "d_nail": 0.45},
    "HVB 110 (ø 4.5 mm, h=110 mm)": {"h_nail": 11.0, "d_nail": 0.45},
}
