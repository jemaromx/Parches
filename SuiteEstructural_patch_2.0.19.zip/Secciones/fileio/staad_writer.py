# fileio/staad_writer.py — Exporta propiedades de sección calculadas en este
# proyecto hacia un modelo de STAAD Pro abierto, como una nueva "User
# Provided Table" (UPT) de tipo GENERAL.
#
# Patrón de conexión idéntico al usado (solo lectura) en
# baseplate_design_pro/fileio/openstaad_reader.py y
# compositecolumn_design_pro/fileio/openstaad_reader.py.
#
# Métodos de escritura usados (confirmados contra el paquete `openstaadpy`
# instalado — módulo openstaadpy.os_analytical.osproperty.OSProperty):
#   CreateUPTTable(table_type)            -> id de tabla (8 = GENERAL)
#   AddUPTPropertyGENERAL(table_id, name, AX, D, TD, B, TB, IZ, IY, IX,
#                          SZ, SY, AY, AZ, PZ, PY, Cw, DEE) -> 0 si OK
#   OJO: el wrapper rotula el 6.º valor como «torsional_constant», pero su
#   propia descripción dice «(IZ)» y el orden real es el de la tabla GENERAL
#   del Technical Reference de STAAD (§5.19, UPT): AX D TD B TB IZ IY IX SZ
#   SY AY AZ PZ PY. Hasta el 18-oct-2026 se mandaba J en IZ e Ix en IX: el
#   modelo recibía la inercia fuerte como torsión y la torsión (0) como Iz.
#   CreatePropertyFromUPTTable(table_id, name) -> id de propiedad (>0) o -1
#
# IMPORTANTE — mapeo de ejes: STAAD Pro usa ejes locales de miembro donde
# el eje "z" local es habitualmente el eje fuerte de flexión y el eje "y"
# local el eje débil (convención distinta a la de este proyecto, donde "x"
# es el eje fuerte). El mapeo usado aquí es:
#   AX=A, D=d, TD=tf, B=bf, TB=tw, IZ=Ix (fuerte->local z), IY=Iy, IX=J,
#   SZ=Sx, SY=Sy, AY=Avy (o estimado), AZ=Avx, PZ=Zx, PY=Zy, Cw=Cw, DEE=hw
# No se pudo verificar este mapeo contra una sesión real de STAAD Pro
# abierta (sin acceso a un modelo activo en este entorno). Antes de confiar
# en los resultados de flexión/cortante asignados a un miembro real, verificar
# en STAAD Pro (View > Property > General) que D, B, IZ, IY coinciden con
# los valores esperados para el perfil exportado.
from __future__ import annotations
from typing import Tuple, Optional

try:
    from openstaadpy import os_analytical
    _AVAIL = True
except ImportError:
    _AVAIL = False

_UPT_TABLE_TYPE_GENERAL = 8


def props_from_full_section(r: dict) -> dict:
    """
    Adapta el dict de resultado de core.geometry.full_section() (sección
    geométrica genérica, sin forma de perfil W/HSS) al formato canónico
    {A,d,bf,tf,tw,Ix,Iy,Sx,Sy,Zx,Zy,J,Cw,Avx,Avy} esperado por
    export_section_to_staad().

    Para una sección 2D genérica no hay patín/alma definidos: tf/tw/Cw se
    reportan en 0.0. J es la de Saint-Venant por elemento finito
    (core/torsion.py); hasta el 18-oct-2026 se mandaba 0. El módulo
    plástico Zx/Zy se aproxima con el elástico (Sx/Sy), ya que
    full_section() no calcula módulos plásticos.
    """
    sx = min(r.get("Sx_top", 0.0), r.get("Sx_bot", 0.0)) or max(r.get("Sx_top", 0.0), r.get("Sx_bot", 0.0))
    sy = min(r.get("Sy_der", 0.0), r.get("Sy_izq", 0.0)) or max(r.get("Sy_der", 0.0), r.get("Sy_izq", 0.0))
    return {
        "A": r.get("A", 0.0),
        "d": r.get("y_top", 0.0) - r.get("y_bot", 0.0),
        "bf": r.get("x_der", 0.0) - r.get("x_izq", 0.0),
        "tf": 0.0, "tw": 0.0,
        "Ix": r.get("Ixx_c", 0.0), "Iy": r.get("Iyy_c", 0.0),
        "Sx": sx, "Sy": sy, "Zx": sx, "Zy": sy,
        "J": r.get("J", 0.0), "Cw": 0.0,
        "Avx": r.get("Avx", 0.0), "Avy": r.get("Avy", 0.0),
    }


def props_from_transformed_section(r: dict) -> dict:
    """
    Adapta el dict de resultado de core.composite_section
    (transformed_concrete_steel / transformed_steel_filled) al formato
    canónico esperado por export_section_to_staad(). Igual que en
    props_from_full_section(), no hay patín/alma ni módulo plástico
    definidos para la sección transformada compuesta: se reportan en 0.0
    o se aproximan con el valor elástico.
    """
    sx = min(r.get("Sx_top", 0.0), r.get("Sx_bot", 0.0)) or max(r.get("Sx_top", 0.0), r.get("Sx_bot", 0.0))
    sy = min(r.get("Sy_der", 0.0), r.get("Sy_izq", 0.0)) or max(r.get("Sy_der", 0.0), r.get("Sy_izq", 0.0))
    sp = r.get("sp", {})
    return {
        "A": r.get("A_tr", 0.0),
        "d": sp.get("d", 0.0), "bf": sp.get("bf", 0.0),
        "tf": 0.0, "tw": 0.0,
        "Ix": r.get("Itr_x", 0.0), "Iy": r.get("Itr_y", 0.0),
        "Sx": sx, "Sy": sy, "Zx": sx, "Zy": sy,
        "J": r.get("J_tr", 0.0), "Cw": 0.0,
        "Avx": r.get("Avx", 0.0), "Avy": r.get("Avy", 0.0),
    }


def connect_to_staad() -> Tuple[bool, str, Optional[object]]:
    """
    Conecta a una instancia de STAAD Pro abierta con un modelo activo.

    Retorna (éxito, mensaje, objeto_staad_o_None).
    """
    if not _AVAIL:
        return False, ("openstaadpy no está instalado.\n"
                        "Instale con: pip install openstaadpy"), None
    try:
        staad = os_analytical.connect()
    except Exception as exc:
        return False, f"No se pudo conectar a STAAD Pro: {exc}", None
    return True, "Conectado a STAAD Pro.", staad


def export_section_to_staad(staad, props: dict, table_name: str,
                             length_unit: str = "m") -> Tuple[bool, str]:
    """
    Crea una nueva User Provided Table (tipo GENERAL) en el modelo STAAD
    activo, con una sección cuyas propiedades geométricas son las de
    `props` (dict con keys A, d, bf, tf, tw, Ix, Iy, Sx, Sy, Zx, Zy, J, Cw,
    todas en cm/cm²/cm³/cm⁴, igual que el resto del proyecto).

    `length_unit`: unidad de longitud ACTIVA del modelo STAAD ("m", "cm",
    "in", "ft"). OpenSTAAD no expone un método confiable para consultar la
    unidad activa (ver fileio/staad_units.py de los proyectos hermanos,
    donde GetInputUnitForLength() no está confirmado); por eso se solicita
    al usuario y se convierte explícitamente desde cm.

    Retorna (éxito, mensaje).
    """
    factors = {"m": 0.01, "cm": 1.0, "in": 1.0 / 2.54, "ft": 0.01 / 0.3048}
    if length_unit not in factors:
        return False, f"Unidad de longitud no soportada: {length_unit}"
    L = factors[length_unit]   # cm -> unidad activa (longitudes)
    A_ = L**2                  # cm² -> unidad²
    I_ = L**4                  # cm⁴ -> unidad⁴
    S_ = L**3                  # cm³ -> unidad³
    CW_ = L**6                 # cm⁶ -> unidad⁶

    try:
        prop = staad.Property
    except Exception as exc:
        return False, f"No se pudo acceder a Property de STAAD: {exc}"

    A   = props.get("A", 0.0)  * A_
    d   = props.get("d", 0.0)  * L
    tf  = props.get("tf", 0.0) * L
    bf  = props.get("bf", 0.0) * L
    tw  = props.get("tw", 0.0) * L
    J   = props.get("J", 0.0)  * I_
    Iy  = props.get("Iy", 0.0) * I_
    Ix  = props.get("Ix", 0.0) * I_
    Sx  = props.get("Sx", 0.0) * S_
    Sy  = props.get("Sy", 0.0) * S_
    Zx  = props.get("Zx", Sx)  * (S_ if "Zx" in props else 1.0)
    Zy  = props.get("Zy", Sy)  * (S_ if "Zy" in props else 1.0)
    Cw  = props.get("Cw", 0.0) * CW_
    hw  = max(props.get("d", 0.0) - 2 * props.get("tf", 0.0), 0.0) * L
    Avy = props.get("Avy", props.get("A", 0.0) * 0.5) * A_
    Avx = props.get("Avx", props.get("A", 0.0) * 0.5) * A_

    try:
        table_id = prop.CreateUPTTable(_UPT_TABLE_TYPE_GENERAL)
        if table_id is None or table_id < 0:
            return False, f"STAAD no pudo crear la tabla UPT (código {table_id})."

        result = prop.AddUPTPropertyGENERAL(
            table_id, table_name,
            A, d, tf, bf, tw, Ix, Iy, J,      # IZ, IY, IX (ver cabecera)
            Sx, Sy, Avy, Avx, Zx, Zy, Cw, hw,
        )
        # El wrapper de openstaadpy retorna bool (True=éxito), no el código
        # entero 0/negativo documentado en la firma COM original.
        if not result:
            return False, f"STAAD rechazó la sección '{table_name}' (resultado: {result})."

        prop_id = prop.CreatePropertyFromUPTTable(table_id, table_name)
        if prop_id is None or prop_id <= 0:
            return False, (f"Tabla UPT creada, pero no se pudo generar la propiedad "
                            f"de sección '{table_name}' (código {prop_id}).")
    except Exception as exc:
        return False, f"Error al exportar la sección a STAAD: {exc}"

    return True, (f"Sección '{table_name}' creada en STAAD Pro (propiedad ID {prop_id}). "
                  "Asígnela a los miembros deseados desde STAAD Pro.")
