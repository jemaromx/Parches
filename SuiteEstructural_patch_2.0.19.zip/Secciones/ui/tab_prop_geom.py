# ui/tab_prop_geom.py  — Tab "Prop. Geom. Secc."
from __future__ import annotations
import math
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, QPushButton,
    QSpinBox, QSplitter, QScrollArea, QTabWidget, QTextEdit,
    QRadioButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QSizePolicy, QApplication, QFileDialog, QMessageBox,
    QInputDialog
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QKeySequence

from core.geometry import full_section
from ui.widgets import MplCanvas, NavToolbar, set_item
from fileio.word_exporter import export_tab_memory
from fileio.staad_writer import connect_to_staad, export_section_to_staad, props_from_full_section
from config.settings import COLORS

P  = COLORS["primary"]
S  = COLORS["secondary"]
BG = COLORS["bg"]
SEP_COLOR = "#D4E6F1"


# ── Tabla editable de coordenadas ─────────────────────────────────────────────

#: Ancho del cuadro de control izquierdo, px.
ANCHO_PANEL = 290
#: Ancho mínimo de un QSpinBox: el estilo de la suite reserva 20 px a las
#: flechas (`padding-right`), y con 54-64 px el número quedaba tapado.
ANCHO_SPIN = 84


def _vaciar_layout(layout) -> None:
    """Quita y destruye TODO lo que cuelga de `layout`, también lo que está
    dentro de sub-layouts (los renglones de los huecos)."""
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()
        elif item.layout() is not None:
            _vaciar_layout(item.layout())
            item.layout().deleteLater()

class CoordTable(QTableWidget):
    """Tabla editable X/Y con Ctrl+C → TSV."""

    def __init__(self, n_rows: int, parent=None):
        super().__init__(n_rows, 3, parent)
        self.setHorizontalHeaderLabels(["ID", "X (cm)", "Y (cm)"])
        hh = self.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Fixed)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        self.setColumnWidth(0, 36)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        font = QFont("Segoe UI", 8)
        self.setFont(font)
        for r in range(n_rows):
            it = QTableWidgetItem(str(r + 1))
            it.setFlags(Qt.ItemIsEnabled)
            it.setBackground(QColor(BG))
            it.setTextAlignment(Qt.AlignCenter)
            self.setItem(r, 0, it)
            for c in (1, 2):
                it2 = QTableWidgetItem("0.00")
                it2.setTextAlignment(Qt.AlignCenter)
                self.setItem(r, c, it2)
        self.setMinimumHeight(80)
        self.setMaximumHeight(min(180, 28 + n_rows * 22))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self._copy()
        else:
            super().keyPressEvent(event)

    def _copy(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r0 = min(r.topRow()    for r in ranges)
        r1 = max(r.bottomRow() for r in ranges)
        c0 = min(r.leftColumn()  for r in ranges)
        c1 = max(r.rightColumn() for r in ranges)
        hdrs = [self.horizontalHeaderItem(c).text() for c in range(c0, c1 + 1)]
        lines = ["\t".join(hdrs)]
        for row in range(r0, r1 + 1):
            cells = [(self.item(row, c).text() if self.item(row, c) else "") for c in range(c0, c1 + 1)]
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))

    def get_points(self) -> list[tuple[float, float]]:
        pts = []
        for r in range(self.rowCount()):
            try:
                x = float(self.item(r, 1).text())
                y = float(self.item(r, 2).text())
                pts.append((x, y))
            except (AttributeError, ValueError):
                pts.append((0.0, 0.0))
        return pts


# ── Tabla de resultados con Ctrl+C ────────────────────────────────────────────
class ResultTable(QTableWidget):
    def __init__(self, parent=None):
        super().__init__(0, 3, parent)
        self.setHorizontalHeaderLabels(["Propiedad", "Valor", "Unidad"])
        hh = self.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setFont(QFont("Segoe UI", 8))
        self.setWordWrap(False)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self._copy()
        else:
            super().keyPressEvent(event)

    def _copy(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r0 = min(r.topRow()    for r in ranges)
        r1 = max(r.bottomRow() for r in ranges)
        lines = []
        for row in range(r0, r1 + 1):
            cells = [(self.item(row, c).text() if self.item(row, c) else "") for c in range(3)]
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))


# ── Tab principal ─────────────────────────────────────────────────────────────
class TabPropGeom(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._hole_tables: list[CoordTable] = []
        self._outer_table: CoordTable | None = None
        self._result: dict = {}
        self._build_ui()

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        spl = QSplitter(Qt.Horizontal)
        spl.setCollapsible(0, False)
        spl.setCollapsible(1, False)

        # ── Panel izquierdo — entradas ─────────────────────────────────────────
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setFrameShape(QScrollArea.NoFrame)
        left_w = QWidget()
        # Ancho MÍNIMO, no fijo: con el contenido fijo en 290 px el área de
        # scroll (que la suite ensancha a lo que pide el contenido) quedaba
        # más ancha y dejaba una franja vacía entre el cuadro de control y
        # los resultados. Así el panel llena su columna.
        left_w.setMinimumWidth(ANCHO_PANEL)
        lv = QVBoxLayout(left_w)
        lv.setSpacing(6)
        lv.setContentsMargins(8, 8, 8, 8)

        # Tipo
        grp_tipo = QGroupBox("Tipo de Sección")
        ht = QHBoxLayout(grp_tipo)
        ht.setContentsMargins(8, 16, 8, 8)
        self.rb_maciza = QRadioButton("Sección Maciza")
        self.rb_hueca  = QRadioButton("Sección Hueca")
        self.rb_maciza.setChecked(True)
        ht.addWidget(self.rb_maciza)
        ht.addWidget(self.rb_hueca)
        lv.addWidget(grp_tipo)

        # Contorno exterior
        grp_ext = QGroupBox("Contorno Exterior (sentido horario)")
        ev = QVBoxLayout(grp_ext)
        ev.setContentsMargins(8, 16, 8, 8)
        ev.setSpacing(4)
        rn = QHBoxLayout()
        rn.addWidget(QLabel("N° vértices:"))
        self.spin_n_ext = QSpinBox()
        self.spin_n_ext.setRange(3, 100)
        self.spin_n_ext.setValue(4)
        self.spin_n_ext.setMinimumWidth(ANCHO_SPIN)
        rn.addWidget(self.spin_n_ext)
        rn.addStretch()
        ev.addLayout(rn)
        btn_gen = QPushButton("Generar tabla exterior")
        btn_gen.clicked.connect(self._gen_outer_table)
        ev.addWidget(btn_gen)
        self.outer_table_container = QVBoxLayout()
        self.outer_table_container.setSpacing(0)
        ev.addLayout(self.outer_table_container)
        lv.addWidget(grp_ext)

        # Huecos
        self.grp_huecos = QGroupBox("Huecos (sentido antihorario)")
        hv = QVBoxLayout(self.grp_huecos)
        hv.setContentsMargins(8, 16, 8, 8)
        hv.setSpacing(4)
        rh = QHBoxLayout()
        rh.addWidget(QLabel("N° huecos:"))
        self.spin_n_holes = QSpinBox()
        self.spin_n_holes.setRange(1, 10)
        self.spin_n_holes.setValue(1)
        self.spin_n_holes.setMinimumWidth(ANCHO_SPIN)
        rh.addWidget(self.spin_n_holes)
        rh.addStretch()
        hv.addLayout(rh)
        self.hole_pts_spins: list[QSpinBox] = []
        self.hole_config_container = QVBoxLayout()
        self.hole_config_container.setSpacing(2)
        hv.addLayout(self.hole_config_container)
        btn_gh = QPushButton("Generar tablas de huecos")
        btn_gh.clicked.connect(self._gen_hole_tables)
        hv.addWidget(btn_gh)
        self.hole_tables_container = QVBoxLayout()
        self.hole_tables_container.setSpacing(4)
        hv.addLayout(self.hole_tables_container)
        lv.addWidget(self.grp_huecos)
        self.grp_huecos.setVisible(False)

        self.rb_maciza.toggled.connect(self._on_type_change)
        self.rb_hueca.toggled.connect(self._on_type_change)
        self.spin_n_holes.valueChanged.connect(self._update_hole_config)

        btn_calc = QPushButton("⚙  Calcular Propiedades")
        btn_calc.setObjectName("btn_run")
        btn_calc.clicked.connect(self._calculate)
        lv.addWidget(btn_calc)

        self.btn_export_word = QPushButton("📄  Exportar Word")
        self.btn_export_word.setEnabled(False)
        self.btn_export_word.clicked.connect(self._export_word)
        lv.addWidget(self.btn_export_word)

        self.btn_export_staad = QPushButton("📐  Exportar a STAAD")
        self.btn_export_staad.setEnabled(False)
        self.btn_export_staad.clicked.connect(self._export_staad)
        lv.addWidget(self.btn_export_staad)
        lv.addStretch()
        left_scroll.setWidget(left_w)

        # ── Panel derecho — vista + resultados ────────────────────────────────
        right_tabs = QTabWidget()

        # Tab única: Vista + Resultados lado a lado
        tab_vista = QWidget()
        tab_vista_layout = QHBoxLayout(tab_vista)
        tab_vista_layout.setContentsMargins(4, 4, 4, 4)

        inner_spl = QSplitter(Qt.Horizontal)
        inner_spl.setCollapsible(0, False)
        inner_spl.setCollapsible(1, False)

        # Canvas
        canvas_w = QWidget()
        cv = QVBoxLayout(canvas_w)
        cv.setContentsMargins(0, 0, 0, 0)
        self.canvas = MplCanvas(figsize=(5, 5), dpi=90)
        self.toolbar = NavToolbar(self.canvas, canvas_w)
        cv.addWidget(self.toolbar)
        cv.addWidget(self.canvas)

        # Tabla resultados
        self.res_table = ResultTable()

        inner_spl.addWidget(canvas_w)
        inner_spl.addWidget(self.res_table)
        inner_spl.setStretchFactor(0, 1)
        inner_spl.setStretchFactor(1, 1)
        inner_spl.setSizes([480, 400])
        tab_vista_layout.addWidget(inner_spl)
        right_tabs.addTab(tab_vista, "Vista de la Sección")

        # Tab Memoria
        tab_mem = QWidget()
        mv = QVBoxLayout(tab_mem)
        mv.setContentsMargins(4, 4, 4, 4)
        self.mem_text = QTextEdit()
        self.mem_text.setReadOnly(True)
        self.mem_text.setFont(QFont("Consolas", 8))
        mv.addWidget(self.mem_text)
        right_tabs.addTab(tab_mem, "Memoria de Cálculo")

        spl.addWidget(left_scroll)
        spl.addWidget(right_tabs)
        spl.setStretchFactor(0, 0)
        spl.setStretchFactor(1, 1)
        spl.setSizes([290, 900])
        root.addWidget(spl)

        self._gen_outer_table()
        self._update_hole_config()

    # ── Tipo de sección ────────────────────────────────────────────────────────
    def _on_type_change(self):
        self.grp_huecos.setVisible(self.rb_hueca.isChecked())

    def _update_hole_config(self):
        # Cada renglón es un QHBoxLayout: `takeAt` devuelve el layout y sus
        # widgets (etiqueta y spin) seguían vivos, encimándose con los
        # nuevos al subir y bajar el número de huecos. Se borran a fondo.
        _vaciar_layout(self.hole_config_container)
        self.hole_pts_spins.clear()
        for i in range(self.spin_n_holes.value()):
            row = QHBoxLayout()
            row.addWidget(QLabel(f"Hueco {i+1} – N° vértices:"))
            sp = QSpinBox(); sp.setRange(3, 50); sp.setValue(4)
            sp.setMinimumWidth(ANCHO_SPIN)
            self.hole_pts_spins.append(sp)
            row.addWidget(sp)
            row.addStretch()
            self.hole_config_container.addLayout(row)

    # ── Generación de tablas ───────────────────────────────────────────────────
    def _gen_outer_table(self):
        while self.outer_table_container.count():
            w = self.outer_table_container.takeAt(0)
            if w.widget():
                w.widget().deleteLater()
        self._outer_table = CoordTable(self.spin_n_ext.value())
        self.outer_table_container.addWidget(self._outer_table)
        self._outer_table.cellChanged.connect(self._live_preview)

    def _gen_hole_tables(self):
        _vaciar_layout(self.hole_tables_container)
        self._hole_tables.clear()
        for i, sp in enumerate(self.hole_pts_spins):
            lbl = QLabel(f"Hueco {i+1}")
            lbl.setStyleSheet(f"font-weight:bold; color:{P}; margin-top:4px;")
            self.hole_tables_container.addWidget(lbl)
            t = CoordTable(sp.value())
            t.cellChanged.connect(self._live_preview)
            self._hole_tables.append(t)
            self.hole_tables_container.addWidget(t)

    # ── Vista previa en vivo ───────────────────────────────────────────────────
    def _live_preview(self):
        if not self._outer_table:
            return
        try:
            outer = self._outer_table.get_points()
            holes = [t.get_points() for t in self._hole_tables] if self.rb_hueca.isChecked() else []
            self._draw_section(outer, holes)
        except Exception:
            pass

    def _draw_section(self, outer: list, holes: list):
        ax = self.canvas.ax
        ax.cla()
        ax.set_aspect('equal')
        ax.set_facecolor("#F8F9FA")
        if len(outer) >= 3:
            xs = [p[0] for p in outer] + [outer[0][0]]
            ys = [p[1] for p in outer] + [outer[0][1]]
            ax.fill(xs[:-1], ys[:-1], color="#AED6F1", alpha=0.65, zorder=1)
            ax.plot(xs, ys, color=P, lw=1.8, zorder=2)
            for i, (x, y) in enumerate(outer):
                ax.annotate(str(i + 1), (x, y), fontsize=7,
                            ha='center', va='bottom', color=P, zorder=6)
        for h in holes:
            if len(h) >= 3:
                hx = [p[0] for p in h] + [h[0][0]]
                hy = [p[1] for p in h] + [h[0][1]]
                ax.fill(hx[:-1], hy[:-1], color='white', zorder=3)
                ax.plot(hx, hy, color='#7F8C8D', lw=1.2, ls='--', zorder=4)
        if self._result:
            cx = self._result.get("Cx", 0)
            cy = self._result.get("Cy", 0)
            ax.plot(cx, cy, 'r+', ms=14, mew=2.2, zorder=5, label=f"CG ({cx:.2f}, {cy:.2f})")
            ax.legend(fontsize=7, loc='best')
        ax.set_xlabel("X (cm)", fontsize=8)
        ax.set_ylabel("Y (cm)", fontsize=8)
        ax.set_title("Sección — Vista Previa", fontsize=9, color=P, fontweight='bold')
        ax.grid(True, ls=':', alpha=0.35)
        ax.tick_params(labelsize=7)
        self.canvas.redraw()

    # ── Cálculo ───────────────────────────────────────────────────────────────
    def _calculate(self):
        if not self._outer_table:
            return
        outer = self._outer_table.get_points()
        holes = [t.get_points() for t in self._hole_tables] if self.rb_hueca.isChecked() else []
        if len(outer) < 3:
            return
        try:
            r = full_section(outer, holes or None)
        except Exception as e:
            self.mem_text.setPlainText(f"Error en cálculo:\n{e}")
            return
        self._result = r
        self._draw_section(outer, holes)
        self._fill_results(r)
        self._fill_memory(r, outer, holes)
        self.btn_export_word.setEnabled(True)
        self.btn_export_staad.setEnabled(True)

    def _export_word(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar memoria de cálculo", "", "Word (*.docx)"
        )
        if not path:
            return
        result = export_tab_memory(self, path)
        if result.startswith("ERROR"):
            QMessageBox.critical(self, "Exportar Word", result)
        else:
            QMessageBox.information(self, "Exportar Word", f"Documento creado:\n{result}")

    def _export_staad(self):
        if not self._result:
            return
        name, ok = QInputDialog.getText(self, "Exportar a STAAD",
                                         "Nombre de la sección en STAAD:",
                                         text="SECC_GEOM")
        if not ok or not name.strip():
            return
        unit, ok = QInputDialog.getItem(self, "Exportar a STAAD",
                                         "Unidad de longitud activa en el modelo STAAD:",
                                         ["m", "cm", "in", "ft"], 0, False)
        if not ok:
            return
        ok2, msg, staad = connect_to_staad()
        if not ok2:
            QMessageBox.critical(self, "Exportar a STAAD", msg)
            return
        props = props_from_full_section(self._result)
        ok3, msg2 = export_section_to_staad(staad, props, name.strip(), unit)
        if ok3:
            QMessageBox.information(self, "Exportar a STAAD", msg2)
        else:
            QMessageBox.critical(self, "Exportar a STAAD", msg2)

    # ── Tabla de resultados ────────────────────────────────────────────────────
    def _fill_results(self, r: dict):
        tbl = self.res_table
        tbl.setRowCount(0)

        def sep(label: str):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            it = QTableWidgetItem(f"  {label}")
            it.setBackground(QColor(SEP_COLOR))
            it.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
            it.setForeground(QColor(P))
            it.setFlags(Qt.ItemIsEnabled)
            tbl.setItem(ri, 0, it)
            for c in (1, 2):
                it2 = QTableWidgetItem("")
                it2.setBackground(QColor(SEP_COLOR))
                it2.setFlags(Qt.ItemIsEnabled)
                tbl.setItem(ri, c, it2)

        def row(prop: str, val: str, unit: str):
            ri = tbl.rowCount(); tbl.insertRow(ri)
            for c, txt in enumerate([prop, val, unit]):
                it = QTableWidgetItem(txt)
                it.setTextAlignment(Qt.AlignCenter if c > 0 else Qt.AlignLeft | Qt.AlignVCenter)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                tbl.setItem(ri, c, it)

        # ── Área y perímetros ─────────────────────────────────────────────────
        sep("ÁREA Y PERÍMETROS")
        row("Área neta (A)",           f"{r['A']:.4f}",                "cm²")
        row("Perímetro exterior",       f"{r['perim_ext']:.4f}",       "cm")
        row("Perímetro interior (sum)", f"{r.get('perim_int',0):.4f}", "cm")

        # ── Centroide ─────────────────────────────────────────────────────────
        sep("CENTROIDE")
        row("Cx  (desde origen)",       f"{r['Cx']:.4f}", "cm")
        row("Cy  (desde origen)",       f"{r['Cy']:.4f}", "cm")

        # ── Momentos de inercia desde el centroide ────────────────────────────
        sep("MOMENTOS DE INERCIA — CENTROIDE")
        row("Ixx  (∫y² dA)",        f"{r['Ixx_c']:.4f}", "cm⁴")
        row("Iyy  (∫x² dA)",        f"{r['Iyy_c']:.4f}", "cm⁴")
        row("Ixy  (∫xy  dA)",            f"{r['Ixy_c']:.4f}", "cm⁴")

        # ── Momentos de inercia desde el origen ──────────────────────────────
        sep("MOMENTOS DE INERCIA — ORIGEN (0,0)")
        row("Ixx₀  (∫y² dA)", f"{r['Ixx_o']:.4f}", "cm⁴")
        row("Iyy₀  (∫x² dA)", f"{r['Iyy_o']:.4f}", "cm⁴")

        # ── Ejes principales ──────────────────────────────────────────────────
        sep("EJES PRINCIPALES")
        row("I₁  (I máximo)",       f"{r['Imax']:.4f}",    "cm⁴")
        row("I₂  (I mínimo)",       f"{r['Imin']:.4f}",    "cm⁴")
        row("Ángulo θ",             f"{r['theta_deg']:.3f}", "°")

        # ── Radios de giro ────────────────────────────────────────────────────
        sep("RADIOS DE GIRO")
        row("r_x  = √(Ixx/A)",     f"{r['rx']:.4f}", "cm")
        row("r_y  = √(Iyy/A)",     f"{r['ry']:.4f}", "cm")

        # ── Módulos de sección elástico ───────────────────────────────────────
        sep("MÓDULOS DE SECCIÓN ELÁSTICO")
        row("S_x sup  = Ixx / c_top",  f"{r['Sx_top']:.4f}", "cm³")
        row("S_x inf  = Ixx / c_bot",  f"{r['Sx_bot']:.4f}", "cm³")
        row("S_y der  = Iyy / c_der",  f"{r['Sy_der']:.4f}", "cm³")
        row("S_y izq  = Iyy / c_izq",  f"{r['Sy_izq']:.4f}", "cm³")

        # ── Áreas de cortante ─────────────────────────────────────────────────
        sep("ÁREAS DE CORTANTE EFECTIVAS")
        row("A_vy  (cortante en Y ↕)", f"{r['Avy']:.4f}", "cm²")
        row("A_vx  (cortante en X ↔)", f"{r['Avx']:.4f}", "cm²")

        sep("CONSTANTE DE TORSIÓN")
        row("J  (Saint-Venant, MEF)", f"{r.get('J', 0):.4f}", "cm⁴")

        tbl.resizeRowsToContents()

    # ── Memoria de cálculo ─────────────────────────────────────────────────────
    def _fill_memory(self, r: dict, outer: list, holes: list):
        tipo = "Sección Hueca" if holes else "Sección Maciza"
        lines = [
            "═" * 62,
            "  PROPIEDADES GEOMÉTRICAS DE SECCIÓN ARBITRARIA",
            f"  Tipo: {tipo}   |   Vértices exteriores: {len(outer)}",
            "═" * 62,
            "",
            "1. ÁREA Y PERÍMETROS",
            f"   A (neta)       = {r['A']:.6f} cm²",
            f"   Perim. ext.    = {r['perim_ext']:.4f} cm",
            f"   Perim. int.    = {r.get('perim_int', 0):.4f} cm",
            "",
            "2. CENTROIDE (desde el origen de coordenadas)",
            f"   Cx             = {r['Cx']:.6f} cm",
            f"   Cy             = {r['Cy']:.6f} cm",
            "",
            "3. MOMENTOS DE INERCIA — CENTROIDE",
            f"   Ixx_c = ∫y² dA = {r['Ixx_c']:.6f} cm⁴",
            f"   Iyy_c = ∫x² dA = {r['Iyy_c']:.6f} cm⁴",
            f"   Ixy_c = ∫xy dA = {r['Ixy_c']:.6f} cm⁴   (puede ser negativo)",
            "",
            "4. MOMENTOS DE INERCIA — ORIGEN (0,0)",
            f"   Ixx_o           = {r['Ixx_o']:.6f} cm⁴",
            f"   Iyy_o           = {r['Iyy_o']:.6f} cm⁴",
            "   Teorema de Steiner: Ixx_o = Ixx_c + A·Cy²",
            f"   Verificación: {r['Ixx_c']:.4f} + {r['A']:.4f}·{r['Cy']:.4f}² = "
            f"{r['Ixx_c'] + r['A']*r['Cy']**2:.4f} cm⁴",
            "",
            "5. EJES PRINCIPALES",
            "   I₁,₂ = (Ixx+Iyy)/2 ± √[((Ixx-Iyy)/2)² + Ixy²]",
            f"   I₁ (máx)        = {r['Imax']:.6f} cm⁴",
            f"   I₂ (mín)        = {r['Imin']:.6f} cm⁴",
            f"   θ  (°)          = {r['theta_deg']:.4f}°  (rotación desde X hasta eje 1)",
            "",
            "6. RADIOS DE GIRO",
            f"   r_x = √(Ixx/A)  = {r['rx']:.4f} cm",
            f"   r_y = √(Iyy/A)  = {r['ry']:.4f} cm",
            "",
            "7. MÓDULOS DE SECCIÓN ELÁSTICO",
            f"   S_x,sup = Ixx_c / (y_top − Cy) = {r['Sx_top']:.4f} cm³",
            f"   S_x,inf = Ixx_c / (Cy − y_bot) = {r['Sx_bot']:.4f} cm³",
            f"   S_y,der = Iyy_c / (x_der − Cx) = {r['Sy_der']:.4f} cm³",
            f"   S_y,izq = Iyy_c / (Cx − x_izq) = {r['Sy_izq']:.4f} cm³",
            "",
            "8. ÁREAS DE CORTANTE EFECTIVAS (integración numérica, 600 tiras)",
            f"   A_vy (cortante en Y) = {r['Avy']:.4f} cm²",
            f"   A_vx (cortante en X) = {r['Avx']:.4f} cm²",
            "",
            "9. CONSTANTE DE TORSIÓN DE SAINT-VENANT",
            "   Función de alabeo ω: ∇²ω = 0, ∂ω/∂n = y·nx − x·ny en cada contorno",
            "   J = ∫(x² + y² + x·∂ω/∂y − y·∂ω/∂x) dA",
            "   (Timoshenko & Goodier §101; MEF con triángulos lineales, dos",
            "   mallas h y h/2 y extrapolación de Richardson)",
            f"   J              = {r.get('J', 0):.4f} cm⁴",
            f"   Error estimado = {100 * r.get('J_err', 0):.2f} %",
            "═" * 62,
        ]
        self.mem_text.setPlainText("\n".join(lines))
