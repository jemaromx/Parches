# fileio/word_exporter.py
"""
Memoria de cálculo detallada en Word.
Incluye gráfica PLT y diagrama de interacción como imágenes incrustadas.
"""

from __future__ import annotations
from io import BytesIO
from typing import List
from design.designer import MemberDesignResult

try:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    import docx.oxml
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    MPLOK = True
except ImportError:
    MPLOK = False

# Paleta de colores consistente con la UI
_C = {
    "primary":   "#1B4F72",
    "secondary": "#2874A6",
    "success":   "#1E8449",
    "warning":   "#D68910",
    "accent":    "#E74C3C",
}


def export_word(results: List[MemberDesignResult],
                project_name: str,
                path: str) -> bool:
    if not DOCX_OK:
        return False

    doc = Document()
    _set_landscape(doc)
    _add_title(doc, project_name)

    for r in results:
        _add_member_section(doc, r)
        doc.add_page_break()

    doc.save(path)
    return True


def _set_landscape(doc):
    # Hoja CARTA apaisada (tablas anchas de trabes de acero) + fuente base
    # unificada de la suite y títulos sin numeración automática.
    try:
        from suite_shared.docx_style import aplicar_estilo_memoria
        aplicar_estilo_memoria(doc, apaisado=True)
    except Exception:
        section = doc.sections[0]
        section.page_width  = Cm(27.94)
        section.page_height = Cm(21.59)


def _add_title(doc, project_name: str):
    p = doc.add_heading("MEMORIA DE CÁLCULO – DISEÑO DE TRABES DE ACERO", 0)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(f"Proyecto: {project_name}").alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph()


def _add_member_section(doc, r: MemberDesignResult):
    # Encabezado de miembro
    doc.add_heading(f"Miembro {r.member_id}  –  {r.profile}", 1)

    # Tabla de datos generales
    tbl = doc.add_table(rows=2, cols=6)
    tbl.style = "Table Grid"
    hdrs = ["Longitud (m)", "Ly (m)", "Lz (m)", "Clasificación", "Tipo", "Código"]
    vals = [f"{r.length_m:.3f}", f"{r.Ly_cm/100:.3f}", f"{r.Lz_cm/100:.3f}",
            r.classification, "Flexocompresión" if r.is_beam_col else "Flexión", r.code]
    for i, (h2, v) in enumerate(zip(hdrs, vals)):
        tbl.cell(0, i).text = h2
        tbl.cell(1, i).text = v
        _bold_cell(tbl.cell(0, i))
    doc.add_paragraph()

    # Capacidades
    doc.add_heading("Capacidades de la sección", 2)
    has_tors = r.tors is not None and r.tors.applicable
    n_caps = 6 if has_tors else 5
    cap_tbl = doc.add_table(rows=2, cols=n_caps)
    cap_tbl.style = "Table Grid"
    _F = "FR" if r.code == "NTC 2023" else "φ"
    cap_hdrs = [f"{_F}Mnx (ton·m)", f"{_F}Mny (ton·m)", f"{_F}Vn (ton)",
                "Lp (m)", "Lr (m)"]
    cap_vals = [
        f"{r.flex.phi_Mnx_tm:.4f}" if r.flex else "-",
        f"{r.flex.phi_Mny_tm:.4f}" if r.flex else "-",
        f"{r.shear.phi_Vn:.4f}"    if r.shear else "-",
        f"{r.flex.ltb.Lp/100:.3f}" if r.flex else "-",
        f"{r.flex.ltb.Lr/100:.3f}" if r.flex else "-",
    ]
    if has_tors:
        cap_hdrs.append(f"{_F}Tn (ton·m)")
        cap_vals.append(f"{r.tors.phi_Tn_tm:.4f}")
    for i, (h2, v) in enumerate(zip(cap_hdrs, cap_vals)):
        cap_tbl.cell(0, i).text = h2
        cap_tbl.cell(1, i).text = v
        _bold_cell(cap_tbl.cell(0, i))
    doc.add_paragraph()

    # Envolvente
    doc.add_heading("Envolvente de resultados", 2)
    _add_envelope_table(doc, r)
    doc.add_paragraph()

    # Aberturas en alma
    if r.openings_result and r.openings_result.opening_results:
        _add_openings_section(doc, r)
        doc.add_paragraph()

    # Gráfica PLT o diagrama de interacción
    if MPLOK:
        if not r.is_beam_col and r.ltb_curve:
            doc.add_heading("Curva de Pandeo Lateral Torsional (PLT)", 2)
            _add_ltb_figure(doc, r)
            doc.add_paragraph()
        elif r.is_beam_col and r.int_diagram:
            doc.add_heading("Diagrama de Interacción P-M", 2)
            _add_interaction_figure(doc, r)
            doc.add_paragraph()
        # Gráfica de cortante (siempre que haya datos de shear)
        if r.shear is not None:
            doc.add_heading(
                "Gráfica de Cortante Nominal Vn vs h/t  "
                + ("(NTC 2023 DEA Fig. C8.3.2.1)" if r.code == "NTC 2023"
                   else "(AISC 360-22 G2.1)"), 2)
            _add_shear_figure(doc, r)
            doc.add_paragraph()

    # Memoria textual
    doc.add_heading("Desarrollo del cálculo", 2)
    for line in r.calc_memory:
        p = doc.add_paragraph(line)
        p.style = "Normal"
        run = p.runs[0] if p.runs else p.add_run(line)
        if line.startswith("─") or line.startswith("=") or line.startswith("►"):
            run.bold = True
            run.font.color.rgb = RGBColor(0x1B, 0x3A, 0x5C)
        elif line.startswith("  NOTA:") or line.startswith("  ***"):
            run.font.color.rgb = RGBColor(0xC0, 0x39, 0x2B)
        p.paragraph_format.space_after = Pt(2)


def _add_ltb_figure(doc, r: MemberDesignResult):
    """Incrusta la curva PLT como imagen en el documento Word."""
    try:
        Lb_m, Mn_tm, phi_Mn_tm = r.ltb_curve
        Lp_m   = r.flex.ltb.Lp / 100.0
        Lr_m   = r.flex.ltb.Lr / 100.0
        Lb_act = r.Ly_cm / 100.0
        is_ntc = (r.code == "NTC 2023")

        fig, ax = plt.subplots(figsize=(12, 5))
        ax.plot(Lb_m, Mn_tm,     color=_C["secondary"], lw=2,
                label="Mn (nominal)")
        ax.plot(Lb_m, phi_Mn_tm, color=_C["primary"],   lw=2.5, ls="--",
                label=("FR·Mn (diseño)" if is_ntc else "φMn (diseño)"))

        ax.axvline(Lp_m,   color=_C["success"], ls=":", lw=1.8,
                   label=f"{'Lu' if is_ntc else 'Lp'} = {Lp_m:.3f} m")
        ax.axvline(Lr_m,   color=_C["accent"],  ls=":", lw=1.8,
                   label=f"Lr = {Lr_m:.3f} m")
        ax.axvline(Lb_act, color=_C["warning"], ls="-", lw=2.5,
                   label=f"Lb = {Lb_act:.3f} m (no arriostrada)")

        # Puntos de envolvente
        mkrs = ["o", "s", "^"]
        lbls = ["Inicio", "Medio", "Fin"]
        for i, (lbl, pt) in enumerate(zip(lbls, r.envelope)):
            ax.scatter(Lb_act, abs(pt.Mz), zorder=7, s=90, marker=mkrs[i],
                       edgecolors="black", lw=0.8,
                       label=f"{lbl}: {abs(pt.Mz):.3f} t·m")

        ymax = max(Mn_tm) if Mn_tm else 1
        ax.axvspan(0,    Lp_m, alpha=0.09, color="green")
        ax.axvspan(Lp_m, Lr_m, alpha=0.09, color="orange")
        if max(Lb_m) > Lr_m:
            ax.axvspan(Lr_m, max(Lb_m), alpha=0.09, color="red")

        zone_lbl = (
            [("Fluencia", "green"), ("PLT Inelástico", "darkorange"), ("PLT Elástico", "red")]
            if is_ntc else
            [("Yielding", "green"), ("Inelastic LTB", "darkorange"), ("Elastic LTB", "red")]
        )
        for x, (lbl, col) in zip([Lp_m*0.45, (Lp_m+Lr_m)/2, Lr_m*1.3], zone_lbl):
            if 0 < x < max(Lb_m):
                ax.text(x, ymax * 0.97, lbl, ha="center", fontsize=8,
                        color=col, style="italic", va="top")

        ax.set_xlabel("Longitud no arriostrada Lb (m)", fontsize=11)
        ax.set_ylabel("Momento (ton·m)", fontsize=11)
        ax.set_title(
            f"Curva PLT – Miembro {r.member_id}  {r.profile}  [{r.classification}]  "
            f"[{r.code}]",
            fontsize=12, fontweight="bold", color=_C["primary"])
        ax.legend(fontsize=8, loc="upper right")
        ax.grid(True, alpha=0.3)
        ax.set_xlim(left=0, right=max(Lb_m))
        ax.set_ylim(bottom=0)
        fig.tight_layout()

        _embed_figure(doc, fig, width_cm=24.0)
        plt.close(fig)
    except Exception as exc:
        doc.add_paragraph(f"[No se pudo generar la gráfica PLT: {exc}]")


def _add_interaction_figure(doc, r: MemberDesignResult):
    """Incrusta el diagrama de interacción P-M con los puntos de combinaciones."""
    try:
        P_list, M_list = r.int_diagram
        fig, ax = plt.subplots(figsize=(7, 8))

        ax.plot(M_list, P_list, color=_C["primary"], lw=2.5,
                label="Diagrama φPn–φMn")
        ax.axhline(0, color="gray", lw=0.8, ls="--")

        # Zona de tensión
        ax.fill_betweenx(P_list, M_list,
                         where=[p < 0 for p in P_list],
                         alpha=0.07, color="blue", label="Tensión")
        ax.fill_betweenx(P_list, M_list,
                         where=[p >= 0 for p in P_list],
                         alpha=0.07, color="red", label="Compresión")

        # Puntos de combinaciones
        if r.all_points:
            Pu_pts = [pt.Pu for pt in r.all_points]
            Mu_pts = [abs(pt.Mz) for pt in r.all_points]
            ax.scatter(Mu_pts, Pu_pts, color="gray", alpha=0.4, s=15, zorder=4,
                       label=f"Combinaciones ({len(r.all_points)} pts)")

        # Puntos de envolvente
        mkrs = ["o", "s", "^"]
        lbls = ["Inicio", "Medio", "Fin"]
        for i, (lbl, pt) in enumerate(zip(lbls, r.envelope)):
            clr = _C["accent"] if pt.ratio_H > 1.0 else _C["success"]
            ax.scatter(abs(pt.Mz), pt.Pu, zorder=8, s=100, marker=mkrs[i],
                       color=clr, edgecolors="black", lw=0.8,
                       label=f"{lbl}: ({abs(pt.Mz):.2f}, {pt.Pu:.2f}) H={pt.ratio_H:.3f}")

        ax.set_xlabel("Momento φMnx (ton·m)", fontsize=11)
        ax.set_ylabel("Carga axial φPn (ton)  [+ compresión]", fontsize=11)
        ax.set_title(
            f"Diagrama P–M – Miembro {r.member_id}  {r.profile}\n"
            f"[{r.classification}]  [{r.code}]",
            fontsize=11, fontweight="bold", color=_C["primary"])
        ax.legend(fontsize=8, loc="lower left")
        ax.grid(True, alpha=0.3)
        ax.set_xlim(left=0)
        fig.tight_layout()

        _embed_figure(doc, fig, width_cm=12.0)
        plt.close(fig)
    except Exception as exc:
        doc.add_paragraph(f"[No se pudo generar el diagrama de interacción: {exc}]")


def _add_openings_section(doc, r: MemberDesignResult):
    """Sección de memoria para aberturas en alma: tabla resumen + figura de sección."""
    op_res = r.openings_result
    if op_res is None or not op_res.opening_results:
        return

    doc.add_heading(
        "Aberturas en alma — NTC 2023 DEA Art. 8.9" if r.code == "NTC 2023"
        else "Aberturas en alma — tomado de NTC 2023 DEA Art. 8.9 "
             "(AISC 360-22 no trata aberturas en alma)", 2)

    # Tabla resumen de resultados
    _F = "FR" if r.code == "NTC 2023" else "φ"
    cols = ["Abertura", "x (m)", "Tipo", "Vu (ton)", f"{_F}Vna (ton)",
            "Ratio V", "M_vv (t·m)", f"{_F}Mn_tee (t·m)", "Ratio VV",
            "Geom.", "Estado"]
    tbl = doc.add_table(rows=len(op_res.opening_results) + 1, cols=len(cols))
    tbl.style = "Table Grid"
    for i, h in enumerate(cols):
        tbl.cell(0, i).text = h
        _bold_cell(tbl.cell(0, i))

    for row_i, r_op in enumerate(op_res.opening_results, 1):
        op = r_op.opening
        desc = f"Circ. D={op.D:.0f}" if op.is_circular else f"Rect. {op.bo:.0f}×{op.ao:.0f}"
        ok_str = "✓" if r_op.checks_ok else "FALLA"
        vals = [
            op.label or f"A{row_i}", f"{r_op.x_m:.3f}", desc,
            f"{abs(r_op.Vu):.4f}", f"{r_op.phi_Vna:.4f}",
            f"{r_op.ratio_V:.3f}",
            f"{r_op.M_vv:.4f}", f"{r_op.phi_Mn_tee:.4f}",
            f"{r_op.ratio_vv:.3f}",
            "✓" if r_op.geom_ok else "⚠",
            ok_str,
        ]
        for col_i, v in enumerate(vals):
            c = tbl.cell(row_i, col_i)
            c.text = v
            try:
                rv = float(v)
                if col_i in (5, 8) and rv > 1.0:
                    c.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xC0, 0x39, 0x2B)
                    for run in c.paragraphs[0].runs:
                        run.bold = True
                elif col_i in (5, 8) and rv > 0.85:
                    c.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xF3, 0x9C, 0x12)
            except Exception:
                pass
    doc.add_paragraph()

    # Figura de sección transversal con aberturas
    if MPLOK:
        _add_section_with_openings_figure(doc, r)
        doc.add_paragraph()


def _add_section_with_openings_figure(doc, r: MemberDesignResult):
    """Dibuja la sección transversal del perfil con las aberturas marcadas."""
    try:
        sp     = None
        # Intentar obtener propiedades desde los resultados de flexión
        # (las propiedades están en el MemberDesignResult indirectamente;
        # los datos geométricos se usan del OpeningCheckResult)
        op_res = r.openings_result

        fig, axes = plt.subplots(1, 2, figsize=(13, 5))

        # ── Subfig 1: Alzado de la trabe con posiciones de aberturas ──────────
        ax1 = axes[0]
        ax1.set_title(f"Miembro {r.member_id} — Aberturas en alzado",
                      fontsize=10, color=_C["primary"])

        L = r.length_m
        ax1.set_xlim(-0.05 * L, 1.05 * L)
        ax1.set_ylim(-0.6, 0.6)
        ax1.set_aspect("equal")
        ax1.set_xlabel("Longitud (m)", fontsize=9)
        ax1.set_yticks([])

        # Trabe como rectángulo delgado
        h_ref = op_res.opening_results[0].h_web / 100.0 if op_res.opening_results else 0.4
        h_scale = min(h_ref, 0.5)
        ax1.add_patch(plt.Rectangle((0, -h_scale / 2), L, h_scale,
                                     color="#AED6F1", alpha=0.6, zorder=1))
        ax1.axhline(0, color="gray", lw=0.5, ls="--")

        colors_op = ["#E74C3C", "#F39C12", "#27AE60", "#8E44AD", "#2980B9"]
        for i, r_op in enumerate(op_res.opening_results):
            op = r_op.opening
            c_op = colors_op[i % len(colors_op)]
            clr_fill = c_op if r_op.ratio_V <= 1.0 and r_op.ratio_vv <= 1.0 else "#C0392B"

            x_c = op.x_m
            e_scaled = op.e / 100.0 * (h_scale / h_ref)

            if op.is_circular:
                r_c = op.D / 200.0 * (h_scale / h_ref)
                circ = plt.Circle((x_c, e_scaled), r_c,
                                   color=clr_fill, alpha=0.75, zorder=3)
                ax1.add_patch(circ)
                ax1.text(x_c, -h_scale / 2 - 0.07,
                         f"{op.label or f'A{i+1}'}\nD={op.D:.0f}",
                         ha="center", fontsize=7, color=c_op)
            else:
                w_r = op.ao / 100.0 * (h_scale / h_ref)
                h_r = op.bo / 100.0 * (h_scale / h_ref)
                ax1.add_patch(plt.Rectangle(
                    (x_c - w_r / 2, e_scaled - h_r / 2), w_r, h_r,
                    color=clr_fill, alpha=0.75, zorder=3))
                ax1.text(x_c, -h_scale / 2 - 0.09,
                         f"{op.label or f'A{i+1}'}\n{op.bo:.0f}×{op.ao:.0f}",
                         ha="center", fontsize=7, color=c_op)

            # Ratio V
            ax1.text(x_c, h_scale / 2 + 0.04,
                     f"R={r_op.ratio_V:.2f}",
                     ha="center", fontsize=7,
                     color="#C0392B" if r_op.ratio_V > 1.0 else "#1E8449")

        ax1.grid(True, axis="x", alpha=0.25)

        # ── Subfig 2: Detalle de la sección transversal (primera abertura) ────
        ax2 = axes[1]
        r_op0 = op_res.opening_results[0]
        op0   = r_op0.opening
        h_w   = r_op0.h_web   # cm

        ax2.set_title(
            f"Sección transversal — {op0.label or 'Abertura 1'}  "
            f"(x={r_op0.x_m:.2f} m)",
            fontsize=10, color=_C["primary"])
        ax2.set_xlim(-30, 30)
        ax2.set_ylim(-h_w * 0.7, h_w * 0.7)
        ax2.set_aspect("equal")
        ax2.set_xlabel("Ancho (cm)", fontsize=9)
        ax2.set_ylabel("Altura (cm)", fontsize=9)

        # Alma
        ax2.add_patch(plt.Rectangle((-1, -h_w / 2), 2, h_w,
                                     color="#AED6F1", alpha=0.5))
        ax2.axhline(0, color="gray", lw=0.5, ls="--", label="Eje neutro")
        ax2.axhline(h_w / 2,  color="#1B4F72", lw=1.0, ls="-")
        ax2.axhline(-h_w / 2, color="#1B4F72", lw=1.0, ls="-")

        # Abertura
        e0 = op0.e
        if op0.is_circular:
            circ = plt.Circle((0, e0), op0.D / 2,
                               color="#E74C3C", alpha=0.55, zorder=3)
            ax2.add_patch(circ)
        else:
            ax2.add_patch(plt.Rectangle(
                (-op0.ao / 2, e0 - op0.bo / 2), op0.ao, op0.bo,
                color="#E74C3C", alpha=0.55, zorder=3))

        # Dimensiones
        ax2.annotate("", xy=(-15, -h_w / 2), xytext=(-15, h_w / 2),
                     arrowprops=dict(arrowstyle="<->", color="gray"))
        ax2.text(-20, 0, f"h={h_w:.0f}cm", ha="center", fontsize=8, color="gray",
                 rotation=90, va="center")

        ax2.legend(fontsize=8, loc="lower right")
        ax2.grid(True, alpha=0.2)

        fig.tight_layout()
        _embed_figure(doc, fig, width_cm=23.0)
        plt.close(fig)
    except Exception as exc:
        doc.add_paragraph(f"[No se pudo generar la figura de aberturas: {exc}]")


def _add_shear_figure(doc, r: MemberDesignResult):
    """
    Gráfica de cortante nominal Vn vs h/t (Fig. C8.3.2.1 NTC).
    Se incluye junto a la curva PLT o diagrama P-M en la memoria Word.
    """
    try:
        from design.shear    import build_shear_curve
        from design.materials import SteelMaterial as SM

        sv    = r.shear
        if sv is None:
            return
        Aw    = sv.Aw
        kv    = sv.kv
        phi_v = sv.phi_v
        h_tw  = sv.h_tw

        _Fy = sv.Vn * 1000.0 / (0.6 * Aw * sv.Cv) if (Aw > 0 and sv.Cv > 0) else 3515.0
        _mat = SM(name="tmp", fy=_Fy, fu=_Fy * 1.4)

        data = build_shear_curve(_mat, kv=kv, Aw_cm2=Aw, phi_v=phi_v,
                                  tension_field_ratios=(1.0, 2.0, 3.0),
                                  h_tw_max=max(h_tw * 1.5, 300.0))

        ht    = data["h_t"]
        tau   = data["tau_n"]
        lim1  = data["lim1"]
        lim2  = data["lim2"]
        lim3  = data["lim3"]
        Fy_v  = data["Fy"]

        fig, ax = plt.subplots(figsize=(11, 5))
        ax2 = ax.twinx()

        # Curva principal
        ax.plot(ht, tau, color=_C["primary"], lw=2.5,
                label="Vn/Aw = 0.6·Fy·Cv")
        ax.plot(ht, [t * phi_v for t in tau],
                color=_C["secondary"], lw=2, ls="--",
                label=(f"FR·Vn/Aw  (FR={phi_v:.2f})" if r.code == "NTC 2023"
                       else f"φv·Vn/Aw  (φv={phi_v:.2f})"))

        # CTD
        _ctd_c = ["#E67E22", "#8E44AD", "#16A085"]
        for idx, (a_h, curve) in enumerate(data["tension_fields"].items()):
            c = _ctd_c[idx % 3]
            ax.plot(ht,
                    [v * 1000.0 / Aw if Aw > 0 else 0 for v in curve["Vn"]],
                    color=c, lw=1.5, ls=":", label=f"CTD a/h={a_h:.0f}")

        y_max = max(tau) * 1.05 if tau else Fy_v * 0.65
        ax.axvspan(0,    lim1, alpha=0.10, color="green",  zorder=0)
        ax.axvspan(lim1, lim2, alpha=0.10, color="orange", zorder=0)
        ax.axvspan(lim2, max(ht), alpha=0.08, color="red", zorder=0)

        ax.axvline(lim1, color="green",     lw=1.5, ls="--",
                   label=f"1.10√(kv·E/Fy)={lim1:.1f}")
        ax.axvline(lim2, color="darkorange",lw=1.5, ls="--",
                   label=f"1.37√(kv·E/Fy)={lim2:.1f}")
        ax.axvline(lim3, color="gray",      lw=1.0, ls=":",
                   label=f"2.24√(E/Fy)={lim3:.1f}")
        ax.axhline(0.6 * Fy_v, color="gray", lw=0.8, ls="-.", alpha=0.6)
        ax.text(max(ht)*0.02, 0.6*Fy_v*1.01,
                f"0.6·Fy={0.6*Fy_v:.0f}", fontsize=7, color="gray", va="bottom")

        # Sección actual (capacidad nominal en la curva)
        ax.axvline(h_tw, color=_C["accent"], lw=2.5,
                   label=f"h/tw={h_tw:.1f}  (sección)")
        ax.scatter([h_tw], [0.6 * Fy_v * sv.Cv], color=_C["accent"], s=80, zorder=8)

        # Todas las combinaciones — puntos de Vu
        if r.all_points and Aw > 0:
            Vu_combos = [abs(pt.Vu) * 1000.0 / Aw for pt in r.all_points]
            ax.scatter([h_tw] * len(Vu_combos), Vu_combos,
                       color="#27AE60", alpha=0.50, s=16, zorder=5,
                       linewidths=0,
                       label=f"Combinaciones ({len(Vu_combos)} pts)")

        # Envolvente — 3 puntos
        if r.envelope and Aw > 0:
            mkrs = ["o", "s", "^"]
            lbls = ["Inicio", "Medio", "Fin"]
            for i, (lbl, pt) in enumerate(zip(lbls, r.envelope)):
                tau_env = abs(pt.Vu) * 1000.0 / Aw
                ax.scatter([h_tw], [tau_env],
                           zorder=7, s=90, marker=mkrs[i],
                           edgecolors="black", linewidths=0.8,
                           label=f"Env. {lbl}={abs(pt.Vu):.3f} t ({tau_env:.0f} kg/cm²)")

        # Vu máximo horizontal
        if r.envelope and Aw > 0:
            Vu_max = max(abs(pt.Vu) for pt in r.envelope)
            tau_u  = Vu_max * 1000.0 / Aw
            ax.axhline(tau_u, color=_C["accent"], lw=1.5, ls="-.",
                       label=f"Vu máx={Vu_max:.2f} ton  ({tau_u:.0f} kg/cm²)")

        ax2.set_ylabel("FR·Vn  (ton)" if r.code == "NTC 2023" else "φv·Vn  (ton)",
                       fontsize=9, color=_C["secondary"])
        ax2.set_ylim(0, y_max * Aw / 1000.0 * phi_v * 1.05)

        ref = "NTC 2023 Art. 8.2.2" if r.code == "NTC 2023" else "AISC G2.1"
        ax.set_xlabel("h/t  (esbeltez del alma)", fontsize=10)
        ax.set_ylabel("τ_n = Vn/Aw  (kg/cm²)", fontsize=10)
        ax.set_title(
            f"Cortante nominal – M{r.member_id}  {r.profile}  "
            f"kv={kv:.2f}  [{ref}]"
            + ("  —  Fig. C8.3.2.1" if r.code == "NTC 2023" else ""),
            fontsize=10, fontweight="bold", color=_C["primary"])
        ax.legend(fontsize=8, loc="upper right")
        ax.grid(True, alpha=0.25)
        ax.set_xlim(left=0, right=max(ht))
        ax.set_ylim(bottom=0, top=y_max)

        # Etiquetas de zona
        for x, lbl, col in [(lim1*0.5,"Fluencia","green"),
                              ((lim1+lim2)/2,"Pandeo\nInelástico","darkorange"),
                              (lim2*1.4,"Pandeo\nElástico","red")]:
            if 0 < x < max(ht):
                ax.text(x, y_max*0.93, lbl, ha="center", fontsize=7.5,
                        color=col, style="italic", va="top")

        fig.tight_layout()
        _embed_figure(doc, fig, width_cm=22.0)
        plt.close(fig)
    except Exception as exc:
        doc.add_paragraph(f"[No se pudo generar la gráfica de cortante: {exc}]")


def _embed_figure(doc, fig, width_cm: float = 22.0):
    """Guarda la figura matplotlib en BytesIO y la inserta en el documento."""
    buf = BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    buf.seek(0)
    doc.add_picture(buf, width=Cm(width_cm))
    last_para = doc.paragraphs[-1]
    last_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    buf.close()


def _add_envelope_table(doc, r: MemberDesignResult):
    has_tors = r.tors is not None and r.tors.applicable
    if has_tors:
        cols = ["Sección", "Mz act. (t·m)", "My act. (t·m)", "V act. (ton)",
                "Tu act. (t·m)", "Pu (ton)", "Ratio Mz", "Ratio My",
                "Ratio V", "Ratio T", "Ratio H", "¿OK?"]
    else:
        cols = ["Sección", "Mz act. (t·m)", "My act. (t·m)", "V act. (ton)",
                "Pu (ton)", "Ratio Mz", "Ratio My", "Ratio V", "Ratio H", "¿OK?"]
    labels = ["Inicio", "Medio", "Fin"]
    tbl = doc.add_table(rows=len(r.envelope) + 1, cols=len(cols))
    tbl.style = "Table Grid"
    for i, h in enumerate(cols):
        tbl.cell(0, i).text = h
        _bold_cell(tbl.cell(0, i))
    for row_i, (lbl, pt) in enumerate(zip(labels, r.envelope), 1):
        ok = pt.ratio_H <= 1.0 and pt.ratio_V <= 1.0
        if has_tors:
            ok = ok and pt.ratio_T <= 1.0
            vals = [lbl, f"{pt.Mz:.4f}", f"{pt.My:.4f}", f"{pt.Vu:.4f}",
                    f"{pt.Tu:.4f}", f"{pt.Pu:.4f}",
                    f"{pt.ratio_Mz:.3f}", f"{pt.ratio_My:.3f}",
                    f"{pt.ratio_V:.3f}",  f"{pt.ratio_T:.3f}",
                    f"{pt.ratio_H:.3f}", "✓" if ok else "✗"]
        else:
            vals = [lbl, f"{pt.Mz:.4f}", f"{pt.My:.4f}", f"{pt.Vu:.4f}",
                    f"{pt.Pu:.4f}",
                    f"{pt.ratio_Mz:.3f}", f"{pt.ratio_My:.3f}",
                    f"{pt.ratio_V:.3f}",  f"{pt.ratio_H:.3f}", "✓" if ok else "✗"]
        for col_i, v in enumerate(vals):
            c = tbl.cell(row_i, col_i)
            c.text = v
            # Colorear ratios (columnas de ratio)
            ratio_start = 6 if has_tors else 5
            if ratio_start <= col_i < len(cols) - 1:
                try:
                    rv = float(v)
                    if rv > 1.0:
                        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xC0, 0x39, 0x2B)
                        for run in c.paragraphs[0].runs:
                            run.bold = True
                    elif rv > 0.85:
                        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xF3, 0x9C, 0x12)
                except Exception:
                    pass


def _bold_cell(cell):
    for para in cell.paragraphs:
        for run in para.runs:
            run.bold = True
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
