# config/settings.py
APP_NAME    = "Steel Beam Design Pro"
APP_VERSION = "1.0.0"
APP_AUTHOR  = "Structural Engineering"

# ── Propiedades elásticas del acero ──────────────────────────────────────────
E_STEEL   = 2_039_000.0   # kg/cm²  (200 000 MPa)
G_STEEL   =   784_000.0   # kg/cm²  (77 200 MPa)

# ── Factores de resistencia ───────────────────────────────────────────────────
#  NTC Acero CDMX 2023 (Art. 6.3, 7.2, 5.2, 8.1)
#  φb = 0.90  flexión          (Art. 6.3,  NTC)
#  φv = 0.90  cortante general  (Art. 7.2.1, NTC)  — 1.00 si h/tw ≤ 2.24√(E/Fy)
#  φc = 0.90  compresión        (Art. 5.2,  NTC)   φc = φb = 0.90 (confirmado PDF Cap.9)
#  φt = 0.90  torsión
NTC_FR_FLEX  = 0.90   # φb  — Art. 6.3,   NTC 2023
NTC_FR_SHEAR = 0.90   # φv  — Art. 7.2.1, NTC 2023 (general; 1.00 cuando h/tw≤2.24√(E/Fy))
NTC_FR_COMP  = 0.90   # φc  — Art. 5.2,   NTC 2023  (φc=φb=0.90, Cap. 9 PDF)
NTC_FR_TORS  = 0.90   # φt
#  AISC 360-22
AISC_PHI_B  = 0.90    # φb  — F1
AISC_PHI_V  = 1.00    # φv  — G1 para perfiles laminados I
AISC_PHI_C  = 0.90    # φc  — E1
AISC_PHI_T  = 0.90    # φt  — H3

# ── Materiales más comunes (Fy y Fu en kg/cm²) ───────────────────────────────
STEEL_MATERIALS = [
    {"name": "A-36  (Fy=2530, Fu=4080)",          "fy": 2530.0,  "fu": 4080.0},
    {"name": "A-42  (Fy=2950, Fu=4200) NMX",      "fy": 2950.0,  "fu": 4200.0},
    {"name": "A-52  (Fy=3660, Fu=5200) NMX",      "fy": 3660.0,  "fu": 5200.0},
    {"name": "A572 Gr50 (Fy=3515, Fu=4570)",       "fy": 3515.0,  "fu": 4570.0},
    {"name": "A572 Gr60 (Fy=4220, Fu=5275)",       "fy": 4220.0,  "fu": 5275.0},
    {"name": "A572 Gr65 (Fy=4570, Fu=5500)",       "fy": 4570.0,  "fu": 5500.0},
    {"name": "A992     (Fy=3515, Fu=4570)",        "fy": 3515.0,  "fu": 4570.0},
    {"name": "A500 Gr B (Fy=3170, Fu=4010)",       "fy": 3170.0,  "fu": 4010.0},
    {"name": "A500 Gr C (Fy=3520, Fu=4290)",       "fy": 3520.0,  "fu": 4290.0},
    {"name": "A53 Gr B  (Fy=2460, Fu=4220)",       "fy": 2460.0,  "fu": 4220.0},
    {"name": "A913 Gr65 (Fy=4570, Fu=5500)",       "fy": 4570.0,  "fu": 5500.0},
    {"name": "A913 Gr70 (Fy=4920, Fu=5840)",       "fy": 4920.0,  "fu": 5840.0},
    {"name": "A709 Gr50 (Fy=3515, Fu=4570)",       "fy": 3515.0,  "fu": 4570.0},
    {"name": "A1085     (Fy=3170, Fu=4290)",       "fy": 3170.0,  "fu": 4290.0},
    {"name": "Manual / Definido por usuario",       "fy":    0.0,  "fu":    0.0},
]

# ── Conversión de unidades STAAD → kg, cm ────────────────────────────────────
#  STAAD Pro usualmente trabaja en kN y m
KN_TO_TON  = 1.0 / 9.81          # kN → ton
KNM_TO_TCM = 1.0 / 9.81 * 100.0  # kN·m → ton·cm
M_TO_CM    = 100.0

# ── Umbral carga axial para flexocompresión (fracción de Pn) ──────────────────
#  Si Pu/φPn > BEAM_COL_THRESHOLD → flexocompresión
BEAM_COL_THRESHOLD = 0.10   # NTC 2023 / AISC 360-22 Capítulo H

# ── UI colores (idénticos a beam_design_pro) ─────────────────────────────────
COLOR_PRIMARY   = "#1B4F72"
COLOR_SECONDARY = "#2874A6"
COLOR_ACCENT    = "#E74C3C"
COLOR_OK        = "#1E8449"
COLOR_WARN      = "#D68910"
COLOR_FAIL      = "#C0392B"
COLOR_BG        = "#EBF5FB"
COLOR_PANEL     = "#FFFFFF"
COLOR_TEXT      = "#1C2833"
COLOR_HEADER    = "#FFFFFF"

# Dict estilo beam_design_pro (acceso alternativo)
COLORS = {
    "primary":   COLOR_PRIMARY,
    "secondary": COLOR_SECONDARY,
    "accent":    COLOR_ACCENT,
    "success":   COLOR_OK,
    "warning":   COLOR_WARN,
    "bg":        COLOR_BG,
    "panel":     COLOR_PANEL,
    "text":      COLOR_TEXT,
    "header_fg": COLOR_HEADER,
}
