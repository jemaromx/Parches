"""
error_reporter.py — Captura y reporte de errores para la Struct-Link.

Instalar al inicio de cada main.py:
    from suite_shared.error_reporter import install_excepthook
    install_excepthook("nombre_modulo")
"""

import sys
import logging
import traceback
from pathlib import Path

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QTextEdit, QMessageBox,
)
from PySide6.QtCore import Qt

SUPPORT_EMAIL = "contacto@struct-link.com.mx"
LOG_DIR = Path.home() / "AppData" / "Roaming" / "SuiteEstructural" / "logs"

log = logging.getLogger(__name__)


class ReportErrorDialog(QDialog):
    """Diálogo que muestra el traceback y ofrece enviarlo por correo."""

    def __init__(self, module_name: str, error_text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Error inesperado")
        self.setMinimumSize(600, 400)
        self._error_text = error_text
        self._module = module_name
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        lbl = QLabel(
            f"<b>Ocurrió un error en <i>{self._module}</i>.</b><br>"
            "El detalle técnico se muestra abajo. Puede copiarlo y enviarlo "
            f"a <a href='mailto:{SUPPORT_EMAIL}'>{SUPPORT_EMAIL}</a> "
            "para que sea atendido."
        )
        lbl.setWordWrap(True)
        lbl.setOpenExternalLinks(True)
        layout.addWidget(lbl)

        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(self._error_text)
        txt.setFont(__import__("PySide6.QtGui", fromlist=["QFont"]).QFont("Consolas", 8))
        layout.addWidget(txt)

        btn_row = QHBoxLayout()
        btn_copy = QPushButton("Copiar al portapapeles")
        btn_copy.clicked.connect(self._copy)
        btn_email = QPushButton("Enviar por correo")
        btn_email.clicked.connect(self._send_email)
        btn_close = QPushButton("Cerrar")
        btn_close.clicked.connect(self.accept)
        btn_row.addWidget(btn_copy)
        btn_row.addWidget(btn_email)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)

    def _copy(self):
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(self._error_text)

    def _send_email(self):
        import urllib.parse, webbrowser
        subject = urllib.parse.quote(f"[{self._module}] Error inesperado")
        body    = urllib.parse.quote(self._error_text[:2000])
        webbrowser.open(f"mailto:{SUPPORT_EMAIL}?subject={subject}&body={body}")


def install_excepthook(module_name: str) -> None:
    """
    Instala un manejador global de excepciones no capturadas.
    Muestra ReportErrorDialog y registra en el log del módulo.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"{module_name}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )

    def _hook(exc_type, exc_value, exc_tb):
        msg = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        log.critical("Excepción no capturada:\n%s", msg)
        try:
            dlg = ReportErrorDialog(module_name, msg)
            dlg.exec()
        except Exception:
            pass
        sys.__excepthook__(exc_type, exc_value, exc_tb)

    sys.excepthook = _hook
