﻿"""
Exportación a Word: resultados de diseño y memoria de cálculo.

ResultsExporter — tabla tabular por zapata y combinación.
MemoExporter    — descripción con fórmulas + valores numéricos + referencias.
"""
from __future__ import annotations
import math
import os
from datetime import datetime
from typing import List, Optional

from design.footing_design  import NodeResult, DesignParams
from design.geotechnical    import GeoResult, INF
from design.structural      import StrucResult

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Cm, Inches
    from docx.enum.text  import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
    from docx.oxml.ns    import qn
    from docx.oxml       import OxmlElement
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

try:
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")   # backend sin GUI para generación fuera de hilo
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D    # noqa: F401
    import matplotlib.colors as mcolors
    MPL_EXPORT_OK = True
except ImportError:
    MPL_EXPORT_OK = False

def _geom_from_struc(sr, params):
    """Tupla de geometría (cy,cz,ex,ez,brazos,gov,d_req) desde un StrucResult.

    Mismo formato que `gui.pressure_3d_widget._elem_geom`, para alimentar los
    renderers compartidos y que la figura de la memoria sea idéntica a la UI.
    """
    cy = getattr(sr, "cy", getattr(params, "cy", 0.30)) if sr else getattr(params, "cy", 0.30)
    cz = getattr(sr, "cz", getattr(params, "cz", 0.30)) if sr else getattr(params, "cz", 0.30)
    ex = getattr(sr, "ex", 0.0) if sr else 0.0
    ez = getattr(sr, "ez", 0.0) if sr else 0.0
    ld_izq = getattr(sr, "ld_izq",   None) if sr else None
    ld_der = getattr(sr, "ld_der",   None) if sr else None
    bd_frt = getattr(sr, "bd_frt",   None) if sr else None
    bd_atr = getattr(sr, "bd_atras", None) if sr else None
    gov_L  = getattr(sr, "lado_gov_L", None) if sr else None
    gov_B  = getattr(sr, "lado_gov_B", None) if sr else None
    d_req  = getattr(sr, "d_req",     0.30) if sr else 0.30
    return cy, cz, ex, ez, ld_izq, ld_der, bd_frt, bd_atr, gov_L, gov_B, d_req


def _pressure_fig_to_bytes(pr, L: float, B: float, ftu: float,
                           geom, gr_ok=None, lc_id="") -> Optional[bytes]:
    """Figura de presiones (2D + 3D) idéntica a la UI → PNG bytes.

    Reutiliza `gui.pressure_3d_widget.render_pressure_figure` para garantizar
    que la memoria use la misma paleta, eje Z invertido y etiquetas que la
    pantalla. Retorna None si matplotlib no está disponible o falla.
    """
    if not MPL_EXPORT_OK:
        return None
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore", UserWarning)
        try:
            from gui.pressure_3d_widget import render_pressure_figure
            from matplotlib.figure import Figure
            import io
            fig = Figure(figsize=(13, 5.5), constrained_layout=True)
            render_pressure_figure(fig, pr, L, B, ftu, geom,
                                   gr_ok=gr_ok, lc_id=lc_id)
            buf = io.BytesIO()
            fig.savefig(buf, format='png', dpi=130)
            buf.seek(0)
            return buf.read()
        except Exception:
            return None


_CAFE   = RGBColor(0x47, 0x5C, 0x6B)   # gris azulado oscuro (#475C6B)
_AZUL   = RGBColor(0x1B, 0x4F, 0x72)
_BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
_ROJO   = RGBColor(0x92, 0x2B, 0x21)
_VERDE  = RGBColor(0x1E, 0x84, 0x49)
_GRIS   = RGBColor(0x56, 0x65, 0x73)


def _select_bar_spaced(as_cm2_m: float,
                       sep_min_m: float = 0.15,
                       sep_max_m: float = 0.30):
    """
    Selecciona varillado con separación entre sep_min_m y sep_max_m.
    Devuelve (diam_mm, sep_cm, as_prov) ó None si no hay solución.
    """
    if as_cm2_m <= 0:
        return None
    bars = [
        (8,  0.503), (10, 0.785), (12, 1.131), (16, 2.011),
        (19, 2.835), (22, 3.801), (25, 4.909), (32, 8.042),
    ]
    sep_min_cm = int(sep_min_m * 100)   # 15
    sep_max_cm = int(sep_max_m * 100)   # 30
    best = None
    for d_mm, a_cm2 in bars:
        for sep_cm in range(sep_min_cm, sep_max_cm + 1):
            as_prov = a_cm2 * 100.0 / sep_cm
            if as_prov >= as_cm2_m:
                if best is None or as_prov < best[2]:
                    best = (d_mm, sep_cm, round(as_prov, 2))
                break   # próxima barra
    return best


def _rebar_2d_fig(nr, params, sr) -> Optional[bytes]:
    """
    Genera figura matplotlib con 2 cortes 2D de la zapata.

    Muestra (por sección Dir.L y Dir.B):
      - Zapata a escala con columna en posición EXCÉNTRICA real
      - Flecha naranja de excentricidad (del centro al centroide de la columna)
      - Brazos de voladizo asimétricos con cotas (lado gobernante en naranja)
      - Sección crítica de cortante (a distancia d de cada cara de la columna)
      - Refuerzo inferior y superior con notación Ø@cm
      - Cotas: ancho (L ó B), espesor h, peralte d, dimensión columna
    Separación de barras: 0.15 – 0.30 m
    """
    if not MPL_EXPORT_OK:
        return None
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore", UserWarning)
        try:
            L, B = nr.L, nr.B
            h   = nr.d_total   # m espesor total
            d   = nr.d_ef      # m peralte efectivo
            rec = params.rec   # m recubrimiento
            # Geometría de la columna del StrucResult (por elemento)
            cy  = getattr(sr, "cy", params.cy)
            cz  = getattr(sr, "cz", params.cz)
            ex  = getattr(sr, "ex", 0.0)
            ez  = getattr(sr, "ez", 0.0)
            # Brazos asimétricos
            ld_izq  = getattr(sr, "ld_izq",   (L - cy) / 2.0)
            ld_der  = getattr(sr, "ld_der",    (L - cy) / 2.0)
            bd_frt  = getattr(sr, "bd_frt",    (B - cz) / 2.0)
            bd_atr  = getattr(sr, "bd_atras",  (B - cz) / 2.0)
            gov_L   = getattr(sr, "lado_gov_L", "izq")
            gov_B   = getattr(sr, "lado_gov_B", "frt")
            d_req   = getattr(sr, "d_req",      d)

            AsL_inf = nr.AsL_max;  AsB_inf = nr.AsB_max
            AsL_sup = nr.AsL_sup_max; AsB_sup = nr.AsB_sup_max

            bar_L_inf = _select_bar_spaced(AsL_inf)
            bar_B_inf = _select_bar_spaced(AsB_inf)
            bar_L_sup = _select_bar_spaced(AsL_sup) if AsL_sup > 0 else None
            bar_B_sup = _select_bar_spaced(AsB_sup) if AsB_sup > 0 else None

            from matplotlib.figure import Figure
            fig = Figure(figsize=(14, 7), constrained_layout=True)
            axes = fig.subplots(1, 2)
            fig.suptitle(
                f"Detalle de Refuerzo — Zapata {nr.node_label}"
                f"   {L:.2f}×{B:.2f}×{h:.2f} m"
                + (f"   ex={ex:+.3f}m  ez={ez:+.3f}m"
                   if abs(ex) > 0.001 or abs(ez) > 0.001 else ""),
                fontsize=10, fontweight="bold")

            sections = [
                # width, col_dim, col_off, arm_near, arm_far, gov,
                # As_inf, As_sup, bar_inf, bar_sup, dir_lbl
                (L, cy, ex, ld_izq, ld_der, gov_L,
                 AsL_inf, AsL_sup, bar_L_inf, bar_L_sup, "Dir. L"),
                (B, cz, ez, bd_frt, bd_atr, gov_B,
                 AsB_inf, AsB_sup, bar_B_inf, bar_B_sup, "Dir. B"),
            ]
            _grapa_sel = (getattr(sr, "grapa_sel", "")
                          if getattr(sr, "grapas_req", False) else "")
            for ax, (width, col_dim, col_off,
                     arm_near, arm_far, gov,
                     As_inf, As_sup, bar_inf, bar_sup,
                     dir_lbl) in zip(axes, sections):
                _draw_section_2d(ax, width, h, d, rec, col_dim, col_off,
                                 arm_near, arm_far, gov,
                                 As_inf, As_sup, bar_inf, bar_sup,
                                 dir_lbl, d_req, grapa_sel=_grapa_sel)

            import io
            buf = io.BytesIO()
            fig.savefig(buf, format='png', dpi=130)
            buf.seek(0)
            return buf.read()
        except Exception:
            return None


def _draw_section_2d(ax, width: float, h: float, d: float, rec: float,
                     col_dim: float, col_off: float,
                     arm_near: float, arm_far: float, gov: str,
                     as_inf: float, as_sup: float,
                     bar_inf, bar_sup,
                     dir_label: str,
                     d_req: float = 0.0,
                     grapa_sel: str = "") -> None:
    """
    Dibuja una sección transversal 2D de la zapata con refuerzo y excentricidad.

    Parámetros
    ----------
    width    : ancho de la zapata en esta dirección (L ó B)  [m]
    h, d     : espesor total y peralte efectivo  [m]
    rec      : recubrimiento  [m]
    col_dim  : dimensión de la columna en esta dirección  [m]
    col_off  : excentricidad de la columna (+= hacia la derecha)  [m]
    arm_near : brazo de voladizo izquierdo (ó frente)  [m]
    arm_far  : brazo de voladizo derecho  (ó atrás)    [m]
    gov      : "izq"/"frt" ó "der"/"atr"  — lado gobernante
    d_req    : peralte efectivo requerido para cortante  [m]
    """
    from matplotlib.patches import Rectangle

    # ── Paleta de colores ──────────────────────────────────────────────────
    C_CONC  = "#F0EAD6"   # concreto
    C_COL   = "#D5D8DC"   # columna
    C_REBAR = "#1A5276"   # armado inferior (azul oscuro)
    C_RSUP  = "#922B21"   # armado superior (rojo)
    C_DIM   = "#7D3C98"   # cotas (morado)
    C_GOV   = "#E67E22"   # lado gobernante (naranja)
    C_NGOV  = "#2980B9"   # lado no gobernante (azul)
    C_SHEAR = "#8E44AD"   # sección crítica cortante (morado)

    ax.set_aspect("equal")
    ax.axis("off")

    # ── Zapata ─────────────────────────────────────────────────────────────
    ax.add_patch(Rectangle((0,0), width, h,
                            fc=C_CONC, ec="black", lw=2, zorder=1))

    # ── Grapas por cortante (refuerzo transversal) ─────────────────────────
    if grapa_sel:
        import re as _re
        m = _re.search(r"@\s*(\d+)", grapa_sel)
        s_gr = (int(m.group(1)) / 100.0) if m else 0.25   # m
        y0g, y1g = rec, h - rec
        xg = s_gr
        while xg < width - 0.5 * s_gr:
            ax.plot([xg, xg], [y0g, y1g], color="#B9770E",
                    lw=1.1, zorder=3, solid_capstyle="round")
            # ganchos superior e inferior
            ax.plot([xg, xg + 0.02], [y1g, y1g - 0.02],
                    color="#B9770E", lw=1.1, zorder=3)
            ax.plot([xg, xg - 0.02], [y0g, y0g + 0.02],
                    color="#B9770E", lw=1.1, zorder=3)
            xg += s_gr
        ax.text(width * 0.5, -0.16 if h < 0.6 else -0.20,
                f"Grapas {grapa_sel} (ambas direcciones)",
                ha="center", fontsize=7, color="#B9770E",
                fontweight="bold")

    # ── Columna en posición excéntrica ─────────────────────────────────────
    col_xc = width / 2.0 + col_off          # centroide de la columna
    col_x0 = col_xc - col_dim / 2.0         # borde izquierdo
    col_x1 = col_xc + col_dim / 2.0         # borde derecho
    col_h  = h * 0.38
    ax.add_patch(Rectangle((col_x0, h), col_dim, col_h,
                            fc=C_COL, ec="black", lw=1.5, zorder=2))

    # Línea central de la zapata (referencia simétrica)
    ax.axvline(x=width/2.0, ymin=0, ymax=1.0,
               color="gray", lw=0.7, ls=":", alpha=0.5)

    # ── Flecha de excentricidad (centro zapata → centroide columna) ────────
    has_ecc = abs(col_off) > 0.001
    if has_ecc:
        y_ecc = h + col_h + 0.05
        ax.annotate("",
                    xy=(col_xc, y_ecc),
                    xytext=(width/2.0, y_ecc),
                    arrowprops=dict(arrowstyle="->",
                                   color=C_GOV, lw=2.0,
                                   mutation_scale=10))
        label_ecc = "ex" if "L" in dir_label else "ez"
        ax.text((width/2.0 + col_xc) / 2.0, y_ecc + 0.04,
                f"{label_ecc} = {col_off*100:+.1f} cm",
                ha="center", va="bottom", fontsize=7,
                color=C_GOV, fontweight="bold")

    # ── Brazos de voladizo con cotas (cerca/lejos de la excentricidad) ─────
    y_arm = -0.10   # nivel de la cota de brazos
    # Decidir si "near" = izquierda o derecha según el signo de col_off
    # arm_near es el brazo del lado "−" (izquierdo en Dir.L, frente en Dir.B)
    # arm_far  es el brazo del lado "+" (derecho en Dir.L, atrás en Dir.B)
    gov_is_near = gov in ("izq", "frt")
    c_near = C_GOV  if gov_is_near else C_NGOV
    c_far  = C_NGOV if gov_is_near else C_GOV
    sym_near = "★" if gov_is_near else ""
    sym_far  = "★" if not gov_is_near else ""

    # Cota brazo izquierdo (near)
    ax.annotate("", xy=(0, y_arm), xytext=(col_x0, y_arm),
                arrowprops=dict(arrowstyle="<->", color=c_near, lw=1.5,
                                mutation_scale=8))
    ax.text(col_x0/2.0, y_arm - 0.05,
            f"{sym_near}{arm_near*100:.1f}cm",
            ha="center", va="top", fontsize=7,
            color=c_near,
            fontweight="bold" if gov_is_near else "normal")

    # Cota brazo derecho (far)
    ax.annotate("", xy=(width, y_arm), xytext=(col_x1, y_arm),
                arrowprops=dict(arrowstyle="<->", color=c_far, lw=1.5,
                                mutation_scale=8))
    ax.text((col_x1 + width)/2.0, y_arm - 0.05,
            f"{sym_far}{arm_far*100:.1f}cm",
            ha="center", va="top", fontsize=7,
            color=c_far,
            fontweight="bold" if not gov_is_near else "normal")

    # ── Secciones críticas de cortante (a distancia d_req de cada cara) ───
    if d_req > 0.005:
        x_crit_near = max(col_x0 - d_req, 0.0)
        x_crit_far  = min(col_x1 + d_req, width)
        for x_sc in [x_crit_near, x_crit_far]:
            ax.axvline(x=x_sc, ymin=0, ymax=1.0,
                       color=C_SHEAR, lw=1.0, ls="--", alpha=0.75, zorder=3)
        # Etiqueta en las secciones críticas
        ax.text(x_crit_near, h * 0.5,
                f" d={d_req*100:.0f}\n cm",
                ha="left", va="center", fontsize=5.5,
                color=C_SHEAR, alpha=0.85)
        ax.text(x_crit_far, h * 0.5,
                f"d={d_req*100:.0f}\ncm ",
                ha="right", va="center", fontsize=5.5,
                color=C_SHEAR, alpha=0.85)

    # ── Armado lecho inferior ──────────────────────────────────────────────
    y_inf = rec + 0.008
    _draw_rebars(ax, 0, width, y_inf, as_inf, bar_inf, C_REBAR,
                 label=f"As inf = {as_inf:.2f} cm²/m")

    # ── Armado lecho superior ──────────────────────────────────────────────
    if as_sup > 0:
        y_sup = h - rec - 0.008
        _draw_rebars(ax, 0, width, y_sup, as_sup, bar_sup, C_RSUP,
                     label=f"As sup = {as_sup:.2f} cm²/m")

    # ── Líneas de recubrimiento ────────────────────────────────────────────
    for yy in [rec, h - rec]:
        ax.axhline(y=yy, xmin=0.04, xmax=0.96,
                   color="gray", lw=0.7, ls="--", alpha=0.55)
    ax.text(-0.04, rec, f"rec={rec*100:.0f}cm",
            ha="right", va="center", fontsize=6, color="gray")

    # ── Peralte efectivo d ────────────────────────────────────────────────
    ax.annotate("", xy=(width+0.10, y_inf), xytext=(width+0.10, h),
                arrowprops=dict(arrowstyle="<->", color=C_DIM, lw=1.2,
                                mutation_scale=8))
    ax.text(width+0.18, (y_inf+h)/2.0,
            f"d = {d:.3f} m", ha="left", va="center",
            fontsize=7, color=C_DIM)

    # ── Cota: ancho total ─────────────────────────────────────────────────
    y_tot = -0.25
    ax.annotate("", xy=(width, y_tot), xytext=(0, y_tot),
                arrowprops=dict(arrowstyle="<->", color=C_DIM, lw=1.2,
                                mutation_scale=8))
    ax.text(width/2.0, y_tot - 0.06,
            f"{dir_label} = {width:.2f} m",
            ha="center", va="top",
            fontsize=8, color=C_DIM, fontweight="bold")

    # ── Cota: espesor total h ─────────────────────────────────────────────
    ax.annotate("", xy=(-0.15, 0), xytext=(-0.15, h),
                arrowprops=dict(arrowstyle="<->", color=C_DIM, lw=1.2,
                                mutation_scale=8))
    ax.text(-0.24, h/2.0, f"h = {h:.3f} m",
            ha="center", va="center",
            fontsize=7, color=C_DIM, rotation=90)

    # ── Cota: dimensión columna ───────────────────────────────────────────
    y_col_dim = h + col_h + 0.16 + (0.14 if has_ecc else 0)
    ax.annotate("", xy=(col_x1, y_col_dim), xytext=(col_x0, y_col_dim),
                arrowprops=dict(arrowstyle="<->", color="black", lw=1.0,
                                mutation_scale=7))
    ax.text(col_xc, y_col_dim + 0.06,
            f"col={col_dim*100:.0f}cm",
            ha="center", va="bottom", fontsize=6.5, color="black")

    # ── Leyenda del lado gobernante ───────────────────────────────────────
    gov_lbl = {
        "izq": "★ Lado izq. GOBIERNA",
        "der": "★ Lado der. GOBIERNA",
        "frt": "★ Lado frt. GOBIERNA",
        "atr": "★ Lado atr. GOBIERNA",
    }.get(gov, f"★ Lado {gov} gobierna")
    ax.text(width/2.0, h*0.92, gov_lbl,
            ha="center", va="top", fontsize=7,
            color=C_GOV, fontweight="bold",
            bbox=dict(facecolor="white", edgecolor=C_GOV,
                      alpha=0.75, lw=0.8, pad=0.3))

    # ── Título y límites ──────────────────────────────────────────────────
    ecc_note = (f" (e={col_off*100:+.1f}cm)" if has_ecc else "")
    ax.set_title(f"Sección {dir_label}{ecc_note}", fontsize=9, pad=6)
    ax.set_xlim(-0.38, width + 0.55)
    ax.set_ylim(-0.40, h + col_h + 0.45)


def _draw_rebars(ax, x0: float, x1: float, y: float,
                 as_cm2m: float, bar_info, color: str,
                 label: str = "") -> None:
    """
    Dibuja las barras de refuerzo como círculos uniformemente espaciados.
    bar_info : (diam_mm, sep_cm, as_prov) ó None → usar espaciado mínimo.
    """
    width = x1 - x0
    if bar_info:
        d_mm, sep_cm, _ = bar_info
        r = d_mm / 1000.0 / 2.0   # radio en m
        sep = sep_cm / 100.0        # separación en m
        lbl_str = f"  Ø{d_mm}@{sep_cm}cm"
    else:
        # Fallback: dibujar barras cada 20cm
        r = 0.008
        sep = 0.20
        lbl_str = ""

    n_bars = max(int(width / sep) + 1, 2)
    xs = [x0 + sep / 2 + i * sep for i in range(n_bars)]
    # Recortar a la longitud de la zapata
    xs = [x for x in xs if x0 <= x <= x1]
    for xb in xs:
        circ = plt.Circle((xb, y), r,
                           fc=color, ec="black", lw=0.5, zorder=5)
        ax.add_patch(circ)
    # Etiqueta
    if label and xs:
        ax.text(xs[-1] + 0.05, y, f"{label}{lbl_str}",
                ha="left", va="center", fontsize=6.5, color=color)


def _select_bar(as_cm2_m: float):
    """
    Selecciona el varillado más común para el acero requerido.
    Devuelve (diam_mm, sep_cm, as_prov) usando varillas métricas mexicanas.
    """
    bars = [
        (8,  0.503), (10, 0.785), (12, 1.131), (16, 2.011),
        (19, 2.835), (22, 3.801), (25, 4.909), (32, 8.042),
    ]
    # Buscar la varilla más pequeña con separación ≥ 10 cm
    for d_mm, a_cm2 in bars:
        for sep in [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 25, 28, 30]:
            as_prov = a_cm2 * 100.0 / sep
            if as_prov >= as_cm2_m:
                return d_mm, sep, round(as_prov, 2)
    return None, None, None


def _settlement_fig_to_bytes(pr, L: float, B: float, ks: float,
                              geom, lc_id="") -> Optional[bytes]:
    """Figura de asentamientos (2D + 3D) idéntica a la UI → PNG bytes.

    Reutiliza `gui.pressure_3d_widget.render_settlement_figure`.
    """
    if not MPL_EXPORT_OK or ks <= 0.0:
        return None
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore", UserWarning)
        try:
            from gui.pressure_3d_widget import render_settlement_figure
            from matplotlib.figure import Figure
            import io
            fig = Figure(figsize=(13, 5.5), constrained_layout=True)
            render_settlement_figure(fig, pr, L, B, ks, geom, lc_id=lc_id)
            buf = io.BytesIO()
            fig.savefig(buf, format='png', dpi=130)
            buf.seek(0)
            return buf.read()
        except Exception:
            return None


def _plan_fig_to_bytes(results, params, plan_geom, metric: str) -> Optional[bytes]:
    """Renderiza la planta (métrica dada) y devuelve PNG bytes (o None)."""
    if not MPL_EXPORT_OK:
        return None
    try:
        import io
        from matplotlib.figure import Figure
        from viz.plan_figure import draw_plan
        fig = Figure(figsize=(7.2, 5.0), facecolor="white", constrained_layout=True)
        ax  = fig.add_subplot(111)
        draw_plan(ax, fig, results, params, plan_geom, metric)
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130)
        return buf.getvalue()
    except Exception:
        return None


def _grid_geom(results) -> dict:
    """Geometría en rejilla de respaldo si no hay coordenadas de STAAD."""
    import math as _m
    n = len(results)
    cols = max(1, int(_m.ceil(_m.sqrt(n))))
    step = max((max(nr.L, nr.B) for nr in results), default=2.0) * 1.6
    return {nr.node_id: {"x": (i % cols) * step, "z": (i // cols) * step,
                         "beta": 0.0}
            for i, nr in enumerate(results)}


def _insert_image_bytes(doc, img_bytes: Optional[bytes],
                        width_cm: float = 15.0) -> None:
    """Inserta una imagen PNG (bytes) en el documento Word."""
    if not img_bytes or not DOCX_OK:
        return
    import io
    try:
        doc.add_picture(io.BytesIO(img_bytes), width=Cm(width_cm))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    except Exception:
        pass


def _shade(cell, hex_color: str) -> None:
    tc = cell._tc; tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color); tcPr.append(shd)


def _hdr_row(table, headers, bg="475C6B") -> None:
    row = table.rows[0]
    for i, txt in enumerate(headers):
        c = row.cells[i]; _shade(c, bg)
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(txt)
        run.font.bold = True; run.font.size = Pt(7)
        run.font.color.rgb = _BLANCO
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _title(doc, text: str, level: int = 1) -> None:
    h = doc.add_heading(text, level=level)
    h.runs[0].font.color.rgb = _CAFE if level == 1 else _AZUL


def _f(v, dec: int = 3) -> str:
    try:
        fv = float(v)
        if abs(fv) >= 9990:
            return "∞"
        return f"{fv:.{dec}f}"
    except Exception:
        return str(v)


def _ok(ok: bool) -> str:
    return "OK" if ok else "NO OK"


def _margins(doc) -> None:
    for sec in doc.sections:
        sec.top_margin = Cm(1.5); sec.bottom_margin = Cm(1.5)
        sec.left_margin = Cm(2.0); sec.right_margin = Cm(1.5)


def _add_formula(doc, titulo: str, formula: str,
                 resultado: str = "", ref: str = "") -> None:
    """Agrega bloque título → fórmula → resultado numérico → referencia."""
    p = doc.add_paragraph()
    run = p.add_run(titulo)
    run.font.bold = True; run.font.color.rgb = _AZUL

    p2 = doc.add_paragraph(formula)
    p2.paragraph_format.left_indent = Cm(1.0)
    p2.runs[0].font.name = "Courier New"; p2.runs[0].font.size = Pt(9)

    if resultado:
        p3 = doc.add_paragraph(resultado)
        p3.paragraph_format.left_indent = Cm(1.0)
        p3.runs[0].font.bold = True
        if "NO OK" in resultado:
            p3.runs[0].font.color.rgb = _ROJO
        elif "OK" in resultado or "✓" in resultado:
            p3.runs[0].font.color.rgb = _VERDE

    if ref:
        p4 = doc.add_paragraph(f"Ref.: {ref}")
        p4.paragraph_format.left_indent = Cm(1.0)
        p4.runs[0].font.italic = True
        p4.runs[0].font.size = Pt(8); p4.runs[0].font.color.rgb = _GRIS

    doc.add_paragraph()


# ── Reporte de resultados ─────────────────────────────────────────────────────

class ResultsExporter:

    def export(self, results: List[NodeResult], params: DesignParams,
               path: str, plan_geom: Optional[dict] = None,
               progress_cb=None) -> str:
        if not DOCX_OK:
            raise RuntimeError("Instale python-docx:  pip install python-docx")
        n = max(len(results), 1)
        if progress_cb:
            progress_cb(2, "Generando portada y resumen…")
        doc = Document(); _margins(doc)
        self._portada(doc, params)
        self._resumen(doc, results, params)
        if progress_cb:
            progress_cb(8, "Dibujando planta y mapas…")
        self._planta(doc, results, params, plan_geom)
        for i, nr in enumerate(results):
            if progress_cb:
                pct = 10 + int(85 * i / n)
                progress_cb(pct, f"Zapata {nr.node_label}  ({i+1}/{n})…")
            self._zapata(doc, nr, params)
        if progress_cb:
            progress_cb(97, "Guardando documento…")
        doc.save(path)
        if progress_cb:
            progress_cb(100, "Listo.")
        return path

    def _planta(self, doc, results, params, plan_geom) -> None:
        """Planta con dimensiones finales + mapas de color (Mejora 3)."""
        if not MPL_EXPORT_OK or not results:
            return
        from viz.plan_figure import METRICS
        geom = plan_geom or {}
        # rejilla de respaldo si no hay coordenadas reales
        if not geom or all((geom.get(nr.node_id, {}).get("x", 0) == 0 and
                            geom.get(nr.node_id, {}).get("z", 0) == 0)
                           for nr in results):
            geom = _grid_geom(results)
        _title(doc, "Planta y Mapas de Resultados")
        doc.add_paragraph(
            "Cada zapata se dibuja con sus dimensiones finales B×L y su giro "
            "BETA. El color es la relación demanda/capacidad del caso más "
            "desfavorable: rojo ≈ 1.0 (límite); magenta = sobrepasa (> 1).")
        for key, label in METRICS:
            png = _plan_fig_to_bytes(results, params, geom, key)
            if png:
                doc.add_paragraph(label).runs[0].font.bold = True
                _insert_image_bytes(doc, png, width_cm=15.0)
        doc.add_page_break()

    def _portada(self, doc, params: DesignParams) -> None:
        doc.add_paragraph()
        for txt, size, color in [
            ("FOOTING DESIGN PRO", 22, _CAFE),
            ("Diseño de Zapatas Aisladas", 14, _AZUL),
        ]:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(txt)
            run.font.size = Pt(size); run.font.bold = True
            run.font.color.rgb = color
        doc.add_paragraph()
        t = doc.add_table(rows=7, cols=2); t.style = "Table Grid"
        for k, v in [
            ("Proyecto",    params.proyecto or "—"),
            ("Fecha",       datetime.now().strftime("%d/%m/%Y %H:%M")),
            ("Código",      params.code),
            ("Método",      f"{'1 — Servicio→Estructural' if params.method==1 else '2 — Últimas (MDOC CFE B.2.5)'}"),
            ("f'c",         f"{params.fc} kgf/cm²"),
            ("fy",          f"{params.fy} kgf/cm²"),
            ("ftu",         f"{params.ftu} ton/m²"),
        ]:
            r = t.add_row()
            r.cells[0].text = k; r.cells[1].text = v
            r.cells[0].paragraphs[0].runs[0].font.bold = True
        t._tbl.remove(t.rows[0]._tr)
        doc.add_page_break()

    def _resumen(self, doc, results, params) -> None:
        _title(doc, "Resumen de Diseño")
        cols = ["Nodo/Barra", "L(m)", "B(m)", "h(m)", "d(m)",
                "AsL inf\ncm²/m", "AsB inf\ncm²/m",
                "AsL sup\ncm²/m", "AsB sup\ncm²/m",
                "CL Cap.", "CL Volt.", "CL Desl.", "CL Ext.",
                "CL Pun.", "CL Cort.", "CL Flex."]
        tbl = doc.add_table(rows=len(results)+1, cols=len(cols))
        tbl.style = "Table Grid"; _hdr_row(tbl, cols)
        for i, nr in enumerate(results):
            row = tbl.rows[i+1]
            row.cells[0].text = nr.node_label
            for j, v in enumerate([_f(nr.L,2), _f(nr.B,2), _f(nr.d_total,2), _f(nr.d_ef,2),
                                    _f(nr.AsL_max,2), _f(nr.AsB_max,2),
                                    _f(nr.AsL_sup_max,2), _f(nr.AsB_sup_max,2),
                                    str(nr.combos[nr.worst_cap].geo_ult.lc_id),
                                    str(nr.combos[nr.worst_volteo].geo_ult.lc_id),
                                    str(nr.combos[nr.worst_desl].geo_ult.lc_id),
                                    str(nr.combos[nr.worst_ext].geo_ult.lc_id),
                                    str(nr.combos[nr.worst_pun].struc.lc_id),
                                    str(nr.combos[nr.worst_cort].struc.lc_id),
                                    str(nr.combos[nr.worst_flex].struc.lc_id)]):
                c = row.cells[j+1]
                c.text = v; c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_paragraph()

    def _zapata(self, doc, nr: NodeResult, params: DesignParams) -> None:
        _title(doc, f"Zapata  {nr.node_label}", 2)
        p = doc.add_paragraph()
        p.add_run(f"L={nr.L:.2f}m  ×  B={nr.B:.2f}m  ×  h={nr.d_total:.2f}m"
                  f"   (d={nr.d_ef:.2f}m)").font.bold = True

        # Tabla geotécnica
        geo_source = "Servicio" if params.method == 1 else "Últimas"
        doc.add_paragraph(f"Verificaciones Geotécnicas — {geo_source}").runs[0].font.italic = True
        geo_cols = ["CL", "P_col\n(ton)", "P_tot\n(ton)",
                    "f₁", "f₂", "f₃", "f₄", "Eje N.\nL(m)", "Eje N.\nB(m)", "≤ftu?",
                    "δmax\ncm", "δperm\ncm", "Asent.?",
                    "FSV_L", "FSV_B", "FSV_R", "Volt.?",
                    "FSD_L", "FSD_B", "FSD_R", "Desl.?",
                    "FS_ext", "Extrac.?"]
        tbl_g = doc.add_table(rows=len(nr.combos)+1, cols=len(geo_cols))
        tbl_g.style = "Table Grid"; _hdr_row(tbl_g, geo_cols)
        for i, cr in enumerate(nr.combos):
            gr = cr.geo_serv if params.method == 1 else cr.geo_ult
            if gr is None: continue
            pr = gr.pressures
            row = tbl_g.rows[i+1]
            asent_on = gr.asent_perm > 0
            vals = [str(gr.lc_id), _f(gr.P_col,2), _f(gr.P_total,2),
                    _f(pr.f1,2), _f(pr.f2,2), _f(pr.f3,2), _f(pr.f4,2),
                    _f(pr.x_neutro_L,2), _f(pr.x_neutro_B,2),
                    _ok(gr.ok_cap),
                    _f(gr.delta_max,2) if asent_on else "—",
                    _f(gr.asent_perm,2) if asent_on else "—",
                    _ok(gr.ok_asent) if asent_on else "—",
                    _f(gr.FS_volteo_L,2), _f(gr.FS_volteo_B,2), _f(gr.FS_volteo_R,2),
                    _ok(gr.ok_volteo),
                    _f(gr.FS_desl_L,2), _f(gr.FS_desl_B,2), _f(gr.FS_desl_R,2),
                    _ok(gr.ok_desl),
                    _f(gr.FS_ext,2), _ok(gr.ok_ext)]
            for j, txt in enumerate(vals):
                c = row.cells[j]; c.text = txt
                c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                if txt in ("NO OK",):
                    c.paragraphs[0].runs[0].font.color.rgb = _ROJO
                    c.paragraphs[0].runs[0].font.bold = True

        doc.add_paragraph()

        # Tabla estructural
        doc.add_paragraph("Diseño Estructural — Últimas").runs[0].font.italic = True
        str_cols = ["CL", "qnu\n(t/m²)", "vu_pun\nkg/cm²", "φvc_pun", "Pun?",
                    "vu_L", "φvc_L", "C_L?", "vu_B", "φvc_B", "C_B?",
                    "MuL\n(t·m)", "MuB\n(t·m)",
                    "AsL\ncm²/m", "AsB\ncm²/m",
                    "AsL_sup\ncm²/m", "AsB_sup\ncm²/m",
                    "d_tot\n(m)"]
        tbl_s = doc.add_table(rows=len(nr.combos)+1, cols=len(str_cols))
        tbl_s.style = "Table Grid"; _hdr_row(tbl_s, str_cols)
        for i, cr in enumerate(nr.combos):
            sr = cr.struc
            if sr is None: continue
            As_sup_L = max(sr.AsL_temp_sup, sr.AsL_ext_sup)
            As_sup_B = max(sr.AsB_temp_sup, sr.AsB_ext_sup)
            row = tbl_s.rows[i+1]
            vals = [str(sr.lc_id), _f(sr.qnu,2),
                    _f(sr.vu_pun,3), _f(sr.vc_pun,3), _ok(sr.ok_pun),
                    _f(sr.vu_L,3), _f(sr.vc_L,3), _ok(sr.ok_cort_L),
                    _f(sr.vu_B,3), _f(sr.vc_B,3), _ok(sr.ok_cort_B),
                    _f(sr.MuL,2), _f(sr.MuB,2),
                    _f(sr.AsL,2), _f(sr.AsB,2),
                    _f(As_sup_L,2), _f(As_sup_B,2),
                    _f(sr.d_total,3)]
            worst_set = {nr.worst_pun, nr.worst_cort, nr.worst_flex}
            for j, txt in enumerate(vals):
                c = row.cells[j]; c.text = txt
                c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                if txt == "NO OK":
                    c.paragraphs[0].runs[0].font.color.rgb = _ROJO
                    c.paragraphs[0].runs[0].font.bold = True
            if i in worst_set:
                _shade(row.cells[0], "FDEBD0")
        doc.add_paragraph()
        doc.add_page_break()


# ── Memoria de cálculo ────────────────────────────────────────────────────────

class MemoExporter:
    """Memoria de cálculo con fórmulas + valores numéricos para la combinación peor."""

    def export(self, results: List[NodeResult], params: DesignParams,
               path: str, progress_cb=None) -> str:
        if not DOCX_OK:
            raise RuntimeError("Instale python-docx:  pip install python-docx")
        n = max(len(results), 1)
        if progress_cb:
            progress_cb(2, "Generando portada y parámetros…")
        doc = Document()
        for sec in doc.sections:
            sec.top_margin = Cm(2.0); sec.bottom_margin = Cm(2.0)
            sec.left_margin = Cm(2.5); sec.right_margin = Cm(2.0)

        self._portada(doc, params)
        self._nota_ejes(doc, params)   # solo si fuente = "Base de columna"
        self._codigos(doc, params)
        self._parametros(doc, params)
        for i, nr in enumerate(results):
            if progress_cb:
                pct = 8 + int(87 * i / n)
                progress_cb(pct, f"Memoria zapata {nr.node_label}  ({i+1}/{n})…")
            self._zapata_memo(doc, nr, params)
        if progress_cb:
            progress_cb(97, "Guardando documento…")
        doc.save(path)
        if progress_cb:
            progress_cb(100, "Listo.")
        return path

    def _portada(self, doc, params: DesignParams) -> None:
        doc.add_paragraph()
        for txt, size, color in [
            ("MEMORIA DE CÁLCULO", 20, _CAFE),
            ("Diseño de Zapatas Aisladas — Footing Design Pro", 13, _AZUL),
        ]:
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(txt)
            run.font.size = Pt(size); run.font.bold = True; run.font.color.rgb = color
        doc.add_paragraph()
        t = doc.add_table(rows=5, cols=2); t.style = "Table Grid"
        for k, v in [("Proyecto", params.proyecto or "—"),
                      ("Código",   params.code),
                      ("Método",   f"{'1 — Servicio/Últimas' if params.method==1 else '2 — Últimas (MDOC CFE B.2.5)'}"),
                      ("FS volteo", str(params.FSV_min)),
                      ("Fecha",    datetime.now().strftime("%d/%m/%Y"))]:
            r = t.add_row()
            r.cells[0].text = k; r.cells[1].text = v
            r.cells[0].paragraphs[0].runs[0].font.bold = True
        t._tbl.remove(t.rows[0]._tr)
        doc.add_page_break()

    def _nota_ejes(self, doc, params: DesignParams) -> None:
        """Nota de transformación de ejes locales→globales (solo para barras)."""
        if params.fuente != "Base de columna":
            return
        _title(doc, "Transformación de Coordenadas Locales → Globales", 2)
        doc.add_paragraph(
            "Cuando los elementos mecánicos se obtienen del extremo inicial de barras "
            "columna en STAAD Pro, las fuerzas y momentos se devuelven en el sistema de "
            "coordenadas LOCALES del miembro. Para el diseño de zapatas se requiere el "
            "sistema GLOBAL (Y↑ vertical)."
        )
        _add_formula(doc,
            "Sistema de coordenadas locales (STAAD Pro, columna vertical, β=0):",
            "lx = dirección axial (nodo inicio → fin = global +Y)\n"
            "ly = normalizar(ref × lx)  con ref = (1,0,0) para miembro vertical\n"
            "   → ly = (0,0,1) = global +Z\n"
            "lz = lx × ly = (1,0,0) = global +X\n\n"
            "Con ángulo beta β ≠ 0: ly y lz rotan alrededor de lx en β grados.",
        )
        _add_formula(doc,
            "Transformación local → global (suma vectorial):",
            "F_global = Fx_local·lx + Fy_local·ly + Fz_local·lz\n"
            "M_global = Mx_local·lx + My_local·ly + Mz_local·lz\n\n"
            "Para columna vertical con β=0:\n"
            "  FY_global = Fx_local  (axial vertical)      → P = –FY_global\n"
            "  FX_global = Fz_local  (cortante local Z)    → Vy\n"
            "  FZ_global = Fy_local  (cortante local Y)    → Vz\n"
            "  MX_global = Mz_local  (momento local Z)     → My (volcante en X)\n"
            "  MZ_global = My_local  (momento local Y)     → Mz (volcante en Z)\n\n"
            "NOTA: Para β=90° los ejes Y y Z locales se intercambian, "
            "por lo que también se intercambian las componentes de cortante y momento.",
            ref="STAAD Pro Technical Reference — Section 5.26 (Member local axes)",
        )
        doc.add_paragraph()

    def _codigos(self, doc, params) -> None:
        _title(doc, "1. Códigos y Referencias")
        for ref in [
            "NTC 2023 — Normas Técnicas Complementarias para Diseño y Construcción "
            "de Estructuras de Concreto, Ciudad de México 2023.",
            "ACI 318-25 — Building Code Requirements for Structural Concrete, "
            "American Concrete Institute, 2025.",
            "MDOC CFE 2015 — Manual de Diseño de Obras Civiles, CFE, "
            "Sección B.2.5 Cimentaciones en Suelos.",
            "Meyerhof, G.G. (1963). Some Recent Research on the Bearing Capacity "
            "of Foundations. Canadian Geotechnical Journal, 1(1), 16-26.",
            "Bowles, J.E. (1996). Foundation Analysis and Design, 5th Ed. McGraw-Hill.",
        ]:
            doc.add_paragraph(ref, style="List Bullet")
        doc.add_paragraph()

    def _parametros(self, doc, params: DesignParams) -> None:
        _title(doc, "2. Parámetros de Diseño")
        items = [
            ("f'c",                  f"{params.fc} kgf/cm²"),
            ("fy",                   f"{params.fy} kgf/cm²"),
            ("γ_concreto",           f"{params.gama_conc} ton/m³"),
            ("ftu (capacidad adm.)", f"{params.ftu} ton/m²"),
            ("γ_suelo",              f"{params.gama_suelo} ton/m³"),
            ("φ (ángulo fricción)",  f"{params.phi_suelo}°"),
            ("c (cohesión)",         f"{params.cohesion} ton/m²"),
            ("Df (desplante)",       f"{params.Df} m"),
            ("cy × cz (defecto)",    f"{params.cy:.2f} m × {params.cz:.2f} m"),
            ("Tipo de zapata",       "Cuadrada" if params.tipo==0 else "Rectangular"),
            ("Método",               f"{'1 — dimensionar con servicio' if params.method==1 else '2 — dimensionar con últimas (MDOC CFE B.2.5)'}"),
            ("FS volteo mínimo",     str(params.FSV_min)),
            ("FS desliz. mínimo",    str(params.FSD_min)),
            ("FS extracción mínimo", str(params.FS_ext_min)),
            ("Frd deslizamiento",    f"{'1.0 (Método 1)' if params.method==1 else '0.6 (Método 2, MDOC CFE)'}"),
            ("Traslado momento V·Df", "Sí  (Mact = |M| + |V|·Df)" if params.include_vdf else "No  (Mact = |M|)"),
            ("Revisión de estabilidad", "Sí — condiciona dimensionado" if getattr(params,"check_stability",True) else "No — solo informativo"),
            ("ks — Módulo reacción vert.", f"{getattr(params,'ks',0.0):.1f} ton/m³" if getattr(params,'ks',0.0) > 0 else "No definido"),
            ("Código diseño",        params.code),
            ("Recubrimiento",        f"{params.rec} m"),
        ]
        t = doc.add_table(rows=len(items)+1, cols=2); t.style = "Table Grid"
        for j, h in enumerate(["Parámetro", "Valor"]):
            c = t.rows[0].cells[j]; c.text = h
            _shade(c, "475C6B")
            c.paragraphs[0].runs[0].font.bold = True
            c.paragraphs[0].runs[0].font.color.rgb = _BLANCO
        for i, (k, v) in enumerate(items):
            t.rows[i+1].cells[0].text = k
            t.rows[i+1].cells[1].text = v
        doc.add_paragraph()

    def _zapata_memo(self, doc, nr: NodeResult, params: DesignParams) -> None:
        _title(doc, f"Zapata  {nr.node_label}")

        _title(doc, "Dimensiones y Resumen de Armado", 2)
        doc.add_paragraph(
            f"L = {nr.L:.2f} m,  B = {nr.B:.2f} m,  "
            f"h = {nr.d_total:.2f} m,  d = {nr.d_ef:.2f} m"
        ).runs[0].font.bold = True

        # Tabla resumen de armado
        _title(doc, "Tabla resumen — armado de la zapata", 3)
        sum_hdrs = ["Parámetro", "Dir. L", "Dir. B"]
        dL_inf, sL_inf, aL_inf = _select_bar(nr.AsL_max)
        dB_inf, sB_inf, aB_inf = _select_bar(nr.AsB_max)
        dL_sup, sL_sup, aL_sup = _select_bar(nr.AsL_sup_max) if nr.AsL_sup_max > 0 else (None,None,None)
        dB_sup, sB_sup, aB_sup = _select_bar(nr.AsB_sup_max) if nr.AsB_sup_max > 0 else (None,None,None)
        rows_arm = [
            ("As lecho inf. requerido (cm²/m)", f"{nr.AsL_max:.2f}", f"{nr.AsB_max:.2f}"),
            ("Varillado inf. propuesto",
             f"Ø{dL_inf}@{sL_inf}cm → {aL_inf:.2f}cm²/m" if dL_inf else "—",
             f"Ø{dB_inf}@{sB_inf}cm → {aB_inf:.2f}cm²/m" if dB_inf else "—"),
            ("As lecho sup. requerido (cm²/m)",
             f"{nr.AsL_sup_max:.2f}" if nr.AsL_sup_max > 0 else "Solo temp.",
             f"{nr.AsB_sup_max:.2f}" if nr.AsB_sup_max > 0 else "Solo temp."),
            ("Varillado sup. propuesto",
             f"Ø{dL_sup}@{sL_sup}cm → {aL_sup:.2f}cm²/m" if dL_sup else "—",
             f"Ø{dB_sup}@{sB_sup}cm → {aB_sup:.2f}cm²/m" if dB_sup else "—"),
            ("Peralte efectivo d (m)", f"{nr.d_ef:.3f}", f"{nr.d_ef:.3f}"),
            ("Espesor total h (m)", f"{nr.d_total:.3f}", f"{nr.d_total:.3f}"),
        ]
        tbl_arm = doc.add_table(rows=len(rows_arm)+1, cols=3)
        tbl_arm.style = "Table Grid"
        _hdr_row(tbl_arm, sum_hdrs)
        for i, row_data in enumerate(rows_arm):
            r = tbl_arm.rows[i+1]
            for j, v in enumerate(row_data):
                r.cells[j].text = v
        doc.add_paragraph()

        geo_src = "Servicio" if params.method == 1 else "Últimas"

        # Combinaciones de referencia
        def geoq(i):
            cr = nr.combos[i]
            return cr.geo_serv if params.method == 1 else cr.geo_ult

        self._sec_presiones(doc, nr, params, geoq, geo_src)
        self._sec_volteo(doc, nr, params, geoq)
        self._sec_deslizamiento(doc, nr, params, geoq)
        self._sec_extraccion(doc, nr, params, geoq)
        self._sec_punzonamiento(doc, nr, params)
        self._sec_cortante(doc, nr, params)
        self._sec_flexion(doc, nr, params)
        self._sec_acero_superior(doc, nr, params)
        self._sec_asentamientos(doc, nr, params)
        doc.add_page_break()

    # ── Secciones individuales de la memoria ──────────────────────────────────

    def _sec_presiones(self, doc, nr, params, geoq, geo_src) -> None:
        _title(doc, f"Capacidad de Carga — {geo_src} (Comb. más desfavorable)", 2)
        i  = nr.worst_cap; gr = geoq(i); pr = gr.pressures if gr else None
        if gr is None: return

        _add_formula(doc,
            "Pesos de cimentación y suelo:",
            "P_cim   = A·h_zap·γ_c + (Df − h_zap)·cy·cz·γ_c\n"
            "Vol_sue = A·Df − A·h_zap − (Df − h_zap)·cy·cz\n"
            "P_suelo = max(Vol_sue, 0)·γ_s\n"
            "P_total = P_col + P_cim + P_suelo",
            f"A = {_f(nr.L,2)}×{_f(nr.B,2)} = {_f(nr.L*nr.B,3)} m²\n"
            f"P_cim   = {_f(gr.P_cim,2)} ton\n"
            f"P_suelo = {_f(gr.P_suelo,2)} ton\n"
            f"P_total = {_f(gr.P_col,2)} + {_f(gr.P_cim,2)} + {_f(gr.P_suelo,2)}"
            f" = {_f(gr.P_total,2)} ton",
            ref="Diseño propio — pesos volumétricos",
        )
        fml_str = (
            "My_act = My_col + Vy·Df   [traslado al nivel de desplante — NTC §3.7]\n"
            "Mz_act = Mz_col + Vz·Df\n"
            if gr.include_vdf else
            "My_act = My_col   [fuerzas ya en nivel de base — sin traslado]\n"
            "Mz_act = Mz_col\n"
        )
        vdf_str = (
            f"My_act = {_f(gr.My_col,2)} + {_f(gr.Vy_col,2)}·{params.Df}"
            f" = {_f(gr.My_act_signed,3)} ton·m\n"
            f"Mz_act = {_f(gr.Mz_col,2)} + {_f(gr.Vz_col,2)}·{params.Df}"
            f" = {_f(gr.Mz_act_signed,3)} ton·m"
            if gr.include_vdf else
            f"My_act = {_f(gr.My_act_signed,3)} ton·m\n"
            f"Mz_act = {_f(gr.Mz_act_signed,3)} ton·m"
        )
        ex = getattr(gr, "ex", 0.0); ez = getattr(gr, "ez", 0.0)
        My_ecc = getattr(gr, "My_ecc", 0.0); Mz_ecc = getattr(gr, "Mz_ecc", 0.0)
        has_ecc = abs(ex) > 0.001 or abs(ez) > 0.001
        ecc_fml = (
            "\nEfecto excentricidad de columna:\n"
            "  ΔMy = P_col × ex   (columna en x = L/2 + ex → momento en centroide)\n"
            "  ΔMz = P_col × ez\n"
            "  My_total = |My_act + ΔMy|   Mz_total = |Mz_act + ΔMz|"
            if has_ecc else ""
        )
        ecc_val = (
            f"\nex = {ex:.3f} m,  ez = {ez:.3f} m\n"
            f"ΔMy = {_f(gr.P_col,2)} × {ex:.3f} = {_f(My_ecc,3)} ton·m\n"
            f"ΔMz = {_f(gr.P_col,2)} × {ez:.3f} = {_f(Mz_ecc,3)} ton·m\n"
            if has_ecc else ""
        )
        _add_formula(doc,
            "Momentos actuantes al nivel de desplante:",
            fml_str +
            "e₁ = |My_total| / P_total    (excentricidad de carga en dir. L)\n"
            "e₂ = |Mz_total| / P_total    (excentricidad de carga en dir. B)"
            + ecc_fml,
            vdf_str + ecc_val + "\n"
            f"My_total = {_f(gr.My_total,2)} ton·m,  Mz_total = {_f(gr.Mz_total,2)} ton·m\n"
            f"e₁ = {_f(pr.E1,4)} m  {'≤' if pr.E1 <= nr.L/6 else '>'} L/6 = {_f(nr.L/6,3)} m\n"
            f"e₂ = {_f(pr.E2,4)} m  {'≤' if pr.E2 <= nr.B/6 else '>'} B/6 = {_f(nr.B/6,3)} m",
            ref="Meyerhof (1963) / Bowles (1996) §8 / NTC 2023",
        )

        zona_desc = {0: "Núcleo kern — toda la base comprimida (plano inclinado)",
                     1: "Una excentricidad fuera del kern — distribución triangular",
                     2: "Meyerhof biaxial iterativo — eje neutro inclinado"}
        xn_L = "∞ (toda la base)" if pr.x_neutro_L >= 9990 else f"{_f(pr.x_neutro_L,3)} m desde borde comprimido"
        xn_B = "∞ (toda la base)" if pr.x_neutro_B >= 9990 else f"{_f(pr.x_neutro_B,3)} m desde borde comprimido"
        _add_formula(doc,
            f"Distribución de presiones — Zona {pr.zona}: {zona_desc.get(pr.zona,'?')}",
            "Zona 0 — dentro del núcleo kern:\n"
            "  fᵢ = P/A ± My/S_L ± Mz/S_B\n"
            "  S_L = B·L²/6,  S_B = L·B²/6\n\n"
            "Zona 1 — una excentricidad fuera del kern:\n"
            "  x_neutro = 3·(L/2 − e)  (desde borde comprimido)\n"
            "  f_max = 2·P / (x_neutro · B)\n\n"
            "Zona 2 — Meyerhof biaxial:\n"
            "  Eje neutro: x/a + y/b = 1   (a, b resueltos iterativamente)\n"
            "  f_max = P / (Area_efec − Qoy/a − Qox/b)",
            f"Zona aplicada: {pr.zona}\n"
            f"f₁ = {_f(pr.f1,2)} ton/m²  (esquina My+, Mz+ — máx. compresión)\n"
            f"f₂ = {_f(pr.f2,2)} ton/m²  (esquina My+, Mz−)\n"
            f"f₃ = {_f(pr.f3,2)} ton/m²  (esquina My−, Mz+)\n"
            f"f₄ = {_f(pr.f4,2)} ton/m²  (esquina My−, Mz− — mín.)\n"
            f"Área efectiva = {_f(pr.A_efec,3)} m²\n"
            f"Eje neutro dir. L: {xn_L}\n"
            f"Eje neutro dir. B: {xn_B}\n"
            f"σ_max = {_f(gr.f_max,2)} ton/m²  {'≤' if gr.ok_cap else '>'} "
            f"ftu = {_f(params.ftu,2)} ton/m²  → {_ok(gr.ok_cap)}",
            ref="Meyerhof (1963) / Bowles (1996) §8",
        )

        # Diagrama de presiones (planta + 3D) — mismo dibujo que la UI
        geom = _geom_from_struc(nr.combos[i].struc, params)
        img = _pressure_fig_to_bytes(pr, nr.L, nr.B, params.ftu, geom,
                                     gr_ok=gr.ok_cap, lc_id=gr.lc_id)
        if img:
            doc.add_paragraph("Diagrama de presiones de contacto (peor combinación por capacidad):").runs[0].font.italic = True
            _insert_image_bytes(doc, img, width_cm=14.5)

    def _sec_volteo(self, doc, nr, params, geoq) -> None:
        check = getattr(params, "check_stability", True)
        titulo = "Volteo (Comb. más desfavorable)" + \
                 ("" if check else "  [Solo informativo]")
        _title(doc, titulo, 2)
        i = nr.worst_volteo; gr = geoq(i)
        if gr is None: return
        ex = getattr(gr, "ex", 0.0); ez = getattr(gr, "ez", 0.0)
        has_ecc = abs(ex) > 0.001 or abs(ez) > 0.001

        formula_base = (
            "M_res_L = (P_cim + P_suelo)·(L/2) + P_col·brazo_L_min\n"
            "  brazo_L_min = min(L/2+ex, L/2−ex) = L/2 − |ex|  (borde más desfavorable)\n"
            "M_res_B = (P_cim + P_suelo)·(B/2) + P_col·(B/2 − |ez|)\n"
            "My_volt = |My_act|  (momento externo, sin incluir excentricidad)\n"
            "FSV_L = M_res_L / My_volt   FSV_B = M_res_B / Mz_volt\n"
            "FSV_R = min(FSV_L, FSV_B)"
            if has_ecc else
            "M_res_L = P_total · (L/2)   M_res_B = P_total · (B/2)\n"
            "FSV_L = M_res_L / My_total   FSV_B = M_res_B / Mz_total\n"
            "FSV_R = min(FSV_L, FSV_B)  ≥  FSV_min"
        )
        ecc_txt = (
            f"\nExcentricidad col: ex = {ex:.3f} m, ez = {ez:.3f} m\n"
            f"→ brazo_L_min = L/2 − |ex| = {nr.L/2:.3f} − {abs(ex):.3f} = {nr.L/2-abs(ex):.3f} m\n"
            f"→ brazo_B_min = B/2 − |ez| = {nr.B/2:.3f} − {abs(ez):.3f} = {nr.B/2-abs(ez):.3f} m\n"
            if has_ecc else ""
        )
        _add_formula(doc,
            "Factor de seguridad al volteo (MDOC CFE B.2.5):",
            formula_base,
            f"{ecc_txt}"
            f"M_res_L = {_f(gr.M_res_L,2)} ton·m\n"
            f"M_res_B = {_f(gr.M_res_B,2)} ton·m\n"
            f"My_volt = {_f(abs(gr.My_act_signed),2)} ton·m,  "
            f"Mz_volt = {_f(abs(gr.Mz_act_signed),2)} ton·m\n"
            f"FSV_L = {_f(gr.FS_volteo_L,2)},  FSV_B = {_f(gr.FS_volteo_B,2)},  "
            f"FSV_R = {_f(gr.FS_volteo_R,2)}\n"
            f"FSV_R = {_f(gr.FS_volteo_R,2)}  {'≥' if gr.ok_volteo else '<'}  "
            f"{params.FSV_min}  → {_ok(gr.ok_volteo)}"
            + ("" if check else "\n[Solo informativo — no condiciona dimensionado]"),
            ref="MDOC CFE B.2.5 / Bowles (1996) §8 / NTC 2023",
        )

    def _sec_deslizamiento(self, doc, nr, params, geoq) -> None:
        _title(doc, "Deslizamiento (Comb. más desfavorable)", 2)
        i = nr.worst_desl; gr = geoq(i)
        if gr is None: return
        A_efec = gr.A_efec_desl
        Frd    = gr.Frd_usado
        V_fric = (gr.P_total * math.tan(math.radians(params.phi_suelo))
                  + params.cohesion * A_efec) * Frd
        _add_formula(doc,
            "Resistencia al deslizamiento — ec. 3.17 (MDOC CFE B.2.5):",
            "Ph ≤ (Pv·tan(δ) + c'·A_efec) · Frd\n\n"
            "donde:\n"
            "  tan(δ)  = coeficiente de fricción zapata-suelo ≈ tan(φ)\n"
            "  c'      = adherencia suelo-zapata ≈ c (cohesión)\n"
            "  A_efec  = área efectiva de la zapata (zona comprimida)\n"
            "  Frd     = factor de reducción:\n"
            "              Método 1 (servicio, FS tradicional)  → Frd = 1.0\n"
            "              Método 2 (últimas, MDOC CFE B.2.5)  → Frd = 0.6\n\n"
            "V_res = (P_total·tan(φ) + c·A_efec) · Frd\n"
            "V_res_R = √(V_res_L²+V_res_B²)  [resultante]\n"
            "V_act_R = √(Vy²+Vz²)             [fuerza horizontal resultante]\n"
            "FSD_R   = V_res_R / V_act_R  ≥  FSD_min",
            f"Frd    = {Frd}\n"
            f"A_efec = {_f(A_efec,4)} m²  (área comprimida bajo la zapata)\n"
            f"V_fric = ({_f(gr.P_total,2)}·tan({params.phi_suelo}°) + "
            f"{params.cohesion}·{_f(A_efec,4)})·{Frd}\n"
            f"       = ({_f(gr.P_total*math.tan(math.radians(params.phi_suelo)),3)} + "
            f"{_f(params.cohesion*A_efec,3)})·{Frd}\n"
            f"       = {_f(V_fric,3)} ton\n"
            f"V_res_L = V_res_B = {_f(gr.V_res_L,3)} ton  "
            f"→  V_res_R = {_f(gr.V_res_R,3)} ton\n"
            f"V_act_R = √({_f(gr.Vy_col,2)}²+{_f(gr.Vz_col,2)}²) = {_f(gr.V_act_res,3)} ton\n"
            f"FSD_L = {_f(gr.FS_desl_L,2)},  FSD_B = {_f(gr.FS_desl_B,2)},  FSD_R = {_f(gr.FS_desl_R,2)}\n"
            f"FSD_R = {_f(gr.FS_desl_R,2)}  ≥  {params.FSD_min}  → {_ok(gr.ok_desl)}",
            ref="MDOC CFE B.2.5 ec.3.17 / Crespo Villalaz §9.6",
        )

    def _sec_extraccion(self, doc, nr, params, geoq) -> None:
        _title(doc, "Extracción (Comb. más desfavorable)", 2)
        i = nr.worst_ext; gr = geoq(i)
        if gr is None: return
        _add_formula(doc,
            "Factor de seguridad a la extracción:",
            "Si P_col < 0 (tracción en columna):\n"
            "  FS_ext = (P_cim + P_suelo) / |P_col|\n"
            "  Si FS_ext ≥ 1.0: los pesos propios equilibran la tracción (OK)\n"
            "  Si FS_ext < 1.0: hay extracción neta — requiere anclaje",
            (f"P_col = {_f(gr.P_col,2)} ton  {'(tracción — hay extracción)' if gr.hay_tension else '(compresión — sin extracción)'}\n"
             + (f"P_cim + P_suelo = {_f(gr.P_cim+gr.P_suelo,2)} ton\n"
                f"FS_ext = {_f(gr.FS_ext,2)}  {'≥ 1.0' if gr.FS_ext>=1 else '< 1.0'}  → {_ok(gr.ok_ext)}"
                if gr.hay_tension else
                f"FS_ext = ∞  (sin tracción)  → {_ok(gr.ok_ext)}")),
            ref="MDOC CFE B.2.5 / Bowles (1996)",
        )

    def _sec_punzonamiento(self, doc, nr, params) -> None:
        _title(doc, "Punzonamiento — Cortante en Dos Direcciones (Comb. más desfavorable)", 2)
        cr = nr.combos[nr.worst_pun]; sr = cr.struc
        if sr is None: return
        cy = params.cy; cz = params.cz
        d_cm = sr.d_req * 100.0
        _add_formula(doc,
            "Sección crítica a d/2 de la cara de la columna (NTC 2023 §5.6.3.1):",
            "bo = 2·(cy + d) + 2·(cz + d)   [cm]\n"
            "A_pun = (cy + d)·(cz + d)       [m²  — área dentro del perímetro crítico]",
            f"d  = {_f(sr.d_req,3)} m  ({_f(d_cm,1)} cm)\n"
            f"bo = 2·({_f(cy*100,1)}+{_f(d_cm,1)}) + 2·({_f(cz*100,1)}+{_f(d_cm,1)})"
            f" = {_f(sr.bo_cm,1)} cm\n"
            f"A_pun = ({_f(cy,3)}+{_f(sr.d_req,3)})·({_f(cz,3)}+{_f(sr.d_req,3)})"
            f" = {_f(sr.A_pun,4)} m²",
            ref="NTC 2023 §5.6.3.1",
        )
        _add_formula(doc,
            "Fuerza de punzonamiento última:",
            "Vu = P_total_ult − qnu·A_pun   [ton]\n"
            "vu = Vu·1000 / (bo·d)           [kgf/cm²]",
            f"qnu = {_f(sr.qnu,2)} ton/m²   (presión neta última = f₁ del caso último)\n"
            f"Vu = {_f(cr.geo_ult.P_total,2)} − {_f(sr.qnu,2)}·{_f(sr.A_pun,4)}"
            f" = {_f(sr.Vu_pun,2)} ton\n"
            f"vu = {_f(sr.Vu_pun,2)}·1000 / ({_f(sr.bo_cm,1)}·{_f(d_cm,1)})"
            f" = {_f(sr.vu_pun,3)} kgf/cm²",
            ref="NTC 2023 §5.6.1",
        )
        _add_formula(doc,
            "Resistencia nominal al punzonamiento (NTC 2023 §5.6.2.1.1 Tabla — sin Av):",
            "v_cR = mín:\n"
            "  a)  1.00 · λ_s · λ · √f'c\n"
            "  b)  0.50 · (1 + 2/β) · λ_s · λ · √f'c\n"
            "  c)  0.27 · (2 + αs·d/bo) · λ_s · λ · √f'c\n\n"
            "λ_s = √(2/(1 + 0.04·d)) ≤ 1.0   (d en cm) — factor de tamaño §5.6.2.1.1\n"
            "β  = cy/cz (relación lados columna, ≥ 1)\n"
            "αs = 40 columna interior, 30 borde, 20 esquina\n"
            "λ  = 1.0 concreto normal\n\n"
            "φv_cR = F_R · v_cR   (F_R = 0.75, NTC Tabla 3.8.2.1)\n"
            "Verificación: vu ≤ φv_cR",
            f"f'c = {params.fc} kgf/cm²,  √f'c = {math.sqrt(params.fc):.3f} kgf½/cm\n"
            f"β  = {_f(sr.beta_c,2)},  αs = 40,  d = {_f(d_cm,1)} cm\n"
            f"λ_s = {_f(sr.lam_s_pun,4)}\n"
            f"a) {_f(1.00*sr.lam_s_pun*math.sqrt(params.fc),3)} kgf/cm²\n"
            f"b) {_f(0.50*(1+2/sr.beta_c)*sr.lam_s_pun*math.sqrt(params.fc),3)} kgf/cm²\n"
            f"c) {_f(0.27*(2+40*d_cm/sr.bo_cm)*sr.lam_s_pun*math.sqrt(params.fc),3)} kgf/cm²\n"
            f"v_cR (nom.) = {_f(sr.vc_pun/0.75,3)} kgf/cm²   (mín. de a,b,c)\n"
            f"φv_cR = 0.75 × {_f(sr.vc_pun/0.75,3)} = {_f(sr.vc_pun,3)} kgf/cm²\n"
            f"vu = {_f(sr.vu_pun,3)} {'≤' if sr.ok_pun else '>'} φv_cR = {_f(sr.vc_pun,3)} kgf/cm²  → {_ok(sr.ok_pun)}",
            ref="NTC 2023 §5.6.2.1.1 Tabla / ACI 318-19 Table 22.6.5.2",
        )

    def _sec_cortante(self, doc, nr, params) -> None:
        _title(doc, "Cortante como Viga Ancha — Una Dirección (Comb. más desfavorable)", 2)
        cr = nr.combos[nr.worst_cort]; sr = cr.struc
        if sr is None: return
        d_cm = sr.d_req * 100.0
        _add_formula(doc,
            "Sección crítica a d de la cara de la columna (NTC 2023 §5.5.1.2):",
            "Dir. L:  x_crit_L = (L − cy)/2 − d   [m desde borde exterior]\n"
            "Dir. B:  x_crit_B = (B − cz)/2 − d\n"
            "Vu_L = qnu · x_crit_L · B   [ton]\n"
            "Vu_B = qnu · x_crit_B · L   [ton]\n"
            "vu   = Vu·1000 / (bw·d)     [kgf/cm²]",
            f"d = {_f(sr.d_req,3)} m  ({_f(d_cm,1)} cm)\n"
            f"qnu = {_f(sr.qnu,2)} ton/m²\n"
            f"Dir. L: x_crit = {_f(sr.x_crit_L,3)} m,  Vu_L = {_f(sr.Vu_L,2)} ton,  "
            f"vu_L = {_f(sr.vu_L,3)} kgf/cm²\n"
            f"Dir. B: x_crit = {_f(sr.x_crit_B,3)} m,  Vu_B = {_f(sr.Vu_B,2)} ton,  "
            f"vu_B = {_f(sr.vu_B,3)} kgf/cm²",
            ref="NTC 2023 §5.5.1.2 / ACI 318-19 §22.5.1.2",
        )
        _add_formula(doc,
            "Resistencia al cortante — zapata sin refuerzo transversal (NTC 2023 §5.5.3.2.1):",
            "V_cR = 0.66 · λ_s · λ · (ρ_w)^(1/3) · √f'c · b_w · d   [kgf]\n\n"
            "Donde:\n"
            "  λ_s = √(2/(1 + 0.04·d)) ≤ 1.0   (d en cm) — factor de tamaño\n"
            "  λ   = 1.0 para concreto normal\n"
            "  ρ_w = cuantía de refuerzo longitudinal (= As_final / (b·d))\n"
            "  b_w : ancho de la franja (= B en dir. L, L en dir. B)  [cm]\n\n"
            "φV_cR = F_R · V_cR,   F_R = 0.75  (NTC 2023 Tabla 3.8.2.1)\n"
            "φv_cR = φV_cR·1000/(b_w·d)  [kgf/cm²]\n"
            "Verificación: vu ≤ φv_cR",
            f"f'c = {params.fc} kgf/cm²,  √f'c = {math.sqrt(params.fc):.3f}\n"
            f"λ_s = {_f(sr.lam_s_cort,4)}\n"
            f"ρ_w = {_f(sr.rho_cort,5)} (cuantía promedio L y B)\n"
            f"(ρ_w)^(1/3) = {_f(sr.rho_cort**(1/3) if sr.rho_cort>0 else 0,4)}\n"
            f"Dir. L: φv_cR = {_f(sr.vc_L,3)} kgf/cm²  ≥  vu_L = {_f(sr.vu_L,3)}  → {_ok(sr.ok_cort_L)}\n"
            f"Dir. B: φv_cR = {_f(sr.vc_B,3)} kgf/cm²  ≥  vu_B = {_f(sr.vu_B,3)}  → {_ok(sr.ok_cort_B)}",
            ref="NTC 2023 §5.5.3.2.1 / ACI 318-19 Table 22.5.5.1",
        )

    def _sec_flexion(self, doc, nr, params) -> None:
        _title(doc, "Flexión y Armado Lecho Inferior (Comb. más desfavorable)", 2)
        cr = nr.combos[nr.worst_flex]; sr = cr.struc
        if sr is None: return
        d_cm = sr.d_req * 100.0
        h_cm = sr.d_total * 100.0
        from design.code_parameters import CodeParameters
        cp = CodeParameters(params.code)
        b1 = cp.beta1(params.fc)

        _add_formula(doc,
            "Factor del bloque rectangular de compresión β₁ (NTC 2023 §3.6.1):",
            "β₁ = 0.85                          si f'c ≤ 300 kgf/cm²\n"
            "β₁ = 1.05 − f'c/1400  ≥ 0.65      si f'c > 300 kgf/cm²",
            f"f'c = {params.fc} kgf/cm²\n"
            f"β₁ = {_f(b1,4)}",
            ref="NTC 2023 §3.6.1",
        )
        # Excentricidad de la columna en este elemento
        ex = getattr(sr, "ex", 0.0); ez = getattr(sr, "ez", 0.0)
        has_ecc = abs(ex) > 0.001 or abs(ez) > 0.001
        if has_ecc:
            col_x = nr.L / 2.0 + ex;  col_z = nr.B / 2.0 + ez
            _add_formula(doc,
                "Excentricidad de la columna respecto del centroide de la zapata:",
                "ex = desfase en dir. L   ez = desfase en dir. B\n"
                "Posición centroide col: x_col = L/2 + ex   z_col = B/2 + ez\n\n"
                "Brazos de voladizo asimétricos:\n"
                "  ld_izq = x_col − cy/2   (cara izq columna → borde izq zapata)\n"
                "  ld_der = L − (x_col + cy/2)   (cara der columna → borde der zapata)\n"
                "  bd_frt = z_col − cz/2   (cara frt columna → borde frt zapata)\n"
                "  bd_atr = B − (z_col + cz/2)\n"
                "Se diseña con el momento del lado GOBERNANTE (mayor).",
                f"ex = {ex:.3f} m,  ez = {ez:.3f} m\n"
                f"x_col = {col_x:.3f} m,  z_col = {col_z:.3f} m\n"
                f"ld_izq = {_f(sr.ld_izq,3)} m,  ld_der = {_f(sr.ld_der,3)} m  → gov: {sr.lado_gov_L}\n"
                f"bd_frt = {_f(sr.bd_frt,3)} m,  bd_atr = {_f(sr.bd_atras,3)} m  → gov: {sr.lado_gov_B}",
                ref="NTC 2023 §10.3 — zapata con columna excéntrica",
            )

        _add_formula(doc,
            "Momentos en la cara de la columna — voladizo con distribución trapezoidal:",
            "Presión promediada sobre B en función de x (dirección L):\n"
            "  σ_L(x) = [(f₃+f₄)/2]·(1−x/L) + [(f₁+f₂)/2]·(x/L)\n"
            "Momento de voladizo (brazo izquierdo, por ejemplo):\n"
            "  MuL_izq = [f_col_izq·ld_izq²/2 + (f_ext_izq−f_col_izq)·ld_izq·(2ld_izq/3)/2]·B\n"
            "MuL = max(MuL_izq, MuL_der)   MuB = max(MuB_frt, MuB_atr)",
            f"MuL_izq = {_f(sr.MuL_izq,3)} ton·m,  MuL_der = {_f(sr.MuL_der,3)} ton·m  → MuL = {_f(sr.MuL,3)} ton·m\n"
            f"MuB_frt = {_f(sr.MuB_frt,3)} ton·m,  MuB_atr = {_f(sr.MuB_atr,3)} ton·m  → MuB = {_f(sr.MuB,3)} ton·m",
            ref="NTC 2023 §5.2.2.1.1 — zapata como consola",
        )
        _add_formula(doc,
            "Acero requerido por flexión — método cuadrático Rn–ρ (NTC 2023 §5.2.2.1.1.1):",
            "M_R = F_R · A_s · f_y · d · (1 − 0.5q)    q = ρ·f_y / (0.85·f'c)\n"
            "Despejando As (forma cuadrática equivalente):\n"
            "  Rn = Mu·10⁵ / (F_R · b · d²)   [kgf/cm², Mu en ton·m]\n"
            "  ρ  = (0.85·f'c/fy) · (1 − √(1 − 2·Rn/(0.85·f'c)))\n"
            "  As_req = ρ · b · d               [cm²]   (b = 100 cm → cm²/m)\n\n"
            "F_R (flexión controlada por tensión, ε_t ≥ ε_cy+0.003) = 0.90  (NTC Tabla 3.8.2.2)",
            f"Dir. L:  Rn = {_f(sr.Rn_L,3)} kgf/cm²,  ρ = {_f(sr.rho_L,5)},  "
            f"As_req = {_f(sr.AsL_req,2)} cm²/m\n"
            f"Dir. B:  Rn = {_f(sr.Rn_B,3)} kgf/cm²,  ρ = {_f(sr.rho_B,5)},  "
            f"As_req = {_f(sr.AsB_req,2)} cm²/m",
            ref="NTC 2023 §5.2.2.1.1.1 / ACI 318-19 §22.2",
        )
        _add_formula(doc,
            "Acero mínimo por flexión (NTC 2023 §9.6.1.2 / ACI 318-19 Table 9.6.1.2):",
            "As_min = max(0.25·√f'c / fy, 1.4 / fy) · b · d   [cm²]",
            f"ρ_min = max(0.25·{_f(math.sqrt(params.fc),3)}/{params.fy:.0f},"
            f" 1.4/{params.fy:.0f})\n"
            f"As_min = {_f(sr.AsL_min,2)} cm²/m",
            ref="NTC 2023 §9.6.1.2",
        )
        _add_formula(doc,
            "Acero mínimo por temperatura y retracción (lecho inferior, NTC 2023 §7.6.1):",
            "ρ_temp = 0.0018              si fy ≤ 4200 kgf/cm²\n"
            "ρ_temp = 0.0018·4200/fy ≥ 0.0014  si fy > 4200 kgf/cm²\n"
            "As_temp = ρ_temp · b · h    [cm²]   (h = espesor total de la zapata)",
            f"fy = {params.fy} kgf/cm²,  h = {_f(h_cm,1)} cm\n"
            f"ρ_temp = {0.0018 if params.fy <= 4200 else max(0.0018*4200/params.fy,0.0014):.6f}\n"
            f"As_temp_inf = {_f(sr.AsL_temp_inf,2)} cm²/m",
            ref="NTC 2023 §7.6.1 / ACI 318-19 §24.4.3.2",
        )
        _add_formula(doc,
            "Acero de diseño lecho inferior — envolvente máxima:",
            "As = max(As_req, As_min, As_temp_inf)   [cm²/m]",
            f"AsL = max({_f(sr.AsL_req,2)}, {_f(sr.AsL_min,2)}, {_f(sr.AsL_temp_inf,2)}) = {_f(nr.AsL_max,2)} cm²/m\n"
            f"AsB = max({_f(sr.AsB_req,2)}, {_f(sr.AsB_min,2)}, {_f(sr.AsB_temp_inf,2)}) = {_f(nr.AsB_max,2)} cm²/m",
        )
        # Propuesta de varillado
        dL, sL, aL = _select_bar(nr.AsL_max)
        dB, sB, aB = _select_bar(nr.AsB_max)
        if dL:
            _add_formula(doc,
                "Propuesta de varillado (varillas métricas, separación mínima 10 cm):",
                "Dir. L: Ø_mm @ sep cm   →  As_prov cm²/m  ≥  As_dis cm²/m\n"
                "Dir. B: Ø_mm @ sep cm   →  As_prov cm²/m  ≥  As_dis cm²/m",
                f"Dir. L: Ø{dL} @ {sL} cm  →  {aL:.2f} cm²/m  ≥  {nr.AsL_max:.2f} cm²/m\n"
                f"Dir. B: Ø{dB} @ {sB} cm  →  {aB:.2f} cm²/m  ≥  {nr.AsB_max:.2f} cm²/m\n"
                "(Propuesta indicativa — revisar separaciones máx/mín y disponibilidad de barras)",
                ref="NTC 2023 §7.6.5 / ACI 318-19 §9.7.2.1",
            )

    def _sec_acero_superior(self, doc, nr, params) -> None:
        _title(doc, "Acero Lecho Superior", 2)

        # Temperatura
        cr0 = nr.combos[0]; sr0 = cr0.struc
        if sr0 and sr0.d_total > 0.15:
            _add_formula(doc,
                "Acero por temperatura — lecho superior (h > 0.15 m):",
                "As_temp_sup = 0.0018·b·h\n"
                "Se coloca en la cara superior de la zapata en ambas direcciones.",
                f"h = {_f(sr0.d_total,3)} m > 0.15 m\n"
                f"As_temp_sup = {_f(sr0.AsL_temp_sup,2)} cm²/m  (ambas direcc.)",
                ref="NTC 2023 §7.6.1 / ACI 318-25 §24.4",
            )

        # Extracción (peor combo)
        cr_e = nr.combos[nr.worst_ext]
        sr_e = cr_e.struc
        if sr_e and sr_e.hay_extraccion:
            _add_formula(doc,
                "Acero por extracción — lecho superior (CL más desfavorable):",
                "La columna transmite tracción a la zapata (P_col < 0).\n"
                "Presión uniforme de diseño: q_ext = |P_col| / (L×B)\n"
                "Momento de diseño (voladizo invertido):\n"
                "  Mu_ext_L = q_ext·((L−cy)/2)²/2·B\n"
                "  Mu_ext_B = q_ext·((B−cz)/2)²/2·L\n"
                "As_ext_sup = max(As_req_ext, As_temp_sup)",
                f"P_col = {_f(sr_e.P_col_tension,2)} ton\n"
                f"q_ext = {_f(sr_e.q_ext,2)} ton/m²\n"
                f"Mu_ext_L = {_f(sr_e.Mu_ext_L,3)} ton·m,  Mu_ext_B = {_f(sr_e.Mu_ext_B,3)} ton·m\n"
                f"AsL_ext_sup = {_f(sr_e.AsL_ext_sup,2)} cm²/m\n"
                f"AsB_ext_sup = {_f(sr_e.AsB_ext_sup,2)} cm²/m\n"
                f"Acero lecho superior final: L = {_f(nr.AsL_sup_max,2)} cm²/m,  B = {_f(nr.AsB_sup_max,2)} cm²/m",
                ref="NTC 2023 §10.3 / ACI 318-25 §13.2",
            )
        else:
            doc.add_paragraph(
                "No se presentó extracción en ninguna combinación. "
                "El acero del lecho superior queda definido solo por temperatura y retracción."
            )
        doc.add_paragraph()

        # ── Diagramas 2D de refuerzo ──────────────────────────────────────────
        _title(doc, "Diagramas 2D de Refuerzo (Secciones transversales)", 2)
        doc.add_paragraph(
            "Se muestran los cortes transversales en las dos direcciones principales,\n"
            "con la posición de la columna (incluida la excentricidad ex/ez),\n"
            "el refuerzo del lecho inferior y del lecho superior (cuando aplique).\n"
            "Separación de barras: mínimo 0.15 m, máximo 0.30 m."
        )
        cr_flex = nr.combos[nr.worst_flex]; sr_2d = cr_flex.struc
        if sr_2d:
            img_2d = _rebar_2d_fig(nr, params, sr_2d)
            if img_2d:
                _insert_image_bytes(doc, img_2d, width_cm=15.0)
            else:
                doc.add_paragraph("[No se pudo generar el diagrama 2D de refuerzo]")
        doc.add_paragraph()

    def _sec_asentamientos(self, doc, nr, params) -> None:
        """Sección de asentamientos elásticos — solo si ks > 0."""
        ks = getattr(params, "ks", 0.0)
        _title(doc, "Asentamientos Elásticos del Suelo", 2)
        if ks <= 0.0:
            doc.add_paragraph(
                "No se calcularon asentamientos porque el módulo de reacción "
                "vertical del suelo (ks) no fue proporcionado por el usuario."
            )
            return

        _add_formula(doc,
            "Modelo de asentamiento — Método de Winkler (módulo de reacción vertical):",
            "δᵢ = σᵢ / ks   [m]\n\n"
            "Donde:\n"
            "  δᵢ  = asentamiento vertical en el punto i  [m]\n"
            "  σᵢ  = presión de contacto en ese punto  [ton/m²]\n"
            "  ks  = módulo de reacción vertical del suelo  [ton/m³]\n\n"
            "Hipótesis: comportamiento elástico lineal del suelo (modelo de Winkler).\n"
            "La zona sin contacto (presión = 0) tiene asentamiento δ = 0.\n"
            "El asentamiento diferencial es: Δδ = δ_max − δ_min.",
            f"ks = {ks:.1f} ton/m³",
            ref="Winkler (1867) / Bowles (1996) §9 / Jiménez Salas (1975)",
        )

        # Tabla de asentamientos por combinación (peor caso)
        i_worst = nr.worst_cap
        geo_src = nr.combos[i_worst].geo_serv if params.method == 1 else nr.combos[i_worst].geo_ult
        if geo_src:
            pr = geo_src.pressures
            d1 = max(pr.f1, 0.0) / ks
            d2 = max(pr.f2, 0.0) / ks
            d3 = max(pr.f3, 0.0) / ks
            d4 = max(pr.f4, 0.0) / ks
            d_max = max(d1, d2, d3, d4)
            d_min = min(d1, d2, d3, d4)

            _add_formula(doc,
                f"Asentamientos en las 4 esquinas — CL {geo_src.lc_id} (peor capacidad):",
                "δ₁ = f₁/ks   δ₂ = f₂/ks   δ₃ = f₃/ks   δ₄ = f₄/ks\n"
                "Δδ = δ_max − δ_min   (asentamiento diferencial)",
                f"δ₁ = {pr.f1:.2f}/{ks:.1f} = {d1*100:.3f} cm  (esquina My+, Mz+)\n"
                f"δ₂ = {pr.f2:.2f}/{ks:.1f} = {d2*100:.3f} cm  (esquina My+, Mz−)\n"
                f"δ₃ = {pr.f3:.2f}/{ks:.1f} = {d3*100:.3f} cm  (esquina My−, Mz+)\n"
                f"δ₄ = {pr.f4:.2f}/{ks:.1f} = {d4*100:.3f} cm  (esquina My−, Mz−)\n"
                f"δ_max = {d_max*100:.3f} cm   δ_min = {d_min*100:.3f} cm\n"
                f"Δδ = {(d_max-d_min)*100:.3f} cm  (asentamiento diferencial)",
            )

            # Revisión contra el asentamiento permisible (si se indicó)
            asent_perm = getattr(params, "asent_perm", 0.0)
            if asent_perm > 0:
                ok = d_max * 100.0 <= asent_perm
                _add_formula(doc,
                    "Revisión del asentamiento permisible:",
                    "δ_max ≤ δ_perm",
                    f"δ_max = {d_max*100:.3f} cm  {'≤' if ok else '>'}  "
                    f"δ_perm = {asent_perm:.2f} cm  → {_ok(ok)}",
                    ref="Asentamiento permisible definido por el usuario",
                )

            # Figura de asentamientos — mismo dibujo que la UI
            geom = _geom_from_struc(nr.combos[i_worst].struc, params)
            img_s = _settlement_fig_to_bytes(pr, nr.L, nr.B, ks, geom,
                                              lc_id=geo_src.lc_id)
            if img_s:
                doc.add_paragraph(
                    "Diagrama de asentamientos — CL con mayor presión de contacto:"
                ).runs[0].font.italic = True
                _insert_image_bytes(doc, img_s, width_cm=14.5)

        doc.add_paragraph()
