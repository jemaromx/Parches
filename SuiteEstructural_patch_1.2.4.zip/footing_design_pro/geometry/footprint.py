﻿"""
Geometría de planta de zapatas — puro Python (sin COM, sin Qt, sin numpy).

Modelo de datos para ubicar cada zapata en planta (coordenadas globales X–Z
de STAAD) y para construir su polígono rectangular B×L girado el ángulo BETA
de la barra (Mejora 3).

Convención: planta en el plano global X–Z (Y es vertical en STAAD).
  * B = dimensión en la dirección "base"   (eje local sin girar → global X)
  * L = dimensión en la dirección "peralte" (eje local sin girar → global Z)
  * beta_deg = giro de la barra/zapata, positivo según regla de la mano
    derecha alrededor del eje vertical Y.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

Point = Tuple[float, float]   # (x, z) en planta global


@dataclass
class FootingPlacement:
    """Ubicación y orientación en planta de una zapata, lista para dibujar."""
    footing_id: int
    x: float                       # coordenada global X del centro (m)
    z: float                       # coordenada global Z del centro (m)
    B: float                       # dimensión en dirección base (m)
    L: float                       # dimensión en dirección peralte (m)
    h: float = 0.0                 # espesor (m), informativo
    beta_deg: float = 0.0          # giro de la barra (grados); 0 si es nodo/apoyo
    label: str = ""
    # Valor escalar para colorear el mapa (relación, FS, asentamiento…).
    # Lo llena la capa que arma cada gráfica; None = sin dato.
    value: Optional[float] = None
    # Dado (columna): dimensiones en X/Z GLOBAL del modelo (m); 0 = no dibujar
    cy: float = 0.0
    cz: float = 0.0

    def dado_corners(self) -> List[Point]:
        """Esquinas del dado cy×cz centrado en (x,z), en dirección del
        MODELO (ejes globales X/Z — el dado no gira con beta)."""
        hx, hz = self.cy / 2.0, self.cz / 2.0
        return [(self.x - hx, self.z - hz), (self.x + hx, self.z - hz),
                (self.x + hx, self.z + hz), (self.x - hx, self.z + hz)]

    def corners(self) -> List[Point]:
        """
        Cuatro esquinas del rectángulo B×L centrado en (x,z) y girado beta.
        Orden antihorario, listo para un polígono cerrado.
        """
        hb, hl = self.B / 2.0, self.L / 2.0
        local = [(-hb, -hl), (hb, -hl), (hb, hl), (-hb, hl)]
        c, s = math.cos(math.radians(self.beta_deg)), math.sin(math.radians(self.beta_deg))
        return [(self.x + lx * c - lz * s,
                 self.z + lx * s + lz * c) for lx, lz in local]


@dataclass
class PlanLayout:
    """Conjunto de zapatas en planta + utilidades de encuadre para dibujar."""
    placements: List[FootingPlacement] = field(default_factory=list)

    def add(self, p: FootingPlacement) -> None:
        self.placements.append(p)

    def bounds(self) -> Tuple[float, float, float, float]:
        """(xmin, zmin, xmax, zmax) abarcando todas las esquinas."""
        xs: List[float] = []
        zs: List[float] = []
        for p in self.placements:
            for x, z in p.corners():
                xs.append(x); zs.append(z)
        if not xs:
            return (0.0, 0.0, 0.0, 0.0)
        return (min(xs), min(zs), max(xs), max(zs))

    def value_range(self) -> Tuple[Optional[float], Optional[float]]:
        """(min, max) de los `value` no nulos; (None, None) si no hay datos."""
        vals = [p.value for p in self.placements if p.value is not None]
        if not vals:
            return (None, None)
        return (min(vals), max(vals))
