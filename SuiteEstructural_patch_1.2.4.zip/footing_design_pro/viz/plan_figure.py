﻿"""
Dibujo de la planta de zapatas coloreada por métrica (Mejora 3).

Lógica pura de figura (sin Qt) compartida por la pestaña interactiva
(`gui.plan_widget`) y el reporte Word (`fileio.word_exporter`), para que ambos
usen exactamente el mismo dibujo y escala de color.

Todas las métricas se expresan como demanda/capacidad (≤1 cumple, >1 no cumple)
para reutilizar la paleta de `viz.colormaps` (rojo ≈ 1, MAGENTA si > 1).
"""
from __future__ import annotations

from typing import List, Optional

from geometry import FootingPlacement, PlanLayout
from viz.colormaps import ratio_colormap, ratio_norm, RATIO_OVER_COLOR

# (clave, etiqueta)
METRICS = [
    ("relacion",      "Relación de esfuerzos  σ_max / ftu"),
    ("asentamiento",  "Relación de asentamiento  δ_max / δ_perm"),
    ("volteo",        "Volteo  FSV_min / FS_volteo"),
    ("deslizamiento", "Deslizamiento  FSD_min / FS_desl"),
]
METRIC_LABELS = dict(METRICS)


def _geo(cr, method: int):
    return (cr.geo_serv if method == 1 else cr.geo_ult) or cr.geo_serv or cr.geo_ult


def worst_ratio(nr, metric: str, params) -> Optional[float]:
    """Relación demanda/capacidad del caso más desfavorable (máx) por zapata."""
    method  = getattr(params, "method", 1)
    ftu     = getattr(params, "ftu", 0.0)
    fsv_min = getattr(params, "FSV_min", 1.5)
    fsd_min = getattr(params, "FSD_min", 1.5)
    vals = []
    for cr in nr.combos:
        gr = _geo(cr, method)
        if gr is None:
            continue
        if metric == "relacion" and ftu > 0:
            vals.append(gr.f_max / ftu)
        elif metric == "asentamiento" and gr.asent_perm > 0:
            vals.append(gr.delta_max / gr.asent_perm)
        elif metric == "volteo" and gr.FS_volteo_R > 1e-9:
            vals.append(fsv_min / gr.FS_volteo_R)
        elif metric == "deslizamiento" and gr.FS_desl_R > 1e-9:
            vals.append(fsd_min / gr.FS_desl_R)
    return max(vals) if vals else None


def build_layout(results: List, params, plan_geom: dict, metric: str) -> PlanLayout:
    lay = PlanLayout()
    plan_geom = plan_geom or {}
    for nr in results:
        g = plan_geom.get(nr.node_id, {})
        lay.add(FootingPlacement(
            footing_id=nr.node_id,
            x=g.get("x", 0.0), z=g.get("z", 0.0),
            B=nr.B, L=nr.L, h=nr.d_total,
            cy=getattr(nr, "cy", 0.0), cz=getattr(nr, "cz", 0.0),
            beta_deg=g.get("beta", 0.0),
            label=nr.node_label or f"Z{nr.node_id}",
            value=worst_ratio(nr, metric, params)))
    return lay


def _dim_labels(ax, p, cs) -> None:
    """Rotula los lados de la zapata indicando cuál es B y cuál L.

    `cs` son las 4 esquinas (orden de FootingPlacement.corners):
      cs[0]→cs[1] es el lado B (dirección local X);
      cs[1]→cs[2] es el lado L (dirección local Z).
    El texto se coloca en el punto medio de cada lado, desplazado un poco
    hacia afuera y girado con la barra (BETA).
    """
    import math

    def _mid(a, b):
        return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)

    beta = p.beta_deg
    off = max(p.B, p.L) * 0.10 + 0.04   # desplazamiento del rótulo hacia afuera
    # Lado B (cs0–cs1): normal exterior ≈ desde el centro hacia el medio del lado
    mb = _mid(cs[0], cs[1])
    nb = math.hypot(mb[0] - p.x, mb[1] - p.z) or 1.0
    bx = mb[0] + (mb[0] - p.x) / nb * off
    bz = mb[1] + (mb[1] - p.z) / nb * off
    ax.text(bx, bz, f"B={p.B:.2f}", rotation=beta, rotation_mode="anchor",
            ha="center", va="center", fontsize=5.5, color="#2471A3")
    # Lado L (cs1–cs2)
    ml = _mid(cs[1], cs[2])
    nl = math.hypot(ml[0] - p.x, ml[1] - p.z) or 1.0
    lx = ml[0] + (ml[0] - p.x) / nl * off
    lz = ml[1] + (ml[1] - p.z) / nl * off
    ax.text(lx, lz, f"L={p.L:.2f}", rotation=beta + 90, rotation_mode="anchor",
            ha="center", va="center", fontsize=5.5, color="#2471A3")


def draw_plan(ax, fig, results: List, params, plan_geom: dict,
              metric: str) -> int:
    """
    Dibuja la planta en `ax` coloreada por `metric`.  Devuelve el nº de
    zapatas sin dato (gris).  `fig` se usa para la barra de color.
    """
    from matplotlib.patches import Polygon
    from matplotlib.cm import ScalarMappable

    lay  = build_layout(results, params, plan_geom, metric)
    cmap = ratio_colormap()
    norm = ratio_norm(1.0)

    n_sin = 0
    for p in lay.placements:
        if p.value is None:
            fc = "#D5D8DC"; n_sin += 1
        else:
            fc = cmap(norm(p.value)) if p.value <= 1.0 else RATIO_OVER_COLOR
        cs = p.corners()
        ax.add_patch(Polygon(cs, closed=True, facecolor=fc,
                             edgecolor="#1C2833", lw=1.2, alpha=0.92))
        # Dado (columna) en la dirección del modelo (X/Z global)
        if p.cy > 0 and p.cz > 0:
            ax.add_patch(Polygon(p.dado_corners(), closed=True,
                                 facecolor="#85929E", edgecolor="#1C2833",
                                 lw=0.8, alpha=0.9, zorder=3))
        txt = p.label + (f"\n{p.value:.2f}" if p.value is not None else "")
        ax.text(p.x, p.z, txt, ha="center", va="center", fontsize=6.5,
                fontweight="bold", color="#1C2833", zorder=4)
        _dim_labels(ax, p, cs)

    xmin, zmin, xmax, zmax = lay.bounds()
    mg = max((xmax - xmin) * 0.08, 1.0)
    ax.set_xlim(xmin - mg, xmax + mg)
    ax.set_ylim(zmin - mg, zmax + mg)
    ax.set_aspect("equal", adjustable="box")
    ax.set_anchor("C")   # centra los ejes en su región (evita el sesgo a un lado)
    ax.invert_yaxis()    # STAAD: +Z hacia ABAJO en planta (Z=0 arriba)
    ax.set_xlabel("X global (m)", fontsize=8)
    ax.set_ylabel("Z global (m)", fontsize=8)
    ax.grid(True, ls=":", alpha=0.4)
    ax.set_title(f"Planta — {METRIC_LABELS[metric]}  (caso más desfavorable)",
                 fontsize=9)

    sm = ScalarMappable(cmap=cmap, norm=norm); sm.set_array([])
    cb = fig.colorbar(sm, ax=ax, shrink=0.8, extend="max")
    cb.set_label("demanda / capacidad", fontsize=8)
    cb.ax.tick_params(labelsize=7)
    return n_sin
