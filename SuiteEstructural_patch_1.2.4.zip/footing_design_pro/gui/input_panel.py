﻿"""
Panel izquierdo de entrada de datos — Footing Design Pro.

Cambios respecto a versión anterior:
  • QListWidget de elementos → QTableWidget editable (ID, Label, cy, cz, ex, ez)
  • Eliminado grupo "Columna (por defecto/respaldo)"
  • Tipo de zapata y recubrimiento movidos a grupo propio
  • Recubrimiento por defecto = 0.05 m (NTC 2023 Tabla 7.4.1)
  • Columnas ex (m) y ez (m) = desfase del centroide de la columna
    respecto del centroide de la zapata (positivo = hacia +L y +B)
"""
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QLabel, QLineEdit, QDoubleSpinBox, QSpinBox,
    QComboBox, QRadioButton, QPushButton, QScrollArea,
    QButtonGroup, QCheckBox, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QSizePolicy, QAbstractItemView,
)
from PySide6.QtCore  import Qt, Signal
from PySide6.QtGui   import QFont, QColor

from config.settings        import COLORS
from design.code_parameters import CodeParameters
from gui.table_utils         import enable_excel_copy


class SectionLabel(QLabel):
    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setObjectName("lbl_section")
        self.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self.setStyleSheet(f"color: {COLORS['accent']}; padding-top: 4px;")


class InputPanel(QScrollArea):
    """
    Panel de entrada con scroll.

    Señales
    -------
    sig_connect_staad      — usuario pulsa "Conectar"
    sig_refresh_selection  — usuario pulsa "↻ Actualizar selección"
    sig_run_design         — usuario pulsa "Ejecutar"
    """
    sig_connect_staad     = Signal()
    sig_refresh_selection = Signal()
    sig_run_design        = Signal()

    # Columnas de la tabla de elementos
    _COL_ID    = 0
    _COL_LABEL = 1
    _COL_CY    = 2
    _COL_CZ    = 3
    _COL_EX    = 4
    _COL_EZ    = 5
    _COL_HEADERS = ["ID", "Label", "cy (m)", "cz (m)", "ex (m)", "ez (m)"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMinimumWidth(320)
        self.setMaximumWidth(370)

        inner = QWidget()
        lay   = QVBoxLayout(inner)
        lay.setSpacing(6)
        lay.setContentsMargins(6, 6, 6, 6)
        self._lay = lay
        self.setWidget(inner)

        self._build_staad()
        self._build_proyecto()
        self._build_combinaciones()
        self._build_materiales()
        self._build_geotecnia()
        self._build_zapata()       # tipo + recubrimiento (reemplaza a "Columna")
        self._build_metodo()
        self._build_codigo()
        self._build_run()

        lay.addStretch()

    # ── Grupos ────────────────────────────────────────────────────────────────

    def _build_staad(self) -> None:
        """Grupo de conexión y tabla de elementos."""
        grp = QGroupBox("STAAD Pro 2024 / 2025")
        lay = QVBoxLayout(grp)
        lay.setSpacing(5)

        # Estado de conexión
        self.lbl_staad = QLabel("Sin conexión")
        self.lbl_staad.setAlignment(Qt.AlignCenter)
        self.lbl_staad.setStyleSheet(
            f"color: {COLORS['danger']}; font-weight: bold; font-size: 8pt;")
        lay.addWidget(self.lbl_staad)

        # Botón conectar
        self.btn_connect = QPushButton("⚡  Conectar a STAAD Pro")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.clicked.connect(self.sig_connect_staad)
        lay.addWidget(self.btn_connect)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #F0D9B5;")
        lay.addWidget(sep)

        # Selector fuente
        lay.addWidget(SectionLabel("Fuente de datos:"))
        hF = QHBoxLayout()
        self.rb_soportes = QRadioButton("Apoyos")
        self.rb_columna  = QRadioButton("Base de columna")
        self.rb_soportes.setChecked(True)
        self._fuente_grp = QButtonGroup()
        self._fuente_grp.addButton(self.rb_soportes, 0)
        self._fuente_grp.addButton(self.rb_columna,  1)
        hF.addWidget(self.rb_soportes)
        hF.addWidget(self.rb_columna)
        lay.addLayout(hF)

        # Botón refrescar + contador
        hR = QHBoxLayout()
        self.btn_refresh = QPushButton("↻  Actualizar selección")
        self.btn_refresh.setToolTip(
            "Lee los nodos/barras seleccionados en STAAD Pro.\n"
            "Para 'Base de columna', lee cy y cz del modelo automáticamente.")
        self.btn_refresh.clicked.connect(self.sig_refresh_selection)
        self.lbl_count = QLabel("—")
        self.lbl_count.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_count.setStyleSheet("font-size: 8pt; color: #566573;")
        hR.addWidget(self.btn_refresh, 1)
        hR.addWidget(self.lbl_count)
        lay.addLayout(hR)

        # ── Tabla de elementos ────────────────────────────────────────────
        lay.addWidget(SectionLabel("Elementos — dimensiones y excentricidades:"))
        self.tbl_elements = QTableWidget(0, 6)
        self.tbl_elements.setHorizontalHeaderLabels(self._COL_HEADERS)
        self.tbl_elements.setAlternatingRowColors(True)
        self.tbl_elements.setFixedHeight(130)
        self.tbl_elements.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl_elements.setEditTriggers(
            QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked)
        hdr = self.tbl_elements.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(self._COL_LABEL, QHeaderView.Stretch)
        self.tbl_elements.verticalHeader().setDefaultSectionSize(20)
        self.tbl_elements.setStyleSheet(
            "QTableWidget { border: 1px solid #D5D8DC; font-size: 8pt; }"
            "QTableWidget::item { padding: 1px 3px; }"
            "QHeaderView::section { background: #475C6B; color: white;"
            "  font-size: 7.5pt; font-weight: bold; padding: 2px; }")
        enable_excel_copy(self.tbl_elements)
        lay.addWidget(self.tbl_elements)

        # Nota sobre ex, ez
        note = QLabel(
            "cy, cz : dimensiones de dado/columna (m)\n"
            "ex, ez : desfase centroide col. respecto\n"
            "          centroide zapata (+L / +B)")
        note.setStyleSheet("font-size: 7.5pt; color: #566573; padding: 2px 4px;")
        lay.addWidget(note)

        # Botones de edición rápida
        hBtns = QHBoxLayout()
        btn_add  = QPushButton("＋ Fila")
        btn_del  = QPushButton("－ Fila")
        btn_add.setMaximumWidth(70)
        btn_del.setMaximumWidth(70)
        btn_add.clicked.connect(self._add_element_row)
        btn_del.clicked.connect(self._del_element_row)
        hBtns.addWidget(btn_add)
        hBtns.addWidget(btn_del)
        hBtns.addStretch()
        lay.addLayout(hBtns)

        # IDs manuales (respaldo)
        lay.addWidget(SectionLabel("IDs manuales (respaldo):"))
        self.le_ids = QLineEdit()
        self.le_ids.setPlaceholderText('p.ej. "1,5,10-15" ó "21;22;23"')
        self.le_ids.setToolTip(
            "Si la detección automática falla, escriba aquí los IDs.\n"
            "Se usarán las dimensiones de la tabla de elementos.")
        lay.addWidget(self.le_ids)

        self._lay.addWidget(grp)

    def _build_proyecto(self) -> None:
        # Apartado "Proyecto" eliminado de la UI (solicitud 2026-07).
        # El campo se conserva oculto para no romper get_params()/reportes.
        self.le_proyecto = QLineEdit()
        self.le_proyecto.setVisible(False)

    def _build_combinaciones(self) -> None:
        grp = QGroupBox("Combinaciones de Carga")
        lay = QVBoxLayout(grp)

        lay.addWidget(SectionLabel("Servicio (ini – fin):"))
        hS = QHBoxLayout()
        self.sp_s_ini = QSpinBox(); self.sp_s_ini.setRange(1, 9999); self.sp_s_ini.setValue(1)
        self.sp_s_fin = QSpinBox(); self.sp_s_fin.setRange(1, 9999); self.sp_s_fin.setValue(10)
        hS.addWidget(QLabel("De:")); hS.addWidget(self.sp_s_ini)
        hS.addWidget(QLabel("a:"));  hS.addWidget(self.sp_s_fin)
        lay.addLayout(hS)

        lay.addWidget(SectionLabel("Últimas (ini – fin):"))
        hU = QHBoxLayout()
        self.sp_u_ini = QSpinBox(); self.sp_u_ini.setRange(1, 9999); self.sp_u_ini.setValue(101)
        self.sp_u_fin = QSpinBox(); self.sp_u_fin.setRange(1, 9999); self.sp_u_fin.setValue(120)
        hU.addWidget(QLabel("De:")); hU.addWidget(self.sp_u_ini)
        hU.addWidget(QLabel("a:"));  hU.addWidget(self.sp_u_fin)
        lay.addLayout(hU)

        self._lay.addWidget(grp)

    def _build_materiales(self) -> None:
        grp = QGroupBox("Materiales")
        lay = QVBoxLayout(grp)
        self.sp_fc = self._dbl("f'c (kgf/cm²):",      1,  1000, 250, 0, lay)
        self.sp_fy = self._dbl("fy  (kgf/cm²):",      1,  8000, 4200, 0, lay)
        self.sp_gc = self._dbl("γ_concreto (ton/m³):", .1, 5,   2.4,  1, lay)
        self._lay.addWidget(grp)

    def _build_geotecnia(self) -> None:
        grp = QGroupBox("Geotecnia")
        lay = QVBoxLayout(grp)
        self.sp_ftu   = self._dbl("ftu (ton/m²):",              1,   500, 20,  1, lay)
        self.sp_Df    = self._dbl("Df — Desplante (m):",         .3,  10,  1.5, 2, lay)
        self.sp_gs    = self._dbl("γ_suelo (ton/m³):",           .5,   5,  1.8, 1, lay)
        self.sp_phi   = self._dbl("φ suelo (°):",                 0,  60,  30,  1, lay)
        self.sp_coh   = self._dbl("c — Cohesión (ton/m²):",      0,  500,   0,  1, lay)

        sep_ks = QFrame(); sep_ks.setFrameShape(QFrame.HLine)
        sep_ks.setStyleSheet("color: #F0D9B5;"); lay.addWidget(sep_ks)
        self.sp_ks = self._dbl("ks — Módulo reacción\n  vertical (ton/m³):", 0, 100000, 0, 0, lay)
        self.sp_ks.setToolTip(
            "Módulo de reacción vertical del suelo (coef. de balasto)\n"
            "Unidades: ton/m³  (= ton/m²/m)\n"
            "Típico:  Suelo blando 500–2 000 · Medio 2 000–10 000 · Duro 10 000–80 000\n"
            "0 = no calcular asentamientos.")
        lbl_ks = QLabel("  (0 = no calcular asentamientos)")
        lbl_ks.setStyleSheet("font-size: 7.5pt; color: #7F8C8D; padding: 0 4px;")
        lay.addWidget(lbl_ks)

        self.sp_asent = self._dbl("Asentamiento permisible\n  (cm):", 0, 100, 0, 2, lay)
        self.sp_asent.setToolTip(
            "Asentamiento total permisible δ_perm (cm).\n"
            "Se revisa δ_max = σ_max/ks ≤ δ_perm.\n"
            "0 = no revisar asentamiento.")
        lbl_as = QLabel("  (0 = no revisar; requiere ks > 0)")
        lbl_as.setStyleSheet("font-size: 7.5pt; color: #7F8C8D; padding: 0 4px;")
        lay.addWidget(lbl_as)
        self._lay.addWidget(grp)

    def _build_zapata(self) -> None:
        """Tipo de zapata y recubrimiento (sustituye al grupo 'Columna')."""
        grp = QGroupBox("Zapata")
        lay = QVBoxLayout(grp)
        lay.addWidget(SectionLabel("Tipo:"))
        hT = QHBoxLayout()
        self.rb_cuad = QRadioButton("Cuadrada")
        self.rb_rect = QRadioButton("Rectangular")
        self.rb_cuad.setChecked(True)
        self._tipo_grp = QButtonGroup()
        self._tipo_grp.addButton(self.rb_cuad, 0)
        self._tipo_grp.addButton(self.rb_rect, 1)
        hT.addWidget(self.rb_cuad); hT.addWidget(self.rb_rect)
        lay.addLayout(hT)

        self.sp_rec = self._dbl("Recubrimiento (m):", 0.03, 0.30, 0.05, 3, lay)
        self.sp_rec.setToolTip(
            "Recubrimiento a la cara inferior de la zapata.\n"
            "NTC 2023 §7.4.1: mínimo 50 mm (0.05 m) para\n"
            "concreto colado contra suelo o agua.")
        self._lay.addWidget(grp)

    def _build_metodo(self) -> None:
        grp = QGroupBox("Método de Dimensionamiento")
        lay = QVBoxLayout(grp)
        lay.addWidget(QLabel(
            "M1: dimensionar con cargas de servicio\n"
            "     (FS mín. definido por el usuario).\n"
            "M2: dimensionar con cargas últimas\n"
            "     (MDOC CFE B.2.5, FS = valor usuario).",
            wordWrap=True))
        hM = QHBoxLayout()
        self.rb_m1 = QRadioButton("Método 1")
        self.rb_m2 = QRadioButton("Método 2")
        self.rb_m1.setChecked(True)
        self._metodo_grp = QButtonGroup()
        self._metodo_grp.addButton(self.rb_m1, 1)
        self._metodo_grp.addButton(self.rb_m2, 2)
        hM.addWidget(self.rb_m1); hM.addWidget(self.rb_m2)
        lay.addLayout(hM)

        # Checkbox estabilidad
        sep_stab = QFrame(); sep_stab.setFrameShape(QFrame.HLine)
        sep_stab.setStyleSheet("color: #F0D9B5;"); lay.addWidget(sep_stab)
        self.chk_stability = QCheckBox("Revisar estabilidad (volteo, desliz., extracción)")
        self.chk_stability.setChecked(True)
        # Revisiones individuales (activas solo si la general esta marcada)
        self.chk_volteo = QCheckBox("   Revisar volteo")
        self.chk_volteo.setChecked(True)
        self.chk_desliz = QCheckBox("   Revisar deslizamiento")
        self.chk_desliz.setChecked(True)
        self.chk_extrac = QCheckBox("   Revisar extracción (tensión)")
        self.chk_extrac.setChecked(True)
        self.chk_stability.setToolTip(
            "Marcado: condiciona el tamaño de la zapata.\n"
            "Desmarcado: solo informativo.")
        lay.addWidget(self.chk_stability)
        lay.addWidget(self.chk_volteo)
        lay.addWidget(self.chk_desliz)
        lay.addWidget(self.chk_extrac)
        self.chk_stability.toggled.connect(self._on_stability_changed)
        for _c in (self.chk_volteo, self.chk_desliz, self.chk_extrac):
            self.chk_stability.toggled.connect(_c.setEnabled)

        self.sp_fsv = self._dbl("FS Volteo mínimo:",        1.0, 5.0, 1.5, 2, lay)
        self.sp_fsd = self._dbl("FS Deslizamiento mínimo:", 1.0, 5.0, 1.5, 2, lay)
        self.sp_fse = self._dbl("FS Extracción mínimo:",    0.5, 5.0, 1.0, 2, lay)
        self.rb_m2.toggled.connect(self._on_method_changed)
        self.rb_m1.toggled.connect(self._on_method_changed)

        sep2 = QFrame(); sep2.setFrameShape(QFrame.HLine)
        sep2.setStyleSheet("color: #F0D9B5;"); lay.addWidget(sep2)

        self.chk_vdf = QCheckBox("Considerar Mact = |M| + |V|·Df")
        self.chk_vdf.setChecked(True)
        self.chk_vdf.setToolTip(
            "Marcado: agrega el momento adicional del cortante al\n"
            "trasladar fuerzas al nivel de desplante.\n"
            "Desmarcado: fuerzas ya en nivel de base.")
        lay.addWidget(self.chk_vdf)

        lbl_frd = QLabel(
            "Frd deslizamiento:\n"
            "  Método 1 → Frd = 1.0\n"
            "  Método 2 → Frd = 0.6  (MDOC CFE ec.3.17)")
        lbl_frd.setStyleSheet("font-size: 8pt; color: #566573; padding: 2px 4px;")
        lay.addWidget(lbl_frd)
        self._lay.addWidget(grp)

    def _build_codigo(self) -> None:
        grp = QGroupBox("Código de Diseño")
        lay = QVBoxLayout(grp)
        self.cb_codigo = QComboBox()
        self.cb_codigo.addItems(CodeParameters.CODES)
        lay.addWidget(self.cb_codigo)
        self._lay.addWidget(grp)

    def _build_run(self) -> None:
        self.btn_run = QPushButton("▶  EJECUTAR DISEÑO")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.clicked.connect(self.sig_run_design)
        self._lay.addWidget(self.btn_run)

    # ── Slots internos ────────────────────────────────────────────────────────

    def _on_method_changed(self) -> None:
        if self.rb_m2.isChecked():
            self.sp_fsv.setValue(1.0)
            self.sp_fsd.setValue(1.0)

    def _on_stability_changed(self, checked: bool) -> None:
        self.sp_fsv.setEnabled(checked)
        self.sp_fsd.setEnabled(checked)
        self.sp_fse.setEnabled(checked)

    def _add_element_row(self) -> None:
        """Agrega una fila vacía a la tabla para entrada manual."""
        r = self.tbl_elements.rowCount()
        self.tbl_elements.setRowCount(r + 1)
        self.tbl_elements.setItem(r, self._COL_ID,    QTableWidgetItem(""))
        self.tbl_elements.setItem(r, self._COL_LABEL, QTableWidgetItem(""))
        self.tbl_elements.setItem(r, self._COL_CY,    QTableWidgetItem("0.300"))
        self.tbl_elements.setItem(r, self._COL_CZ,    QTableWidgetItem("0.300"))
        self.tbl_elements.setItem(r, self._COL_EX,    QTableWidgetItem("0.000"))
        self.tbl_elements.setItem(r, self._COL_EZ,    QTableWidgetItem("0.000"))
        self._update_count()

    def _del_element_row(self) -> None:
        """Elimina la fila seleccionada."""
        rows = set(idx.row() for idx in self.tbl_elements.selectedIndexes())
        for r in sorted(rows, reverse=True):
            self.tbl_elements.removeRow(r)
        self._update_count()

    def _update_count(self) -> None:
        n = self.tbl_elements.rowCount()
        self.lbl_count.setText(f"{n} elem." if n else "—")
        if n > 0:
            self.lbl_count.setStyleSheet(
                f"font-size: 8pt; color: {COLORS['success']}; font-weight: bold;")
        else:
            self.lbl_count.setStyleSheet("font-size: 8pt; color: #566573;")

    # ── API pública ───────────────────────────────────────────────────────────

    def set_staad_status(self, connected: bool, msg: str = "") -> None:
        if connected:
            self.lbl_staad.setText("✔  Conectado")
            self.lbl_staad.setStyleSheet(
                f"color: {COLORS['success']}; font-weight: bold; font-size: 8pt;")
            self.btn_connect.setEnabled(False)
        else:
            txt = msg or "Sin conexión"
            self.lbl_staad.setText(f"✗  {txt}")
            self.lbl_staad.setStyleSheet(
                f"color: {COLORS['danger']}; font-weight: bold; font-size: 8pt;")
            self.btn_connect.setEnabled(True)

    def load_elements(self, elements: list[dict]) -> None:
        """
        Rellena la tabla con los elementos cargados desde STAAD Pro o manualmente.

        elements : [{'id': int, 'label': str, 'cy': float, 'cz': float}, ...]

        Las columnas ex y ez se inicializan en 0.000 si no estaban ya presentes
        en la tabla (preserva ediciones del usuario en el caso de re-lectura).
        """
        # Leer ex/ez existentes por ID para preservar ediciones del usuario
        prev_ex: dict[int, str] = {}
        prev_ez: dict[int, str] = {}
        for r in range(self.tbl_elements.rowCount()):
            id_item = self.tbl_elements.item(r, self._COL_ID)
            if id_item is None:
                continue
            try:
                nid = int(id_item.text())
            except ValueError:
                continue
            ex_item = self.tbl_elements.item(r, self._COL_EX)
            ez_item = self.tbl_elements.item(r, self._COL_EZ)
            prev_ex[nid] = ex_item.text() if ex_item else "0.000"
            prev_ez[nid] = ez_item.text() if ez_item else "0.000"

        self.tbl_elements.setRowCount(len(elements))
        for row, el in enumerate(elements):
            nid  = el.get("id", 0)
            lbl  = el.get("label", "")
            cy   = el.get("cy", 0.30)
            cz   = el.get("cz", 0.30)
            ex_s = prev_ex.get(nid, "0.000")
            ez_s = prev_ez.get(nid, "0.000")

            items = [
                (self._COL_ID,    str(nid),           False),  # no editable
                (self._COL_LABEL, lbl,                 False),  # no editable
                (self._COL_CY,    f"{cy:.3f}",         True),
                (self._COL_CZ,    f"{cz:.3f}",         True),
                (self._COL_EX,    ex_s,                True),
                (self._COL_EZ,    ez_s,                True),
            ]
            for col, txt, editable in items:
                it = QTableWidgetItem(txt)
                it.setTextAlignment(Qt.AlignCenter)
                if not editable:
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                    it.setBackground(QColor("#EBF5FB"))
                self.tbl_elements.setItem(row, col, it)

        self._update_count()

    def get_elements_data(self) -> list[dict]:
        """
        Devuelve la lista de elementos con sus dimensiones y excentricidades.

        Returns
        -------
        list of dict: [{'id', 'label', 'cy', 'cz', 'ex', 'ez'}, ...]
        """
        result = []
        for r in range(self.tbl_elements.rowCount()):
            id_item = self.tbl_elements.item(r, self._COL_ID)
            if id_item is None or id_item.text() == "":
                continue
            try:
                nid = int(id_item.text())
            except ValueError:
                continue

            def _fval(col: int, default: float = 0.0) -> float:
                it = self.tbl_elements.item(r, col)
                if it is None:
                    return default
                try:
                    return float(it.text())
                except ValueError:
                    return default

            lbl_it = self.tbl_elements.item(r, self._COL_LABEL)
            result.append({
                "id":    nid,
                "label": lbl_it.text() if lbl_it else f"N{nid}",
                "cy":    _fval(self._COL_CY, 0.30),
                "cz":    _fval(self._COL_CZ, 0.30),
                "ex":    _fval(self._COL_EX, 0.00),
                "ez":    _fval(self._COL_EZ, 0.00),
            })
        return result

    def get_params(self) -> dict:
        return {
            "proyecto":    self.le_proyecto.text().strip(),
            "fuente":      "Soportes" if self.rb_soportes.isChecked() else "Base de columna",
            "ids_str":     self.le_ids.text().strip(),
            "lc_serv_ini": self.sp_s_ini.value(),
            "lc_serv_fin": self.sp_s_fin.value(),
            "lc_ult_ini":  self.sp_u_ini.value(),
            "lc_ult_fin":  self.sp_u_fin.value(),
            "fc":          self.sp_fc.value(),
            "fy":          self.sp_fy.value(),
            "gama_conc":   self.sp_gc.value(),
            "ftu":         self.sp_ftu.value(),
            "Df":          self.sp_Df.value(),
            "gama_suelo":  self.sp_gs.value(),
            "phi_suelo":   self.sp_phi.value(),
            "cohesion":    self.sp_coh.value(),
            "ks":          self.sp_ks.value(),
            "asent_perm":  self.sp_asent.value(),
            "tipo":        self._tipo_grp.checkedId(),
            "rec":         self.sp_rec.value(),
            "method":      self._metodo_grp.checkedId(),
            "FSV_min":     self.sp_fsv.value(),
            "FSD_min":     self.sp_fsd.value(),
            "FS_ext_min":  self.sp_fse.value(),
            "include_vdf": self.chk_vdf.isChecked(),
            "check_stability": self.chk_stability.isChecked(),
            "check_volteo":  self.chk_stability.isChecked() and self.chk_volteo.isChecked(),
            "check_desliz":  self.chk_stability.isChecked() and self.chk_desliz.isChecked(),
            "check_extrac":  self.chk_stability.isChecked() and self.chk_extrac.isChecked(),
            "code":        self.cb_codigo.currentText(),
        }

    # ── Helper ────────────────────────────────────────────────────────────────

    @staticmethod
    def _dbl(label: str, mn: float, mx: float,
             val: float, dec: int, layout) -> QDoubleSpinBox:
        h   = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setFixedWidth(190)
        sp  = QDoubleSpinBox()
        sp.setRange(mn, mx)
        sp.setValue(val)
        sp.setDecimals(dec)
        sp.setSingleStep(10 ** (-dec) if dec else 1)
        h.addWidget(lbl)
        h.addWidget(sp)
        layout.addLayout(h)
        return sp
