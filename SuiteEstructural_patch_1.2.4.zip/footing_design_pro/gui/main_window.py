﻿"""
Ventana principal — Footing Design Pro.

Patrón idéntico a beam_design_pro para thread-safety COM:
  1. connect()             hilo principal — establece objeto COM
  2. get_selected_*()      hilo principal — lee IDs seleccionados en STAAD Pro
  3. get_section_from_*()  hilo principal — lee dimensiones de columna del modelo
  4. pre_fetch_*()         hilo principal — llena cachés de reacciones/fuerzas
  5. dump_cache()          hilo principal — extrae datos Python puros (sin COM)
  6. DesignWorker (QThread)            — usa solo los dicts de dump_cache

La lista de elementos se muestra en el InputPanel después de "↻ Actualizar selección",
incluyendo el ID y las dimensiones cy × cz leídas automáticamente del modelo.
"""
from __future__ import annotations

import logging
import os
import traceback
from datetime import datetime
from typing import List, Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QSplitter, QTabWidget, QLabel, QStatusBar,
    QProgressBar, QProgressDialog, QMessageBox, QFileDialog,
    QApplication, QFrame, QPushButton,
)
from PySide6.QtCore import Qt, QThread, Signal, QObject, Slot
from PySide6.QtGui  import QFont

from config.settings        import APP_NAME, APP_VERSION, APP_SUBTITLE, COLORS
from gui.styles             import MAIN_STYLE, HEADER_STYLE
from gui.input_panel        import InputPanel
from gui.results_widget     import ResultsWidget
from gui.summary_widget     import SummaryWidget
from gui.final_dims_widget   import FinalDimsWidget
from gui.plan_widget          import PlanWidget
from design.footing_design  import FootingDesigner, DesignParams, NodeResult
from design.geotechnical    import LoadPoint

log = logging.getLogger(__name__)

try:
    from fileio.openstaad_reader import OpenSTAADReader, AVAILABLE as _STAAD_AVAIL
except Exception:
    OpenSTAADReader = None  # type: ignore
    _STAAD_AVAIL   = False

try:
    from fileio.word_exporter import ResultsExporter, MemoExporter
    _DOCX_AVAIL = True
except Exception:
    _DOCX_AVAIL = False


# ── Worker (QThread) ──────────────────────────────────────────────────────────

class DesignWorker(QObject):
    """
    Ejecuta el diseño en un hilo secundario.

    IMPORTANTE: recibe sec_cache, react_cache y member_cache como dicts
    Python puros (dump_cache) para no tocar COM desde el QThread.
    """
    progress = Signal(int, str)
    finished = Signal(list)
    error    = Signal(str)

    def __init__(self, nodes: list, params: DesignParams,
                 sec_cache: dict, react_cache: dict, member_cache: dict,
                 fuente: str,
                 lc_serv: List[int], lc_ult: List[int],
                 fixed_dims: Optional[dict] = None):
        super().__init__()
        self._nodes        = nodes        # [{id, label, cy, cz}]
        self._params       = params
        self._sec_cache    = sec_cache
        self._react_cache  = react_cache
        self._member_cache = member_cache
        self._fuente       = fuente
        self._lc_serv      = lc_serv
        self._lc_ult       = lc_ult
        self._fixed_dims   = fixed_dims or None

    def run(self) -> None:
        try:
            self._execute()
        except Exception:
            self.error.emit(traceback.format_exc())

    def _execute(self) -> None:
        from fileio.openstaad_reader import OpenSTAADReader as R

        # Instancia temporal para usar los métodos de lectura desde caché
        tmp = R.__new__(R)
        tmp._sec_cache    = self._sec_cache
        tmp._react_cache  = self._react_cache
        tmp._member_cache = self._member_cache
        tmp._staad = tmp._geometry = tmp._output = tmp._prop = tmp._load_mod = None

        nodes_design = []
        for el in self._nodes:
            nid   = el["id"]
            label = el["label"]

            if self._fuente == "Soportes":
                serv = tmp.get_support_loads(nid, self._lc_serv,
                                             self._react_cache)
                ult  = tmp.get_support_loads(nid, self._lc_ult,
                                             self._react_cache)
            else:
                serv = tmp.get_member_base_loads(nid, self._lc_serv,
                                                 self._member_cache)
                ult  = tmp.get_member_base_loads(nid, self._lc_ult,
                                                 self._member_cache)

            nodes_design.append({
                "id":    nid,
                "label": label,
                "serv":  serv,
                "ult":   ult,
                # cy/cz/ex/ez vienen del elemento (leídos del modelo y/o tabla)
                "cy": el.get("cy", self._params.cy),
                "cz": el.get("cz", self._params.cz),
                "ex": el.get("ex", 0.0),
                "ez": el.get("ez", 0.0),
            })

        designer = FootingDesigner(self._params)
        results  = designer.run(nodes_design, progress_cb=self.progress.emit,
                                fixed_dims=self._fixed_dims)
        self.finished.emit(results)


# ── Worker de exportación a Word ───────────────────────────────────────────────

class ExportWorker(QObject):
    """Genera el documento Word en un hilo secundario (puede tardar minutos
    cuando hay muchas zapatas) reportando avance a la barra de progreso."""
    progress = Signal(int, str)
    finished = Signal(str)
    error    = Signal(str)

    def __init__(self, kind: str, results: list, params,
                 path: str, plan_geom: Optional[dict] = None):
        super().__init__()
        self._kind = kind          # "results" | "memo"
        self._results = results
        self._params = params
        self._path = path
        self._plan_geom = plan_geom

    def run(self) -> None:
        try:
            from fileio.word_exporter import ResultsExporter, MemoExporter
            cb = self.progress.emit
            if self._kind == "results":
                ResultsExporter().export(self._results, self._params, self._path,
                                         plan_geom=self._plan_geom, progress_cb=cb)
            else:
                MemoExporter().export(self._results, self._params, self._path,
                                      progress_cb=cb)
            self.finished.emit(self._path)
        except Exception:
            self.error.emit(traceback.format_exc())


# ── Ventana principal ─────────────────────────────────────────────────────────

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(1420, 840)
        self.setStyleSheet(MAIN_STYLE)

        # Estado
        self._reader  : Optional[OpenSTAADReader] = (OpenSTAADReader()
                                                      if _STAAD_AVAIL else None)
        self._elements: List[dict] = []   # [{id, label, cy, cz}] cargados de STAAD
        self._results : List[NodeResult] = []
        self._params  : Optional[DesignParams]    = None
        self._worker  : Optional[DesignWorker]    = None
        self._thread  : Optional[QThread]         = None
        self._export_worker : Optional[ExportWorker] = None
        self._export_thread : Optional[QThread]      = None
        self._export_dlg                             = None
        self._fixed_active = False   # True tras recalcular con dimensión fija
        self._fuente  : str = "Soportes"
        self._lc_serv : List[int] = []
        self._lc_ult  : List[int] = []
        self._plan_geom: dict = {}   # {id: {x, z, beta}} para la planta (Mejora 3)

        # Cachés dump (datos Python puros para el worker)
        self._sec_cache   : dict = {}
        self._react_cache : dict = {}
        self._member_cache: dict = {}

        self._build_ui()

    # ── Construcción de UI ────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_header())

        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(4)

        # Panel izquierdo
        self._input = InputPanel()
        self._input.sig_connect_staad.connect(self._on_connect)
        self._input.sig_refresh_selection.connect(self._on_refresh)
        self._input.sig_run_design.connect(self._on_run)
        splitter.addWidget(self._input)

        # Panel derecho
        right = QWidget()
        rlay  = QVBoxLayout(right)
        rlay.setContentsMargins(4, 4, 4, 4)
        rlay.setSpacing(4)

        # Botones de exportación
        bbar = QHBoxLayout()
        self.btn_export = QPushButton("📄  Exportar Resultados (Word)")
        self.btn_export.setObjectName("btn_export")
        self.btn_export.setEnabled(False)
        self.btn_export.clicked.connect(self._on_export_results)
        self.btn_memo = QPushButton("📚  Memoria de Cálculo (Word)")
        self.btn_memo.setObjectName("btn_memo")
        self.btn_memo.setEnabled(False)
        self.btn_memo.clicked.connect(self._on_export_memo)
        bbar.addWidget(self.btn_export)
        bbar.addWidget(self.btn_memo)
        bbar.addStretch()
        rlay.addLayout(bbar)

        # Tabs de resultados
        self._tabs      = QTabWidget()
        self._summary   = SummaryWidget()
        self._results_w = ResultsWidget()
        self._final_dims = FinalDimsWidget()
        self._final_dims.sig_recompute.connect(self._on_recompute_fixed)
        self._plan = PlanWidget()
        self._tabs.addTab(self._summary,    "📊  Resumen")
        self._tabs.addTab(self._results_w,  "📋  Resultados por Zapata")
        self._tabs.addTab(self._final_dims, "📐  Dimensión final")
        self._tabs.addTab(self._plan,       "🗺️  Planta / Mapas")
        rlay.addWidget(self._tabs)

        splitter.addWidget(right)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([335, 1085])
        root.addWidget(splitter, 1)

        # Barra de progreso
        self._progress = QProgressBar()
        self._progress.setFixedHeight(5)
        self._progress.setTextVisible(False)
        self._progress.setRange(0, 100)
        self._progress.setVisible(False)
        root.addWidget(self._progress)

        # Status bar
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage(f"  {APP_NAME}  {APP_VERSION}  |  {APP_SUBTITLE}")

    def _make_header(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(HEADER_STYLE)
        frame.setFixedHeight(60)
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 0, 16, 0)
        t = QLabel(APP_NAME)
        t.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        t.setStyleSheet("color: white;")
        lay.addWidget(t)
        s = QLabel(APP_SUBTITLE)
        s.setStyleSheet("color: #AED6F1; font-size: 9pt;")
        lay.addWidget(s)
        lay.addStretch()
        v = QLabel(f"v{APP_VERSION}")
        v.setStyleSheet("color: #7FB3D3; font-size: 8pt;")
        lay.addWidget(v)
        return frame

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _on_connect(self) -> None:
        if not _STAAD_AVAIL or self._reader is None:
            QMessageBox.warning(self, "openstaadpy no disponible",
                                "Instale openstaadpy:\n  pip install openstaadpy")
            return
        self._status.showMessage("  Conectando a STAAD Pro…")
        QApplication.processEvents()
        ok, msg = self._reader.connect()
        self._input.set_staad_status(ok, msg)
        self._status.showMessage(f"  STAAD: {msg}")
        if ok:
            # Al conectar, leer automáticamente la selección activa
            self._on_refresh()

    def _on_refresh(self) -> None:
        """
        Lee los nodos/barras seleccionados en STAAD Pro y extrae sus dimensiones.
        Sigue exactamente el patrón de beam_design_pro._on_refresh_beams().
        """
        if self._reader is None or not self._reader.connected:
            QMessageBox.warning(self, "Sin conexión",
                                "Conecte a STAAD Pro primero.")
            return

        raw    = self._input.get_params()
        fuente = raw["fuente"]

        self._status.showMessage(f"  Leyendo {fuente.lower()} seleccionados en STAAD Pro…")
        QApplication.processEvents()

        # ── 1) Detección automática de la selección ───────────────────────────
        elements = []
        try:
            if fuente == "Soportes":
                # Para soportes: las dimensiones del dado vienen del panel de entrada
                # (el usuario las especifica manualmente — no se leen del modelo)
                ids = self._reader.get_selected_nodes()
                for nid in ids:
                    elements.append({
                        "id":    nid,
                        "label": f"N{nid}",
                        "cy":    0.30,   # valor por defecto; el usuario edita en la tabla
                        "cz":    0.30,
                    })
            else:
                # Para barras: las dimensiones se leen automáticamente del modelo
                ids = self._reader.get_selected_beams()
                for bid in ids:
                    sec = self._reader.get_section_from_beam(bid)
                    elements.append({
                        "id":    bid,
                        "label": f"M{bid}",
                        "cy":    sec.get("cy", 0.30),   # leído del modelo STAAD
                        "cz":    sec.get("cz", 0.30),
                    })
        except Exception as exc:
            log.exception("Error leyendo selección de STAAD")
            QMessageBox.critical(self, "Error al leer STAAD", str(exc))
            return

        # ── 2) Respaldo: IDs ingresados manualmente ───────────────────────────
        if not elements:
            manual = self._parse_ids(raw.get("ids_str", ""))
            if manual:
                self._status.showMessage(
                    f"  Selección vacía — cargando {len(manual)} IDs manuales…")
                QApplication.processEvents()
                try:
                    for nid in manual:
                        if fuente == "Soportes":
                            lbl = f"N{nid}"
                            elements.append({
                                "id": nid, "label": lbl,
                                "cy": 0.30, "cz": 0.30,   # usuario edita en la tabla
                            })
                        else:
                            lbl = f"M{nid}"
                            sec = self._reader.get_section_from_beam(nid)
                            elements.append({
                                "id":    nid, "label": lbl,
                                "cy":    sec.get("cy", 0.30),   # del modelo STAAD
                                "cz":    sec.get("cz", 0.30),
                            })
                except Exception as exc:
                    QMessageBox.critical(self, "Error IDs manuales", str(exc))
                    return

        self._elements = elements
        self._input.load_elements(elements)
        n = len(elements)

        if n == 0:
            self._status.showMessage(
                f"  Sin elementos — seleccione {fuente.lower()} en STAAD Pro "
                "o ingrese IDs manuales.")
        else:
            dims = [f"{el['label']} "
                    f"({el['cy']*100:.0f}×{el['cz']*100:.0f} cm)"
                    for el in elements[:3]]
            extra = f"  +{n-3} más" if n > 3 else ""
            self._status.showMessage(
                f"  {n} {fuente.lower()}: {', '.join(dims)}{extra}")

    def _on_run(self) -> None:
        if self._thread and self._thread.isRunning():
            return

        raw    = self._input.get_params()
        fuente = raw["fuente"]

        # ── Validar elementos ─────────────────────────────────────────────────
        # Obtener datos actualizados de la tabla (cy, cz, ex, ez por elemento)
        tbl_data = self._input.get_elements_data()
        # Construir dict de lookup por ID
        tbl_by_id = {el["id"]: el for el in tbl_data}
        # Fusionar: datos de STAAD + override desde tabla de elementos
        for el in self._elements:
            tbl_el = tbl_by_id.get(el["id"], {})
            el["cy"] = tbl_el.get("cy", el.get("cy", 0.30))
            el["cz"] = tbl_el.get("cz", el.get("cz", 0.30))
            el["ex"] = tbl_el.get("ex", 0.0)
            el["ez"] = tbl_el.get("ez", 0.0)

        if not self._elements:
            if self._reader and self._reader.connected:
                QMessageBox.warning(self, "Sin elementos",
                                    f"No hay {fuente.lower()} cargados.\n"
                                    "Seleccione elementos en STAAD Pro y pulse\n"
                                    "↻ Actualizar selección.")
            else:
                # Sin STAAD: usar IDs manuales con cargas de ejemplo (modo demo)
                manual = self._parse_ids(raw.get("ids_str", ""))
                if not manual:
                    QMessageBox.warning(self, "Sin datos",
                                        "No hay elementos para diseñar.\n"
                                        "Conecte a STAAD Pro o ingrese IDs manuales.")
                    return
                # Usar datos de la tabla si existen, o defaults
                self._elements = []
                for nid in manual:
                    tbl_el = tbl_by_id.get(nid, {})
                    self._elements.append({
                        "id":    nid,
                        "label": f"N{nid}",
                        "cy":    tbl_el.get("cy", 0.30),
                        "cz":    tbl_el.get("cz", 0.30),
                        "ex":    tbl_el.get("ex", 0.0),
                        "ez":    tbl_el.get("ez", 0.0),
                    })

        # ── Construir DesignParams usando cy/cz del primer elemento como base ─
        # (cada nodo puede tener cy/cz distintos; se pasan por separado al worker)
        p = DesignParams(
            fc         = raw["fc"],
            fy         = raw["fy"],
            gama_conc  = raw["gama_conc"],
            ftu        = raw["ftu"],
            gama_suelo = raw["gama_suelo"],
            phi_suelo  = raw["phi_suelo"],
            cohesion   = raw["cohesion"],
            Df         = raw["Df"],
            cy         = 0.30,   # fallback; cada elemento usa su propio cy de la tabla
            cz         = 0.30,   # fallback; cada elemento usa su propio cz de la tabla
            tipo       = raw["tipo"],
            method     = raw["method"],
            FSV_min    = raw["FSV_min"],
            FSD_min    = raw["FSD_min"],
            FS_ext_min       = raw.get("FS_ext_min", 1.0),
            include_vdf      = raw.get("include_vdf", True),
            check_stability  = raw.get("check_stability", True),
            check_volteo     = raw.get("check_volteo", True),
            check_desliz     = raw.get("check_desliz", True),
            check_extrac     = raw.get("check_extrac", True),
            ks               = raw.get("ks", 0.0),
            asent_perm       = raw.get("asent_perm", 0.0),
            code        = raw["code"],
            rec        = raw["rec"],
            proyecto   = raw["proyecto"],
            fuente     = fuente,
        )
        self._params = p

        lc_serv = list(range(raw["lc_serv_ini"], raw["lc_serv_fin"] + 1))
        lc_ult  = list(range(raw["lc_ult_ini"],  raw["lc_ult_fin"]  + 1))

        # ── Pre-fetch COM en hilo principal ───────────────────────────────────
        if self._reader and self._reader.connected:
            ids = [el["id"] for el in self._elements]
            self._status.showMessage("  Extrayendo datos de STAAD Pro…")
            QApplication.processEvents()
            try:
                if fuente == "Soportes":
                    self._reader.pre_fetch_supports(ids, lc_serv + lc_ult)
                else:
                    self._reader.pre_fetch_members(ids, lc_serv + lc_ult)
            except Exception as exc:
                QMessageBox.critical(self, "Error pre-fetch STAAD", str(exc))
                return

            # Geometría en planta (coordenadas + BETA) para la Mejora 3
            try:
                self._plan_geom = self._reader.get_plan_geometry(ids, fuente)
            except Exception as exc:
                log.debug("get_plan_geometry: %s", exc)
                self._plan_geom = {}

            # dump_cache → datos Python puros para el QThread
            dump = self._reader.dump_cache()
            self._sec_cache    = dump[0]
            self._react_cache  = dump[1]
            self._member_cache = dump[2]
            # axes_cache no se usa directamente en el worker (ya integrado en member_cache)

            # ── Advertencias de validación del modelo (p. ej. columnas no
            #    creadas de abajo hacia arriba — ver openstaad_reader) ──────────
            warns = self._reader.get_warnings()
            if warns:
                preview = "\n".join(f"• {w}" for w in warns[:8])
                extra = f"\n\n(+{len(warns)-8} más)" if len(warns) > 8 else ""
                box = QMessageBox(self)
                box.setIcon(QMessageBox.Warning)
                box.setWindowTitle("Advertencias del modelo STAAD")
                box.setText(
                    f"Se detectaron {len(warns)} advertencia(s) al leer el modelo.\n"
                    "Revíselas: pueden invertir el signo de las fuerzas.")
                box.setDetailedText("\n\n".join(warns))
                box.setInformativeText(preview + extra)
                box.exec()
        else:
            # Modo demo: cachés vacíos → el worker generará LoadPoints nulos
            self._sec_cache    = {}
            self._react_cache  = {}
            self._member_cache = {}
            lc_serv = lc_serv or [1]
            lc_ult  = lc_ult  or [101]

        # Guardar contexto de corrida para poder recalcular con dimensión fija
        self._fuente  = fuente
        self._lc_serv = lc_serv
        self._lc_ult  = lc_ult

        # ── Lanzar QThread ────────────────────────────────────────────────────
        self._launch_worker(fixed_dims=None)

    def _launch_worker(self, fixed_dims: Optional[dict] = None) -> None:
        """Lanza el QThread de diseño. fixed_dims activa la Mejora 2."""
        if self._params is None:
            return
        self._progress.setVisible(True)
        self._progress.setValue(0)
        self.btn_export.setEnabled(False)
        self.btn_memo.setEnabled(False)

        worker = DesignWorker(
            nodes        = self._elements,
            params       = self._params,
            sec_cache    = self._sec_cache,
            react_cache  = self._react_cache,
            member_cache = self._member_cache,
            fuente       = self._fuente,
            lc_serv      = self._lc_serv,
            lc_ult       = self._lc_ult,
            fixed_dims   = fixed_dims,
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_progress)
        worker.finished.connect(self._on_finished)
        worker.error.connect(self._on_error)
        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)

        self._worker = worker
        self._thread = thread
        thread.start()

    # ── Slots de progreso / finalización ─────────────────────────────────────

    def _on_progress(self, pct: int, msg: str) -> None:
        self._progress.setValue(pct)
        self._status.showMessage(f"  {msg}")

    def _on_finished(self, results: List[NodeResult]) -> None:
        self._results = results
        self._progress.setVisible(False)
        self._results_w.load_results(results, self._params, self._elements)
        self._summary.load(results, self._params)
        self._final_dims.load_results(results)
        self._plan.load(results, self._params, self._plan_geometry_or_grid(results))
        self.btn_export.setEnabled(True)
        self.btn_memo.setEnabled(True)
        n  = len(results)
        ts = datetime.now().strftime("%H:%M:%S")
        suffix = "  (dimensión fija)" if self._fixed_active else ""
        self._status.showMessage(
            f"  ✔  Diseño completado  ·  {n} zapata(s)  ·  {ts}{suffix}")

    def _plan_geometry_or_grid(self, results: List[NodeResult]) -> dict:
        """Usa las coordenadas reales de STAAD; si faltan, arregla en rejilla
        (modo demo o sin geometría) para que la planta no se traslape."""
        geom = dict(self._plan_geom)
        missing = [nr for nr in results if nr.node_id not in geom
                   or (geom[nr.node_id].get("x", 0) == 0
                       and geom[nr.node_id].get("z", 0) == 0)]
        if missing and len(missing) == len(results):
            import math as _m
            n = len(results)
            cols = max(1, int(_m.ceil(_m.sqrt(n))))
            step = max((max(nr.L, nr.B) for nr in results), default=2.0) * 1.6
            for i, nr in enumerate(results):
                geom[nr.node_id] = {"x": (i % cols) * step,
                                    "z": (i // cols) * step, "beta": 0.0}
        return geom

    def _on_recompute_fixed(self, dims: dict) -> None:
        """Recalcula con dimensiones fijas del usuario (Mejora 2).
        dims vacío → restaura el diseño automático."""
        if self._params is None or not self._elements:
            QMessageBox.information(self, "Sin diseño previo",
                                    "Ejecute primero un diseño.")
            return
        self._fixed_active = bool(dims)
        self._launch_worker(fixed_dims=dims or None)

    def _on_error(self, msg: str) -> None:
        self._progress.setVisible(False)
        self._status.showMessage("  ✗  Error en el diseño.")
        QMessageBox.critical(self, "Error en el diseño", msg)

    # ── Exportaciones ─────────────────────────────────────────────────────────

    def _on_export_results(self) -> None:
        if not self._results:
            return
        if not _DOCX_AVAIL:
            QMessageBox.warning(self, "Sin python-docx",
                                "pip install python-docx")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Resultados", "", "Word Document (*.docx)")
        if not path:
            return
        if not path.endswith(".docx"):
            path += ".docx"
        self._run_export("results", path, "Exportando resultados a Word…",
                         plan_geom=self._plan_geometry_or_grid(self._results))

    def _on_export_memo(self) -> None:
        if not self._results:
            return
        if not _DOCX_AVAIL:
            QMessageBox.warning(self, "Sin python-docx",
                                "pip install python-docx")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Memoria de Cálculo", "", "Word Document (*.docx)")
        if not path:
            return
        if not path.endswith(".docx"):
            path += ".docx"
        self._run_export("memo", path, "Generando memoria de cálculo…")

    def _run_export(self, kind: str, path: str, titulo: str,
                    plan_geom: Optional[dict] = None) -> None:
        """Lanza la exportación en un QThread con barra de progreso modal."""
        if self._export_thread and self._export_thread.isRunning():
            return

        dlg = QProgressDialog(titulo, "Cancelar", 0, 100, self)
        dlg.setWindowTitle("Exportando a Word")
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setMinimumWidth(420)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setValue(0)
        self._export_dlg = dlg

        worker = ExportWorker(kind, self._results, self._params, path, plan_geom)
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)

        # IMPORTANTE: conectar a METODOS de esta ventana (QObject del hilo
        # principal). Con closures sueltos PySide6 ejecuta el slot en el hilo
        # del worker, y thread.wait() ahi mismo produce un deadlock: la barra
        # llegaba a 100% "Listo" pero el dialogo nunca cerraba.
        worker.progress.connect(self._on_export_prog)
        worker.finished.connect(self._on_export_done)
        worker.error.connect(self._on_export_err)
        # Si el usuario cancela: la exportación continúa en el hilo pero
        # cerramos el diálogo (no hay punto de interrupción seguro a mitad).
        dlg.canceled.connect(dlg.close)

        self._export_thread = thread
        self._export_worker = worker
        thread.start()
        dlg.show()

    # ── Slots de exportacion (hilo principal) ─────────────────────────────────

    def _on_export_prog(self, pct: int, msg: str) -> None:
        dlg = getattr(self, "_export_dlg", None)
        if dlg is not None and not dlg.wasCanceled():
            dlg.setValue(pct)
            dlg.setLabelText(msg)

    def _export_cleanup(self) -> None:
        dlg = getattr(self, "_export_dlg", None)
        if dlg is not None:
            dlg.close()
            self._export_dlg = None
        if self._export_thread is not None:
            self._export_thread.quit()
            self._export_thread.wait()
        self._export_thread = None
        self._export_worker = None

    def _on_export_done(self, out_path: str) -> None:
        self._export_cleanup()
        QMessageBox.information(self, "Exportado",
                                f"Documento guardado en:\n{out_path}")

    def _on_export_err(self, msg: str) -> None:
        self._export_cleanup()
        QMessageBox.critical(self, "Error al exportar", msg)

    # ── Utilidades ────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_ids(text: str) -> List[int]:
        """
        Convierte texto de IDs a lista de enteros.
        Acepta: "1,5,10"  "10-15"  "1;2;3"  "1, 5, 10-15"
        """
        ids: set[int] = set()
        for token in text.replace(";", ",").split(","):
            token = token.strip()
            if not token:
                continue
            if "-" in token:
                parts = token.split("-", 1)
                try:
                    a, b = int(parts[0].strip()), int(parts[1].strip())
                    ids.update(range(min(a, b), max(a, b) + 1))
                except ValueError:
                    pass
            else:
                try:
                    ids.add(int(token))
                except ValueError:
                    pass
        return sorted(ids)
