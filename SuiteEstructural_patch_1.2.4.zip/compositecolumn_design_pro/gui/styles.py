﻿# gui/styles.py
"""QSS stylesheet — Suite Composite Column Design Pro."""

QSS = """
/* ── Global ── */
* {
    font-family: "Segoe UI";
    font-size: 9pt;
    color: #1C2833;
}
QMainWindow, QWidget {
    background-color: #EFEFEF;
}

/* ── GroupBox ── */
QGroupBox {
    background-color: transparent;
    border: 1px solid #AED6F1;
    border-radius: 4px;
    margin-top: 6px;
    padding: 4px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 4px;
    color: #1B4F72;
    font-weight: bold;
}

/* ── CheckBox / RadioButton (indicador explícito, como columnsteel) ── */
QCheckBox { spacing: 6px; }
QCheckBox::indicator {
    width: 15px; height: 15px;
    border: 1px solid #85C1E9;
    border-radius: 3px;
    background: #FFFFFF;
}
QCheckBox::indicator:checked {
    background-color: #2874A6;
    border: 1px solid #2874A6;
}
QCheckBox::indicator:disabled {
    background: #EAECEE;
    border: 1px solid #D5DBDB;
}
QRadioButton { spacing: 6px; }
QRadioButton::indicator {
    width: 14px; height: 14px;
    border: 1px solid #85C1E9;
    border-radius: 7px;
    background: #FFFFFF;
}
QRadioButton::indicator:checked {
    background-color: #2874A6;
    border: 1px solid #2874A6;
}

/* ── Inputs ── */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #FFFFFF;
    border: 1px solid #85C1E9;
    border-radius: 3px;
    padding: 2px 4px;
    min-height: 22px;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
    border: 1.5px solid #2874A6;
}
QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QComboBox:disabled {
    background-color: #E0E0E0;
    color: #909090;
    border: 1px solid #C8C8C8;
}
QTextEdit {
    background-color: #FFFFFF;
    border: 1px solid #AED6F1;
    border-radius: 3px;
    font-family: "Consolas";
    font-size: 9pt;
}

/* ── Buttons ── */
QPushButton {
    background-color: #2874A6;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 5px 12px;
    min-height: 26px;
}
QPushButton:hover   { background-color: #1B4F72; }
QPushButton:pressed { background-color: #117A65; }
QPushButton:disabled{ background-color: #AAB7B8; color: #717D7E; }

QPushButton#btn_run, QPushButton#btnGreen {
    background-color: #1E8449;
    font-size: 11pt;
    font-weight: bold;
    min-height: 36px;
}
QPushButton#btn_run:hover { background-color: #196F3D; }

QPushButton#btn_connect {
    background-color: #117A65;
    font-weight: bold;
}
QPushButton#btn_connect:hover { background-color: #0E6655; }

QPushButton#btn_word  { background-color: #2E86C1; }
QPushButton#btn_memory { background-color: #7D3C98; }
QPushButton#btn_excel, QPushButton#btnOrange { background-color: #D68910; }
QPushButton#btn_clear, QPushButton#btnRed   { background-color: #E74C3C; }

/* ── Tabs ── */
QTabWidget::pane {
    border: 1px solid #AED6F1;
    background-color: #FFFFFF;
    border-radius: 4px;
}
QTabBar::tab {
    background: #D6EAF8;
    border: 1px solid #AED6F1;
    padding: 5px 14px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    color: #1B4F72;
    min-width: 90px;
}
QTabBar::tab:selected {
    background: #2874A6;
    color: white;
    font-weight: bold;
}
QTabBar::tab:hover:!selected { background: #A9CCE3; }

/* ── Tables ── */
QTableWidget {
    background-color: #FFFFFF;
    alternate-background-color: #EBF5FB;
    border: 1px solid #AED6F1;
    gridline-color: #D6EAF8;
    selection-background-color: #2874A6;
    selection-color: white;
}
QHeaderView::section {
    background-color: #1B4F72;
    color: white;
    font-weight: bold;
    padding: 4px;
    border: 1px solid #2874A6;
}

/* ── Progress bar ── */
QProgressBar {
    border: none;
    background-color: #D6EAF8;
    max-height: 5px;
    min-height: 5px;
    border-radius: 2px;
    text-align: center;
}
QProgressBar::chunk {
    background-color: #1E8449;
    border-radius: 2px;
}

/* ── Scroll ── */
QScrollBar:vertical {
    background: #EBF5FB;
    width: 10px;
    border-radius: 5px;
}
QScrollBar::handle:vertical {
    background: #2874A6;
    border-radius: 5px;
    min-height: 20px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

/* ── Labels especiales ── */
QLabel#lbl_connected { color: #1E8449; font-weight: bold; }
QLabel#lbl_disconnected { color: #E74C3C; font-weight: bold; }
QLabel#lbl_header_title {
    color: white;
    font-size: 14pt;
    font-weight: bold;
}
QLabel#lbl_header_sub {
    color: #AED6F1;
    font-size: 9pt;
}
QLabel#lbl_header_ver {
    color: rgba(255,255,255,0.65);
    font-size: 8pt;
}

/* ── Splitter ── */
QSplitter::handle {
    background: #AED6F1;
    width: 2px;
}
"""
