﻿# gui/stress_strain_plot.py
"""
Widget para visualizar el diagrama de esfuerzo-deformación con inclinación
del eje neutro para cada combinación de carga.

Muestra 3 subplots:
  1. Distribución de deformación (diagrama lineal + eje neutro)
  2. Mapa de esfuerzo en la sección (scatter por tipo de fibra)
  3. Distribución de fuerza por fibra (barras horizontales agrupadas)
"""
from __future__ import annotations
import math
from typing import Optional

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PySide6.QtCore import Qt

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np


class StrainStressWidget(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)

        self._info_lbl = QLabel("")
        self._info_lbl.setAlignment(Qt.AlignCenter)
        self._info_lbl.setStyleSheet(
            "font-weight:bold;font-size:9pt;color:#1A5276;"
            "background:#EAF2F8;padding:4px;border-radius:4px;"
        )
        lay.addWidget(self._info_lbl)

        self._fig = Figure(figsize=(10, 4), tight_layout=True)
        self._canvas = FigureCanvas(self._fig)
        lay.addWidget(self._canvas, 1)

        self._data: Optional[dict] = None

    def set_data(self, data: dict):
        """
        data: dict devuelto por fiber_model.strain_stress_diagram()
          keys: c, theta_deg, fibers, eps_max, eps_min, label
          fibers: [{type, y, z, eps, sigma, F}, ...]
        """
        self._data = data
        self._draw()

    def _draw(self):
        self._fig.clear()
        d = self._data
        if not d or not d.get("fibers"):
            self._canvas.draw()
            return

        c       = d.get("c", 0)
        theta   = d.get("theta_deg", 0)
        d_max   = d.get("d_max", 0)   # offset del eje neutro (NTC P-M, no pasa por el centro salvo flexión pura)
        label   = d.get("label", "")
        fibers  = d["fibers"]
        eps_max = d.get("eps_max", 0.003)
        eps_min = d.get("eps_min", -0.002)

        self._info_lbl.setText(
            f"{label}   |   c = {c:.1f} cm   |   θ eje neutro = {theta:.1f}°"
        )

        # Separar por tipo
        conc_f   = [f for f in fibers if f["type"] == "concreto"]
        rebar_f  = [f for f in fibers if f["type"] == "refuerzo"]
        steel_f  = [f for f in fibers if f["type"] == "perfil"]

        ax1, ax2, ax3 = self._fig.subplots(1, 3)

        # ── 1. Distribución lineal de deformación vs Y ──────────────────
        ax1.set_title("Deformación ε vs Y", fontsize=9)
        ax1.set_xlabel("ε", fontsize=8)
        ax1.set_ylabel("Y (cm)", fontsize=8)
        ax1.tick_params(labelsize=7)

        if conc_f:
            y_c   = [f["y"] for f in conc_f]
            eps_c = [f["eps"] for f in conc_f]
            ax1.scatter(eps_c, y_c, s=4, c="lightblue", alpha=0.5, label="Concreto")
        if rebar_f:
            ax1.scatter([f["eps"] for f in rebar_f],
                        [f["y"]   for f in rebar_f],
                        s=25, c="red", zorder=5, label="Refuerzo")
        if steel_f:
            ax1.scatter([f["eps"] for f in steel_f],
                        [f["y"]   for f in steel_f],
                        s=15, c="steelblue", alpha=0.7, label="Perfil")

        ax1.axvline(0, color="black", lw=0.8)
        ax1.axvline(0.003, color="gray", lw=0.7, ls="--", label="εcu=0.003")
        ax1.legend(fontsize=7)

        # ── 2. Mapa de esfuerzos en sección (y-z) ───────────────────────
        ax2.set_title("Esfuerzo σ en sección", fontsize=9)
        ax2.set_xlabel("Z (cm)", fontsize=8)
        ax2.set_ylabel("Y (cm)", fontsize=8)
        ax2.set_aspect("equal")
        ax2.tick_params(labelsize=7)

        all_sigma = [f["sigma"] for f in fibers if f["sigma"] != 0]
        sigma_abs = max(abs(s) for s in all_sigma) if all_sigma else 1.0

        if conc_f:
            zc = [f["z"]     for f in conc_f]
            yc = [f["y"]     for f in conc_f]
            sc = [f["sigma"] for f in conc_f]
            sp = ax2.scatter(zc, yc, c=sc, cmap="Blues", s=20,
                             vmin=0, vmax=sigma_abs, alpha=0.7)
            self._fig.colorbar(sp, ax=ax2, fraction=0.04, pad=0.02).set_label("σ kg/cm²", fontsize=6)

        if rebar_f:
            ax2.scatter([f["z"] for f in rebar_f],
                        [f["y"] for f in rebar_f],
                        c=[f["sigma"] for f in rebar_f],
                        cmap="RdBu_r", s=60, vmin=-sigma_abs, vmax=sigma_abs,
                        edgecolors="black", lw=0.5, zorder=6)

        if steel_f:
            ax2.scatter([f["z"] for f in steel_f],
                        [f["y"] for f in steel_f],
                        c=[f["sigma"] for f in steel_f],
                        cmap="RdYlGn", s=30, vmin=-sigma_abs, vmax=sigma_abs,
                        alpha=0.8, zorder=5)

        # Límites de la vista = extensión real de la sección (con margen),
        # fijados ANTES de dibujar el eje neutro y reafirmados después: la
        # línea del eje neutro se extiende matemáticamente sin límite y, si
        # se deja que matplotlib autoescale para incluirla completa, una
        # inclinación pronunciada (sin_t pequeño) hace que la vista se
        # aleje tanto que la sección real se ve diminuta (ver reporte).
        z_ext = max((abs(f["z"]) for f in fibers), default=1.0) or 1.0
        y_ext = max((abs(f["y"]) for f in fibers), default=1.0) or 1.0
        margin = 1.15
        xlim = (-z_ext * margin, z_ext * margin)
        ylim = (-y_ext * margin, y_ext * margin)

        # Eje neutro: lugar geométrico y*sin(theta)+z*cos(theta) = K, con
        # K = d_max - c (ver fiber_model.strain_stress_diagram). K=0 solo
        # en flexión pura (P=0); en flexocompresión el eje neutro se
        # desplaza del centroide según la carga axial.
        theta_rad = math.radians(theta)
        K = d_max - c
        cos_t = math.cos(theta_rad); sin_t = math.sin(theta_rad)
        if abs(sin_t) > 0.01:
            zn = np.linspace(*xlim, 10)
            yn = (K - cos_t * zn) / sin_t
            ax2.plot(zn, yn, "k--", lw=1, label="Eje neutro")
        else:
            z_na = K / cos_t if abs(cos_t) > 1e-9 else 0.0
            ax2.axvline(z_na, color="k", lw=1, ls="--", label="Eje neutro")
        ax2.set_xlim(*xlim)
        ax2.set_ylim(*ylim)
        ax2.legend(fontsize=7)

        # ── 3. Fuerza resultante por tipo ────────────────────────────────
        ax3.set_title("Fuerza resultante por tipo (kg)", fontsize=9)
        ax3.tick_params(labelsize=7)

        F_conc  = sum(f["F"] for f in conc_f)
        F_reb   = sum(f["F"] for f in rebar_f)
        F_perf  = sum(f["F"] for f in steel_f)
        F_tot   = F_conc + F_reb + F_perf
        types   = ["Concreto", "Refuerzo", "Perfil", "ΣF (equilibrio)"]
        forces  = [F_conc, F_reb, F_perf, F_tot]
        colors  = ["#2E86C1", "#E74C3C", "#1E8449", "#7D3C98"]
        bars    = ax3.barh(types, forces, color=colors, alpha=0.8)
        ax3.axvline(0, color="black", lw=0.8)
        ax3.set_xlabel("F (kg)", fontsize=8)
        for bar, val in zip(bars, forces):
            ax3.text(val + (max(forces, key=abs, default=1) * 0.02),
                     bar.get_y() + bar.get_height() / 2,
                     f"{val:,.0f}", va="center", fontsize=7)

        # ── Verificación de equilibrio: ΣF debe igualar la carga axial P ──
        # del punto analizado (0 solo en flexión pura).
        P_targ = d.get("Pu_target")
        if P_targ is not None:
            dif    = F_tot - P_targ
            tol    = max(abs(P_targ) * 0.05, 500.0)   # 5 % o 500 kg
            ok_eq  = abs(dif) <= tol
            ax3.axvline(P_targ, color="#7D3C98", lw=1.2, ls="--")
            ax3.text(0.02, 1.02,
                     f"ΣF = {F_tot:,.0f} kg   vs   P = {P_targ:,.0f} kg   "
                     f"(Δ = {dif:+,.0f} kg)  "
                     + ("✔ EQUILIBRIO" if ok_eq else "✘ revisar"),
                     transform=ax3.transAxes, fontsize=7.5,
                     color=("#1E8449" if ok_eq else "#C0392B"),
                     fontweight="bold")
        else:
            ax3.text(0.02, 1.02,
                     f"ΣF = {F_tot:,.0f} kg (debe igualar la P del punto; "
                     "0 solo en flexión pura)",
                     transform=ax3.transAxes, fontsize=7.5, color="#555")

        self._canvas.draw()
