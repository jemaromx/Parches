# -*- coding: utf-8 -*-
"""Propuesta de configuración de estribos según ACI Detailing Manual (MNL-66).

Reglas aplicadas (columnas rectangulares):
  • ≤ 4 barras:  estribo perimetral cerrado únicamente.
  • 5–7 barras:  estribo perimetral + grapas en las barras intermedias.
  • 8 barras:    estribo perimetral + estribo tipo DIAMANTE (rombo) que
                 soporta las 4 barras centrales de cara (detalle típico MNL-66).
  • > 8 barras:  estribo perimetral + grapas (crossties) colocadas de modo
                 que ninguna barra longitudinal quede a más de 15 cm libres
                 (x_i ≤ 35 cm entre barras soportadas; se adopta el criterio
                 de soporte cuando la separación excede 30 cm de una barra
                 soportada — NTC 8.3.4/ACI 25.7.2.3).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field


_SEP_MAX_SOPORTE_CM = 30.0   # separación máx. de una barra NO soportada a una soportada


@dataclass
class PropuestaEstribos:
    """Resultado de la propuesta de refuerzo transversal."""
    config: str = "perimetral"       # perimetral | perimetral+diamante | perimetral+grapas
    n_grapas_x: int = 0              # grapas paralelas a la dirección X (ancho b)
    n_grapas_y: int = 0              # grapas paralelas a la dirección Y (peralte h)
    diamante: bool = False
    n_ramas_x: float = 2.0           # ramas efectivas de cortante dir X
    n_ramas_y: float = 2.0
    descripcion: str = ""
    notas: list = field(default_factory=list)


def proponer_estribos(n_var: int, b_cm: float, h_cm: float,
                      rec_cm: float = 5.0, db_var_cm: float = 2.54,
                      db_est_cm: float = 0.95) -> PropuestaEstribos:
    """Propone la configuración de estribos/grapas para una columna
    rectangular con ``n_var`` barras distribuidas en el perímetro.

    Args:
        n_var:      número total de barras longitudinales
        b_cm, h_cm: dimensiones de la sección (cm)
        rec_cm:     recubrimiento al centroide de la barra (cm)
        db_var_cm:  diámetro de barra longitudinal (cm)
        db_est_cm:  diámetro del estribo (cm)
    """
    p = PropuestaEstribos()
    est_lbl = "#3" if db_est_cm < 1.1 else ("#4" if db_est_cm < 1.4 else "#5")

    if n_var <= 4:
        p.config = "perimetral"
        p.descripcion = (
            f"Estribo perimetral cerrado {est_lbl} con ganchos sísmicos a 135°. "
            "Las 4 barras de esquina quedan soportadas por el estribo "
            "(MNL-66, detalle de columna con 4 barras).")
        return p

    if n_var == 8:
        p.config = "perimetral+diamante"
        p.diamante = True
        # El diamante aporta 2 ramas inclinadas a 45° por dirección → 2·cos45
        p.n_ramas_x = p.n_ramas_y = 2.0 + 2.0 * math.cos(math.radians(45))
        p.descripcion = (
            f"Estribo perimetral cerrado {est_lbl} + estribo tipo DIAMANTE "
            f"(rombo) {est_lbl} que soporta las 4 barras centrales de cara. "
            "Ambos con ganchos sísmicos a 135° (MNL-66, detalle típico de "
            "columna con 8 barras). "
            f"Ramas efectivas por dirección: {p.n_ramas_x:.2f}.")
        return p

    # Distribución de barras por cara (perímetro, esquinas compartidas)
    # nx barras en cada cara horizontal (ancho b), ny en cada cara vertical.
    per = 2.0 * ((b_cm - 2 * rec_cm) + (h_cm - 2 * rec_cm))
    nb_side = max(n_var - 4, 0)                       # barras intermedias totales
    lado_b = b_cm - 2 * rec_cm
    lado_h = h_cm - 2 * rec_cm
    # Reparto proporcional al perímetro de cada par de caras
    ni_b = int(round(nb_side * (2 * lado_b / per))) if per > 0 else 0
    ni_h = nb_side - ni_b
    n_caraB = (ni_b + 1) // 2     # intermedias por cara horizontal
    n_caraH = (ni_h + 1) // 2     # intermedias por cara vertical

    def _grapas_en_cara(n_int: int, largo_cm: float) -> int:
        """Grapas necesarias en una cara con n_int barras intermedias."""
        if n_int <= 0:
            return 0
        sep = largo_cm / (n_int + 1)   # separación entre barras de la cara
        # (a) Distancia entre barras SOPORTADAS ≤ 30 cm → se requieren
        #     al menos ceil(largo/30) − 1 barras intermedias soportadas.
        g_dist = 0
        if largo_cm > _SEP_MAX_SOPORTE_CM:
            g_dist = min(n_int,
                         int(math.ceil(largo_cm / _SEP_MAX_SOPORTE_CM)) - 1)
        # (b) Barras alternadas soportadas cuando la separación entre
        #     barras excede 15 cm libres (MNL-66 / ACI 25.7.2.3).
        g_alt = (n_int + 1) // 2 if sep > 15.0 else 0
        return max(g_dist, g_alt)

    gx = _grapas_en_cara(n_caraB, lado_b)   # grapas por cara horizontal
    gy = _grapas_en_cara(n_caraH, lado_h)   # grapas por cara vertical

    p.config = "perimetral+grapas"
    p.n_grapas_x = gy      # las grapas que cruzan en X soportan barras de caras verticales
    p.n_grapas_y = gx
    p.n_ramas_x = 2.0 + gy
    p.n_ramas_y = 2.0 + gx
    p.descripcion = (
        f"Estribo perimetral cerrado {est_lbl} + "
        f"{gx + gy} grapa(s) {est_lbl} (crossties) con gancho sísmico 135°/90° "
        f"alternado: {gx} por cara en dirección del ancho b y {gy} por cara "
        f"en dirección del peralte h. Ninguna barra longitudinal queda a más "
        f"de {_SEP_MAX_SOPORTE_CM:.0f} cm de una barra soportada "
        "(MNL-66 / ACI 25.7.2.3 / NTC 8.3.4). "
        f"Ramas: {p.n_ramas_x:.0f} dir X, {p.n_ramas_y:.0f} dir Y.")
    if n_var in (5, 6, 7):
        p.notas.append(
            "Con 5 a 7 barras considere redistribuir a 4 u 8 barras para un "
            "detallado más regular (MNL-66).")
    return p
