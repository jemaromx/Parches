﻿# ui/widgets.py  — Widgets reutilizables de la suite
from __future__ import annotations
from PySide6.QtWidgets import (QTableWidget, QTableWidgetItem, QApplication,
                              QHeaderView, QAbstractItemView, QLabel)
from PySide6.QtGui import QKeySequence, QColor, QFont
from PySide6.QtCore import Qt
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from config.settings import COLORS

P = COLORS["primary"]


class CopyableTable(QTableWidget):
    """QTableWidget con Ctrl+C → TSV compatible con Excel/Word."""

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self._copy_to_clipboard()
        else:
            super().keyPressEvent(event)

    def _copy_to_clipboard(self):
        ranges = self.selectedRanges()
        if not ranges:
            return
        r_min = min(r.topRow() for r in ranges)
        r_max = max(r.bottomRow() for r in ranges)
        c_min = min(r.leftColumn() for r in ranges)
        c_max = max(r.rightColumn() for r in ranges)
        hdrs  = [self.horizontalHeaderItem(c).text()
                 if self.horizontalHeaderItem(c) else ""
                 for c in range(c_min, c_max+1)]
        lines = ["\t".join(hdrs)]
        for row in range(r_min, r_max+1):
            cells = [self.item(row, c).text().strip()
                     if self.item(row, c) else ""
                     for c in range(c_min, c_max+1)]
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))


def make_result_table(parent=None, cols: list[str] = None) -> CopyableTable:
    """CopyableTable configurada como tabla de resultados (solo lectura)."""
    t = CopyableTable(0, len(cols or []), parent)
    if cols:
        t.setHorizontalHeaderLabels(cols)
    t.setAlternatingRowColors(True)
    t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    t.verticalHeader().setVisible(False)
    return t


def set_item(table: QTableWidget, row: int, col: int,
             text: str, color: str | None = None, bold: bool = False,
             fg: str | None = None):
    """Inserta un ítem en la tabla con formato opcional."""
    it = QTableWidgetItem(text)
    it.setTextAlignment(Qt.AlignCenter)
    if color:
        it.setBackground(QColor(color))
    if fg:
        it.setForeground(QColor(fg))
    if bold:
        f = it.font(); f.setBold(True); it.setFont(f)
    table.setItem(row, col, it)


class MplCanvas(FigureCanvas):
    """Canvas de Matplotlib para incrustar en PySide6."""

    def __init__(self, parent=None, figsize=(5, 4), dpi=90):
        self.fig = Figure(figsize=figsize, dpi=dpi, tight_layout=True)
        self.ax  = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)

    def clear(self):
        self.ax.cla()

    def redraw(self):
        self.fig.canvas.draw_idle()


def header_label(text: str, size: int = 14, color: str = "white") -> QLabel:
    """QLabel para el encabezado de la ventana."""
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color:{color}; font-size:{size}pt; font-weight:bold;")
    return lbl
