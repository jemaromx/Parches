﻿# -*- coding: utf-8 -*-
"""Exporta resultados de column_design_pro al formato JSON de intercambio
para que joint_design_pro pueda importar las areas de acero de columnas.

Formato del archivo:
    column_results_<modelo>.json
    {
      "source":  "column_design_pro",
      "model":   "nombre.std",
      "date":    "2026-06-24T10:30:00",
      "columns": {
        "<col_id>": {
          "As_total_cm2": float,   -- acero longitudinal total (cm2)
          "p_diseno":     float,   -- ratio de acero (adimensional)
          "b_cm":         float,
          "h_cm":         float
        }
      }
    }

Uso dentro de main_window.py de column_design_pro:
    from fileio.joint_exporter import export_column_results_json
    export_column_results_json(results_list, model_name, output_path)
"""
from __future__ import annotations
import json
import os
from datetime import datetime
from typing import List


def export_column_results_json(
    design_results: List[object],   # lista de DesignResult
    model_name: str,
    output_path: str,
) -> str:
    """Genera el JSON de intercambio con las areas de acero de columnas.

    Toma el maximo As_total entre todos los resultados de cada col_id
    (envolvente sobre todas las combinaciones y ambos nodos).

    Args:
        design_results: lista de DesignResult de column_design_pro
        model_name:     nombre del archivo .std
        output_path:    ruta de salida del JSON

    Returns:
        Ruta del archivo generado.
    """
    data: dict = {
        "source":  "column_design_pro",
        "model":   os.path.basename(model_name),
        "date":    datetime.now().isoformat(timespec="seconds"),
        "columns": {},
    }

    # Agrupar por col_id y tomar el envolvente (max As_total)
    por_col: dict[str, dict] = {}
    for r in design_results:
        cid  = str(getattr(r, "col_id", 0))
        As   = float(getattr(r, "As_total", 0.0))
        p    = float(getattr(r, "p_diseno", 0.0))
        Bc   = float(getattr(r, "Bc", 0.0))
        Hc   = float(getattr(r, "Hc", 0.0))

        if cid not in por_col or As > por_col[cid]["As_total_cm2"]:
            por_col[cid] = {
                "As_total_cm2": round(As, 3),
                "p_diseno":     round(p, 5),
                "b_cm":         round(Bc, 1),
                "h_cm":         round(Hc, 1),
                # Armado propuesto (para importar diametro en nudos)
                "n_var":        int(getattr(r, "n_var", 0) or 0),
                "var_num":      int(getattr(r, "var_num", 0) or 0),
                "db_cm":        round(float(getattr(r, "d_var_cm", 0.0) or 0.0), 3),
            }

    data["columns"] = por_col

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return output_path


def read_column_results_json(json_path: str) -> dict:
    """Lee un archivo JSON de intercambio de column_design_pro.

    Returns:
        dict con clave str(col_id) -> {"As_total_cm2", "p_diseno", ...}
        Retorna {} si el archivo no existe o tiene error.
    """
    if not os.path.isfile(json_path):
        return {}
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("source") != "column_design_pro":
            return {}
        return data.get("columns", {})
    except Exception:
        return {}
