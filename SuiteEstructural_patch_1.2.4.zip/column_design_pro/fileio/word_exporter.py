﻿"""
Exportador de resultados a Microsoft Word (.docx).

Genera tres tipos de documentos:
  1. export_results_table()        — Tabla de resultados de diseño
  2. export_interaction_diagrams() — Diagramas de interacción 3-D
  3. export_full_calculations()    — Memoria de cálculo DETALLADA

La memoria detallada muestra, para cada columna:
  • Sección con geometría y propiedades de materiales.
  • Tabla resumen de todas las combinaciones.
  • Combinación más desfavorable por flexocompresión:
      geometría del eje neutro, bloque de compresión, deformación y tensión
      de cada varilla, sumatoria de fuerzas y momentos, capacidades nominales
      y reducidas, verificación de excentricidad mínima, factor FR/phi.
  • Combinación más desfavorable por cortante (dir-Z y dir-Y):
      fórmulas referenciadas a norma, operaciones con valores.
  • Combinación más desfavorable por torsión:
      umbral, geometría centrolínea, acero requerido, mínimos, check sección.
  • Diagrama de interacción 2-D (P vs Mr) con todos los puntos de demanda
    coloreados (verde = dentro, rojo = fuera de la envolvente reducida).
  • Diagrama de interacción 3-D (si está disponible la imagen pre-renderizada).

Requiere: python-docx, matplotlib
"""
from __future__ import annotations

import io
import math
import os
import datetime
from typing import Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from config.settings import COLORS, APP_NAME, APP_VERSION

_Es   = 2_039_000.0   # kg/cm²
_Epsi = 0.003          # εcu


# ── Helpers de formato ────────────────────────────────────────────────────────

def _rgb(hex_color: str):
    h = hex_color.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _set_cell_bg(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.lstrip("#"))
    tcPr.append(shd)


def _bold_cell(cell, text: str, size: int = 9, color_hex: str = "#FFFFFF"):
    cell.text = text
    run = cell.paragraphs[0].runs[0]
    run.bold = True
    run.font.size = Pt(size)
    run.font.color.rgb = _rgb(color_hex)
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _data_cell(cell, text: str, size: int = 8, bold: bool = False,
               color_hex: str = "#2C3E50", align=WD_ALIGN_PARAGRAPH.CENTER):
    cell.text = str(text)
    run = cell.paragraphs[0].runs[0]
    run.bold = bold
    run.font.size = Pt(size)
    run.font.color.rgb = _rgb(color_hex)
    cell.paragraphs[0].alignment = align
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


# ── Clase principal ───────────────────────────────────────────────────────────

class WordExporter:
    """Genera documentos Word con los resultados del diseño de columnas."""

    PRIMARY   = COLORS["primary"]
    SECOND    = COLORS["secondary"]
    PASS_BG   = "D5F5E3"
    FAIL_BG   = "FADBD8"
    HEADER_BG = "1B4F72"
    SUB_BG    = "2E86C1"
    ALT_BG    = "EBF5FB"

    def __init__(self):
        self.doc: Optional[Document] = None

    # ── API pública ───────────────────────────────────────────────────────────

    def export_results_table(self, results: list, params: dict,
                              output_path: str) -> bool:
        self.doc = Document()
        self._setup_document()
        self._cover_page(params, "TABLA DE RESULTADOS DE DISEÑO")
        self.doc.add_page_break()

        cols: dict = {}
        for r in results:
            cols.setdefault(r.col_id, []).append(r)

        for col_id, col_results in cols.items():
            self._column_header(col_id, col_results[0], params)
            self._results_table(col_results)
            self.doc.add_paragraph()

        self.doc.save(output_path)
        return True

    def export_interaction_diagrams(self, diagrams: dict,
                                     output_path: str,
                                     params: dict) -> bool:
        self.doc = Document()
        self._setup_document()
        self._cover_page(params, "DIAGRAMAS DE INTERACCION 3-D")
        self.doc.add_page_break()

        for col_id, data in diagrams.items():
            h = self.doc.add_heading(f"Columna {col_id}", level=2)
            h.paragraph_format.space_before = Pt(12)
            if "fig_path" in data and os.path.exists(data["fig_path"]):
                self.doc.add_picture(data["fig_path"], width=Inches(6.0))
                self.doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            self.doc.add_page_break()

        self.doc.save(output_path)
        return True

    def export_full_calculations(self, results: list, params: dict,
                                  diagrams: dict, output_path: str) -> bool:
        """Memoria de cálculo completa y detallada."""
        self.doc = Document()
        self._setup_document()
        self._cover_page(params, "MEMORIA DE CALCULO")
        self.doc.add_page_break()

        self._intro_section(params)
        self.doc.add_page_break()
        self._normative_section(params)
        self.doc.add_page_break()
        self._material_section(params)

        cols: dict = {}
        for r in results:
            cols.setdefault(r.col_id, []).append(r)

        for col_id, col_results in cols.items():
            self.doc.add_page_break()
            self._column_calculation(col_id, col_results, params, diagrams)

        self.doc.save(output_path)
        return True

    # ── Secciones genéricas ───────────────────────────────────────────────────

    def _setup_document(self):
        sec = self.doc.sections[0]
        sec.page_width  = Cm(21.59)
        sec.page_height = Cm(27.94)
        sec.left_margin = sec.right_margin = Cm(2.54)
        sec.top_margin  = sec.bottom_margin = Cm(2.0)
        style = self.doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(10)

    def _cover_page(self, params: dict, title: str):
        self.doc.add_paragraph()
        p = self.doc.add_paragraph()
        run = p.add_run(APP_NAME)
        run.bold = True; run.font.size = Pt(28)
        run.font.color.rgb = _rgb(self.PRIMARY)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

        p2 = self.doc.add_paragraph()
        run2 = p2.add_run(title)
        run2.bold = True; run2.font.size = Pt(16)
        run2.font.color.rgb = _rgb(self.SECOND)
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER

        self.doc.add_paragraph()
        code = params.get("code", "ACI")
        norm = "ACI 318-25" if code == "ACI" else "NTC 2023 (DEC)"
        info = [
            ("Norma de diseño:", norm),
            ("f'c:", f"{params.get('fc', 0):.0f} kg/cm²"),
            ("fy:",  f"{params.get('fy', 0):.0f} kg/cm²"),
            ("Recubrimiento (rec1/rec2):",
             f"{params.get('rec1',0):.1f} / {params.get('rec2',0):.1f} cm"),
            ("Cuantia minima - maxima:",
             f"{params.get('p_min',0)*100:.1f}% - {params.get('p_max',0)*100:.1f}%"),
            ("Fecha:", datetime.date.today().strftime("%d/%m/%Y")),
        ]
        for label, value in info:
            pi = self.doc.add_paragraph()
            pi.add_run(f"{label}  ").bold = True
            pi.runs[0].font.size = Pt(11)
            pi.add_run(value).font.size = Pt(11)
            pi.alignment = WD_ALIGN_PARAGRAPH.CENTER

    def _column_header(self, col_id: int, r, params: dict):
        code = params.get("code", "ACI")
        norm = "ACI 318-25" if code == "ACI" else "NTC 2023"
        h = self.doc.add_heading(f"Columna {col_id} — {norm}", level=2)
        h.paragraph_format.space_before = Pt(10)
        tipo = "Rectangular" if r.col_type == 1 else "Circular"
        self.doc.add_paragraph(
            f"Seccion: {tipo}  |  B = {r.Bc:.1f} cm  |  H = {r.Hc:.1f} cm"
        ).paragraph_format.space_after = Pt(4)

    def _results_table(self, col_results: list):
        headers = [
            "Comb", "Nodo", "Pu\n(ton)", "Muy\n(ton·m)", "Muz\n(ton·m)",
            "a (°)", "rho (%)", "As\n(cm²)", "Pr\n(ton)", "Mr\n(ton·m)",
            "Vc-Z\n(ton)", "rv-Z", "Vc-Y\n(ton)", "rv-Y", "Condicion"
        ]
        tbl = self.doc.add_table(rows=1 + len(col_results), cols=len(headers))
        tbl.style = "Table Grid"
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        for c, h in enumerate(headers):
            _bold_cell(tbl.rows[0].cells[c], h, size=7)
            _set_cell_bg(tbl.rows[0].cells[c], self.HEADER_BG)
        for i, r in enumerate(col_results, 1):
            bg = self.PASS_BG if r.cumple else self.FAIL_BG
            vals = [
                str(r.comb_id), r.node.upper(),
                f"{r.Pu:.2f}", f"{r.Muy:.2f}", f"{r.Muz:.2f}",
                f"{r.ang1:.1f}", f"{r.p_diseno*100:.2f}", f"{r.As_total:.2f}",
                f"{r.Pr:.2f}", f"{r.Mr:.2f}",
                f"{r.shear.vc_z:.3f}", f"{r.shear.p_z:.4f}",
                f"{r.shear.vc_y:.3f}", f"{r.shear.p_y:.4f}",
                r.condicion,
            ]
            for c, v in enumerate(vals):
                _data_cell(tbl.rows[i].cells[c], v, size=7,
                           bold=(c == len(vals)-1))
                _set_cell_bg(tbl.rows[i].cells[c], bg)

    def _intro_section(self, params: dict):
        self.doc.add_heading("1. Introduccion", level=1)
        code = params.get("code", "ACI")
        norm = ("ACI 318-25" if code == "ACI" else
                "NTC 2023 — Normas Tecnicas Complementarias para Diseño y "
                "Construccion de Estructuras de Concreto (CDMX)")
        self.doc.add_paragraph(
            f"El presente documento constituye la memoria de calculo para el "
            f"diseño de columnas de concreto reforzado conforme a la norma {norm}. "
            f"Para cada elemento se identifican las combinaciones de carga mas "
            f"desfavorables y se presenta el desarrollo completo de las operaciones "
            f"de diseño por flexocompresion biaxial, cortante y torsion."
        ).paragraph_format.space_after = Pt(6)

    def _normative_section(self, params: dict):
        self.doc.add_heading("2. Marco Normativo", level=1)
        code = params.get("code", "ACI")
        refs = {
            "ACI": [
                "ACI 318-25 — Building Code Requirements for Structural Concrete, "
                "American Concrete Institute, 2025.",
                "ACI 318-25 §22.2.2.1 — Deformacion ultima del concreto: ecu = 0.003",
                "ACI 318-25 Tabla 22.2.2.4.3 — Factor beta1 del bloque rectangular",
                "ACI 318-25 Tabla 21.2.2 — Factores de reduccion de resistencia phi",
                "ACI 318-25 §22.5.5.1 — Resistencia al cortante del concreto Vc",
                "ACI 318-25 §9.6.3.3 — Refuerzo transversal minimo",
                "ACI 318-25 §22.4.2 — Carga axial maxima en columnas",
                "ACI 318-25 §22.7.4 / §22.7.6 — Diseño por torsion",
            ],
            "NTC": [
                "NTC 2023 — Normas Tecnicas Complementarias para Diseño y "
                "Construccion de Estructuras de Concreto, CDMX, 2023.",
                "NTC 2023 §3.6.1 — Bloque de compresion equivalente (beta1), "
                "deformacion ultima ecu = 0.003",
                "NTC 2023 §3.6.1 — beta1 = 0.85 si f'c <= 300 kg/cm²; "
                "beta1 = 1.05 - f'c/1400 >= 0.65 si f'c > 300 kg/cm²",
                "NTC 2023 Tabla 3.8.2.2 — Factores de reduccion FR "
                "(zona de transicion: anchura 0.003 sobre eps_cy)",
                "NTC 2023 §5.5.3.1.1.a — Resistencia cortante Vc (termino axial aditivo): "
                "VcR = FR*(0.50*sqrt(f'c) + Nu/(6*Ag))*bw*d",
                "NTC 2023 §6.3.5.4.4 — Refuerzo transversal minimo",
                "NTC 2023 §5.3 / §6.4 — Carga axial maxima en columnas",
                "NTC 2023 §5.8.2.5 — Umbral de torsion: T_ch = 0.27*sqrt(f'c)*Acp²/pcp",
                "NTC 2023 §5.8.3.1.2 — Verificacion seccion: limite 2.0*sqrt(f'c)",
                "NTC 2023 §5.8.3.2.2-3 — Diseño por torsion At y Al",
                "NTC 2023 §5.3.2 — Excentricidad minima: e_min = max(0.05h, 2 cm)",
            ],
        }
        for ref in refs.get(code, refs["ACI"]):
            p = self.doc.add_paragraph(style="List Bullet")
            p.add_run(ref).font.size = Pt(9)

        # Referencias sísmicas adicionales (Q=3 / Q=4)
        Q_val = params.get("Q", 1)
        if Q_val >= 3:
            self.doc.add_paragraph()
            self.doc.add_heading("Marco Normativo — Diseño Sismico", level=2)
            if code == "NTC":
                if Q_val == 3:
                    refs_sis = [
                        "NTC 2023 DEC Cap.7 — Ductilidad Media (Q=3)",
                        "§7.4.2 — Cortante de capacidad Ve = (Mpr_a+Mpr_b)/Hn  (fy_eff = fy)",
                        "§7.4.4.2.1 — Zona de confinamiento Lo ≥ max(Hn/6, mayor_dim, 600mm)",
                        "§7.4.4.2.2 — Separaciones s_o por grado de acero",
                        "§7.4.2 ref. §8.4.6 — Ignorar Vc si Pu < Ag·f'c/20 Y Vsismo ≥ 0.5·Ve",
                    ]
                else:
                    refs_sis = [
                        "NTC 2023 DEC Cap.8 — Ductilidad Alta (Q=4)",
                        "§8.4.2 — Dimensiones minimas: min_dim ≥ 300mm; ratio min/max ≥ 0.4",
                        "§8.4.3 — ΣMnc ≥ 1.2·ΣMprb con fy_eff = 1.25·fy; FR = 1.0",
                        "§8.4.4 — Cuantia longitudinal: 0.01 ≤ ρ ≤ 0.04; min 6 barras circular",
                        "§8.4.5.1 — Lo ≥ max(peralte, Hn/6, 600mm)",
                        "§8.4.5.3 — s_o = 100+(350-hx)/3 acotada [100,150]mm",
                        "Tabla 8.4.5.4 — Ash/Ach ≥ max(0.3(Ag/Ach-1)f'c/fyt, 0.09f'c/fyt)",
                        "§8.4.6 — Ignorar Vc si Pu < Ag·f'c/20 Y Vsismo ≥ 0.5·Ve",
                    ]
            else:
                if Q_val == 3:
                    refs_sis = [
                        "ACI 318-25 §18.4 — Marco Intermedio (IMF, Q=3)",
                        "§18.4.3.1 — Ve = (Mpr_a+Mpr_b)/Hn  (Mpr con fy, no 1.25fy)",
                        "§18.4.3.3 — Lo ≥ max(mayor_dim, Hn/6, 18in=45.72cm)",
                        "§18.4.3.3 — Separaciones en Lo",
                    ]
                else:
                    refs_sis = [
                        "ACI 318-25 §18.7 — Marco Especial (SMF, Q=4)",
                        "§18.7.6.1 — Ve = (Mpr_a+Mpr_b)/Hn  (Mpr con 1.25·fy)",
                        "§18.7.5.1 — Lo ≥ max(mayor_dim, Hn/6, 18in=45.72cm)",
                        "§18.7.5.3 — s ≤ min(min_dim/4, 6db, 15.24cm)",
                        "§18.7.5.4 — Ash minima de confinamiento",
                        "§18.7.6.1 — Ignorar Vc si Pu < Ag·f'c/20 Y Vsismo ≥ 0.5·Ve",
                    ]
            for ref in refs_sis:
                p = self.doc.add_paragraph(style="List Bullet")
                p.add_run(ref).font.size = Pt(9)

    def _material_section(self, params: dict):
        self.doc.add_heading("3. Propiedades de los Materiales", level=1)
        fc   = params.get("fc", 250)
        fy   = params.get("fy", 4200)
        code = params.get("code", "ACI")
        Ec   = (15_100 if code == "ACI" else 14_000) * math.sqrt(fc)
        eps_y = fy / _Es
        # beta1 segun codigo
        if code == "ACI":
            B1 = 0.85 if fc <= 280 else max(0.65, 0.85 - 0.05*(fc-280)/70)
            b1_ref = "ACI 318-25 Tabla 22.2.2.4.3"
        else:
            B1 = 0.85 if fc <= 300 else max(0.65, 1.05 - fc/1400.0)
            b1_ref = "NTC 2023 §3.6.1"

        data = [
            ("f'c — Resistencia a compresion del concreto", f"{fc:.0f} kg/cm²"),
            ("f''c = 0.85·f'c", f"0.85 x {fc:.0f} = {0.85*fc:.1f} kg/cm²"),
            ("fy  — Fluencia del acero de refuerzo",        f"{fy:.0f} kg/cm²"),
            ("Es  — Modulo de elasticidad del acero",       "2 039 000 kg/cm²"),
            ("Ec  — Modulo de elasticidad del concreto",    f"{Ec:,.0f} kg/cm²"),
            ("ecu — Deformacion ultima del concreto",       "0.003"),
            ("eps_y = fy/Es — Deformacion de fluencia",    f"{eps_y:.5f}"),
            (f"beta1 [{b1_ref}]",                           f"{B1:.3f}"),
        ]
        tbl = self.doc.add_table(rows=len(data) + 1, cols=2)
        tbl.style = "Table Grid"
        for c, txt in enumerate(["Parametro", "Valor"]):
            _bold_cell(tbl.rows[0].cells[c], txt)
            _set_cell_bg(tbl.rows[0].cells[c], self.HEADER_BG)
        for i, (p_name, val) in enumerate(data, 1):
            tbl.rows[i].cells[0].text = p_name
            tbl.rows[i].cells[1].text = val
            if i % 2 == 0:
                _set_cell_bg(tbl.rows[i].cells[0], self.ALT_BG)
                _set_cell_bg(tbl.rows[i].cells[1], self.ALT_BG)

        if code == "NTC":
            self.doc.add_paragraph()
            self._add_para(
                "Nota NTC — Factor FR (Tabla 3.8.2.2): "
                "FR_compresion = 0.65 (estribos) / 0.75 (zunchos); "
                "FR_tension = 0.90; zona de transicion de ancho 0.003 sobre eps_cy. "
                "FR_cortante = 0.75; FR_torsion = 0.75.", size=8)

    # ── Memoria detallada por columna ─────────────────────────────────────────

    def _column_calculation(self, col_id: int, col_results: list,
                              params: dict, diagrams: dict):
        code = params.get("code", "ACI")
        norm = "ACI 318-25" if code == "ACI" else "NTC 2023"
        r0   = col_results[0]
        tipo = "Rectangular" if r0.col_type == 1 else "Circular"
        Ag   = r0.Bc * r0.Hc if r0.col_type == 1 else math.pi * r0.Bc**2 / 4.0

        self.doc.add_heading(f"Columna {col_id}", level=1)
        self._add_para(
            f"Seccion: {tipo}  |  B = {r0.Bc:.1f} cm, H = {r0.Hc:.1f} cm  "
            f"|  Ag = {Ag:.1f} cm²  |  Norma: {norm}", size=10)

        self.doc.add_heading("Expresiones de diseño aplicadas", level=2)
        for expr in self._get_formulas(params):
            p = self.doc.add_paragraph(style="List Bullet")
            p.add_run(expr).font.size = Pt(9)

        self.doc.add_heading("Resumen de todas las combinaciones de diseño", level=2)
        self._results_table(col_results)

        # Combinaciones criticas
        r_flexo = max(col_results, key=lambda r: r.As_total)
        r_vz    = max(col_results, key=lambda r: abs(r.Vuz))
        r_vy    = max(col_results, key=lambda r: abs(r.Vuy))
        r_tor   = max(col_results, key=lambda r: abs(r.Ttor))

        # ── Factor de longitud efectiva K (si se calculó) ────────────────────
        k_results = params.get("k_results", {})
        k_res = k_results.get(col_id)
        if k_res is not None:
            self.doc.add_heading(
                "Factor de Longitud Efectiva K",
                level=2)
            self._section_k_factor(k_res, params)

        # ── Efectos de 2° orden (si se activo) ───────────────────────────────
        tiene_so = any(r.second_order is not None for r in col_results)
        if tiene_so:
            self.doc.add_heading(
                "Efectos de 2° orden — Amplificacion de momentos por esbeltez",
                level=2)
            r_so = max(col_results,
                       key=lambda r: max(
                           getattr(r.second_order, "delta_y", 1.0),
                           getattr(r.second_order, "delta_z", 1.0))
                       if r.second_order else 0.0)
            self._section_segundo_orden(r_so, params)

        self.doc.add_heading(
            "Calculo detallado — Flexocompresion biaxial (combinacion mas desfavorable)",
            level=2)
        self._section_flexo_critica(r_flexo, params)

        self.doc.add_heading(
            "Calculo detallado — Cortante (combinacion mas desfavorable)",
            level=2)
        self._section_cortante_critico(r_vz, r_vy, params)

        self.doc.add_heading(
            "Calculo detallado — Torsion (combinacion mas desfavorable)",
            level=2)
        self._section_torsion_critica(r_tor, params)

        # ── Requisitos sísmicos Q=3 / Q=4 ────────────────────────────────────
        Q_val = params.get("Q", 1)
        if Q_val >= 3:
            # Combinación más desfavorable: mayor área de acero longitudinal
            r_sis = r_flexo
            sr = getattr(r_sis, "seismic", None)
            if sr is not None and sr.Q >= 3:
                self.doc.add_heading(
                    f"Requisitos Sismicos — Q={Q_val} "
                    f"({'Ductilidad Media / IMF' if Q_val == 3 else 'Ductilidad Alta / SMF'})",
                    level=2)
                self._section_seismic(sr, r_sis, params)

        # ── Diagrama 2-D P vs Mr con todos los puntos de demanda ─────────────
        self.doc.add_heading(
            "Diagrama de interaccion P-M (resultante) con puntos de demanda",
            level=2)
        self._add_para(
            "El diagrama muestra la envolvente reducida (FR·Pn, FR·Mn) en el plano "
            "P – Mr (momento resultante). Cada punto de demanda se etiqueta con su "
            "combinacion y nodo. Verde = dentro de la envolvente; Rojo = fuera.",
            size=8)
        diag_data = diagrams.get(col_id, {})
        fig_2d_buf = self._gen_interaction_2d(col_results, diag_data, params)
        if fig_2d_buf is not None:
            self.doc.add_picture(fig_2d_buf, width=Inches(5.8))
            self.doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

        # ── Diagrama 3-D si existe imagen pre-renderizada ─────────────────────
        if col_id in diagrams and "fig_path" in diagrams[col_id]:
            fp = diagrams[col_id]["fig_path"]
            if os.path.exists(fp):
                self.doc.add_heading("Diagrama de interaccion 3-D", level=2)
                self.doc.add_picture(fp, width=Inches(5.5))
                self.doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ── Generacion del diagrama 2-D ───────────────────────────────────────────

    def _gen_interaction_2d(self, col_results: list,
                             diag_data: dict, params: dict):
        """Genera el diagrama P vs Mr_resultante y retorna un BytesIO con la imagen.

        Algoritmo de envolvente:
          1. Recolecta todos los puntos (P, Mr) de todas las curvas factoradas.
          2. Construye una grilla de P y para cada nivel calcula el Mr maximo
             mediante interpolacion de ventana deslizante — evita huecos en bins.
          3. Suaviza la envolvente final para una curva limpia.
        """
        try:
            code    = params.get("code", "ACI")
            phi_lbl = "phi" if code == "ACI" else "FR"

            fig, ax = plt.subplots(figsize=(8.5, 6.2), dpi=130)
            fig.patch.set_facecolor("#F5F6FA")
            ax.set_facecolor("#FDFEFE")

            # ── Envolvente factorada ───────────────────────────────────────────
            curves_fac = diag_data.get("curves_fac", [])
            plotted_env = False

            if curves_fac:
                all_P  = []
                all_Mr = []
                for curve in curves_fac:
                    if len(curve) < 2:
                        continue
                    P_c  = curve[:, 0]
                    Mr_c = np.sqrt(curve[:, 1]**2 + curve[:, 2]**2)
                    all_P.extend(P_c.tolist())
                    all_Mr.extend(Mr_c.tolist())

                if len(all_P) > 4:
                    all_P  = np.array(all_P)
                    all_Mr = np.array(all_Mr)

                    # ── Envolvente robusta: grilla con ventana deslizante ──────
                    P_min, P_max = all_P.min(), all_P.max()
                    n_grid  = 250
                    P_grid  = np.linspace(P_min, P_max, n_grid)
                    Mr_env  = np.zeros(n_grid)
                    half_w  = (P_max - P_min) / 60.0   # ventana adaptativa

                    for i, p in enumerate(P_grid):
                        mask = np.abs(all_P - p) <= half_w
                        if mask.sum() > 0:
                            Mr_env[i] = all_Mr[mask].max()
                        else:
                            # vecino mas cercano
                            closest = int(np.argmin(np.abs(all_P - p)))
                            Mr_env[i] = all_Mr[closest]

                    # Suavizado ligero (media movil de 5 puntos)
                    kernel   = np.ones(5) / 5
                    Mr_smooth = np.convolve(Mr_env, kernel, mode="same")
                    # Preservar extremos sin suavizar
                    Mr_smooth[:3]  = Mr_env[:3]
                    Mr_smooth[-3:] = Mr_env[-3:]

                    ax.plot(Mr_smooth, P_grid, color="#2E86C1", linewidth=2.4,
                            label=f"Envolvente {phi_lbl}·(Pn, Mn)", zorder=3)
                    ax.fill_betweenx(P_grid, 0, Mr_smooth,
                                     alpha=0.10, color="#2E86C1", zorder=2)
                    plotted_env = True

            if not plotted_env:
                ax.plot([0, 0], [0, 0], color="#2E86C1", linewidth=2,
                        label=f"Envolvente {phi_lbl}·(Pn,Mn) [no disponible]")

            # ── Puntos de demanda ─────────────────────────────────────────────
            pts_ok   = []
            pts_fail = []
            lbl_ok   = []
            lbl_fail = []

            for r in col_results:
                Mr_d = math.sqrt(r.Muy**2 + r.Muz**2)
                lbl  = f"C{r.comb_id}-{r.node[0].upper()}"
                if r.cumple:
                    pts_ok.append((Mr_d, r.Pr));  lbl_ok.append(lbl)
                else:
                    pts_fail.append((Mr_d, r.Pr)); lbl_fail.append(lbl)

            # Combinacion gobernante (maxima cuantia)
            r_crit  = max(col_results, key=lambda r: r.As_total)
            Mr_crit = math.sqrt(r_crit.Muy**2 + r_crit.Muz**2)

            # Dibujar puntos OK
            for (x, y), lbl in zip(pts_ok, lbl_ok):
                ax.scatter(x, y, color="#27AE60", s=50, zorder=6,
                           edgecolors="white", linewidths=0.4)
                ax.annotate(lbl, (x, y), textcoords="offset points",
                            xytext=(4, 3), fontsize=6, color="#145A32")

            # Dibujar puntos FAIL
            for (x, y), lbl in zip(pts_fail, lbl_fail):
                ax.scatter(x, y, color="#E74C3C", s=50, zorder=6,
                           edgecolors="white", linewidths=0.4)
                ax.annotate(lbl, (x, y), textcoords="offset points",
                            xytext=(4, 3), fontsize=6, color="#922B21")

            # Estrella gobernante
            ax.scatter(Mr_crit, r_crit.Pr, color="#F39C12", s=130, zorder=7,
                       marker="*", edgecolors="#784212", linewidths=0.8,
                       label=f"Gobernante: C{r_crit.comb_id}-{r_crit.node[0].upper()}")

            # Leyenda
            patch_ok   = mpatches.Patch(color="#27AE60", label="Dentro — cumple")
            patch_fail = mpatches.Patch(color="#E74C3C", label="Fuera — no cumple")
            handles, lbls = ax.get_legend_handles_labels()
            ax.legend(handles=handles + [patch_ok, patch_fail],
                      fontsize=7.5, loc="upper right", framealpha=0.85)

            fc_v  = params.get("fc", 0)
            fy_v  = params.get("fy", 0)
            norm_v = "ACI 318-25" if code == "ACI" else "NTC 2023"
            ax.set_xlabel("Mr resultante = sqrt(Muy² + Muz²)  [ton·m]",
                          fontsize=9, labelpad=5)
            ax.set_ylabel("Pr  [ton]", fontsize=9, labelpad=5)
            ax.set_title(
                f"Diagrama de interaccion P – Mr  |  {norm_v}  "
                f"|  f'c={fc_v} kg/cm²  fy={fy_v} kg/cm²",
                fontsize=9, fontweight="bold", color="#1B4F72")
            ax.grid(True, alpha=0.3, linestyle="--")
            ax.axhline(0, color="#7F8C8D", linewidth=0.6)
            ax.axvline(0, color="#7F8C8D", linewidth=0.6)
            ax.set_xlim(left=0)

            plt.tight_layout()
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=140, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
            buf.seek(0)
            plt.close(fig)
            return buf
        except Exception as exc:
            import traceback
            traceback.print_exc()
            return None

    # ── Sección: factor de longitud efectiva K ───────────────────────────────

    def _section_k_factor(self, k_res, params: dict):
        """Memoria detallada del cálculo del factor K por columna."""
        code = params.get("code", "ACI")
        if code == "NTC":
            ref_k = "NTC DEC 2023 §3.3.5.1.3"
        else:
            ref_k = "ACI 318-25 §6.2.5 / R6.2.5"

        metodo = ("Fórmula analítica NTC DEC 2023 §3.3.5.1.3"
                  if getattr(k_res, "method", "nomogram") == "ntc"
                  else "Nomograma de alineación (Jackson-Moreland)")
        braced = getattr(k_res, "braced", True)
        tipo_marco = ("Arriostrado (non-sway), sin traslación lateral"
                      if braced else "No arriostrado (sway), con traslación lateral")

        self._add_para(f"Referencia normativa: {ref_k}", bold=True)
        self._add_para(f"Método: {metodo}")
        self._add_para(f"Tipo de marco: {tipo_marco}")
        self.doc.add_paragraph()

        # Propiedades de la columna
        Lc  = getattr(k_res, "Lc_m",   0.0)
        Icy = getattr(k_res, "Ic_y_m4", 0.0)
        Icz = getattr(k_res, "Ic_z_m4", 0.0)

        tbl_prop = self.doc.add_table(rows=4, cols=2)
        tbl_prop.style = "Table Grid"
        data_prop = [
            ("Longitud libre Lc",           f"{Lc:.4f} m"),
            ("Inercia columna Iy (→ Muy)",  f"{Icy:.8f} m⁴"),
            ("Inercia columna Iz (→ Muz)",  f"{Icz:.8f} m⁴"),
            ("Norma de cálculo",            ref_k),
        ]
        for i, (lbl, val) in enumerate(data_prop):
            _bold_cell(tbl_prop.rows[i].cells[0], lbl, size=8, color_hex="#FFFFFF")
            _set_cell_bg(tbl_prop.rows[i].cells[0], self.SUB_BG)
            _data_cell(tbl_prop.rows[i].cells[1], val, size=8, align=WD_ALIGN_PARAGRAPH.LEFT)
        self.doc.add_paragraph()

        # Nodos A y B
        for lbl_nodo, beams, psi_val, G_val in [
            ("Nodo A — Inferior (inicio de barra)",
             getattr(k_res, "beams_A", []),
             getattr(k_res, "psi_A",   0.0),
             getattr(k_res, "GA",      0.0)),
            ("Nodo B — Superior (fin de barra)",
             getattr(k_res, "beams_B", []),
             getattr(k_res, "psi_B",   0.0),
             getattr(k_res, "GB",      0.0)),
        ]:
            self._add_para(lbl_nodo, bold=True, size=9)
            if beams:
                n_cols = 5
                tbl_beams = self.doc.add_table(rows=1 + len(beams), cols=n_cols)
                tbl_beams.style = "Table Grid"
                hdrs = ["Barra", "L (m)", "Iy (m⁴)", "Iz (m⁴)", "I/L (m³)"]
                for c, h in enumerate(hdrs):
                    _bold_cell(tbl_beams.rows[0].cells[c], h, size=7)
                    _set_cell_bg(tbl_beams.rows[0].cells[c], self.HEADER_BG)
                for i, b in enumerate(beams, 1):
                    bid = b.get("beam_id", "?")
                    Lv  = b.get("L_m",    0.0)
                    Iy  = b.get("Iy_m4",  b.get("I_m4", 0.0))
                    Iz  = b.get("Iz_m4",  b.get("I_m4", 0.0))
                    IL  = (Iy + Iz) / 2.0 / max(Lv, 0.01)
                    row = tbl_beams.rows[i]
                    for c, v in enumerate([
                            str(bid), f"{Lv:.4f}", f"{Iy:.8f}",
                            f"{Iz:.8f}", f"{IL:.8f}"]):
                        _data_cell(row.cells[c], v, size=7)
            else:
                self._add_para("  Sin trabes detectadas → apoyo articulado asumido (ψ = 10)", size=8)

            self._add_para(
                f"  ψ = Σ(I/L)_col / Σ(I/L)_vigas = {psi_val:.4f}   "
                f"G = {G_val:.4f}", size=8)
            self.doc.add_paragraph()

        # Fórmulas de cálculo
        self._add_para("Cálculo del factor K:", bold=True, size=9)
        method = getattr(k_res, "method", "nomogram")
        if method == "ntc" and braced:
            psi_A = getattr(k_res, "psi_A", 0.0)
            psi_B = getattr(k_res, "psi_B", 0.0)
            kA    = getattr(k_res, "kA_ntc", 0.0)
            kB    = getattr(k_res, "kB_ntc", 0.0)
            disc  = getattr(k_res, "disc",   0.0)
            Ky    = getattr(k_res, "Ky",     1.0)
            Kz    = getattr(k_res, "Kz",     1.0)
            formulas = [
                f"k_A = (0.4 + ψ_A) / (0.8 + ψ_A) = "
                f"(0.4 + {psi_A:.4f}) / (0.8 + {psi_A:.4f}) = {kA:.4f}",
                f"k_B = (0.4 + ψ_B) / (0.8 + ψ_B) = "
                f"(0.4 + {psi_B:.4f}) / (0.8 + {psi_B:.4f}) = {kB:.4f}",
                "k = 1.35 − √[1.35·(1.35 − k_A − k_B) + ½·(k_A² + k_B²)]",
                f"k = 1.35 − √[1.35·(1.35 − {kA:.4f} − {kB:.4f})"
                f" + 0.5·({kA:.4f}² + {kB:.4f}²)]",
                f"Discriminante bajo la raíz = {disc:.6f}",
                f"► Ky = {Ky:.4f}   Kz = {Kz:.4f}",
            ]
        else:
            GA = getattr(k_res, "GA", 0.0)
            GB = getattr(k_res, "GB", 0.0)
            Ky = getattr(k_res, "Ky", 1.0)
            Kz = getattr(k_res, "Kz", 1.0)
            formulas = [
                f"Nomograma {'arriostrado' if braced else 'no arriostrado'} (Jackson-Moreland)",
                f"GA = {GA:.4f}   GB = {GB:.4f}",
                f"► Ky = {Ky:.4f}   Kz = {Kz:.4f}",
            ]
        for f_text in formulas:
            p_f = self.doc.add_paragraph(style="List Bullet")
            p_f.add_run(f_text).font.size = Pt(8)

        # Resultado final en recuadro
        self.doc.add_paragraph()
        tbl_res = self.doc.add_table(rows=2, cols=2)
        tbl_res.style = "Table Grid"
        _bold_cell(tbl_res.rows[0].cells[0], "Factor Ky (dir. Y)", size=9)
        _set_cell_bg(tbl_res.rows[0].cells[0], self.HEADER_BG)
        _bold_cell(tbl_res.rows[0].cells[1], "Factor Kz (dir. Z)", size=9)
        _set_cell_bg(tbl_res.rows[0].cells[1], self.HEADER_BG)
        _data_cell(tbl_res.rows[1].cells[0],
                   f"{getattr(k_res,'Ky',1.0):.4f}", size=12, bold=True)
        _data_cell(tbl_res.rows[1].cells[1],
                   f"{getattr(k_res,'Kz',1.0):.4f}", size=12, bold=True)

        warn = getattr(k_res, "warning", "")
        if warn:
            p_w = self._add_para(f"Advertencia: {warn}", size=8)
            p_w.runs[0].font.color.rgb = _rgb("#922B21")

        self.doc.add_paragraph()

    # ── Sección: efectos de 2° orden ─────────────────────────────────────────

    def _section_segundo_orden(self, r, params: dict):
        """Memoria completa de amplificacion de momentos por efectos de 2° orden."""
        so = r.second_order
        if so is None:
            self._add_para("No se calculo amplificacion de 2° orden.", size=9)
            return

        code = params.get("code", "ACI")
        if code == "ACI":
            ref_esb  = "ACI 318-25 §6.6.4.5.1"
            ref_EI   = "ACI 318-25 §6.6.4.4.4a"
            ref_Pc   = "ACI 318-25 §6.6.4.4.2"
            ref_Cm   = "ACI 318-25 §6.6.4.5.3"
            ref_delta = "ACI 318-25 §6.6.4.5.2"
        else:
            ref_esb  = "NTC 2023 §3.5.2.1"
            ref_EI   = "NTC 2023 ec. 3.3.5.2.4"
            ref_Pc   = "NTC 2023 §3.3.5.2.4"
            ref_Cm   = "NTC 2023 §3.3.5.2.4"
            ref_delta = "NTC 2023 §3.3.5.2.4"

        tipo_marco = "Arriostrado (sin traslacion)" if so.arriostra else "No arriostrado (con traslacion)"
        self._add_para(
            f"Combinacion gobernante: {r.comb_id}  |  Nodo: {r.node.upper()}  "
            f"|  Marco: {tipo_marco}", bold=True)

        if so.advertencia:
            self._add_para(f"ADVERTENCIA: {so.advertencia}", bold=True, size=9)

        # a) Parametros de entrada
        self.doc.add_heading("a) Parametros de esbeltez", level=3)
        ky_val = getattr(so, "ky", so.k)
        kz_val = getattr(so, "kz", so.k)
        self._calc_table([
            ("Tipo de marco",                           tipo_marco),
            ("Lu — Longitud no soportada",              f"{so.Lu_cm:.1f} cm = {so.Lu_cm/100:.2f} m"),
            ("Ky — Factor longitud efectiva dir-Y",     f"{ky_val:.4f}"),
            ("Kz — Factor longitud efectiva dir-Z",     f"{kz_val:.4f}"),
            ("Ky·Lu (longitud efectiva dir-Y)",         f"{ky_val*so.Lu_cm:.2f} cm"),
            ("Kz·Lu (longitud efectiva dir-Z)",         f"{kz_val*so.Lu_cm:.2f} cm"),
            ("beta_dns — CM fac./Ctotal fac.",          f"{so.beta_dns:.2f}"),
            ("r_y — Radio de giro dir-Y",               f"{so.r_y:.3f} cm"),
            ("r_z — Radio de giro dir-Z",               f"{so.r_z:.3f} cm"),
            ("Ky·Lu/r_y  — Esbeltez dir-Y",            f"{so.kLu_r_y:.2f}"),
            ("Kz·Lu/r_z  — Esbeltez dir-Z",            f"{so.kLu_r_z:.2f}"),
        ])

        if so.arriostra:
            # b) Verificacion de esbeltez
            self.doc.add_heading("b) Verificacion: ¿puede ignorarse la esbeltez?", level=3)
            self._add_para(
                f"Condicion NTC/ACI: k·Lu/r < 34 - 12·(M1/M2)  [{ref_esb}]\n"
                f"  Si se cumple la condicion → esbeltez ignorable (delta = 1.0).", size=8)
            self._calc_table([
                ("Limite esbeltez dir-Y = 34 - 12*(M1/M2)",
                 f"{so.lim_esbeltez_y:.2f}"),
                ("k·Lu/r_y vs limite",
                 f"{so.kLu_r_y:.2f} {'< IGNORABLE' if so.ignora_esb_y else '>= REQUIERE amplificacion'}"),
                ("Limite esbeltez dir-Z = 34 - 12*(M1/M2)",
                 f"{so.lim_esbeltez_z:.2f}"),
                ("k·Lu/r_z vs limite",
                 f"{so.kLu_r_z:.2f} {'< IGNORABLE' if so.ignora_esb_z else '>= REQUIERE amplificacion'}"),
            ])

            # c) EI efectivo
            self.doc.add_heading("c) Rigidez efectiva (EI)ef  " + f"[{ref_EI}]", level=3)
            self._add_para(
                "(EI)ef = 0.4 * Ec * Ig / (1 + beta_dns)   [formula conservadora]",
                size=8, mono=True)
            self._calc_table([
                ("Ec — Modulo elasticidad concreto",
                 f"{so.Ec:,.0f} kg/cm²"),
                ("(EI)ef dir-Y = 0.4*Ec*Ig_y/(1+beta_dns)",
                 f"0.4 * {so.Ec:,.0f} * Ig_y / (1+{so.beta_dns:.2f}) = {so.EI_ef_y:,.0f} kg·cm²"),
                ("(EI)ef dir-Z = 0.4*Ec*Ig_z/(1+beta_dns)",
                 f"0.4 * {so.Ec:,.0f} * Ig_z / (1+{so.beta_dns:.2f}) = {so.EI_ef_z:,.0f} kg·cm²"),
            ])

            # d) Carga critica Pc
            self.doc.add_heading(f"d) Carga critica de Euler Pc  [{ref_Pc}]", level=3)
            self._add_para(
                "Pc = pi² * (EI)ef / (k*Lu)²", size=8, mono=True)
            kLu = so.k * so.Lu_cm
            self._calc_table([
                ("k*Lu", f"{kLu:.2f} cm"),
                ("(k*Lu)²", f"{kLu**2:,.1f} cm²"),
                ("Pc_y = pi²*(EI)ef_y/(k*Lu)²",
                 f"pi²*{so.EI_ef_y:,.0f}/{kLu**2:,.1f} = {so.Pc_y:,.0f} kg = {so.Pc_y/1000:.2f} ton"),
                ("Pc_z = pi²*(EI)ef_z/(k*Lu)²",
                 f"pi²*{so.EI_ef_z:,.0f}/{kLu**2:,.1f} = {so.Pc_z:,.0f} kg = {so.Pc_z/1000:.2f} ton"),
                ("Pu de diseño (compresion positiva)",
                 f"{abs(r.Pu)*1000:.0f} kg = {abs(r.Pu):.3f} ton"),
                ("Verificacion: Pu < 0.75*Pc_y",
                 f"{abs(r.Pu)*1000:.0f} {'< OK' if abs(r.Pu)*1000 < 0.75*so.Pc_y else '>= INESTABLE'} "
                 f"(0.75*Pc_y = {0.75*so.Pc_y/1000:.2f} ton)"),
                ("Verificacion: Pu < 0.75*Pc_z",
                 f"{abs(r.Pu)*1000:.0f} {'< OK' if abs(r.Pu)*1000 < 0.75*so.Pc_z else '>= INESTABLE'} "
                 f"(0.75*Pc_z = {0.75*so.Pc_z/1000:.2f} ton)"),
            ])

            # e) Factor Cm y delta
            self.doc.add_heading(f"e) Factor Cm y amplificacion delta  [{ref_Cm}]", level=3)
            self._add_para(
                "Cm = 0.6 + 0.4*(M1/M2) >= 0.4\n"
                "delta = Cm / (1 - Pu/(0.75*Pc)) >= 1.0  [{ref_delta}]".format(
                    ref_delta=ref_delta),
                size=8, mono=True)
            denom_y = 1.0 - abs(r.Pu)*1000/(0.75*so.Pc_y) if so.Pc_y > 0 else 0
            denom_z = 1.0 - abs(r.Pu)*1000/(0.75*so.Pc_z) if so.Pc_z > 0 else 0
            self._calc_table([
                ("Cm_y  (estimacion M1=0.5*M2 → ratio=0.5)",
                 f"max(0.40, 0.6+0.4*0.5) = {so.Cm_y:.3f}"),
                ("Cm_z",
                 f"{so.Cm_z:.3f}"),
                ("1 - Pu/(0.75*Pc_y)",
                 f"1 - {abs(r.Pu)*1000:.0f}/(0.75*{so.Pc_y:.0f}) = {denom_y:.4f}"),
                ("1 - Pu/(0.75*Pc_z)",
                 f"1 - {abs(r.Pu)*1000:.0f}/(0.75*{so.Pc_z:.0f}) = {denom_z:.4f}"),
                ("delta_y = max(1.0, Cm_y/denom_y)",
                 f"max(1.0, {so.Cm_y:.3f}/{denom_y:.4f}) = {so.delta_y:.4f}"),
                ("delta_z = max(1.0, Cm_z/denom_z)",
                 f"max(1.0, {so.Cm_z:.3f}/{denom_z:.4f}) = {so.delta_z:.4f}"),
            ])
        else:
            # Marco no arriostrado
            self.doc.add_heading("b) Amplificacion lateral — marco no arriostrado", level=3)
            self._add_para(
                "Para marcos no arriostrados se aplica el factor delta_s al momento total.\n"
                "delta_s = 1/(1-lambda_est) >= 1.0  [NTC §3.3.5.2.5 / ACI §6.6.4.6]\n"
                "Como STAAD entrega momentos combinados (no separados en traslatorio/"
                "no-traslatorio), se usa: Mc = delta_s * M_total (conservador).",
                size=8)
            self._calc_table([
                ("delta_s (amplificador de piso — ingresado por el usuario)",
                 f"{so.delta_s:.3f}"),
                ("Limite esbeltez no arriostrado (k·Lu/r < 22)",
                 f"dir-Y: {so.kLu_r_y:.2f} {'< OK' if so.ignora_esb_y else '>= ampl. requerida'} | "
                 f"dir-Z: {so.kLu_r_z:.2f} {'< OK' if so.ignora_esb_z else '>= ampl. requerida'}"),
            ])

        # f) Momentos amplificados
        self.doc.add_heading("f) Momentos de diseño amplificados", level=3)
        self._add_para(
            "Se aplica el factor delta solo en las direcciones donde la esbeltez "
            "NO es ignorable. Si la esbeltez es ignorable, delta = 1.0.", size=8)
        d_y = so.delta_y if (not so.ignora_esb_y and so.arriostra) or not so.arriostra else 1.0
        d_z = so.delta_z if (not so.ignora_esb_z and so.arriostra) or not so.arriostra else 1.0
        self._calc_table([
            ("Muy original (del analisis)",
             f"{so.Muy_orig:+.4f} ton·m"),
            ("Muz original (del analisis)",
             f"{so.Muz_orig:+.4f} ton·m"),
            ("delta efectivo dir-Y",
             f"{d_y:.4f} {'(esbeltez ignorable — no amplifica)' if d_y <= 1.0001 else ''}"),
            ("delta efectivo dir-Z",
             f"{d_z:.4f} {'(esbeltez ignorable — no amplifica)' if d_z <= 1.0001 else ''}"),
            ("Muy amplificado = delta_y * Muy_orig",
             f"{d_y:.4f} x {so.Muy_orig:+.4f} = {so.Muy_amp:+.4f} ton·m"),
            ("Muz amplificado = delta_z * Muz_orig",
             f"{d_z:.4f} x {so.Muz_orig:+.4f} = {so.Muz_amp:+.4f} ton·m"),
            ("Estado de la amplificacion",
             "SE AMPLIFICO — momentos de diseño aumentados" if so.aplica
             else "NO SE AMPLIFICO — esbeltez ignorable en ambas direcciones (delta=1.0)"),
        ])

    # ── Sección: flexocompresión detallada ────────────────────────────────────

    def _section_flexo_critica(self, r, params: dict):
        fc = params["fc"]; fy = params["fy"]
        rec1 = params["rec1"]; rec2 = params["rec2"]
        code = params.get("code", "ACI")
        col_type = params.get("col_type", "tied")

        fc1  = 0.85 * fc
        # beta1 segun codigo correcto
        if code == "ACI":
            B1 = 0.85 if fc <= 280 else max(0.65, 0.85 - 0.05*(fc-280)/70)
            ref_b1  = "ACI 318-25 Tabla 22.2.2.4.3"
            ref_ecu = "ACI 318-25 §22.2.2.1"
            ref_phi = "ACI 318-25 Tabla 21.2.2"
            phi_lbl = "phi"
        else:
            B1 = 0.85 if fc <= 300 else max(0.65, 1.05 - fc/1400.0)
            ref_b1  = "NTC 2023 §3.6.1"
            ref_ecu = "NTC 2023 §3.6.1"
            ref_phi = "NTC 2023 Tabla 3.8.2.2"
            phi_lbl = "FR"

        eps_y = fy / _Es
        phi_c = 0.65 if col_type == "tied" else 0.75
        phi_t = 0.90

        # Zona de transicion (diferente por codigo)
        if code == "ACI":
            trans_width = 0.005 - eps_y
            trans_desc  = f"eps_y <= |eps_t| <= 0.005 → {phi_lbl} = {phi_c:.2f} + {phi_t-phi_c:.2f}*(|eps_t|-eps_y)/(0.005-eps_y)"
        else:
            trans_width = 0.003
            trans_desc  = (f"eps_cy < eps_t < eps_cy+0.003 → "
                           f"Estribos: {phi_lbl} = 0.65+0.25*(eps_t-eps_cy)/0.003  |  "
                           f"Zunchos: {phi_lbl} = 0.75+0.15*(eps_t-eps_cy)/0.003")

        # a) Identificacion de la combinacion
        self._add_para(
            f"Combinacion: {r.comb_id}  |  Nodo: {r.node.upper()}  "
            f"|  Condicion: {r.condicion}", bold=True)

        pu_design = (-r.Pu if r.node == "ini" else r.Pu)
        Mr_res = math.sqrt(r.Muy**2 + r.Muz**2)
        theta_deg = math.degrees(math.atan2(abs(r.Muz), abs(r.Muy))) if Mr_res > 1e-6 else 0.0
        conv_nota = ("En el nodo inicial (INI) el convenio STAAD indica "
                     "compresion con signo negativo → Pu diseño = -Pu_STAAD"
                     if r.node == "ini" else
                     "En el nodo final (FIN) compresion positiva → Pu diseño = Pu_STAAD")

        self.doc.add_heading("a) Demandas de diseño", level=3)
        self._add_para(conv_nota, size=8)
        self._calc_table([
            ("Pu (STAAD)",                          f"{r.Pu:+.3f} ton"),
            ("Pu diseño (compresion positiva)",     f"{pu_design:+.3f} ton"),
            ("Muy",                                 f"{r.Muy:+.3f} ton·m"),
            ("Muz",                                 f"{r.Muz:+.3f} ton·m"),
            ("Mr = sqrt(Muy² + Muz²)",
             f"sqrt({r.Muy:.3f}² + {r.Muz:.3f}²) = {Mr_res:.3f} ton·m"),
            ("theta = atan2(|Muy|, |Muz|)",
             f"atan2({abs(r.Muy):.3f}, {abs(r.Muz):.3f}) = {theta_deg:.2f}°"),
            ("Vuy",                                 f"{r.Vuy:+.3f} ton"),
            ("Vuz",                                 f"{r.Vuz:+.3f} ton"),
        ])

        # Verificacion excentricidad minima
        self.doc.add_heading("a.1) Excentricidad minima (NTC §5.3.2 / ACI §22.4.2.4)", level=3)
        h_sec = r.Hc   # dimension de seccion en la direccion de flexion dominante
        e_min_cm = max(0.05 * h_sec, 2.0)  # 2 cm = 20 mm
        Mr_min = abs(pu_design) * e_min_cm / 100_000.0  # ton·m
        self._calc_table([
            ("h (dimension de seccion en flexion dominante)",
             f"{h_sec:.1f} cm"),
            ("e_min = max(0.05h, 2.0 cm)  [NTC §5.3.2]",
             f"max(0.05 x {h_sec:.1f}, 2.0) = max({0.05*h_sec:.2f}, 2.0) = {e_min_cm:.2f} cm"),
            ("M_min = |Pu| * e_min",
             f"|{pu_design:.3f}| x {e_min_cm:.2f}/100000 = {Mr_min:.4f} ton·m"),
            ("Mr de demanda",
             f"{Mr_res:.4f} ton·m"),
            ("Verificacion: Mr >= M_min",
             "OK" if Mr_res >= Mr_min or abs(pu_design) < 1e-3
             else f"GOVERNA excentricidad minima: M_min = {Mr_min:.4f} ton·m"),
        ])

        # b) Parametros de material
        self.doc.add_heading("b) Parametros de material y factores de codigo", level=3)
        self._calc_table([
            ("f'c",                     f"{fc:.0f} kg/cm²"),
            ("f''c = 0.85 x f'c  [§3.6.1 NTC / §22.2.2.4 ACI]",
             f"0.85 x {fc:.0f} = {fc1:.1f} kg/cm²"),
            (f"beta1  [{ref_b1}]",
             f"{B1:.3f}  (f'c {'<=' if (code=='ACI' and fc<=280) or (code=='NTC' and fc<=300) else '>'} "
             f"{'280' if code=='ACI' else '300'} kg/cm²)"),
            ("fy",                      f"{fy:.0f} kg/cm²"),
            ("Es",                      "2 039 000 kg/cm²"),
            (f"ecu  [{ref_ecu}]",       "0.003"),
            ("eps_y = fy / Es",
             f"{fy:.0f} / 2 039 000 = {eps_y:.5f}"),
            (f"{phi_lbl} compresion ({col_type})  [{ref_phi}]",
             f"{phi_c:.2f}"),
            (f"{phi_lbl} tension  [{ref_phi}]",
             f"{phi_t:.2f}"),
            (f"Zona de transicion  [{ref_phi}]",
             trans_desc),
            (f"{phi_lbl} utilizado (segun eps_max de la iteracion convergida)",
             f"{r.phi:.3f}"),
        ])

        # c) Propiedades de la seccion
        self.doc.add_heading("c) Propiedades de la seccion y disposicion del acero", level=3)
        Bc = r.Bc; Hc = r.Hc; Ag = Bc * Hc
        numfilz = max(2, int(Bc / 10.0))
        numfily = max(2, int(Hc / 10.0))
        numvar  = (numfilz * 2 + numfily * 2) - 4
        sepz = (Bc - 2*rec1) / max(numfilz - 1, 1)
        sepy = (Hc - 2*rec2) / max(numfily - 1, 1)
        Asvar = r.As_total / max(numvar, 1)

        self._calc_table([
            ("Bc (base, direccion Z)",    f"{Bc:.1f} cm"),
            ("Hc (altura, direccion Y)",  f"{Hc:.1f} cm"),
            ("Ag = Bc x Hc",              f"{Bc:.1f} x {Hc:.1f} = {Ag:.1f} cm²"),
            ("rho diseño",                f"{r.p_diseno*100:.3f} %"),
            ("As = rho x Ag",
             f"{r.p_diseno*100:.3f}% x {Ag:.1f} = {r.As_total:.2f} cm²"),
            ("rec1 (direccion Z)",         f"{rec1:.1f} cm"),
            ("rec2 (direccion Y)",         f"{rec2:.1f} cm"),
            ("Numero de varillas (n)",
             f"{numvar}  ({numfilz} en base + {numfily} en altura - 4 esquinas)"),
            ("Separacion sepz (dir-Z)",
             f"(Bc - 2*rec1) / (numfilz-1) = ({Bc:.1f} - {2*rec1:.1f}) / {numfilz-1} = {sepz:.2f} cm"),
            ("Separacion sepy (dir-Y)",
             f"(Hc - 2*rec2) / (numfily-1) = ({Hc:.1f} - {2*rec2:.1f}) / {numfily-1} = {sepy:.2f} cm"),
            ("Asvar = As / n",
             f"{r.As_total:.2f} / {numvar} = {Asvar:.4f} cm² por varilla"),
        ])

        # d) Geometria del eje neutro inclinado
        self.doc.add_heading("d) Geometria del eje neutro inclinado", level=3)
        ang1_deg = r.ang1
        ang1_rad = math.radians(ang1_deg)
        tan_ang  = math.tan(ang1_rad) if abs(math.cos(ang1_rad)) > 1e-6 else 1e9
        if abs(tan_ang) < 1e-9:
            tan_ang = 1e-9
        h1 = Bc * tan_ang
        h2 = Bc * 0.5 * tan_ang
        h3 = Hc + h1
        Hb = Bc * math.sin(ang1_rad) + Hc * math.cos(ang1_rad)

        self._calc_table([
            ("theta = atan2(|Muy|, |Muz|) — angulo del eje neutro",
             f"{ang1_deg:.3f}°"),
            ("tan(theta)",
             f"tan({ang1_deg:.3f}°) = {tan_ang:.4f}"),
            ("h1 = Bc * tan(theta)",
             f"{Bc:.1f} x {tan_ang:.4f} = {h1:.3f} cm"),
            ("h2 = Bc * 0.5 * tan(theta)",
             f"{Bc:.1f} x 0.5 x {tan_ang:.4f} = {h2:.3f} cm"),
            ("h3 = Hc + h1",
             f"{Hc:.1f} + {h1:.3f} = {h3:.3f} cm"),
            ("Hb = Bc*sin(theta) + Hc*cos(theta)",
             f"{Bc:.1f}*sin({ang1_deg:.1f}°) + {Hc:.1f}*cos({ang1_deg:.1f}°) "
             f"= {Bc*math.sin(ang1_rad):.3f} + {Hc*math.cos(ang1_rad):.3f} = {Hb:.3f} cm"),
            ("Excentricidad de la demanda (eres)",
             f"{r.eres:.3f} cm"),
            ("Excentricidad balanceada (eb)",
             f"{r.eb:.3f} cm"),
            ("Tipo de falla",
             r.tipo_falla),
        ])

        # e) Convergencia del eje neutro
        self.doc.add_heading("e) Profundidad del eje neutro — Convergencia", level=3)
        dist_ini  = r.dist_ini
        dist_ini1 = dist_ini * math.cos(ang1_rad)
        h4 = Hc + h1 - dist_ini
        b4 = h4 / tan_ang if abs(tan_ang) > 1e-9 else Bc * 1e6

        self._add_para(
            "El motor itera la profundidad d_n del eje neutro hasta que la "
            "excentricidad de capacidad (er = Mr/Pr) converge a la excentricidad "
            "de demanda (eres). Se registra el valor que satisface la convergencia.", size=8)
        self._calc_table([
            ("d_n — profundidad del eje neutro (convergida)",
             f"{dist_ini:.3f} cm"),
            ("d_n1 = d_n * cos(theta)",
             f"{dist_ini:.3f} x cos({ang1_deg:.1f}°) = {dist_ini1:.3f} cm"),
            ("h4 = h3 - d_n",
             f"{h3:.3f} - {dist_ini:.3f} = {h4:.3f} cm"),
            ("b4 = h4 / tan(theta)",
             f"{h4:.3f} / {tan_ang:.4f} = {b4:.3f} cm"),
        ])

        # f) Bloque de compresion
        self.doc.add_heading("f) Bloque de compresion equivalente", level=3)
        self._add_para(
            f"Cc = f''c * beta1 * A_comp   [{ref_b1.replace('Tabla 22.2.2.4.3','§22.2.2.4')}]", size=8, mono=True)
        coord_y_cent = Hc * 0.5 + h2
        area, xcen, ycen = self._compute_comp_block(
            dist_ini, h3, h4, b4, Hc, Bc, tan_ang, h1)
        caso = self._comp_block_case(h4, b4, Hc, Bc, tan_ang, dist_ini, h3)

        caso_desc = {
            1: "Caso 1: Seccion rectangular completa en compresion",
            3: "Caso 3: Trapecio grande (h4 >= Hc) — zona de compresion cubre toda la altura",
            5: "Caso 5: Trapecio pequeno (b4 > Bc, h4 < Hc)",
            7: "Caso 7: Triangulo en la esquina comprimida (b4 <= Bc, h4 < Hc)",
        }.get(caso, f"Caso {caso}")

        dx = xcen; dy = coord_y_cent - ycen
        hyp = math.sqrt(dx**2 + dy**2)
        if hyp > 1e-9:
            a1 = 90.0 - math.degrees(math.atan2(dy, dx))
            a2 = abs(a1 + ang1_deg)
            dist_cen = hyp * math.cos(math.radians(a2))
        else:
            dist_cen = 0.0
        Cc_kg   = fc1 * area * B1
        Mc_kgcm = Cc_kg * dist_cen

        self._add_para(caso_desc, bold=True, size=9)
        self._calc_table([
            ("Area del bloque comprimido (A_comp)",
             f"{area:.3f} cm²"),
            ("Centroide xcen (local, dir-Z)",
             f"{xcen:.3f} cm"),
            ("Centroide ycen (local, dir-Y)",
             f"{ycen:.3f} cm"),
            ("Distancia centroide → referencia (dist_c)",
             f"{dist_cen:.3f} cm"),
            ("Cc = f''c * beta1 * A_comp",
             f"{fc1:.2f} x {B1:.3f} x {area:.3f} = {Cc_kg:.1f} kg  "
             f"({Cc_kg/1000:.3f} ton)"),
            ("Mc = Cc * dist_c",
             f"{Cc_kg:.1f} x {dist_cen:.3f} = {Mc_kgcm:.1f} kg·cm  "
             f"({Mc_kgcm/100_000:.4f} ton·m)"),
        ])

        # g) Deformaciones y fuerzas en varillas
        self.doc.add_heading(
            "g) Deformaciones unitarias y fuerzas en las varillas de refuerzo",
            level=3)
        denom_eps = Hb - dist_ini1
        self._add_para(
            f"Compatibilidad lineal de deformaciones (fibra extrema comprimida: ecu = 0.003):", size=8)
        self._add_para(
            f"    eps_s = ecu * dist_n / (Hb - d_n1)  "
            f"= 0.003 * dist_n / ({Hb:.3f} - {dist_ini1:.3f})  "
            f"= 0.003 * dist_n / {denom_eps:.3f}", size=8, mono=True)
        self._add_para(
            f"Positivo = compresion  |  Negativo = tension  |  "
            f"Fluencia si |eps_s| >= 0.003", size=8)
        self._add_para(
            f"fs = Es*eps_s (si |eps_s| < 0.003)  o  fy = {fy:.0f} kg/cm² (fluencia)  "
            f"| Fs = fs * Asvar = fs * {Asvar:.4f} cm²", size=8)

        ptovar = self._rebar_coords(Bc, Hc, rec1, rec2, numfilz, numfily,
                                     numvar, sepz, sepy)
        rebar_data, Fvartot_kg, Mvartot_kgcm = self._compute_rebar_forces(
            ptovar, numvar, Asvar, h4, ang1_deg, ang1_rad,
            Hb, dist_ini1, coord_y_cent, fy)
        self._rebar_table(rebar_data)

        # h) Resultados de capacidad
        self.doc.add_heading("h) Resultados de capacidad nominal y reducida", level=3)
        Pn_ton = (Cc_kg + Fvartot_kg) / 1000.0
        Mn_ton = (Mc_kgcm + Mvartot_kgcm) / 100_000.0
        phi_used = r.phi
        phi_lbl2 = "phi" if code == "ACI" else "FR"

        self._calc_table([
            ("Sum_Fs = Fvartot (suma de fuerzas en varillas)",
             f"{Fvartot_kg:.1f} kg  ({Fvartot_kg/1000:.3f} ton)"),
            ("Sum_Ms = Mvartot (suma de momentos de varillas)",
             f"{Mvartot_kgcm:.1f} kg·cm  ({Mvartot_kgcm/100_000:.4f} ton·m)"),
            ("Pn = (Cc + Fvartot) / 1000",
             f"({Cc_kg:.1f} + {Fvartot_kg:.1f}) / 1000 = {Pn_ton:.3f} ton"),
            ("Mn = (Mc + Mvartot) / 100 000",
             f"({Mc_kgcm:.1f} + {Mvartot_kgcm:.1f}) / 100 000 = {Mn_ton:.4f} ton·m"),
            (f"{phi_lbl2} utilizado  [{ref_phi}]",
             f"{phi_used:.3f}"),
            (f"Pr = {phi_lbl2} * Pn",
             f"{phi_used:.3f} x {Pn_ton:.3f} = {phi_used*Pn_ton:.3f} ton  "
             f"(reportado: {r.Pr:.3f} ton)"),
            (f"Mr = {phi_lbl2} * Mn",
             f"{phi_used:.3f} x {Mn_ton:.4f} = {phi_used*Mn_ton:.4f} ton·m  "
             f"(reportado: {r.Mr:.4f} ton·m)"),
            ("er = Mr / Pr  (excentricidad de capacidad)",
             f"{r.er:.3f} cm"),
            ("eres = Mr_demanda / Pu  (excentricidad de demanda)",
             f"{r.eres:.3f} cm"),
            ("Verificacion convergencia: er ≈ eres",
             f"|er - eres| = {abs(r.er - r.eres):.3f} cm"),
            ("Condicion final",
             r.condicion),
        ])

        # i) Razon de utilizacion (DR/C)
        self.doc.add_heading("i) Razon demanda/capacidad", level=3)
        ratio_P = abs(pu_design) / abs(r.Pr) if abs(r.Pr) > 1e-6 else 0.0
        ratio_M = Mr_res / abs(r.Mr) if abs(r.Mr) > 1e-6 else 0.0
        ratio_combo = math.sqrt(ratio_P**2 + ratio_M**2) / math.sqrt(2.0)
        self._add_para(
            "La razon de utilizacion indica que fraccion de la capacidad esta siendo "
            "aprovechada. Valor <= 1.0 indica que el elemento cumple.", size=8)
        self._calc_table([
            ("Razon P: |Pu| / Pr",
             f"|{pu_design:.3f}| / {r.Pr:.3f} = {ratio_P:.3f}  "
             f"({'OK' if ratio_P <= 1.0 else 'EXCEDE'})"),
            ("Razon M: Mr_dem / Mr_cap",
             f"{Mr_res:.3f} / {r.Mr:.4f} = {ratio_M:.3f}  "
             f"({'OK' if ratio_M <= 1.0 else 'EXCEDE'})"),
            ("Razon combinada approx.: sqrt(rP²+rM²)/sqrt(2)",
             f"sqrt({ratio_P:.3f}²+{ratio_M:.3f}²)/sqrt(2) = {ratio_combo:.3f}"),
        ])

    # ── Sección: cortante detallado ───────────────────────────────────────────

    def _section_cortante_critico(self, r_vz, r_vy, params: dict):
        fc   = params["fc"]; fy  = params["fy"]
        rec1 = params["rec1"]; rec2 = params["rec2"]
        code = params.get("code", "ACI")
        sqrt_fc = math.sqrt(fc)
        phi_v = 0.75
        lbl_phi = "phi" if code == "ACI" else "FR"

        if code == "ACI":
            coef_vc = 0.53
            k_c = 140.0; k_t = 35.0
            ref_vc  = "ACI 318-25 §22.5.5.1"
            ref_rv  = "ACI 318-25 §9.6.3.3"
            formula_vc = f"Vc = {coef_vc}*(1 + Nu/(k*Ag))*sqrt(f'c)*bw*d  (multiplicativo)"
        else:
            coef_vc = 0.50
            ref_vc  = "NTC 2023 §5.5.3.1.1.a"
            ref_rv  = "NTC 2023 §6.3.5.4.4"
            formula_vc = f"Vc = ({coef_vc}*sqrt(f'c) + Nu/(6*Ag))*bw*d  (aditivo)"

        for lbl, r in [("Direccion Z  — cortante Vuz", r_vz),
                       ("Direccion Y  — cortante Vuy", r_vy)]:
            self._add_para(f"■ {lbl}", bold=True, size=10)
            self._add_para(
                f"Combinacion: {r.comb_id}  |  Nodo: {r.node.upper()}", size=9)

            Bc = r.Bc; Hc = r.Hc; Ag = Bc * Hc
            Nu = (-r.Pu if r.node == "ini" else r.Pu) * 1000.0
            Vu_kg = (abs(r.Vuz) if "Z" in lbl else abs(r.Vuy)) * 1000.0

            if "Z" in lbl:
                bw = Hc; d = Bc - rec1
                vc_rep = r.shear.vc_z * 1000.0
                pv_rep = r.shear.p_z
            else:
                bw = Bc; d = Hc - rec2
                vc_rep = r.shear.vc_y * 1000.0
                pv_rep = r.shear.p_y

            self._add_para(f"Formula aplicada:  {formula_vc}  [{ref_vc}]",
                           size=8, mono=True)

            if code == "ACI":
                k = k_c if Nu >= 0 else k_t
                factor = max(0.0, 1.0 + Nu / (k * Ag))
                Vc1 = coef_vc * sqrt_fc * bw * d
                Vc2 = coef_vc * factor * sqrt_fc * bw * d
                Vc  = min(Vc1, Vc2)
                self._calc_table([
                    ("Vu",
                     f"|{'Vuz' if 'Z' in lbl else 'Vuy'}| = {Vu_kg/1000:.3f} ton = {Vu_kg:.0f} kg"),
                    ("Nu (compresion positiva)",  f"{Nu:.0f} kg"),
                    ("bw",                        f"{bw:.1f} cm"),
                    ("d (peralte efectivo)",
                     f"{'Bc-rec1' if 'Z' in lbl else 'Hc-rec2'} = {d:.1f} cm"),
                    ("Ag",                        f"{Ag:.1f} cm²"),
                    ("sqrt(f'c)",                 f"sqrt({fc:.0f}) = {sqrt_fc:.4f} kg½/cm"),
                    (f"Vc1 = {coef_vc}*sqrt(f'c)*bw*d  [{ref_vc}]",
                     f"{coef_vc}*{sqrt_fc:.4f}*{bw:.1f}*{d:.1f} = {Vc1:.1f} kg  ({Vc1/1000:.3f} ton)"),
                    (f"k = {k:.0f}  ({'compresion' if Nu>=0 else 'tension'})",
                     ""),
                    (f"factor = 1 + Nu/({k:.0f}*Ag)",
                     f"1 + {Nu:.0f}/({k:.0f}*{Ag:.1f}) = {factor:.4f}"),
                    (f"Vc2 = {coef_vc}*factor*sqrt(f'c)*bw*d",
                     f"{coef_vc}*{factor:.4f}*{sqrt_fc:.4f}*{bw:.1f}*{d:.1f} = {Vc2:.1f} kg  ({Vc2/1000:.3f} ton)"),
                    ("Vc = min(Vc1, Vc2)",
                     f"{Vc:.1f} kg  ({Vc/1000:.3f} ton)  [verif.: {vc_rep:.1f} kg]"),
                ])
            else:
                # NTC: formula aditiva con limites
                nu_term = Nu / (6.0 * Ag) if Ag > 1e-9 else 0.0
                nu_term_lim = min(nu_term, 0.05 * fc)
                vc_nom = (coef_vc * sqrt_fc + nu_term_lim) * bw * d
                vc_max = 0.42 * sqrt_fc * bw * d
                vc_min = 0.08 * sqrt_fc * bw * d
                Vc = max(vc_min, min(vc_nom, vc_max))
                self._calc_table([
                    ("Vu",
                     f"|{'Vuz' if 'Z' in lbl else 'Vuy'}| = {Vu_kg/1000:.3f} ton = {Vu_kg:.0f} kg"),
                    ("Nu (compresion positiva, NTC: + compresion)",
                     f"{Nu:.0f} kg"),
                    ("bw",     f"{bw:.1f} cm"),
                    ("d",      f"{d:.1f} cm"),
                    ("Ag",     f"{Ag:.1f} cm²"),
                    ("sqrt(f'c)",  f"sqrt({fc:.0f}) = {sqrt_fc:.4f}"),
                    ("Termino base: 0.50*sqrt(f'c)",
                     f"0.50 * {sqrt_fc:.4f} = {coef_vc*sqrt_fc:.4f} kg/cm²"),
                    ("Termino axial: Nu/(6*Ag)  [NTC §5.5.3.1.1.a]",
                     f"{Nu:.0f} / (6 * {Ag:.1f}) = {nu_term:.4f} kg/cm²"),
                    ("Limite axial: Nu/(6*Ag) <= 0.05*f'c",
                     f"min({nu_term:.4f}, 0.05*{fc:.0f}={0.05*fc:.2f}) = {nu_term_lim:.4f} kg/cm²"),
                    ("Vc_nom = (0.50*sqrt(f'c) + Nu_lim/(6*Ag))*bw*d  [NTC §5.5.3.1.1.a]",
                     f"({coef_vc*sqrt_fc:.4f} + {nu_term_lim:.4f})*{bw:.1f}*{d:.1f} = {vc_nom:.1f} kg"),
                    ("Limite sup: 0.42*sqrt(f'c)*bw*d  [NTC §5.5.3.1.1]",
                     f"0.42*{sqrt_fc:.4f}*{bw:.1f}*{d:.1f} = {vc_max:.1f} kg"),
                    ("Limite inf: 0.08*sqrt(f'c)*bw*d  [NTC §5.5.3.1.1]",
                     f"0.08*{sqrt_fc:.4f}*{bw:.1f}*{d:.1f} = {vc_min:.1f} kg"),
                    ("Vc = max(Vc_min, min(Vc_nom, Vc_max))",
                     f"max({vc_min:.1f}, min({vc_nom:.1f}, {vc_max:.1f})) = {Vc:.1f} kg  ({Vc/1000:.3f} ton)  [verif.: {vc_rep:.1f} kg]"),
                ])

            # Acero transversal
            pv_min1 = 0.2 * sqrt_fc * bw / fy
            pv_min2 = 3.5 * bw / fy
            pv_min  = max(pv_min1, pv_min2)
            pv_req  = (Vu_kg - Vc) / (0.8 * fy * d)
            pv_dis  = max(pv_req, pv_min)

            self._calc_table([
                (f"rv,min1 = 0.2*sqrt(f'c)*bw/fy  [{ref_rv}]",
                 f"0.2*{sqrt_fc:.4f}*{bw:.1f}/{fy:.0f} = {pv_min1:.6f} cm²/cm"),
                ("rv,min2 = 3.5*bw/fy",
                 f"3.5*{bw:.1f}/{fy:.0f} = {pv_min2:.6f} cm²/cm"),
                ("rv,min = max(rv,min1, rv,min2)",
                 f"max({pv_min1:.6f}, {pv_min2:.6f}) = {pv_min:.6f} cm²/cm"),
                ("rv,req = (Vu - Vc) / (0.8*fy*d)",
                 f"({Vu_kg:.1f} - {Vc:.1f}) / (0.8*{fy:.0f}*{d:.1f}) = "
                 f"{pv_req:.6f} cm²/cm"),
                ("rv diseño = max(rv,req, rv,min)",
                 f"max({pv_req:.6f}, {pv_min:.6f}) = {pv_dis:.6f} cm²/cm  "
                 f"[verif.: {pv_rep:.6f}]"),
            ])
            self.doc.add_paragraph()

    # ── Sección: requisitos sísmicos Q=3 / Q=4 ───────────────────────────────

    def _section_seismic(self, sr, r, params: dict):
        """
        Memoria detallada de los requisitos sísmicos.
        sr  : SeismicResult (del DesignResult más desfavorable por flexocompresión)
        r   : DesignResult  (para acceder a dimensiones de sección y Pu)
        """
        Q    = sr.Q
        code = sr.code
        fc   = params.get("fc", 250)
        fy   = params.get("fy", 4200)
        Bc   = r.Bc;  Hc = r.Hc
        Ag   = Bc * Hc if r.col_type == 1 else math.pi * Bc**2 / 4.0

        if code == "NTC":
            if Q == 3:
                cap_ref = "NTC 2023 DEC Cap.7 §7.4 (Ductilidad Media)"
                ref_Ve  = "§7.4.2 / §8.4.6.1.1"
                ref_Lo  = "§7.4.4.2.1"
                ref_s   = "§7.4.4.2.2"
                ref_Vc  = "§7.4.2 referencia §8.4.6"
            else:
                cap_ref = "NTC 2023 DEC Cap.8 §8.4 (Ductilidad Alta)"
                ref_Ve  = "§8.4.6.1.1"
                ref_Lo  = "§8.4.5.1"
                ref_s   = "§8.4.5.3 / Tabla 8.4.5.4"
                ref_Vc  = "§8.4.6"
        else:
            if Q == 3:
                cap_ref = "ACI 318-25 §18.4 (IMF — Marco Intermedio)"
                ref_Ve  = "§18.4.3.1"
                ref_Lo  = "§18.4.3.3"
                ref_s   = "§18.4.3.3"
                ref_Vc  = "§18.4.3.1"
            else:
                cap_ref = "ACI 318-25 §18.7 (SMF — Marco Especial)"
                ref_Ve  = "§18.7.6.1"
                ref_Lo  = "§18.7.5.1"
                ref_s   = "§18.7.5.3"
                ref_Vc  = "§18.7.6.1"

        fy_eff_lbl = "1.25·fy" if Q >= 4 else "fy"
        phi_lbl    = "FR" if code == "NTC" else "phi"

        self._add_para(f"Referencia normativa: {cap_ref}", bold=True, size=9)
        self._add_para(
            f"Combinacion gobernante: {r.comb_id}  |  Nodo: {r.node.upper()}  "
            f"|  As = {r.As_total:.2f} cm²", size=9)
        self.doc.add_paragraph()

        # ── 1. Momento probable Mpr ────────────────────────────────────────────
        self.doc.add_heading("1. Momento Probable (Mpr)", level=3)
        self._add_para(
            f"fy_eff = {fy_eff_lbl} = {sr.fy_eff:.0f} kg/cm²   "
            f"[{ref_Ve}]\n"
            f"Mpr ≈ (fy_eff / fy) × Mn  (escala del momento nominal de diseño)\n"
            f"factor = {sr.fy_eff:.0f} / {fy:.0f} = {sr.fy_eff/fy:.4f}",
            size=8, mono=True)
        self._calc_table([
            ("fy_eff utilizado",
             f"{fy_eff_lbl} = {sr.fy_eff:.0f} kg/cm²"),
            ("Factor Mpr = fy_eff / fy",
             f"{sr.fy_eff:.0f} / {fy:.0f} = {sr.fy_eff/fy:.4f}"),
            ("Mn nodo inicial (del diseño)",
             f"{sr.Mpr_ini / (sr.fy_eff/fy) if sr.fy_eff>fy else sr.Mpr_ini:.4f} ton·m"),
            ("Mpr_ini = factor × Mn_ini",
             f"{sr.Mpr_ini:.4f} ton·m"),
            ("Mn nodo final (del diseño)",
             f"{sr.Mpr_fin / (sr.fy_eff/fy) if sr.fy_eff>fy else sr.Mpr_fin:.4f} ton·m"),
            ("Mpr_fin = factor × Mn_fin",
             f"{sr.Mpr_fin:.4f} ton·m"),
        ])

        # ── 2. Cortante de capacidad Ve ────────────────────────────────────────
        self.doc.add_heading(f"2. Cortante de Capacidad Ve  [{ref_Ve}]", level=3)
        self._add_para(
            "Ve = (Mpr_ini + Mpr_fin) / Hn\n"
            "Hn = altura libre de la columna entre caras de nudos",
            size=8, mono=True)
        self._calc_table([
            ("Hn (altura libre de la columna)",
             f"{sr.Hn_m:.2f} m"),
            ("Mpr_ini + Mpr_fin",
             f"{sr.Mpr_ini:.4f} + {sr.Mpr_fin:.4f} = {sr.Mpr_ini+sr.Mpr_fin:.4f} ton·m"),
            ("Ve = (Mpr_ini + Mpr_fin) / Hn",
             f"({sr.Mpr_ini:.4f} + {sr.Mpr_fin:.4f}) / {sr.Hn_m:.2f} "
             f"= {sr.Ve:.4f} ton"),
        ])

        # ── 3. Ignorar Vc ──────────────────────────────────────────────────────
        self.doc.add_heading(f"3. Verificacion: ¿Ignorar Vc?  [{ref_Vc}]", level=3)
        Pu_kg    = abs(r.Pu) * 1_000.0
        lim_vc   = Ag * fc / 20.0
        self._add_para(
            f"Condicion: Pu < Ag·f'c/20  Y  Vsismo ≥ 0.5·Ve\n"
            f"Si se cumple AMBAS condiciones → ignorar Vc en el diseño por cortante.",
            size=8)
        self._calc_table([
            ("Ag (area bruta de la seccion)",
             f"{Ag:.1f} cm²"),
            ("Limite Pu: Ag × f'c / 20",
             f"{Ag:.1f} × {fc:.0f} / 20 = {lim_vc:.1f} kg"),
            ("Pu de diseño",
             f"{Pu_kg:.1f} kg = {abs(r.Pu):.3f} ton"),
            ("Condicion Pu < Ag·f'c/20",
             f"{Pu_kg:.1f} {'< CUMPLE' if sr.ignore_Vc else '>= NO CUMPLE'}  "
             f"(limite = {lim_vc:.1f} kg)"),
            ("Decision sobre Vc",
             "SE IGNORA Vc — diseñar toda la cortante con acero transversal"
             if sr.ignore_Vc else
             "SE MANTIENE Vc — aporte del concreto es valido"),
        ])

        # ── 4. Zona de confinamiento Lo ────────────────────────────────────────
        self.doc.add_heading(f"4. Zona de Confinamiento Lo  [{ref_Lo}]", level=3)
        Hn_cm   = sr.Hn_m * 100.0
        min_dim = min(Bc, Hc)
        max_dim = max(Bc, Hc)

        if code == "NTC" and Q == 3:
            formula_Lo = "Lo ≥ max(Hn/6, mayor_dim_transversal, 600 mm=60 cm)"
            lo_terms   = [
                ("Hn / 6", f"{Hn_cm:.1f} / 6 = {Hn_cm/6:.2f} cm"),
                ("Dimension mayor de la seccion", f"{max_dim:.1f} cm"),
                ("Minimo normativo", "60.0 cm  [§7.4.4.2.1]"),
            ]
        elif code == "NTC" and Q >= 4:
            formula_Lo = "Lo ≥ max(peralte_mayor, Hn/6, 600 mm=60 cm)"
            lo_terms   = [
                ("Peralte mayor de la seccion", f"{max_dim:.1f} cm"),
                ("Hn / 6", f"{Hn_cm:.1f} / 6 = {Hn_cm/6:.2f} cm"),
                ("Minimo normativo", "60.0 cm  [§8.4.5.1]"),
            ]
        else:
            formula_Lo = "Lo ≥ max(mayor_dim, Hn/6, 18 in=45.72 cm)"
            lo_terms   = [
                ("Dimension mayor de la seccion", f"{max_dim:.1f} cm"),
                ("Hn / 6", f"{Hn_cm:.1f} / 6 = {Hn_cm/6:.2f} cm"),
                ("Minimo ACI", "45.72 cm (18 in)"),
            ]

        self._add_para(formula_Lo, size=8, mono=True)
        self._calc_table(lo_terms + [
            ("Lo calculado = max(terminos anteriores)",
             f"{sr.Lo_cm:.2f} cm"),
        ])

        # ── 5. Separaciones máximas de estribos ───────────────────────────────
        self.doc.add_heading(f"5. Separacion Maxima de Estribos  [{ref_s}]", level=3)
        db_m  = params.get("db_main_cm", 1.905)
        grade = params.get("rebar_grade", 42)

        if code == "NTC" and Q >= 4:
            hx    = min(sr.hx_max_cm, 35.0)
            s_ec  = max(10.0, min(15.0, 10.0 + (35.0 - hx) / 3.0))
            self._add_para(
                "Separacion en Lo (ec.8.4.5.3):\n"
                "  s_o = 100 + (350 - hx)/3  acotada [100, 150] mm\n"
                "  donde hx = separacion lateral maxima entre barras soportadas",
                size=8, mono=True)
            self._calc_table([
                ("db longitudinal principal", f"{db_m:.3f} cm"),
                ("Grado del refuerzo transversal", f"Grado {grade}"),
                ("hx (separacion lateral max. barras soportadas)", f"{hx:.1f} cm"),
                ("s_o por ec.8.4.5.3 = 10 + (35 - hx)/3",
                 f"10 + (35 - {hx:.1f})/3 = {s_ec:.2f} cm"),
                ("Limite por grado (db)",
                 f"{min(6*db_m, 15.0):.2f} cm  (Gr.42: 6db; Gr.56: 5db; Gr.70: 4db)"),
                ("Limite por min_dim/4",
                 f"{min_dim:.1f} / 4 = {min_dim/4:.2f} cm"),
                ("s_max (EN zona Lo) = min de los anteriores",
                 f"{sr.s_max_cm:.2f} cm"),
                ("s_fuera (FUERA de Lo)",
                 f"{sr.s_fuera_cm:.2f} cm"),
            ])
        else:
            self._calc_table([
                ("db longitudinal principal", f"{db_m:.3f} cm"),
                ("Grado del refuerzo transversal", f"Grado {grade}"),
                ("Limite por grado",
                 f"{sr.s_max_cm:.2f} cm"),
                ("Limite por min_dim/4",
                 f"{min_dim:.1f} / 4 = {min_dim/4:.2f} cm"),
                ("s_max (EN zona Lo) = min de anteriores",
                 f"{sr.s_max_cm:.2f} cm"),
                ("s_fuera (FUERA de Lo)",
                 f"{sr.s_fuera_cm:.2f} cm"),
            ])

        # ── 6. Cuantía mínima de confinamiento ────────────────────────────────
        if Q >= 4:
            fy_t = params.get("fy_transv", fy)
            Ach  = max((Bc - 10.0) * (Hc - 10.0), 1.0)
            col_type_str = "tied" if r.col_type == 1 else "spiral"

            self.doc.add_heading(
                f"6. Cuantia Minima de Confinamiento  [{'Tabla 8.4.5.4 NTC' if code=='NTC' else 'ACI §18.7.5.4'}]",
                level=3)
            if col_type_str == "spiral":
                rho_a = 0.45 * (Ag / Ach - 1.0) * fc / fy_t
                rho_b = 0.12 * fc / fy_t
                self._add_para(
                    "Columna circular (helicoidal):\n"
                    "  ρs ≥ 0.45·(Ag/Ach − 1)·f'c/fyt   (opcion d/e)\n"
                    "  ρs ≥ 0.12·f'c/fyt                 (opcion e)",
                    size=8, mono=True)
                self._calc_table([
                    ("Ag", f"{Ag:.2f} cm²"),
                    ("Ach (nucleo confinado aprox.)", f"{Ach:.2f} cm²"),
                    ("Ag/Ach − 1", f"{Ag/Ach - 1:.4f}"),
                    ("fyt (fluencia transversal)", f"{fy_t:.0f} kg/cm²"),
                    ("ρs,min opcion a = 0.45·(Ag/Ach−1)·f'c/fyt",
                     f"0.45 × {Ag/Ach-1:.4f} × {fc:.0f} / {fy_t:.0f} = {rho_a:.5f}"),
                    ("ρs,min opcion b = 0.12·f'c/fyt",
                     f"0.12 × {fc:.0f} / {fy_t:.0f} = {rho_b:.5f}"),
                    ("ρs,min DISENO = max(opcion a, opcion b)",
                     f"max({rho_a:.5f}, {rho_b:.5f}) = {sr.rho_s_min:.5f}"),
                ])
            else:
                Ash_a = 0.30 * (Ag / Ach - 1.0) * fc / fy_t
                Ash_b = 0.09 * fc / fy_t
                self._add_para(
                    "Columna rectangular (estribos):\n"
                    "  Ash/(s·b\") ≥ 0.30·(Ag/Ach − 1)·f'c/fyt   (opcion a)\n"
                    "  Ash/(s·b\") ≥ 0.09·f'c/fyt                  (opcion b)",
                    size=8, mono=True)
                self._calc_table([
                    ("Ag", f"{Ag:.2f} cm²"),
                    ("Ach (nucleo confinado aprox.)", f"{Ach:.2f} cm²"),
                    ("Ag/Ach − 1", f"{Ag/Ach - 1:.4f}"),
                    ("fyt", f"{fy_t:.0f} kg/cm²"),
                    ("Ash/(s·b\"),min opcion a = 0.30·(Ag/Ach−1)·f'c/fyt",
                     f"0.30 × {Ag/Ach-1:.4f} × {fc:.0f} / {fy_t:.0f} = {Ash_a:.5f}"),
                    ("Ash/(s·b\"),min opcion b = 0.09·f'c/fyt",
                     f"0.09 × {fc:.0f} / {fy_t:.0f} = {Ash_b:.5f}"),
                    ("Ash/(s·b\"),min DISENO",
                     f"max({Ash_a:.5f}, {Ash_b:.5f}) = {sr.Ash_Ach_min:.5f}"),
                ])

        # ── 7. Resumen sísmico ────────────────────────────────────────────────
        self.doc.add_heading("Resumen de Requisitos Sismicos", level=3)
        rows_resumen = [
            ("Q / Factor sismico", f"Q = {Q}  —  {cap_ref}"),
            ("Altura libre Hn", f"{sr.Hn_m:.2f} m"),
            ("fy_eff para Mpr", f"{fy_eff_lbl} = {sr.fy_eff:.0f} kg/cm²"),
            ("Mpr_ini", f"{sr.Mpr_ini:.4f} ton·m"),
            ("Mpr_fin", f"{sr.Mpr_fin:.4f} ton·m"),
            ("Ve = cortante de capacidad", f"{sr.Ve:.4f} ton"),
            ("¿Ignorar Vc?", "SI" if sr.ignore_Vc else "NO"),
            ("Lo — longitud zona confinada", f"{sr.Lo_cm:.2f} cm"),
            ("s_max dentro de Lo", f"{sr.s_max_cm:.2f} cm"),
            ("s_max fuera de Lo", f"{sr.s_fuera_cm:.2f} cm"),
        ]
        if Q >= 4:
            if r.col_type == 1:
                rows_resumen.append(
                    ("Ash/(s·b\"),min  confinamiento", f"{sr.Ash_Ach_min:.5f}"))
            else:
                rows_resumen.append(
                    ("ρs,min  confinamiento helicoidal", f"{sr.rho_s_min:.5f}"))
        self._calc_table(rows_resumen)

        # ── 8. Propuesta de refuerzo transversal (MNL-66) ─────────────────────
        try:
            from suite_shared.estribos_mnl66 import proponer_estribos
            n_var_p = getattr(r, "n_var", 0) or 0
            if n_var_p > 0 and r.col_type == 1:
                db_est_p = 0.95   # estribo #3 tipico; el disenador puede ajustar
                prop = proponer_estribos(
                    n_var=n_var_p, b_cm=Bc, h_cm=Hc,
                    rec_cm=params.get("rec1", 5.0),
                    db_var_cm=getattr(r, "d_var_cm", 2.54) or 2.54,
                    db_est_cm=db_est_p)
                self.doc.add_heading(
                    "Propuesta de Refuerzo Transversal  [ACI Detailing "
                    "Manual MNL-66]", level=3)
                self._add_para(
                    f"Armado longitudinal propuesto: {n_var_p} varillas "
                    f"#{getattr(r, 'var_num', 8)}  |  Seccion {Bc:.0f} x "
                    f"{Hc:.0f} cm", size=9, bold=True)
                self._add_para(prop.descripcion, size=9)
                self._add_para(
                    f"Separacion: s = {sr.s_max_cm:.0f} cm en la zona "
                    f"confinada Lo = {sr.Lo_cm:.0f} cm (ambos extremos) y "
                    f"s = {sr.s_fuera_cm:.0f} cm en el resto de la columna.",
                    size=9)
                for nota in prop.notas:
                    self._add_para(f"Nota: {nota}", size=8)
        except Exception:
            pass

        # Advertencias
        if sr.advertencias:
            self._add_para("ADVERTENCIAS NORMATIVAS:", bold=True, size=9)
            for adv in sr.advertencias:
                p = self.doc.add_paragraph(style="List Bullet")
                run = p.add_run(adv)
                run.font.size = Pt(8)
                run.font.color.rgb = _rgb("#922B21")

        self.doc.add_paragraph()

    # ── Sección: torsión detallada ────────────────────────────────────────────

    def _section_torsion_critica(self, r, params: dict):
        fc   = params["fc"]; fy  = params["fy"]
        rec1 = params["rec1"]; rec2 = params["rec2"]
        code = params.get("code", "ACI")
        phi  = 0.75
        sqrt_fc = math.sqrt(fc)

        if code == "ACI":
            coef_th = 0.083
            cv_max  = 4.44
            ref_th  = "ACI 318-25 §22.7.4"
            ref_At  = "ACI 318-25 §22.7.6.1"
            ref_Al  = "ACI 318-25 §22.7.6.3"
            ref_min = "ACI 318-25 §9.6.4"
            ref_chk = "ACI 318-25 §22.7.7.1"
        else:
            coef_th = 0.27
            cv_max  = 2.00
            ref_th  = "NTC 2023 §5.8.2.5 (Tabla 5.8.2.5.1a)"
            ref_At  = "NTC 2023 §5.8.3.2.2"
            ref_Al  = "NTC 2023 §5.8.3.2.3"
            ref_min = "NTC 2023 §6.3.5.5"
            ref_chk = "NTC 2023 §5.8.3.1.2"

        phi_lbl = "phi" if code == "ACI" else "FR"
        tor = r.torsion

        self._add_para(
            f"Combinacion: {r.comb_id}  |  Nodo: {r.node.upper()}  "
            f"|  Ttor = {r.Ttor:+.4f} ton·m", bold=True)

        # a) Torsor umbral
        self.doc.add_heading("a) Torsor umbral — ¿se diseña por torsion?", level=3)
        Bc = r.Bc; Hc = r.Hc
        Acp = Bc * Hc; pcp = 2.0 * (Bc + Hc)
        Tu_th_kgcm = phi * coef_th * sqrt_fc * Acp**2 / pcp

        if code == "ACI":
            formula_umbral = f"{phi_lbl}*{coef_th}*sqrt(f'c)*Acp²/pcp  [{ref_th}]"
        else:
            formula_umbral = f"{phi_lbl}*{coef_th}*lambda*sqrt(f'c)*Acp²/pcp  [{ref_th}]  (lambda=1.0 concreto normal)"

        self._calc_table([
            ("Bc",   f"{Bc:.1f} cm"),
            ("Hc",   f"{Hc:.1f} cm"),
            ("Acp = Bc*Hc  (area bruta)",
             f"{Bc:.1f} x {Hc:.1f} = {Acp:.1f} cm²"),
            ("pcp = 2*(Bc+Hc)  (perimetro bruto)",
             f"2*({Bc:.1f}+{Hc:.1f}) = {pcp:.1f} cm"),
            ("sqrt(f'c)",
             f"sqrt({fc:.0f}) = {sqrt_fc:.4f} kg½/cm"),
            (f"T_umbral = {formula_umbral}",
             f"{phi}*{coef_th}*{sqrt_fc:.4f}*{Acp:.1f}²/{pcp:.1f} "
             f"= {Tu_th_kgcm:.1f} kg·cm = {tor.Tu_th:.4f} ton·m"),
            ("|Tu| = |Ttor|",
             f"{tor.Tu:.4f} ton·m"),
            ("¿|Tu| > T_umbral? → ¿Requiere diseño?",
             "SI — Diseño requerido" if tor.diseno_req
             else "NO — Torsion despreciable"),
        ])

        if not tor.diseno_req:
            self._add_para(
                "Conclusion: el torsor de diseño es inferior al umbral. "
                "No se requiere acero adicional por torsion. Los estribos "
                "minimos por cortante son suficientes.", size=9)
            return

        # b) Geometria centrolinea
        self.doc.add_heading(
            "b) Geometria de la centrolinea de los estribos cerrados", level=3)
        b_int = Bc - 2*rec1; h_int = Hc - 2*rec2
        self._calc_table([
            ("rec1",          f"{rec1:.1f} cm"),
            ("rec2",          f"{rec2:.1f} cm"),
            ("b_int = Bc - 2*rec1",
             f"{Bc:.1f} - {2*rec1:.1f} = {b_int:.1f} cm"),
            ("h_int = Hc - 2*rec2",
             f"{Hc:.1f} - {2*rec2:.1f} = {h_int:.1f} cm"),
            ("Aoh = b_int * h_int",
             f"{b_int:.1f} x {h_int:.1f} = {tor.Aoh:.3f} cm²"),
            ("ph = 2*(b_int + h_int)",
             f"2*({b_int:.1f}+{h_int:.1f}) = {tor.ph:.3f} cm"),
            ("Ao = 0.85*Aoh  [ACI §22.7.6.1a / NTC §5.8.3.2.2]",
             f"0.85 x {tor.Aoh:.3f} = {tor.Ao:.3f} cm²"),
        ])

        # c) Acero transversal
        self.doc.add_heading("c) Acero transversal requerido por torsion", level=3)
        Tu_kgcm = tor.Tu * 100_000.0
        self._add_para(
            f"At/s = Tu / (2*{phi_lbl}*Ao*fy*cot theta)  "
            f"[theta = 45°, cot theta = 1.0]  [{ref_At}]", size=8, mono=True)
        self._calc_table([
            ("|Tu|",             f"{tor.Tu:.4f} ton·m = {Tu_kgcm:.1f} kg·cm"),
            (f"{phi_lbl}",       f"{phi:.2f}"),
            ("Ao",               f"{tor.Ao:.3f} cm²"),
            ("fy",               f"{fy:.0f} kg/cm²"),
            ("cot theta (45°)",  "1.000"),
            ("At/s = Tu / (2*phi*Ao*fy)",
             f"{Tu_kgcm:.1f} / (2*{phi}*{tor.Ao:.3f}*{fy:.0f}) "
             f"= {tor.At_s:.6f} cm²/cm"),
        ])

        # d) Acero longitudinal
        self.doc.add_heading("d) Acero longitudinal requerido por torsion", level=3)
        self._add_para(
            f"Al = (At/s)*ph*(fy_t/fy_l)*cot²theta = (At/s)*ph  "
            f"(fy_t = fy_l, theta=45°)  [{ref_Al}]", size=8, mono=True)
        self._calc_table([
            ("At/s",   f"{tor.At_s:.6f} cm²/cm"),
            ("ph",     f"{tor.ph:.3f} cm"),
            ("Al = (At/s)*ph",
             f"{tor.At_s:.6f} x {tor.ph:.3f} = {tor.Al:.4f} cm²"),
        ])

        # e) Minimos
        self.doc.add_heading("e) Minimos por codigo", level=3)
        bw_min = min(Bc, Hc)
        At_s_min1 = 0.062 * sqrt_fc * bw_min / fy
        At_s_min2 = 0.350 * bw_min / fy
        self._add_para(f"[{ref_min}]", size=8)
        self._calc_table([
            ("bw,min = min(Bc, Hc)",
             f"{bw_min:.1f} cm"),
            ("At/s,min1 = 0.062*sqrt(f'c)*bw/fy",
             f"0.062*{sqrt_fc:.4f}*{bw_min:.1f}/{fy:.0f} = {At_s_min1:.6f} cm²/cm"),
            ("At/s,min2 = 0.350*bw/fy",
             f"0.350*{bw_min:.1f}/{fy:.0f} = {At_s_min2:.6f} cm²/cm"),
            ("At/s,min = max(At/s,min1, At/s,min2)",
             f"max({At_s_min1:.6f}, {At_s_min2:.6f}) = {tor.At_s_min:.6f} cm²/cm"),
            ("Al,min = 5*sqrt(f'c)*Acp/fy - At/s,min*ph",
             f"5*{sqrt_fc:.4f}*{Acp:.1f}/{fy:.0f} - {tor.At_s_min:.6f}*{tor.ph:.3f} "
             f"= {tor.Al_min:.4f} cm²"),
            ("At/s,diseno = max(At/s, At/s,min)",
             f"max({tor.At_s:.6f}, {tor.At_s_min:.6f}) = {tor.At_s_dis:.6f} cm²/cm"),
            ("Al,diseno = max(Al, Al,min)",
             f"max({tor.Al:.4f}, {tor.Al_min:.4f}) = {tor.Al_dis:.4f} cm²"),
        ])

        # f) Verificacion seccion combinada
        self.doc.add_heading(
            "f) Verificacion de la seccion — interaccion cortante-torsion", level=3)
        self._add_para(f"[{ref_chk}]", size=8)
        if code == "ACI":
            formula_chk = "sqrt[(Vu/bw·d)² + (Tu·ph/1.7/Aoh²)²]  <=  phi*(Vc/bw·d + 4.44*sqrt(f'c))"
        else:
            formula_chk = "sqrt[(Vu/bw·d)² + (Tu·ph/1.7/Aoh²)²]  <=  FR*(Vc/bw·d + 2.0*sqrt(f'c))"
        self._add_para(formula_chk, size=8, mono=True)
        self._calc_table([
            ("Lado izquierdo (demanda)",
             f"{tor.lhs_check:.4f} kg/cm²"),
            (f"Lado derecho (capacidad, lim Cv_max = {cv_max}*sqrt(f'c))",
             f"{tor.rhs_check:.4f} kg/cm²"),
            ("Verificacion",
             "OK — seccion adecuada" if tor.ok_section
             else "FALLA — aumentar seccion o reducir cargas"),
            ("Condicion de torsion",
             tor.condicion),
        ])

    # ── Helpers de formato ────────────────────────────────────────────────────

    def _add_para(self, text: str, size: int = 9, bold: bool = False,
                  mono: bool = False):
        p = self.doc.add_paragraph()
        run = p.add_run(text)
        run.font.size = Pt(size)
        run.bold = bold
        if mono:
            run.font.name = "Courier New"
        p.paragraph_format.space_after  = Pt(2)
        p.paragraph_format.space_before = Pt(1)
        return p

    def _calc_table(self, rows: list):
        tbl = self.doc.add_table(rows=len(rows), cols=2)
        tbl.style = "Table Grid"
        tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, (desc, val) in enumerate(rows):
            c0 = tbl.rows[i].cells[0]
            c1 = tbl.rows[i].cells[1]
            c0.text = desc; c1.text = val
            for c_idx, cell in enumerate((c0, c1)):
                run = cell.paragraphs[0].runs[0]
                run.font.size = Pt(8)
                cell.paragraphs[0].alignment = (
                    WD_ALIGN_PARAGRAPH.LEFT if c_idx == 0
                    else WD_ALIGN_PARAGRAPH.CENTER)
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            if i % 2 == 0:
                _set_cell_bg(c0, self.ALT_BG)
                _set_cell_bg(c1, self.ALT_BG)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(2)

    def _rebar_table(self, rebar_data: list):
        headers = [
            "Var.", "Z\n(cm)", "Y\n(cm)",
            "dist_n\n(cm)", "eps_s", "fs\n(kg/cm²)",
            "Fs\n(ton)", "Estado"
        ]
        tbl = self.doc.add_table(rows=1 + len(rebar_data), cols=len(headers))
        tbl.style = "Table Grid"
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        for c, h in enumerate(headers):
            _bold_cell(tbl.rows[0].cells[c], h, size=7)
            _set_cell_bg(tbl.rows[0].cells[c], self.HEADER_BG)
        for i, d in enumerate(rebar_data, 1):
            vals = [
                str(d["k"]),
                f"{d['z_v']:.2f}",
                f"{d['y_v']:.2f}",
                f"{d['dist_n']:+.3f}",
                f"{d['eps_v']:+.5f}",
                f"{d['fsi']:+.1f}",
                f"{d['Fvar']:+.3f}",
                d["estado"],
            ]
            bg = "D5F5E3" if d["Fvar"] >= 0 else "FADBD8"
            for c, v in enumerate(vals):
                _data_cell(tbl.rows[i].cells[c], v, size=7)
                _set_cell_bg(tbl.rows[i].cells[c], bg)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # ── Helpers de cálculo ────────────────────────────────────────────────────

    def _rebar_coords(self, Bc, Hc, rec1, rec2,
                      numfilz, numfily, numvar, sepz, sepy) -> dict:
        ptovar: dict = {}
        for k in range(1, numfilz + 1):
            z = rec1 + sepz * (k - 1)
            ptovar[k]           = (z, rec2)
            ptovar[k + numfilz] = (z, Hc - rec2)
        for k in range(1, numfily - 1):
            y = rec2 + sepy * k
            ptovar[k + numfilz*2]              = (rec1, y)
            ptovar[k + numfilz*2 + numfily-2]  = (Bc - rec1, y)
        return ptovar

    def _compute_rebar_forces(self, ptovar, numvar, Asvar,
                               coord_y_neu, ang1_deg, ang1_rad,
                               Hb, dist_ini1, coord_y_cent, fy):
        rebar_data:  list  = []
        Fvartot_kg   = 0.0
        Mvartot_kgcm = 0.0

        for k in range(1, numvar + 1):
            z_v, y_v = ptovar[k]

            dz = z_v; dy_n = coord_y_neu - y_v
            hyp_n = math.sqrt(dz**2 + dy_n**2)
            if hyp_n < 1e-9:
                dist_n = 0.0
            else:
                a1 = 90.0 - math.degrees(math.atan2(dy_n, dz))
                a2 = abs(a1 + ang1_deg)
                dist_n = hyp_n * math.cos(math.radians(a2))

            denom = Hb - dist_ini1
            if dist_ini1 < 1e-9:
                eps_v = 0.0022
            elif dist_ini1 >= Hb:
                eps_v = -0.0049
            elif abs(denom) < 1e-9:
                eps_v = 0.0
            else:
                eps_v = _Epsi * dist_n / denom

            if abs(eps_v) >= _Epsi and eps_v >= 0:
                fsi = fy;  estado = "Fluye (C)"
            elif abs(eps_v) >= _Epsi:
                fsi = -fy; estado = "Fluye (T)"
            else:
                fsi = max(-fy, min(fy, _Es * eps_v))
                estado = "Elastico"

            Fvar_kg = fsi * Asvar

            dz_c = z_v; dy_c = coord_y_cent - y_v
            hyp_c = math.sqrt(dz_c**2 + dy_c**2)
            if hyp_c < 1e-9:
                dist_c = 0.0
            else:
                a1c = 90.0 - math.degrees(math.atan2(dy_c, dz_c))
                a2c = abs(a1c + ang1_deg)
                dist_c = hyp_c * math.cos(math.radians(a2c))

            Fvartot_kg   += Fvar_kg
            Mvartot_kgcm += abs(Fvar_kg) * abs(dist_c)

            rebar_data.append({
                "k":      k,
                "z_v":    z_v,
                "y_v":    y_v,
                "dist_n": dist_n,
                "eps_v":  eps_v,
                "fsi":    fsi,
                "Fvar":   Fvar_kg / 1000.0,
                "estado": estado,
            })

        return rebar_data, Fvartot_kg, Mvartot_kgcm

    def _comp_block_case(self, h4, b4, Hc, Bc, tan_ang, distini, h3) -> int:
        if distini >= h3:          return 0
        if h4 >= Hc and abs(tan_ang) > 1e-9: return 3
        if b4 > Bc and h4 < Hc:   return 5
        if h4 < Hc and b4 <= Bc:  return 7
        return 1

    def _compute_comp_block(self, distini, h3, h4, b4, Hc, Bc,
                             tan_ang, h1) -> tuple:
        if distini >= h3:
            return 0.0, 0.0, 0.0

        caso = self._comp_block_case(h4, b4, Hc, Bc, tan_ang, distini, h3)

        if caso == 1:
            pts = [(0,0),(Bc,0),(Bc,Hc),(0,Hc),(0,0),(0,0)]
        elif caso == 3:
            z4 = ((h4 - Hc) * b4) / h4 if abs(h4) > 1e-9 else 0.0
            pts = [(0,0),(Bc,0),(Bc,(b4-Bc)*abs(tan_ang)),(z4,Hc),(0,Hc),(0,0)]
        elif caso == 5:
            y3 = ((b4 - Bc) * h4) / b4 if abs(b4) > 1e-9 else 0.0
            pts = [(0,0),(Bc,0),(Bc,y3),(0,h4),(0,0),(0,0)]
        else:
            pts = [(0,0),(b4,0),(0,h4),(0,0),(0,0),(0,0)]

        A = X = Y = 0.0
        for i in range(5):
            x1, y1 = pts[i]; x2, y2 = pts[i+1]
            dA = (y2 - y1) * (x2 + x1) / 2.0
            A  += dA
            X  += (y2 - y1) / 8.0 * ((x2+x1)**2 + (x2-x1)**2/3.0)
            Y  += (x2 - x1) / 8.0 * ((y2+y1)**2 + (y2-y1)**2/3.0)
        if abs(A) < 1e-9:
            return 0.0, 0.0, 0.0
        return A, X/A, -Y/A

    # ── Formulas generales ────────────────────────────────────────────────────

    def _get_formulas(self, params: dict) -> list:
        code     = params.get("code", "ACI")
        fc       = params.get("fc", 250)
        fy       = params.get("fy", 4200)
        col_type = params.get("col_type", "tied")
        eps_y    = fy / _Es

        if code == "ACI":
            B1 = 0.85 if fc <= 280 else max(0.65, 0.85 - 0.05*(fc-280)/70)
            phi_c = 0.65 if col_type == "tied" else 0.75
            return [
                f"beta1 = {B1:.3f}  [ACI 318-25 Tabla 22.2.2.4.3]  "
                f"(umbral 280 kg/cm²)",
                "ecu = 0.003  [ACI 318-25 §22.2.2.1]",
                f"eps_y = fy/Es = {fy}/{int(_Es)} = {eps_y:.5f}",
                f"f''c = 0.85*f'c = 0.85*{fc:.0f} = {0.85*fc:.1f} kg/cm²",
                f"phi (compresion, {col_type}) = {phi_c:.2f}  [ACI 318-25 Tabla 21.2.2]",
                "phi (tension) = 0.90  [ACI 318-25 Tabla 21.2.2]",
                f"Transicion ACI: phi = {phi_c:.2f} + {0.90-phi_c:.2f}*(|eps_t|-eps_y)/(0.005-eps_y)",
                "Cc = f''c * beta1 * A_comp  [ACI 318-25 §22.2.1.1]",
                "Pn = (Cc + Sum_Fs) / 1000  [ton]",
                "Mn = (Mc + Sum_Ms) / 100 000  [ton·m]",
                "Vc = 0.53*(1+Nu/(k*Ag))*sqrt(f'c)*bw*d  [ACI 318-25 §22.5.5.1]",
                "rv,min = max(0.2*sqrt(f'c)/fy, 3.5/fy)*bw  [ACI 318-25 §9.6.3.3]",
                "Torsion umbral: phi*0.083*sqrt(f'c)*Acp²/pcp  [ACI §22.7.4]",
            ]
        else:
            B1 = 0.85 if fc <= 300 else max(0.65, 1.05 - fc/1400.0)
            phi_c = 0.65 if col_type == "tied" else 0.75
            return [
                f"beta1 = {B1:.3f}  [NTC 2023 §3.6.1]  "
                f"(umbral 300 kg/cm²; beta1=1.05-f'c/1400>=0.65 si f'c>300)",
                "ecu = 0.003  [NTC 2023 §3.6.1]",
                f"eps_y = {eps_y:.5f}",
                f"f''c = 0.85*{fc:.0f} = {0.85*fc:.1f} kg/cm²  [NTC §3.6.1]",
                f"FR (compresion, {col_type}) = {phi_c:.2f}  [NTC 2023 Tabla 3.8.2.2]",
                "FR (tension) = 0.90  [NTC 2023 Tabla 3.8.2.2]",
                f"Transicion NTC (anchura=0.003): Estribos: FR=0.65+0.25*(eps_t-eps_cy)/0.003",
                "Cc = f''c * beta1 * A_comp  [NTC 2023 §3.6.1]",
                "Pn = (Cc + Sum_Fs) / 1000  [ton]",
                "Mn = (Mc + Sum_Ms) / 100 000  [ton·m]",
                "Vc = (0.50*sqrt(f'c) + Nu/(6*Ag))*bw*d  [NTC 2023 §5.5.3.1.1.a]  (aditivo)",
                "  Limites NTC: 0.08*sqrt(f'c)*bw*d <= Vc <= 0.42*sqrt(f'c)*bw*d",
                "rv,min = max(0.2*sqrt(f'c)/fy, 3.5/fy)*bw  [NTC 2023 §6.3.5.4.4]",
                "Torsion umbral: FR*0.27*lambda*sqrt(f'c)*Acp²/pcp  [NTC §5.8.2.5]",
                "Check torsion: limite 2.0*sqrt(f'c)  [NTC §5.8.3.1.2]",
                "e_min = max(0.05h, 2.0 cm)  [NTC 2023 §5.3.2]",
            ]
