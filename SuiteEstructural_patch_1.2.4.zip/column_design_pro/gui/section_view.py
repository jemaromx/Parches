﻿"""
Widget de visualización de la sección transversal de la columna.

Muestra, junto al diagrama de interacción:
  • Geometría de la sección (rectangular o circular) con sus dimensiones.
  • Distribución propuesta de varillas de refuerzo (según la combinación
    crítica — la que requiere mayor área de acero "As").
  • Cantidad total de acero propuesto (número de varillas, diámetro
    equivalente y área total As).
"""
from __future__ import annotations

import math
from typing import Optional

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QSizePolicy
from PySide6.QtCore import Qt

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle, Circle


# Varillas comerciales disponibles para columnas (NTC DEC 2023 / práctica MX)
# Solo los números permitidos: #3, #4, #5, #6, #8, #10, #12
# Diámetro nominal en cm = número_de_octavos_de_pulgada × 2.54 / 8
_BAR_TABLE = [
    (3  * 2.54 / 8,  '#3  (3/8")'),    # d = 0.9525 cm,  As = 0.7126 cm²
    (4  * 2.54 / 8,  '#4  (1/2")'),    # d = 1.2700 cm,  As = 1.2668 cm²
    (5  * 2.54 / 8,  '#5  (5/8")'),    # d = 1.5875 cm,  As = 1.9794 cm²
    (6  * 2.54 / 8,  '#6  (3/4")'),    # d = 1.9050 cm,  As = 2.8503 cm²
    (8  * 2.54 / 8,  '#8  (1")'),      # d = 2.5400 cm,  As = 5.0671 cm²
    (10 * 2.54 / 8,  '#10 (1-1/4")'),  # d = 3.1750 cm,  As = 7.9168 cm²
    (12 * 2.54 / 8,  '#12 (1-1/2")'),  # d = 3.8100 cm,  As = 11.4  cm²
]
# Área de cada varilla (cm²)
_BAR_AREA = {
    '#3  (3/8")':   0.7126,
    '#4  (1/2")':   1.2668,
    '#5  (5/8")':   1.9794,
    '#6  (3/4")':   2.8503,
    '#8  (1")':     5.0671,
    '#10 (1-1/4")': 7.9168,
    '#12 (1-1/2")': 11.401,
}


def _nearest_bar(d_cm: float) -> str:
    """
    Retorna la designación de varilla comercial disponible cuyo diámetro
    nominal es más cercano al diámetro equivalente calculado.
    Solo considera los tamaños permitidos: #3, #4, #5, #6, #8, #10, #12.
    """
    if d_cm <= 0:
        return "—"
    best = min(_BAR_TABLE, key=lambda t: abs(t[0] - d_cm))
    return best[1]


def _bar_area_cm2(bar_label: str) -> float:
    """Área nominal de la varilla comercial en cm²."""
    return _BAR_AREA.get(bar_label, 0.0)


class SectionViewWidget(QWidget):
    """Vista 2-D de la sección de concreto con su distribución de refuerzo."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: dict = {}
        self._current_col_id = 0
        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(2)

        self.lbl_title = QLabel("Sección y refuerzo propuesto")
        self.lbl_title.setAlignment(Qt.AlignCenter)
        self.lbl_title.setStyleSheet(
            "color:#1B4F72; font-weight:bold; font-size:11px;")
        lay.addWidget(self.lbl_title)

        self.fig = Figure(figsize=(3.6, 3.6), facecolor="#F5F6FA")
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lay.addWidget(self.canvas)

        self.ax = self.fig.add_subplot(111)
        self._style_axes()

        self.lbl_info = QLabel("Sin datos de sección")
        self.lbl_info.setWordWrap(True)
        self.lbl_info.setAlignment(Qt.AlignCenter)
        self.lbl_info.setStyleSheet("color:#34495E; font-size:10px;")
        lay.addWidget(self.lbl_info)

    def _style_axes(self):
        self.ax.set_aspect("equal", adjustable="box")
        self.ax.set_facecolor("#FDFEFE")
        self.fig.patch.set_facecolor("#F5F6FA")
        self.ax.grid(True, alpha=0.25)
        self.ax.tick_params(labelsize=7)

    # ── API pública ───────────────────────────────────────────────────────────

    def set_column(self, col_id: int):
        """Cambia la columna mostrada (sincronizada con el diagrama 3-D)."""
        self._current_col_id = col_id
        self._plot()

    def add_section(self, col_id: int, section: Optional[dict]):
        """Registra los datos de sección/refuerzo de una columna."""
        if section is None:
            return
        self._data[str(col_id)] = section
        if self._current_col_id == 0:
            self._current_col_id = col_id
            self._plot()

    def clear(self):
        self._data = {}
        self._current_col_id = 0
        self.ax.cla()
        self._style_axes()
        self.canvas.draw()
        self.lbl_info.setText("Sin datos de sección")

    # ── Trazado ───────────────────────────────────────────────────────────────

    def _plot(self):
        self.ax.cla()
        self._style_axes()
        d = self._data.get(str(self._current_col_id))
        if d is None:
            self.canvas.draw()
            self.lbl_info.setText("Sin datos de sección")
            self.lbl_title.setText("Sección y refuerzo propuesto")
            return

        col_type = d.get("col_type", 1)
        Bc       = d.get("Bc", 0.0)
        Hc       = d.get("Hc", 0.0)
        d_var    = d.get("d_var_cm", 0.0)
        As_total = d.get("As_total", 0.0)
        rebar    = d.get("rebar_xy", [])

        # ── Varilla comercial elegida por el motor de diseño ──────────────
        # El número de varillas es EXACTAMENTE el arreglo físico dibujado
        # (n_var = len(rebar_xy)); la etiqueta y el dibujo quedan sincronizados.
        var_num   = d.get("var_num", 0)
        n_var     = d.get("n_var", 0) or len(rebar)
        _lbl_by_num = {3:'#3  (3/8")', 4:'#4  (1/2")', 5:'#5  (5/8")',
                       6:'#6  (3/4")', 8:'#8  (1")', 10:'#10 (1-1/4")',
                       12:'#12 (1-1/2")'}
        bar_label = _lbl_by_num.get(var_num) or _nearest_bar(d_var)
        bar_area  = _bar_area_cm2(bar_label)
        bar_d_nom = next((t[0] for t in _BAR_TABLE if t[1] == bar_label), d_var)
        n_req     = n_var if n_var > 0 else (
            math.ceil(As_total / bar_area) if bar_area > 0 else len(rebar))
        As_prov   = n_req * bar_area if bar_area > 0 else As_total

        # Radio de dibujo para las varillas (nominal, mínimo visible)
        dim_ref   = max(Bc, Hc)
        r_draw    = max(bar_d_nom / 2.0, dim_ref * 0.012)

        # ── Geometría de la sección ───────────────────────────────────────
        if col_type == 2:
            self.ax.add_patch(Circle((0, 0), Bc / 2.0, fill=False,
                                      edgecolor="#1B4F72", linewidth=1.6))
            self.ax.annotate(
                f"Ø {Bc:.0f} cm", xy=(0, -Bc / 2.0),
                xytext=(0, -Bc / 2.0 * 1.28),
                ha="center", fontsize=8, color="#1B4F72", fontweight="bold")
            ax_rad = max(Bc / 2.0 * 1.45, 1.0)
            self.ax.set_xlim(-ax_rad, ax_rad)
            self.ax.set_ylim(-ax_rad, ax_rad)
        else:
            self.ax.add_patch(Rectangle((0, 0), Bc, Hc, fill=False,
                                         edgecolor="#1B4F72", linewidth=1.6))
            self.ax.annotate(
                f"Bc = {Bc:.0f} cm", xy=(Bc / 2.0, 0),
                xytext=(Bc / 2.0, -Hc * 0.12),
                ha="center", fontsize=8, color="#1B4F72", fontweight="bold")
            self.ax.annotate(
                f"Hc = {Hc:.0f} cm", xy=(0, Hc / 2.0),
                xytext=(-Bc * 0.18, Hc / 2.0),
                ha="center", va="center", rotation=90,
                fontsize=8, color="#1B4F72", fontweight="bold")
            margin = dim_ref * 0.22
            self.ax.set_xlim(-margin, Bc + margin)
            self.ax.set_ylim(-margin, Hc + margin)

        # ── Varillas de refuerzo ──────────────────────────────────────────
        for (x, y) in rebar:
            self.ax.add_patch(Circle((x, y), r_draw,
                                      facecolor="#CB4335",
                                      edgecolor="#922B21", linewidth=0.6,
                                      zorder=5))

        # ── Leyenda dentro de la figura ───────────────────────────────────
        self.ax.text(
            0.02, 0.98,
            f"{n_req}  {bar_label.strip()}\nAs = {As_prov:.2f} cm²",
            transform=self.ax.transAxes,
            va="top", ha="left", fontsize=8,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#EAF4FC",
                      edgecolor="#1B4F72", alpha=0.85))

        self.ax.set_title(
            f"Columna {self._current_col_id} — refuerzo propuesto",
            fontsize=9, fontweight="bold", color="#1B4F72")
        self.canvas.draw()

        comb = d.get("comb_id", "—")
        dim_str = (f"Ø {Bc:.0f} cm" if col_type == 2
                   else f"{Bc:.0f}×{Hc:.0f} cm")
        self.lbl_title.setText(
            f"Sección {dim_str}  —  Columna {self._current_col_id}")
        self.lbl_info.setText(
            f"Combinación crítica (As máx.): {comb}   |   "
            f"As requerida = {As_total:.2f} cm²\n"
            f"Varilla seleccionada: {bar_label.strip()}   "
            f"As/varilla = {bar_area:.4f} cm²\n"
            f"Varillas necesarias: {n_req}   →   "
            f"As provista = {As_prov:.2f} cm²"
        )

    def save_figure(self, path: str, dpi: int = 180):
        self.fig.savefig(path, dpi=dpi, bbox_inches="tight",
                         facecolor=self.fig.get_facecolor())
