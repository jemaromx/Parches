﻿"""
Widget para el diagrama de interacción 3-D y vistas 2-D embebidas en Qt.

Pestañas:
  • Diagrama 3-D  — superficie P-Mx-My completa
  • P vs Mx       — envolvente plano (Mx, P)
  • P vs My       — envolvente plano (My, P)
  • Mx vs My      — corte horizontal a nivel de la demanda Pu más crítica
"""
from __future__ import annotations

import math
import os
import tempfile
from typing import Optional

import numpy as np
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QComboBox, QLabel, QFileDialog, QSizePolicy,
    QCheckBox, QSplitter, QTabWidget,
)
from PySide6.QtCore import Qt

from gui.section_view import SectionViewWidget

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D          # noqa: F401


class InteractionPlotWidget(QWidget):
    """Visualizador 3-D/2-D del diagrama de interacción."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._nom_pts:    Optional[np.ndarray] = None
        self._fac_pts:    Optional[np.ndarray] = None
        self._curves_nom: list = []
        self._curves_fac: list = []
        self._demand_pts: list = []
        self._current_col_id = 0
        self._data: dict = {}
        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(4)

        # ── Barra de controles ────────────────────────────────────────────────
        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Columna:"))
        self.cb_col = QComboBox()
        self.cb_col.currentIndexChanged.connect(self._on_col_changed)
        ctrl.addWidget(self.cb_col)

        self.chk_nom = QCheckBox("Nominal")
        self.chk_nom.setChecked(True)
        self.chk_nom.stateChanged.connect(self._replot_all)
        ctrl.addWidget(self.chk_nom)

        self.chk_fac = QCheckBox("Factorado φ")
        self.chk_fac.setChecked(True)
        self.chk_fac.stateChanged.connect(self._replot_all)
        ctrl.addWidget(self.chk_fac)

        self.chk_dem = QCheckBox("Demanda")
        self.chk_dem.setChecked(True)
        self.chk_dem.stateChanged.connect(self._replot_all)
        ctrl.addWidget(self.chk_dem)

        ctrl.addStretch()

        btn_exp = QPushButton("💾 Exportar imagen")
        btn_exp.clicked.connect(self._export_image)
        btn_exp.setObjectName("btn_export")
        ctrl.addWidget(btn_exp)

        btn_word = QPushButton("📄 → Word")
        btn_word.clicked.connect(self._export_to_word)
        btn_word.setObjectName("btn_export")
        ctrl.addWidget(btn_word)

        root.addLayout(ctrl)

        # ── Splitter: tabs de diagramas (izq.) + vista de sección (der.) ──────
        splitter = QSplitter(Qt.Horizontal)

        # ── Pestañas de diagramas ─────────────────────────────────────────────
        self._diag_tabs = QTabWidget()
        self._diag_tabs.setDocumentMode(True)

        # ── Pestaña 0: Diagrama 3-D ───────────────────────────────────────────
        panel_3d = QWidget()
        lay_3d   = QVBoxLayout(panel_3d)
        lay_3d.setContentsMargins(0, 0, 0, 0)
        lay_3d.setSpacing(2)
        self.fig3d = Figure(figsize=(9, 7), facecolor="#F5F6FA")
        self.canvas3d = FigureCanvas(self.fig3d)
        self.canvas3d.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        nav3d = NavToolbar(self.canvas3d, self)
        nav3d.setStyleSheet("background:#FFFFFF; border:none;")
        lay_3d.addWidget(nav3d)
        lay_3d.addWidget(self.canvas3d)
        self.ax3d = self.fig3d.add_subplot(111, projection="3d")
        self._style_axes_3d()
        self._diag_tabs.addTab(panel_3d, "Diagrama 3-D")

        # ── Pestaña 1: P vs Mx ────────────────────────────────────────────────
        self.fig_pmx, self.ax_pmx, self.canvas_pmx = self._make_2d_canvas()
        self._diag_tabs.addTab(self._wrap_canvas(self.canvas_pmx), "P vs Mx")

        # ── Pestaña 2: P vs My ────────────────────────────────────────────────
        self.fig_pmy, self.ax_pmy, self.canvas_pmy = self._make_2d_canvas()
        self._diag_tabs.addTab(self._wrap_canvas(self.canvas_pmy), "P vs My")

        # ── Pestaña 3: Mx vs My ───────────────────────────────────────────────
        self.fig_mm, self.ax_mm, self.canvas_mm = self._make_2d_canvas()
        self._diag_tabs.addTab(self._wrap_canvas(self.canvas_mm), "Mx vs My")

        # Actualizar al cambiar de pestaña (evita dibujar si no se ve)
        self._diag_tabs.currentChanged.connect(self._on_tab_changed)

        self.section_view = SectionViewWidget()

        splitter.addWidget(self._diag_tabs)
        splitter.addWidget(self.section_view)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter)

    # ── Helpers de canvas 2-D ─────────────────────────────────────────────────

    @staticmethod
    def _make_2d_canvas():
        fig = Figure(figsize=(7, 6), facecolor="#F5F6FA")
        canvas = FigureCanvas(fig)
        canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        ax = fig.add_subplot(111)
        ax.set_facecolor("#FDFEFE")
        fig.patch.set_facecolor("#F5F6FA")
        ax.grid(True, alpha=0.3)
        return fig, ax, canvas

    @staticmethod
    def _wrap_canvas(canvas: FigureCanvas) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(NavToolbar(canvas, w))
        lay.addWidget(canvas)
        return w

    # ── API pública ───────────────────────────────────────────────────────────

    def add_column(self, col_id: int,
                   nom_pts:    np.ndarray,
                   fac_pts:    np.ndarray,
                   curves_nom: list,
                   curves_fac: list,
                   demand:     list,
                   section:    Optional[dict] = None):
        """
        Agrega datos de una columna.
        curves_nom / curves_fac : lista de ndarray (M,3) [P, Mx, My]
        demand                  : lista de (P, Mx, My) ton / ton·m
        section                 : dict con geometría y refuerzo propuesto
        """
        key = str(col_id)
        self._data[key] = {
            "nom":        nom_pts,
            "fac":        fac_pts,
            "curves_nom": curves_nom,
            "curves_fac": curves_fac,
            "demand":     demand,
        }
        if section is not None:
            self.section_view.add_section(col_id, section)
        if self.cb_col.findText(f"Col {col_id}") < 0:
            self.cb_col.addItem(f"Col {col_id}", col_id)
        if self.cb_col.count() == 1:
            self._load_column(col_id)

    def _on_col_changed(self, idx: int):
        col_id = self.cb_col.itemData(idx)
        if col_id is not None:
            self._load_column(col_id)

    def _on_tab_changed(self, _idx: int):
        self._replot_all()

    def _load_column(self, col_id: int):
        self._current_col_id = col_id
        key = str(col_id)
        if key not in self._data:
            return
        d = self._data[key]
        self._nom_pts    = d["nom"]
        self._fac_pts    = d["fac"]
        self._curves_nom = d.get("curves_nom", [])
        self._curves_fac = d.get("curves_fac", [])
        self._demand_pts = d["demand"]
        self.section_view.set_column(col_id)
        self._replot_all()

    def clear(self):
        self._nom_pts    = None
        self._fac_pts    = None
        self._curves_nom = []
        self._curves_fac = []
        self._demand_pts = []
        self._data       = {}
        self.cb_col.clear()
        self.ax3d.cla()
        self._style_axes_3d()
        self.canvas3d.draw()
        for ax, canvas in [(self.ax_pmx, self.canvas_pmx),
                           (self.ax_pmy, self.canvas_pmy),
                           (self.ax_mm,  self.canvas_mm)]:
            ax.cla()
            ax.set_facecolor("#FDFEFE")
            ax.grid(True, alpha=0.3)
            canvas.draw()
        self.section_view.clear()

    # ── Trazado coordinado ────────────────────────────────────────────────────

    def _replot_all(self, _=None):
        tab = self._diag_tabs.currentIndex()
        if tab == 0:
            self._replot_3d()
        elif tab == 1:
            self._replot_2d_pmx()
        elif tab == 2:
            self._replot_2d_pmy()
        elif tab == 3:
            self._replot_2d_mxmy()

    # ── 3-D ──────────────────────────────────────────────────────────────────

    def _replot_3d(self):
        self.ax3d.cla()
        self._style_axes_3d()
        plotted = False

        if self.chk_nom.isChecked() and self._curves_nom:
            for curve in self._curves_nom:
                if len(curve) < 2:
                    continue
                self.ax3d.plot(curve[:, 1], curve[:, 2], curve[:, 0],
                               color="#85C1E9", linewidth=0.6, alpha=0.45)
            self.ax3d.plot([], [], [], color="#85C1E9",
                           linewidth=1.2, label="Nominal")
            plotted = True

        if self.chk_fac.isChecked() and self._curves_fac:
            for curve in self._curves_fac:
                if len(curve) < 2:
                    continue
                self.ax3d.plot(curve[:, 1], curve[:, 2], curve[:, 0],
                               color="#2E86C1", linewidth=0.9, alpha=0.65)
            self.ax3d.plot([], [], [], color="#2E86C1",
                           linewidth=1.5, label="Factorado φ")
            plotted = True

        if self.chk_dem.isChecked() and self._demand_pts:
            Pd  = [d[0] for d in self._demand_pts]
            Mxd = [d[1] for d in self._demand_pts]
            Myd = [d[2] for d in self._demand_pts]
            inside = [self._point_inside(p) for p in self._demand_pts]
            colors = ["#27AE60" if ok else "#E74C3C" for ok in inside]
            self.ax3d.scatter(Mxd, Myd, Pd, c=colors, s=60, zorder=6,
                              edgecolors="white", linewidths=0.6,
                              label="Demanda")
            plotted = True

        if plotted:
            self.ax3d.legend(loc="upper left", fontsize=8, framealpha=0.7)

        self.ax3d.set_title(
            f"Diagrama 3-D — Columna {self._current_col_id}",
            fontsize=10, fontweight="bold", color="#1B4F72")
        self.canvas3d.draw()

    # ── 2-D: P vs Mx ─────────────────────────────────────────────────────────

    def _replot_2d_pmx(self):
        ax = self.ax_pmx
        ax.cla()
        ax.set_facecolor("#FDFEFE")
        ax.grid(True, alpha=0.3)

        if self.chk_nom.isChecked() and self._curves_nom:
            P_env, Mx_env = self._envelope_2d(self._curves_nom, axis=1)
            ax.plot(Mx_env, P_env, color="#85C1E9", linewidth=1.2,
                    label="Nominal", alpha=0.8)

        if self.chk_fac.isChecked() and self._curves_fac:
            P_env, Mx_env = self._envelope_2d(self._curves_fac, axis=1)
            ax.plot(Mx_env, P_env, color="#2E86C1", linewidth=2.0,
                    label="Factorado φ")

        if self.chk_dem.isChecked() and self._demand_pts:
            inside = [self._point_inside(p) for p in self._demand_pts]
            for (Pd, Mxd, _), ok in zip(self._demand_pts, inside):
                ax.scatter(abs(Mxd), Pd, c="#27AE60" if ok else "#E74C3C",
                           s=55, zorder=6, edgecolors="white", linewidths=0.5)

        ax.set_xlabel("Mrx  (ton·m)", fontsize=9)
        ax.set_ylabel("Pr  (ton)", fontsize=9)
        ax.set_title(f"P vs Mx — Columna {self._current_col_id}",
                     fontsize=10, fontweight="bold", color="#1B4F72")
        ax.legend(fontsize=8, framealpha=0.7)
        self.canvas_pmx.draw()

    # ── 2-D: P vs My ─────────────────────────────────────────────────────────

    def _replot_2d_pmy(self):
        ax = self.ax_pmy
        ax.cla()
        ax.set_facecolor("#FDFEFE")
        ax.grid(True, alpha=0.3)

        if self.chk_nom.isChecked() and self._curves_nom:
            P_env, My_env = self._envelope_2d(self._curves_nom, axis=2)
            ax.plot(My_env, P_env, color="#85C1E9", linewidth=1.2,
                    label="Nominal", alpha=0.8)

        if self.chk_fac.isChecked() and self._curves_fac:
            P_env, My_env = self._envelope_2d(self._curves_fac, axis=2)
            ax.plot(My_env, P_env, color="#2E86C1", linewidth=2.0,
                    label="Factorado φ")

        if self.chk_dem.isChecked() and self._demand_pts:
            inside = [self._point_inside(p) for p in self._demand_pts]
            for (Pd, _, Myd), ok in zip(self._demand_pts, inside):
                ax.scatter(abs(Myd), Pd, c="#27AE60" if ok else "#E74C3C",
                           s=55, zorder=6, edgecolors="white", linewidths=0.5)

        ax.set_xlabel("Mry  (ton·m)", fontsize=9)
        ax.set_ylabel("Pr  (ton)", fontsize=9)
        ax.set_title(f"P vs My — Columna {self._current_col_id}",
                     fontsize=10, fontweight="bold", color="#1B4F72")
        ax.legend(fontsize=8, framealpha=0.7)
        self.canvas_pmy.draw()

    # ── 2-D: Mx vs My ────────────────────────────────────────────────────────

    def _replot_2d_mxmy(self):
        ax = self.ax_mm
        ax.cla()
        ax.set_facecolor("#FDFEFE")
        ax.grid(True, alpha=0.3)

        # Nivel de P de referencia = Pu máx de la demanda (si existe)
        Pu_ref = None
        if self._demand_pts:
            Pu_ref = max(abs(d[0]) for d in self._demand_pts)

        if self.chk_nom.isChecked() and self._curves_nom:
            Mx_c, My_c = self._contour_at_P(self._curves_nom, Pu_ref)
            if len(Mx_c) > 1:
                ax.plot(Mx_c, My_c, color="#85C1E9", linewidth=1.2,
                        label="Nominal", alpha=0.8)

        if self.chk_fac.isChecked() and self._curves_fac:
            Mx_c, My_c = self._contour_at_P(self._curves_fac, Pu_ref)
            if len(Mx_c) > 1:
                ax.fill(Mx_c, My_c, color="#AED6F1", alpha=0.25, zorder=1)
                ax.plot(Mx_c, My_c, color="#2E86C1", linewidth=2.0,
                        label="Factorado φ")

        if self.chk_dem.isChecked() and self._demand_pts:
            inside = [self._point_inside(p) for p in self._demand_pts]
            for (Pd, Mxd, Myd), ok in zip(self._demand_pts, inside):
                ax.scatter(Mxd, Myd, c="#27AE60" if ok else "#E74C3C",
                           s=55, zorder=6, edgecolors="white", linewidths=0.5)

        # Ejes iguales para que sea un contorno simétrico
        ax.set_aspect("equal", adjustable="datalim")
        ax.axhline(0, color="#95A5A6", linewidth=0.6)
        ax.axvline(0, color="#95A5A6", linewidth=0.6)
        Pu_txt = f"Pu ≈ {Pu_ref:.1f} ton" if Pu_ref is not None else "Pu máx"
        ax.set_xlabel("Mrx  (ton·m)", fontsize=9)
        ax.set_ylabel("Mry  (ton·m)", fontsize=9)
        ax.set_title(
            f"Mx vs My — Col {self._current_col_id}  ({Pu_txt})",
            fontsize=10, fontweight="bold", color="#1B4F72")
        ax.legend(fontsize=8, framealpha=0.7)
        self.canvas_mm.draw()

    # ── Helpers de proyección 2-D ─────────────────────────────────────────────

    @staticmethod
    def _envelope_2d(curves: list, axis: int):
        """
        Curva de interacción UNIAXIAL P vs M sobre el eje pedido
        (axis=1 → Mx, axis=2 → My).

        En una superficie biaxial, cada curva es un meridiano a un ángulo θ:
        el punto es (Mx = Mr·cosθ, My = Mr·senθ). La curva P-Mx correcta es
        el meridiano de flexión pura sobre X (θ≈0, con My≈0); la de P-My es
        el meridiano θ≈90 (Mx≈0). Tomar el "máximo por nivel de P" mezclaba
        meridianos y producía una curva dentada — esto lo evita.

        Retorna (P_array, M_array) ordenados por P.
        """
        if not curves:
            return np.array([]), np.array([])

        other = 2 if axis == 1 else 1   # componente que debe ser ~0
        best = None
        best_off = None
        for curve in curves:
            if len(curve) < 2:
                continue
            off = float(np.mean(np.abs(curve[:, other])))
            if best_off is None or off < best_off:
                best_off = off
                best = curve
        if best is None:
            return np.array([]), np.array([])

        # Orden NATURAL de trazado (por profundidad del eje neutro): recorre
        # el diagrama de forma continua desde compresión pura hasta tensión.
        # No se ordena por P (eso plegaría la curva y crearía saltos).
        P = best[:, 0].astype(float)
        M = np.abs(best[:, axis]).astype(float)
        return P, M

    @staticmethod
    def _contour_at_P(curves: list, Pu_ref: Optional[float]):
        """
        Extrae la sección de la superficie a un nivel de P de referencia.
        Si Pu_ref=None usa el nivel P=0 (aproximadamente la carga balanceada).

        Para cada curva (ángulo) interpola el (Mx, My) al nivel Pu_ref.
        Retorna (Mx_list, My_list) cerrando el contorno.
        """
        if not curves:
            return [], []

        # Determinar Pu_ref automáticamente si no se da
        if Pu_ref is None:
            all_P = np.concatenate([c[:, 0] for c in curves if len(c) > 0])
            Pu_ref = float(np.median(np.abs(all_P))) * 0.5

        Mx_c: list = []
        My_c: list = []

        for curve in curves:
            if len(curve) < 3:
                continue
            P  = curve[:, 0]
            Mx = curve[:, 1]
            My = curve[:, 2]

            P_min, P_max = float(P.min()), float(P.max())
            if Pu_ref < P_min - 1e-3 or Pu_ref > P_max + 1e-3:
                continue
            try:
                sort_idx = np.argsort(P)
                Ps  = P[sort_idx]
                Mxs = Mx[sort_idx]
                Mys = My[sort_idx]
                mx_i = float(np.interp(Pu_ref, Ps, Mxs))
                my_i = float(np.interp(Pu_ref, Ps, Mys))
                Mx_c.append(mx_i)
                My_c.append(my_i)
            except Exception:
                continue

        if len(Mx_c) > 1:
            Mx_c.append(Mx_c[0])
            My_c.append(My_c[0])

        return Mx_c, My_c

    # ── Verificación punto dentro/fuera ───────────────────────────────────────

    def _point_inside(self, pt: tuple) -> bool:
        """Verifica si (Pd, Mxd, Myd) está dentro de la superficie factorada."""
        if not self._curves_fac:
            return self._inside_cloud(pt)

        Pd, Mxd, Myd = pt
        Mr_d = math.sqrt(Mxd**2 + Myd**2)

        if Mr_d < 1e-3:
            P_vals = np.concatenate([c[:, 0] for c in self._curves_fac
                                     if len(c) > 0])
            return float(P_vals.min()) <= Pd <= float(P_vals.max())

        theta_d = math.atan2(Myd, Mxd)
        best_cap = 0.0

        for curve in self._curves_fac:
            if len(curve) < 3:
                continue
            P_c  = curve[:, 0]
            Mx_c = curve[:, 1]
            My_c = curve[:, 2]
            Mr_c = np.sqrt(Mx_c**2 + My_c**2)

            peak_idx = int(np.argmax(Mr_c))
            theta_c  = math.atan2(float(My_c[peak_idx]), float(Mx_c[peak_idx]))
            delta    = abs(math.atan2(math.sin(theta_c - theta_d),
                                      math.cos(theta_c - theta_d)))
            if delta > math.pi / 4:
                continue

            if Pd < float(P_c.min()) - 1e-3 or Pd > float(P_c.max()) + 1e-3:
                continue
            try:
                sort_idx  = np.argsort(P_c)
                mr_interp = float(np.interp(Pd, P_c[sort_idx], Mr_c[sort_idx]))
                best_cap  = max(best_cap, mr_interp)
            except Exception:
                continue

        if best_cap > 1e-6:
            return Mr_d <= best_cap
        return self._inside_cloud(pt)

    def _inside_cloud(self, pt: tuple) -> bool:
        if self._fac_pts is None or len(self._fac_pts) == 0:
            return False
        Pd, Mxd, Myd = pt
        Mr_d = math.sqrt(Mxd**2 + Myd**2)
        tol  = max(abs(Pd) * 0.15, 5.0)
        mask = np.abs(self._fac_pts[:, 0] - Pd) < tol
        sub  = self._fac_pts[mask] if mask.sum() > 0 else self._fac_pts
        Mr_s = np.sqrt(sub[:, 1]**2 + sub[:, 2]**2)
        return float(Mr_s.max()) >= Mr_d

    # ── Estilo 3-D ────────────────────────────────────────────────────────────

    def _style_axes_3d(self):
        self.ax3d.set_xlabel("Mrx  (ton·m)", fontsize=9, labelpad=6)
        self.ax3d.set_ylabel("Mry  (ton·m)", fontsize=9, labelpad=6)
        self.ax3d.set_zlabel("Pr  (ton)",    fontsize=9, labelpad=6)
        self.ax3d.tick_params(labelsize=7)
        self.ax3d.set_facecolor("#FDFEFE")
        self.fig3d.patch.set_facecolor("#F5F6FA")
        self.ax3d.grid(True, alpha=0.3)

    # ── Exportar ──────────────────────────────────────────────────────────────

    def _export_image(self):
        tab = self._diag_tabs.currentIndex()
        _fig = [self.fig3d, self.fig_pmx, self.fig_pmy, self.fig_mm][tab]
        path, _ = QFileDialog.getSaveFileName(
            self, "Guardar diagrama",
            f"interaccion_col{self._current_col_id}.png",
            "PNG (*.png);;PDF (*.pdf)")
        if path:
            _fig.savefig(path, dpi=200, bbox_inches="tight",
                         facecolor=_fig.get_facecolor())

    def _export_to_word(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar a Word",
            f"diagrama_col{self._current_col_id}.docx",
            "Word (*.docx)")
        if not path:
            return
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        tmp.close()
        self.fig3d.savefig(tmp.name, dpi=180, bbox_inches="tight")
        from fileio.word_exporter import WordExporter
        exp   = WordExporter()
        diags = {self._current_col_id: {"fig_path": tmp.name}}
        params = {"code": "ACI", "fc": 0, "fy": 0,
                  "rec1": 0, "rec2": 0, "p_min": 0, "p_max": 0}
        exp.export_interaction_diagrams(diags, path, params)
        os.unlink(tmp.name)

    def save_figure(self, path: str, dpi: int = 180):
        """Guarda el diagrama 3-D (usado por la exportación de memoria)."""
        self.fig3d.savefig(path, dpi=dpi, bbox_inches="tight",
                           facecolor=self.fig3d.get_facecolor())
