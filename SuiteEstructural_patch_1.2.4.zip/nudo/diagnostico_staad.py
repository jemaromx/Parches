# -*- coding: utf-8 -*-
"""
Diagnóstico directo de OpenSTAAD para el diseño de nudos.

Conecta a STAAD Pro (con el modelo abierto y ANALIZADO), y para cada nodo
que tenga columna + trabes vuelca: miembros conectados, incidencias y
fuerzas de extremo (local y global) en el primer caso de carga.

Uso:
    _runtime\\python.exe nudo\\diagnostico_staad.py

Escribe el resultado en:
    %USERPROFILE%\\Desktop\\diagnostico_nudo.txt
"""
import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE.parent))

OUT = Path(os.path.expanduser("~")) / "Desktop" / "diagnostico_nudo.txt"
_lines = []


def w(msg=""):
    print(msg)
    _lines.append(str(msg))


def main():
    w("=" * 70)
    w(" DIAGNÓSTICO OpenSTAAD — Nudo")
    w("=" * 70)

    # 1. Conexión (misma vía que usa el script de nudo)
    try:
        from staad.connector import STAADConnector
        conn = STAADConnector()
        ok, msg = conn.connect()
        w(f"Conexión: {'OK' if ok else 'FALLO'} — {msg}")
        if not ok:
            return
    except Exception as exc:
        import traceback
        w("ERROR al conectar:\n" + traceback.format_exc())
        return

    geo = conn.geometry
    out = conn.output

    # 2. ¿Qué métodos expone el objeto Output? (clave para comtypes)
    w("\n-- Métodos disponibles en Output --")
    for name in ("GetMemberEndForces", "GetIntermediateMemberForcesAtDistance",
                 "AreResultsAvailable", "GetMinMaxBendingMoment"):
        w(f"  {name}: {'sí' if hasattr(out, name) else 'NO'}")
    w("\n-- Métodos de Geometry para incidencia/nodos --")
    for name in ("GetMemberIncidence", "GetBeamIncidence", "GetBeamList",
                 "GetMemberCount", "GetNodeCoordinates",
                 "GetMembersConnectedToNode", "GetBeamsConnectedToNode"):
        w(f"  {name}: {'sí' if hasattr(geo, name) else 'NO'}")

    # 3. Resultados disponibles
    try:
        w(f"\nAreResultsAvailable: {out.AreResultsAvailable()}")
    except Exception as exc:
        w(f"AreResultsAvailable FALLO: {exc}")

    # 4. Lista de barras y casos de carga
    try:
        beams = list(geo.GetBeamList())
        w(f"\nTotal de barras: {len(beams)}  primeras: {beams[:10]}")
    except Exception as exc:
        w(f"GetBeamList FALLO: {exc}")
        beams = []

    try:
        from staad.extractor import STAADExtractor
        ext = STAADExtractor(conn)
    except Exception as exc:
        import traceback
        w("ERROR creando extractor:\n" + traceback.format_exc())
        return

    lcs = conn.get_load_cases()
    w(f"Casos de carga: {lcs[:10]}")
    lc = lcs[0] if lcs else 1

    # 5. Incidencias de las primeras barras
    w("\n-- Incidencias (nodo_i, nodo_j) primeras 8 barras --")
    node_members = {}
    for b in beams[:200]:
        try:
            inc = ext.get_member_incidence(b)
            node_members.setdefault(inc.node_start, []).append(b)
            node_members.setdefault(inc.node_end, []).append(b)
            if b in beams[:8]:
                w(f"  barra {b}: ({inc.node_start}, {inc.node_end})")
        except Exception as exc:
            w(f"  barra {b}: incidencia FALLO: {exc}")

    # 6. Nodos con >=2 barras (candidatos a nudo) y sus fuerzas
    candidatos = {n: ms for n, ms in node_members.items() if n and len(ms) >= 2}
    w(f"\nNodos con >=2 barras: {len(candidatos)}")
    for node, ms in list(candidatos.items())[:3]:
        w(f"\n>>> Nodo {node} — miembros conectados: {ms}")
        for m in ms:
            w(f"    --- barra {m}, lc {lc} ---")
            try:
                floc = out.GetMemberEndForces(int(m), 0, int(lc), 0)
                w(f"    LOCAL  end0: {list(floc) if floc is not None else None}")
            except Exception as exc:
                w(f"    LOCAL  end0 FALLO: {exc}")
            try:
                fglo = out.GetMemberEndForces(int(m), 0, int(lc), 1)
                w(f"    GLOBAL end0: {list(fglo) if fglo is not None else None}")
            except Exception as exc:
                w(f"    GLOBAL end0 FALLO: {exc}")

    w("\n" + "=" * 70)
    w(" FIN")


if __name__ == "__main__":
    try:
        main()
    finally:
        OUT.write_text("\n".join(_lines), encoding="utf-8")
        print(f"\n\nGuardado en: {OUT}")
