# -*- coding: utf-8 -*-
"""
Diagnóstico del FLUJO DE DISEÑO de nudos (no solo extracción).

Conecta a STAAD, detecta nodos con columna+trabes, corre el diseñador real
y vuelca Vjh, vu, momentos de columna y trabes por nudo — para localizar
en qué punto se pierden los elementos mecánicos.

Uso (con STAAD abierto y analizado):
    _runtime\\python.exe nudo\\diagnostico_diseno.py

Salida en pantalla y en:  <carpeta de nudo>\\diagnostico_diseno.txt
"""
import os
import sys
import traceback
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE.parent))

OUT = _HERE / "diagnostico_diseno.txt"
_lines = []


def w(msg=""):
    print(msg)
    _lines.append(str(msg))


def main():
    w("=" * 70)
    w(" DIAGNÓSTICO — FLUJO DE DISEÑO DE NUDO")
    w("=" * 70)

    from staad.connector import STAADConnector
    from staad.extractor import STAADExtractor

    conn = STAADConnector()
    ok, msg = conn.connect()
    w(f"Conexión: {'OK' if ok else 'FALLO'} — {msg}")
    if not ok:
        return

    ext = STAADExtractor(conn)

    # Selector: detectar clase disponible
    import staad.selector as selmod
    SelCls = None
    for name in dir(selmod):
        obj = getattr(selmod, name)
        if isinstance(obj, type) and name.lower().endswith("selector"):
            SelCls = obj
    w(f"Clase selector: {SelCls}")
    try:
        sel = SelCls(conn, ext)
    except TypeError:
        sel = SelCls(ext)

    lcs = conn.get_load_cases()
    lc0, lc1 = (lcs[0], lcs[-1]) if lcs else (1, 1)
    w(f"Casos de carga: {lc0}..{lc1}")

    # Barras y nodos candidatos
    beams = list(conn.geometry.GetBeamList())
    node_members = {}
    for b in beams:
        inc = ext.get_member_incidence(b)
        node_members.setdefault(inc.node_start, []).append(b)
        node_members.setdefault(inc.node_end, []).append(b)
    cand = [n for n, ms in node_members.items() if n and len(ms) >= 3]
    w(f"Nodos candidatos (>=3 barras): {cand[:8]}")
    if not cand:
        w("No hay nodos con suficientes miembros."); return

    # Construir joints con el selector
    joints = sel.get_joints_from_nodes(cand[:5])
    for j in joints:
        col = getattr(j, "col_member", None)
        trabes = getattr(j, "trabe_members", [])
        w(f"\n>>> Nodo {j.node_id}")
        w(f"    columna: {getattr(col,'member_id',None)}  "
          f"(kind={getattr(col,'kind',None)})")
        w(f"    trabes:  {[t.member_id for t in trabes]}")
        if col is None or not trabes:
            w("    ⚠ sin columna o sin trabes → nudo se omite en el diseño")
            continue
        # Momentos crudos que alimentan Vjh
        for lc in range(lc0, min(lc0 + 2, lc1 + 1)):
            cef = ext.get_member_end_forces(col.member_id, lc)
            cinc = ext.get_member_incidence(col.member_id)
            Mcol = abs(cef.Mz_i if cinc.node_start == j.node_id else cef.Mz_f)
            Mtr = 0.0
            for t in trabes:
                tef = ext.get_member_end_forces(t.member_id, lc)
                tinc = ext.get_member_incidence(t.member_id)
                Mtr += abs(tef.Mz_i if tinc.node_start == j.node_id else tef.Mz_f)
            w(f"    lc {lc}: Mcol={Mcol:.1f} kgf·cm   ΣMtrabes={Mtr:.1f} kgf·cm")

    # Correr el diseñador completo
    w("\n-- Ejecutando JointDesigner --")
    try:
        from design.joint_designer import JointDesigner
        from design.code_parameters import CodeParameters
        # Parámetros mínimos
        cd = sel.get_column_joints([j.node_id for j in joints]) \
            if hasattr(sel, "get_column_joints") else None
        w(f"get_column_joints disponible: {cd is not None}")
    except Exception:
        w(traceback.format_exc())

    w("\n" + "=" * 70 + "\n FIN")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        w(traceback.format_exc())
    finally:
        OUT.write_text("\n".join(_lines), encoding="utf-8")
        print(f"\n\nGuardado en: {OUT}")
