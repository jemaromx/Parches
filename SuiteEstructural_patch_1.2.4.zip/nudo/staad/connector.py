﻿# -*- coding: utf-8 -*-
"""Conexion a STAAD Pro 2024 mediante openstaadpy (identico a footing_design_pro)."""
from __future__ import annotations
import logging
from typing import Tuple

log = logging.getLogger("joint_design.staad.connector")

try:
    from openstaadpy import os_analytical
    AVAILABLE = True
except Exception:
    AVAILABLE = False
    log.warning("openstaadpy no disponible -- instale con: pip install openstaadpy")


class STAADConnector:
    """Conexion con STAAD Pro 2024 via openstaadpy.

    Patron identico al usado en footing_design_pro/fileio/openstaad_reader.py:
        staad    = os_analytical.connect()
        geometry = staad.Geometry
        output   = staad.Output
        prop     = staad.Property
        load_mod = staad.Load
    """

    def __init__(self):
        self._staad    = None
        self._geometry = None
        self._output   = None
        self._prop     = None
        self._load_mod = None
        self.last_error = ""

    # ── Conexion ──────────────────────────────────────────────────────────────

    def connect(self) -> Tuple[bool, str]:
        """Conecta con STAAD Pro abierto.

        Returns:
            (True, mensaje_ok) o (False, mensaje_error)
        """
        if not AVAILABLE:
            self.last_error = (
                "openstaadpy no esta instalado.\n\n"
                "Instale con:\n"
                "    pip install openstaadpy\n\n"
                "Si no tiene STAAD Pro, use el boton MODO DEMO."
            )
            return False, self.last_error

        try:
            self._staad    = os_analytical.connect()
            self._geometry = self._staad.Geometry
            self._output   = self._staad.Output
            self._prop     = self._staad.Property
            try:
                self._load_mod = self._staad.Load
            except Exception:
                self._load_mod = None
        except Exception as exc:
            self.last_error = (
                f"No se pudo conectar a STAAD Pro:\n{exc}\n\n"
                "Verifique que:\n"
                "  1. STAAD Pro 2024 este ABIERTO\n"
                "  2. Haya un modelo (.std) cargado y analizado\n"
                "  3. El modelo tenga resultados (ejecute el analisis primero)\n\n"
                "Si no tiene STAAD Pro disponible, use el boton MODO DEMO."
            )
            log.error("Conexion fallida: %s", exc)
            return False, self.last_error

        # Verificar que haya resultados disponibles
        try:
            if not self._output.AreResultsAvailable():
                msg = (
                    "Conexion OK, pero el modelo no tiene resultados.\n"
                    "Ejecute el analisis en STAAD Pro primero (Analyze > Run Analysis)."
                )
                self.last_error = msg
                return False, msg
        except Exception:
            pass   # Algunos modelos no exponen AreResultsAvailable

        # Contar casos de carga como confirmacion
        lcs  = self._fetch_load_cases()
        n_lc = len(lcs)
        rng  = f" ({lcs[0]}-{lcs[-1]})" if n_lc else ""
        msg  = f"Conectado a STAAD Pro. {n_lc} casos de carga{rng}."
        log.info(msg)
        return True, msg

    def disconnect(self):
        self._staad    = None
        self._geometry = None
        self._output   = None
        self._prop     = None
        self._load_mod = None
        log.info("Desconectado de STAAD Pro")

    # ── Propiedades ───────────────────────────────────────────────────────────

    @property
    def is_connected(self) -> bool:
        return self._staad is not None

    @property
    def geometry(self):
        return self._geometry

    @property
    def output(self):
        return self._output

    @property
    def prop(self):
        return self._prop

    @property
    def load_mod(self):
        return self._load_mod

    # ── Utilidades ────────────────────────────────────────────────────────────

    def get_load_cases(self) -> list[int]:
        return self._fetch_load_cases()

    def get_file_name(self) -> str:
        try:
            return str(self._staad.GetSTAADFile())
        except Exception:
            try:
                return str(self._geometry.GetFileName())
            except Exception:
                return "modelo STAAD Pro"

    def _fetch_load_cases(self) -> list[int]:
        """Recupera lista de casos de carga (primarios + combinaciones)."""
        lcs: list[int] = []
        if self._load_mod is None:
            return lcs

        # Métodos NATIVOS de openstaadpy que devuelven la LISTA directa
        # (STAAD Pro 2025). Es lo que usan los scripts que sí funcionan.
        for list_name in ("GetPrimaryLoadCaseNumbers",
                          "GetLoadCombinationNumbers",
                          "GetLoadCaseNumbers"):
            fn = getattr(self._load_mod, list_name, None)
            if fn is None:
                continue
            try:
                raw = fn()
                if raw is not None:
                    for v in raw:
                        try:
                            lcs.append(int(v))
                        except Exception:
                            pass
            except Exception as exc:
                log.debug("%s(): %s", list_name, exc)
        if lcs:
            log.info("Casos de carga (API nativa): %s", sorted(set(lcs)))
            return sorted(set(lcs))

        # Fallback por conteo (versiones antiguas)
        for cnt in ("GetLoadCaseCount", "GetPrimaryLoadCaseCount",
                    "GetNoOfPrimaryLoadCases"):
            try:
                n = int(getattr(self._load_mod, cnt)())
                if n <= 0:
                    break
                for i in range(n):
                    for idn in ("GetLoadCaseID", "GetPrimaryLoadCaseID",
                                "GetLoadCaseNumber"):
                        try:
                            lcs.append(int(getattr(self._load_mod, idn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        # Combinaciones
        for cnt in ("GetLoadCombinationCount", "GetLoadComboCount",
                    "GetNoOfLoadCombinations"):
            try:
                n = int(getattr(self._load_mod, cnt)())
                if n <= 0:
                    break
                for i in range(n):
                    for idn in ("GetLoadCombinationID", "GetLoadComboID",
                                "GetCombinationCaseID"):
                        try:
                            lcs.append(int(getattr(self._load_mod, idn)(i)))
                            break
                        except Exception:
                            pass
                break
            except Exception:
                continue
        return sorted(set(lcs))
