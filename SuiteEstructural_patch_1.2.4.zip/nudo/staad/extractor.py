﻿# -*- coding: utf-8 -*-
"""Extraccion de geometria, propiedades y fuerzas del modelo STAAD Pro.

Patron identico a footing_design_pro/fileio/openstaad_reader.py:
  - geometry  = staad.Geometry
  - output    = staad.Output
  - prop      = staad.Property
  - Fuerzas en GLOBAL: GetMemberEndForces(beam_id, end=0, lc, LocalOrGlobal=1)
  - Unidades nativas openstaadpy: kN / kN*m -> convertimos a kgf / kgf*cm
"""
from __future__ import annotations
import math
import logging
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("joint_design.staad.extractor")

_KN_TO_KGF   = 101.9716      # 1 kN  = 101.97 kgf
_KNM_TO_KGFCM = 10_197.16    # 1 kN*m = 10197.16 kgf*cm
_M_TO_CM      = 100.0


# ── Estructuras de datos ──────────────────────────────────────────────────────

@dataclass
class NodeCoord:
    id: int
    x: float = 0.0   # cm
    y: float = 0.0
    z: float = 0.0


@dataclass
class MemberIncidence:
    id: int
    node_start: int = 0
    node_end:   int = 0


@dataclass
class SectionProps:
    """Propiedades de seccion en cm."""
    b:  float = 0.0    # ancho (cm)
    h:  float = 0.0    # peralte total (cm)
    Ag: float = 0.0    # area bruta (cm2)


@dataclass
class MaterialProps:
    fc:  float = 250.0        # kgf/cm2
    fy:  float = 4200.0       # kgf/cm2
    Es:  float = 2_040_000.0  # kgf/cm2


@dataclass
class MemberEndForces:
    """Fuerzas en extremo de miembro para una combinacion de carga.

    Convencion STAAD global (Y arriba):
        Fx_i = axial inicio, Fy_i = cortante Y inicio, Fz_i = cortante Z inicio
        Mx_i = torsion, My_i = momento Y, Mz_i = momento Z
    Unidades: kgf y kgf*cm (ya convertidos de kN/kN*m).
    """
    lc_id: int = 0
    Fx_i: float = 0.0;  Fy_i: float = 0.0;  Fz_i: float = 0.0
    Mx_i: float = 0.0;  My_i: float = 0.0;  Mz_i: float = 0.0
    Fx_f: float = 0.0;  Fy_f: float = 0.0;  Fz_f: float = 0.0
    Mx_f: float = 0.0;  My_f: float = 0.0;  Mz_f: float = 0.0


# ── Extractor ─────────────────────────────────────────────────────────────────

class STAADExtractor:
    """Extrae y cachea datos del modelo STAAD Pro via openstaadpy."""

    def __init__(self, connector):
        self._conn  = connector
        self._cache: dict = {}

    # ── Propiedades de acceso rapido ──────────────────────────────────────────
    @property
    def _geo(self):
        return self._conn.geometry

    @property
    def _out(self):
        return self._conn.output

    @property
    def _prop(self):
        return self._conn.prop

    # ── Nodos ─────────────────────────────────────────────────────────────────

    def get_node_coord(self, node_id: int) -> NodeCoord:
        key = ("node", node_id)
        if key in self._cache:
            return self._cache[key]
        try:
            c  = self._geo.GetNodeCoordinates(int(node_id))
            nc = NodeCoord(id=node_id,
                           x=float(c[0]) * _M_TO_CM,
                           y=float(c[1]) * _M_TO_CM,
                           z=float(c[2]) * _M_TO_CM)
        except Exception as exc:
            log.debug("GetNodeCoordinates(%d): %s", node_id, exc)
            nc = NodeCoord(id=node_id)
        self._cache[key] = nc
        return nc

    # ── Miembros ──────────────────────────────────────────────────────────────

    def get_all_member_ids(self) -> list[int]:
        key = "all_members"
        if key in self._cache:
            return self._cache[key]
        try:
            ids = sorted(int(x) for x in self._geo.GetBeamList())
        except Exception as exc:
            log.warning("GetBeamList: %s", exc)
            ids = []
        self._cache[key] = ids
        return ids

    def get_member_incidence(self, mid: int) -> MemberIncidence:
        key = ("inc", mid)
        if key in self._cache:
            return self._cache[key]
        # Probar varios nombres de método (patrón robusto de column_design_pro)
        for name in ("GetMemberIncidence", "GetBeamIncidence",
                     "GetMemberNodeNumbers", "GetBeamNodeNumbers",
                     "GetBeamEndNodes"):
            fn = getattr(self._geo, name, None)
            if fn is None:
                continue
            try:
                raw = fn(int(mid))
                if raw is not None and hasattr(raw, "__len__") and len(raw) >= 2:
                    inc = MemberIncidence(id=mid,
                                          node_start=int(raw[0]),
                                          node_end=int(raw[1]))
                    log.info("DIAG incidencia m=%d -> (%d, %d) via %s",
                             mid, inc.node_start, inc.node_end, name)
                    self._cache[key] = inc
                    return inc
            except Exception as exc:
                log.debug("%s(%d): %s", name, mid, exc)
        # Fallback: GetMemberStartNode / GetMemberEndNode
        try:
            ni = int(self._geo.GetMemberStartNode(int(mid)))
            nj = int(self._geo.GetMemberEndNode(int(mid)))
            inc = MemberIncidence(id=mid, node_start=ni, node_end=nj)
            log.info("DIAG incidencia m=%d -> (%d, %d) via StartNode/EndNode",
                     mid, ni, nj)
        except Exception as exc:
            log.warning("Incidencia miembro %d FALLO: %s", mid, exc)
            inc = MemberIncidence(id=mid)
        self._cache[key] = inc
        return inc

    def get_member_section(self, mid: int) -> SectionProps:
        """Lee b, h y Ag de la seccion. Patron igual a footing_design_pro."""
        key = ("sec", mid)
        if key in self._cache:
            return self._cache[key]
        try:
            # GetBeamPropertyAll devuelve [ZD, YD, ...] en metros
            raw = self._prop.GetBeamPropertyAll(int(mid))
            if raw is not None and len(raw) >= 2:
                ZD = float(raw[0]) * _M_TO_CM   # ancho local Z -> cm
                YD = float(raw[1]) * _M_TO_CM   # peralte local Y -> cm
                if YD > 0 and ZD > 0:
                    sec = SectionProps(b=ZD, h=YD, Ag=ZD * YD)
                elif YD > 0:   # seccion circular
                    sec = SectionProps(b=YD, h=YD,
                                       Ag=math.pi * (YD / 2) ** 2)
                else:
                    sec = SectionProps(b=30.0, h=30.0, Ag=900.0)
            else:
                sec = SectionProps(b=30.0, h=30.0, Ag=900.0)
        except Exception as exc:
            log.debug("GetBeamPropertyAll(%d): %s", mid, exc)
            sec = SectionProps(b=30.0, h=30.0, Ag=900.0)
        self._cache[key] = sec
        return sec

    def get_member_material(self, mid: int) -> MaterialProps:
        """Devuelve propiedades de material (E en kgf/cm2)."""
        key = ("mat", mid)
        if key in self._cache:
            return self._cache[key]
        mat = MaterialProps()   # valores por defecto
        self._cache[key] = mat
        return mat

    def get_member_length(self, mid: int) -> float:
        """Longitud del miembro en cm."""
        key = ("len", mid)
        if key in self._cache:
            return self._cache[key]
        try:
            inc = self.get_member_incidence(mid)
            ni  = self.get_node_coord(inc.node_start)
            nj  = self.get_node_coord(inc.node_end)
            L   = math.sqrt((nj.x - ni.x)**2 +
                             (nj.y - ni.y)**2 +
                             (nj.z - ni.z)**2)
        except Exception as exc:
            log.debug("Longitud miembro %d: %s", mid, exc)
            L = 300.0
        self._cache[key] = L
        return L

    # ── Fuerzas ───────────────────────────────────────────────────────────────

    def get_member_end_forces(self, mid: int, lc_id: int) -> MemberEndForces:
        """Fuerzas en ambos extremos del miembro en coordenadas LOCALES.

        Usa GetMemberEndForces(beam_id, end, lc, LocalOrGlobal=0) igual que
        beam_design_pro y column_design_pro (flag=0 = LOCAL). En ejes locales
        el momento Mz es la flexion principal (mayor), que es la que genera el
        cortante del nudo; en globales esa componente sale casi nula.
        Unidades del modelo: kN y kN*m -> se convierten a kgf y kgf*cm.
        end=0 -> extremo inicial, end=1 -> extremo final.
        """
        key = ("forces", mid, lc_id)
        if key in self._cache:
            return self._cache[key]

        kn, km = _KN_TO_KGF, _KNM_TO_KGFCM
        ef = MemberEndForces(lc_id=lc_id)

        try:
            # Extremo inicio (end=0), coordenadas LOCALES (flag=0)
            vi = self._out.GetMemberEndForces(int(mid), 0, int(lc_id), 0)
            log.info("DIAG fuerzas m=%d end=0 lc=%d -> %r", mid, lc_id, vi)
            if vi is not None and len(vi) >= 6:
                ef.Fx_i = float(vi[0]) * kn
                ef.Fy_i = float(vi[1]) * kn
                ef.Fz_i = float(vi[2]) * kn
                ef.Mx_i = float(vi[3]) * km
                ef.My_i = float(vi[4]) * km
                ef.Mz_i = float(vi[5]) * km
        except Exception as exc:
            log.warning("GetMemberEndForces(m=%d end=0 lc=%d) FALLO: %s", mid, lc_id, exc)

        try:
            # Extremo fin (end=1), coordenadas LOCALES (flag=0)
            vf = self._out.GetMemberEndForces(int(mid), 1, int(lc_id), 0)
            if vf is not None and len(vf) >= 6:
                ef.Fx_f = float(vf[0]) * kn
                ef.Fy_f = float(vf[1]) * kn
                ef.Fz_f = float(vf[2]) * kn
                ef.Mx_f = float(vf[3]) * km
                ef.My_f = float(vf[4]) * km
                ef.Mz_f = float(vf[5]) * km
        except Exception as exc:
            log.warning("GetMemberEndForces(m=%d end=1 lc=%d) FALLO: %s", mid, lc_id, exc)

        self._cache[key] = ef
        return ef

    # ── Busqueda de miembros conectados a un nodo ──────────────────────────────

    def find_members_at_node(self, node_id: int,
                              exclude_ids: Optional[set] = None) -> list[int]:
        """Devuelve IDs de miembros que tienen node_id como nodo ini o fin.

        Patron identico a footing_design_pro/_beams_at_node:
        primero intenta GetMembersConnectedToNode, luego busqueda lineal.
        """
        exclude = exclude_ids or set()
        geo = self._geo

        # Intentar API directa
        for name in ("GetMembersConnectedToNode", "GetBeamsConnectedToNode"):
            fn = getattr(geo, name, None)
            if fn:
                try:
                    ids = [int(x) for x in fn(int(node_id)) if x]
                    ids = [i for i in ids if i not in exclude]
                    if ids:
                        return ids
                except Exception:
                    pass

        # Fallback: recorrer todos los miembros
        connected = []
        for mid in self.get_all_member_ids():
            if mid in exclude:
                continue
            inc = self.get_member_incidence(mid)
            if inc.node_start == node_id or inc.node_end == node_id:
                connected.append(mid)
        log.info("DIAG miembros en nodo %d (excl %s): %s",
                 node_id, sorted(exclude), connected)
        return connected

    # ── Pre-carga (hilo principal antes de lanzar QThread) ────────────────────

    def pre_fetch(self, col_ids: list[int], trabe_ids: list[int],
                  lc_ids: list[int]) -> None:
        """Pre-carga todas las propiedades y fuerzas en el hilo principal COM.

        Debe llamarse ANTES de lanzar el QThread de diseno (igual que
        footing_design_pro usa pre_fetch_members + dump_cache).
        """
        all_ids = list(set(col_ids + trabe_ids))
        for mid in all_ids:
            self.get_member_incidence(mid)
            self.get_member_section(mid)
            self.get_member_length(mid)
            inc = self.get_member_incidence(mid)
            self.get_node_coord(inc.node_start)
            self.get_node_coord(inc.node_end)
            for lc in lc_ids:
                self.get_member_end_forces(mid, lc)
        log.info("pre_fetch: %d miembros x %d CL cacheados",
                 len(all_ids), len(lc_ids))

    def clear_cache(self):
        self._cache.clear()
        log.debug("Cache extractor limpiada")
