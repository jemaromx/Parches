# -*- coding: utf-8 -*-
"""Generador de memoria de cálculo en formato Word (.docx) para nudos.

Estructura (por cada columna/nudo):
    1. Geometría del nudo
    2. Elementos mecánicos (solo del código seleccionado por el usuario)
    3. Diseño del refuerzo transversal
    4. Desarrollo de cálculos — fórmulas con referencia a la norma y
       operaciones numéricas del caso más desfavorable
    5. Gráficas del nudo y su armado
    6. Recomendaciones cuando la relación de esfuerzos supera la unidad
"""
from __future__ import annotations

import io
import logging
from datetime import datetime

try:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    DOCX_OK = True
except ImportError:            # pragma: no cover
    DOCX_OK = False

log = logging.getLogger("joint_design.report.docx")

_AZUL   = RGBColor(0x1B, 0x4F, 0x72) if DOCX_OK else None
_VERDE  = RGBColor(0x1E, 0x84, 0x49) if DOCX_OK else None
_ROJO   = RGBColor(0x92, 0x2B, 0x21) if DOCX_OK else None
_GRIS   = RGBColor(0x56, 0x65, 0x73) if DOCX_OK else None

# (tipo_nudo): (gamma_NTC, gamma_ACI_psi)  — igual a config.settings
_GAMMA = {
    "interior":         (3.20, 20.0),
    "exterior_borde":   (2.40, 15.0),
    "exterior_esquina": (1.60, 12.0),
    "en_T":             (2.40, 15.0),
}


class DocxGenerator:
    """Genera la memoria de cálculo de nudos en Word."""

    def __init__(self, output_path: str, project_name: str = "Proyecto",
                 engineer: str = "", revision: str = "A",
                 params: dict | None = None,
                 use_ntc: bool = True, use_aci: bool = True):
        self.output_path  = output_path
        self.project_name = project_name
        self.engineer     = engineer
        self.revision     = revision
        self.params       = params or {}
        self.use_ntc      = use_ntc
        self.use_aci      = use_aci

    # ── API principal (compatible con ExportWorker) ───────────────────────────
    def generate(self, envelope_results: list,
                 fig_plan=None, fig_elev=None, fig_3d=None,
                 figs_por_nudo: dict | None = None,
                 progress_cb=None) -> bool:
        if not DOCX_OK:
            log.error("python-docx no instalado")
            return False
        cb = progress_cb or (lambda p, m: None)
        figs_por_nudo = figs_por_nudo or {}

        doc = Document()
        st = doc.styles["Normal"]
        st.font.name = "Calibri"
        st.font.size = Pt(10)

        cb(3, "Generando portada…")
        self._cover(doc)

        cb(6, "Datos generales…")
        self._h1(doc, "1. DATOS GENERALES")
        norm_rows = [["Normativa", "Descripción"]]
        if self.use_ntc:
            norm_rows.append(["NTC 2023 DEC",
                "Normas Técnicas Complementarias para Diseño y Construcción "
                "de Estructuras de Concreto — CDMX 2023"])
        if self.use_aci:
            norm_rows.append(["ACI 318-25",
                "Building Code Requirements for Structural Concrete — "
                "ACI 2025"])
        self._table(doc, norm_rows)
        fc = self.params.get("fc", 0.0)
        fy = self.params.get("fy", 0.0)
        if fc and fy:
            self._table(doc, [["Parámetro", "Valor", "Unidad"],
                              ["f'c", f"{fc:.0f}", "kgf/cm²"],
                              ["fy",  f"{fy:.0f}", "kgf/cm²"],
                              ["Ductilidad",
                               str(self.params.get("ductility", "—")), "—"]])

        n = max(len(envelope_results), 1)
        for i, env in enumerate(envelope_results, 1):
            cb(8 + int(85 * (i - 1) / n),
               f"Nudo Col {env.col_id} ({i}/{n})…")
            doc.add_page_break()
            self._h1(doc, f"{i + 1}. NUDO — COLUMNA {env.col_id} | "
                          f"NODO {env.node_id}")
            self._geometry(doc, env)
            self._forces(doc, env)
            self._reinforcement(doc, env)
            self._calculations(doc, env)
            self._graphics(doc, env, figs_por_nudo.get(env.col_id)
                           or figs_por_nudo.get(i - 1))
            self._recommendations(doc, env)

        cb(94, "Conclusiones…")
        doc.add_page_break()
        self._h1(doc, f"{len(envelope_results) + 2}. CONCLUSIONES")
        self._conclusions(doc, envelope_results)

        cb(97, "Guardando documento…")
        doc.save(self.output_path)
        cb(100, "Word generado")
        return True

    # ── Portada ───────────────────────────────────────────────────────────────
    def _cover(self, doc):
        codes = " | ".join(c for c, u in
                           [("NTC 2023 DEC", self.use_ntc),
                            ("ACI 318-25", self.use_aci)] if u) or "—"
        for txt, size, bold in [
                ("MEMORIA DE CÁLCULO", 22, True),
                ("Diseño de Nudos Columna–Trabe", 16, True),
                (codes, 11, False),
                ("", 11, False),
                (f"Proyecto: {self.project_name}", 12, False),
                (f"Elaboró: {self.engineer or '—'}", 11, False),
                (f"Revisión: {self.revision}", 11, False),
                (f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}", 11, False)]:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(txt)
            r.font.size = Pt(size)
            r.font.bold = bold
            r.font.color.rgb = _AZUL
        doc.add_page_break()

    # ── a) Geometría ──────────────────────────────────────────────────────────
    def _geometry(self, doc, env):
        jg = env.joint_geometry
        self._h2(doc, "a)  Geometría del nudo")
        rows = [["Parámetro", "Valor", "Unidad", "Norma"],
                ["Tipo de nudo", jg.joint_type.upper(), "—",
                 "NTC §8.3 / ACI §18.8.3"],
                ["b columna", f"{jg.b_col:.1f}", "cm", "STAAD Pro"],
                ["h columna", f"{jg.h_col:.1f}", "cm", "STAAD Pro"],
                ["Área efectiva Aj = b×h", f"{jg.Aj:.1f}", "cm²",
                 "NTC §8.3.3 / ACI §18.8.4.3"],
                ["Lados confinados", str(jg.confinement_sides), "—",
                 "Trabes conectadas"],
                ["Trabes conectadas", str(jg.n_trabes_framing), "—",
                 "STAAD Pro"]]
        for d in getattr(jg, "trabe_details", []) or []:
            ok = "CUMPLE" if d.get("ok", True) else "NO CUMPLE"
            rows.append([
                f"Trabe {d.get('id', '?')}  (b×h)",
                f"{d.get('b', 0):.0f} × {d.get('h', 0):.0f}", "cm",
                f"h_col/h_trabe = {d.get('ratio', 0):.2f} ≥ 1.20 → {ok}"])
        self._table(doc, rows)
        for w in jg.warnings:
            self._warn(doc, w)

    # ── b) Elementos mecánicos (solo código seleccionado) ────────────────────
    def _forces(self, doc, env):
        self._h2(doc, "b)  Elementos mecánicos por combinación de carga")
        hdr = ["LC", "Mci (t·m)", "Mcs (t·m)", "Vcol (t)",
               "Vjh (t)", "vu (kgf/cm²)"]
        if self.use_ntc:
            hdr += ["φVn NTC (t)", "DCR NTC"]
        if self.use_aci:
            hdr += ["φVn ACI (t)", "DCR ACI"]
        rows = [hdr]
        for cr in env.combos:
            jf = cr.joint_force
            if not jf:
                continue
            row = [str(jf.lc_id),
                   f"{jf.Mci/1e5:.2f}", f"{jf.Mcs/1e5:.2f}",
                   f"{jf.Vcol/1000:.2f}",
                   f"{jf.Vjh/1000:.2f}", f"{jf.vu:.3f}"]
            if self.use_ntc:
                row += [f"{jf.Vn_NTC/1000:.2f}", f"{jf.DCR_NTC:.3f}"]
            if self.use_aci:
                row += [f"{jf.Vn_ACI/1000:.2f}", f"{jf.DCR_ACI:.3f}"]
            rows.append(row)
        self._table(doc, rows)

    # ── c) Refuerzo transversal ───────────────────────────────────────────────
    def _reinforcement(self, doc, env):
        self._h2(doc, "c)  Diseño del refuerzo transversal")
        worst_cr = (env.combos[env.worst_Ash]
                    if env.combos and env.worst_Ash < len(env.combos) else None)
        conf = worst_cr.confinement if worst_cr else None
        lap  = worst_cr.lap_splice  if worst_cr else None
        if conf:
            rows = [["Parámetro", "Valor", "Unidad", "Norma"]]
            if self.use_ntc:
                rows.append(["Ash req. NTC", f"{conf.Ash_req_NTC:.2f}",
                             "cm²", "NTC Tabla 8.3.4"])
            if self.use_aci:
                rows.append(["Ash req. ACI", f"{conf.Ash_req_ACI:.2f}",
                             "cm²", "ACI §18.7.5.4"])
            rows += [["Ash gobernante", f"{conf.Ash_req:.2f}", "cm²", "máx."],
                     ["Ash provista", f"{conf.Ash_prov:.2f}", "cm²",
                      "n_ramas × Ab"],
                     ["s máxima", f"{conf.s_max_cm:.1f}", "cm",
                      "NTC §8.3.4 / ACI §18.7.5.3"],
                     ["s provista", f"{conf.s_prov_cm:.0f}", "cm", "—"],
                     ["lo (zona confinada)", f"{conf.lo_cm:.1f}", "cm",
                      "NTC §8.3.4 / ACI §18.7.5.1"],
                     ["Ø estribo", f"{conf.db_est_cm*10:.0f} mm", "—", "—"],
                     ["No. ramas", str(conf.n_ramas), "—", "—"]]
            self._table(doc, rows)
        if lap:
            doc.add_paragraph(
                f"Longitudes de desarrollo (NTC §6.1 / ACI §25.4):  "
                f"Ld = {lap.Ld_cm:.1f} cm  |  Ldh = {lap.Ldh_cm:.1f} cm  |  "
                f"Ls (traslape) = {lap.Ls_cm:.1f} cm")
        prop = getattr(env, "estribos_prop", None)
        if prop is not None:
            p2 = doc.add_paragraph()
            r2 = p2.add_run("Propuesta de estribos (ACI Detailing Manual "
                            "MNL-66):")
            r2.font.bold = True
            _n = getattr(env, "estribos_prop_nvar", 0)
            if _n:
                doc.add_paragraph(f"Armado longitudinal estimado: {_n} varillas.")
            doc.add_paragraph(prop.descripcion)
            for nota in getattr(prop, "notas", []):
                doc.add_paragraph(f"Nota: {nota}")

    # ── d) Desarrollo de cálculos (caso más desfavorable) ────────────────────
    def _calculations(self, doc, env):
        self._h2(doc, "d)  Desarrollo de cálculos — combinación más "
                      "desfavorable")
        jg = env.joint_geometry
        jf_list = [c.joint_force for c in env.combos if c.joint_force]
        if not jf_list:
            doc.add_paragraph("Sin elementos mecánicos disponibles.")
            return
        idx = min(getattr(env, "worst_shear_ntc", 0), len(jf_list) - 1)
        jf = jf_list[idx]
        fc = self.params.get("fc", 250.0)
        g_ntc, g_aci = _GAMMA.get(jg.joint_type, (2.4, 15.0))
        jd = 0.875 * jf.h_col

        def formula(titulo, ref, texto):
            p = doc.add_paragraph()
            r = p.add_run(f"{titulo}   [{ref}]")
            r.font.bold = True
            r.font.color.rgb = _AZUL
            r.font.size = Pt(9.5)
            q = doc.add_paragraph()
            rq = q.add_run(texto)
            rq.font.name = "Consolas"
            rq.font.size = Pt(8.5)

        doc.add_paragraph(
            f"Combinación gobernante: LC {jf.lc_id}   |   "
            f"Tipo de nudo: {jg.joint_type.upper()}")

        formula(
            "1. Cortante horizontal del nudo Vjh",
            "NTC 2023 §8.3.2 / ACI 318-25 §R18.8.4",
            f"Vjh = (Mci + Mcs)/jd − Vcol ;   jd ≈ 0.875·h_col\n"
            f"jd  = 0.875 × {jf.h_col:.1f} = {jd:.1f} cm\n"
            f"Vjh = ({jf.Mci:,.0f} + {jf.Mcs:,.0f}) / {jd:.1f} "
            f"− {jf.Vcol:,.0f}\n"
            f"Vjh = {jf.Vjh:,.0f} kgf = {jf.Vjh/1000:.2f} t")

        formula(
            "2. Esfuerzo cortante actuante vu",
            "NTC 2023 §8.3.3 / ACI 318-25 §18.8.4.3",
            f"vu = |Vjh| / Aj = {abs(jf.Vjh):,.0f} / {jg.Aj:,.0f}\n"
            f"vu = {jf.vu:.3f} kgf/cm²")

        if self.use_ntc:
            vn_ntc = g_ntc * (fc ** 0.5)
            formula(
                "3. Resistencia del nudo — NTC 2023",
                "NTC 2023 §8.3.3 (nudo "
                + jg.joint_type.replace("_", " ") + ")",
                f"VR = FR · γ · √f'c · Aj ;   γ = {g_ntc:.2f} "
                f"(confinamiento en {jg.confinement_sides} caras)\n"
                f"vn = {g_ntc:.2f} × √{fc:.0f} = {vn_ntc:.2f} kgf/cm²\n"
                f"φVn = {jf.Vn_NTC:,.0f} kgf = {jf.Vn_NTC/1000:.2f} t\n"
                f"DCR = Vjh/φVn = {abs(jf.Vjh):,.0f} / {jf.Vn_NTC:,.0f} "
                f"= {jf.DCR_NTC:.3f}  → "
                + ("CUMPLE" if jf.ok_shear_NTC else "NO CUMPLE"))

        if self.use_aci:
            formula(
                "4. Resistencia del nudo — ACI 318-25",
                "ACI 318-25 Tabla 18.8.4.3",
                f"Vn = γ · √f'c(psi) · Aj ;   γ = {g_aci:.0f} "
                f"(nudo {jg.joint_type.replace('_', ' ')})\n"
                f"φVn = {jf.Vn_ACI:,.0f} kgf = {jf.Vn_ACI/1000:.2f} t\n"
                f"DCR = Vjh/φVn = {abs(jf.Vjh):,.0f} / {jf.Vn_ACI:,.0f} "
                f"= {jf.DCR_ACI:.3f}  → "
                + ("CUMPLE" if jf.ok_shear_ACI else "NO CUMPLE"))

        worst_cr = (env.combos[env.worst_Ash]
                    if env.combos and env.worst_Ash < len(env.combos) else None)
        conf = worst_cr.confinement if worst_cr else None
        if conf:
            fy = self.params.get("fy", 4200.0)
            formula(
                "5. Confinamiento — acero transversal Ash",
                "NTC 2023 Tabla 8.3.4 / ACI 318-25 §18.7.5.4",
                "Ash ≥ máx[ 0.30·(Ag/Ach − 1)·(f'c/fy)·s·bc ,  "
                "0.09·(f'c/fy)·s·bc ]\n"
                + (f"Ash req NTC = {conf.Ash_req_NTC:.2f} cm²   "
                   if self.use_ntc else "")
                + (f"Ash req ACI = {conf.Ash_req_ACI:.2f} cm²\n"
                   if self.use_aci else "\n")
                + f"Ash gobernante = {conf.Ash_req:.2f} cm²  ≤  "
                  f"Ash provista = {conf.Ash_prov:.2f} cm²  → "
                + ("CUMPLE" if conf.Ash_prov >= conf.Ash_req else "NO CUMPLE")
                + f"\nEstribo Ø{conf.db_est_cm*10:.0f} mm, {conf.n_ramas} "
                  f"ramas @ {conf.s_prov_cm:.0f} cm en lo = {conf.lo_cm:.0f} cm")

        cap = worst_cr.capacity_design if worst_cr else None
        if cap is not None and getattr(cap, "applies", False):
            formula(
                "6. Diseño por capacidad — columna fuerte / trabe débil",
                "NTC 2023 §8.2 / ACI 318-25 §18.7.3.2",
                f"ΣMnc / ΣMnb ≥ 1.20 (NTC) / 6/5 (ACI)\n"
                f"ΣMnc/ΣMnb = {cap.ratio:.3f}  → "
                + ("CUMPLE" if cap.ratio >= 1.2 else "NO CUMPLE"))

    # ── e) Gráficas ───────────────────────────────────────────────────────────
    def _graphics(self, doc, env, figs):
        self._h2(doc, "e)  Gráficas del nudo y su armado")
        if not figs:
            doc.add_paragraph("(Sin gráficas disponibles para este nudo.)")
            return
        titulos = ("Vista en planta", "Elevación y armado", "Render 3D")
        for fig, tit in zip(figs, titulos):
            if fig is None:
                continue
            p = doc.add_paragraph()
            r = p.add_run(tit)
            r.font.bold = True
            r.font.size = Pt(9.5)
            r.font.color.rgb = _GRIS
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=140, bbox_inches="tight")
            buf.seek(0)
            doc.add_picture(buf, width=Cm(15))

    # ── f) Recomendaciones si DCR > 1 ─────────────────────────────────────────
    def _recommendations(self, doc, env):
        dcr_ntc = getattr(env, "DCR_NTC_max", 0.0) if self.use_ntc else 0.0
        dcr_aci = getattr(env, "DCR_ACI_max", 0.0) if self.use_aci else 0.0
        dcr = max(dcr_ntc, dcr_aci)
        if dcr <= 1.0:
            return
        jg = env.joint_geometry
        self._h2(doc, "f)  Recomendaciones — la relación de esfuerzos "
                      f"supera la unidad (DCR = {dcr:.2f})")
        recs = [
            f"Aumentar la sección de la columna: el área efectiva del nudo "
            f"Aj = b×h ({jg.b_col:.0f}×{jg.h_col:.0f} cm) crece directamente "
            f"la resistencia φVn. Se requiere incrementar Aj al menos "
            f"{(dcr - 1.0) * 100:.0f} %.",
            "Aumentar f'c del concreto: la resistencia del nudo es "
            "proporcional a √f'c (p. ej., pasar de 250 a 350 kgf/cm² "
            "incrementa φVn ≈ 18 %).",
        ]
        if jg.joint_type != "interior":
            recs.append(
                "Agregar trabes que confinen el nudo en más caras: pasar de "
                f"nudo {jg.joint_type.replace('_', ' ')} a interior aumenta "
                "el factor γ (NTC: 1.6/2.4 → 3.2; ACI: 12/15 → 20).")
        recs += [
            "Reducir la demanda: revisar la redistribución de momentos en "
            "las trabes que llegan al nudo o disminuir el acero longitudinal "
            "de trabes (menor Ts = As·1.25·fy transmitida al nudo).",
            "Verificar que las trabes se apoyen concéntricamente y cubran al "
            "menos 3/4 del ancho de la columna para poder considerar el "
            "nudo como confinado (NTC §8.3.1 / ACI §18.8.4).",
        ]
        for rtxt in recs:
            p = doc.add_paragraph(style="List Bullet")
            r = p.add_run(rtxt)
            r.font.size = Pt(9)
            r.font.color.rgb = _ROJO if rtxt is recs[0] else None or _GRIS

    # ── Conclusiones ──────────────────────────────────────────────────────────
    def _conclusions(self, doc, envelope_results):
        def _dcr(e):
            return max(getattr(e, "DCR_NTC_max", 0) if self.use_ntc else 0,
                       getattr(e, "DCR_ACI_max", 0) if self.use_aci else 0)
        n = len(envelope_results)
        malos = [e for e in envelope_results if _dcr(e) > 1.0]
        if not malos:
            txt, color = (f"Los {n} nudos revisados CUMPLEN con los "
                          "requisitos de cortante y confinamiento de las "
                          "normativas seleccionadas.", _VERDE)
        else:
            ids = ", ".join(f"Col {e.col_id}/Nodo {e.node_id}" for e in malos)
            txt, color = (f"{len(malos)} de {n} nudos NO CUMPLEN ({ids}). "
                          "Consulte las recomendaciones de cada nudo.", _ROJO)
        p = doc.add_paragraph()
        r = p.add_run(txt)
        r.font.bold = True
        r.font.color.rgb = color
        doc.add_paragraph(
            "Esta memoria fue generada automáticamente por la Suite "
            "Estructural. Los resultados deben ser verificados por un "
            "ingeniero responsable.")

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _h1(self, doc, text):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.font.size = Pt(13)
        r.font.bold = True
        r.font.color.rgb = _AZUL

    def _h2(self, doc, text):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.font.size = Pt(11)
        r.font.bold = True
        r.font.color.rgb = _AZUL

    def _warn(self, doc, text):
        p = doc.add_paragraph()
        r = p.add_run(f"⚠ {text}")
        r.font.color.rgb = _ROJO
        r.font.size = Pt(9)

    def _table(self, doc, rows):
        if not rows:
            return None
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Light Grid Accent 1"
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                cell = t.cell(i, j)
                cell.text = str(val)
                for par in cell.paragraphs:
                    for run in par.runs:
                        run.font.size = Pt(8.5)
                        if i == 0:
                            run.font.bold = True
        doc.add_paragraph()
        return t
