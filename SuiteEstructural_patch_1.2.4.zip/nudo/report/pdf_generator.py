﻿"""Generador de memoria de cálculo en PDF usando ReportLab."""
from __future__ import annotations
import io
import math
import os
import tempfile
from datetime import datetime
from typing import Optional

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, Image, HRFlowable, KeepTogether,
    )
    from reportlab.platypus.tableofcontents import TableOfContents
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
    REPORTLAB_OK = True
except ImportError:
    REPORTLAB_OK = False

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ── Colores corporativos ───────────────────────────────────────────────────────
C_PRIMARY = colors.HexColor("#1B4F72")
C_SECOND  = colors.HexColor("#2874A6")
C_ACCENT  = colors.HexColor("#475C6B")
C_OK      = colors.HexColor("#D5F5E3")
C_FAIL    = colors.HexColor("#FADBD8")
C_WARN    = colors.HexColor("#FDEBD0")
C_LIGHT   = colors.HexColor("#F4F6F7")
C_DARK    = colors.HexColor("#1C2833")


class PDFGenerator:
    """Genera la memoria de cálculo completa en formato PDF."""

    PAGE_SIZE = A4

    def __init__(self, output_path: str, project_name: str = "Proyecto",
                 engineer: str = "", revision: str = "A"):
        self.output_path  = output_path
        self.project_name = project_name
        self.engineer     = engineer
        self.revision     = revision
        self._story: list = []

    def generate(self, envelope_results: list,
                 fig_plan=None, fig_elev=None, fig_3d=None,
                 progress_cb=None) -> bool:
        """Genera el PDF completo.

        Args:
            envelope_results: lista de EnvelopeResult
            fig_plan, fig_elev, fig_3d: figuras matplotlib opcionales
            progress_cb: callback(int, str)

        Returns:
            True si se generó correctamente
        """
        if not REPORTLAB_OK:
            print("ERROR: ReportLab no instalado. pip install reportlab")
            return False

        cb = progress_cb or (lambda p, m: None)
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.PAGE_SIZE,
            rightMargin=2*cm, leftMargin=2*cm,
            topMargin=2.5*cm, bottomMargin=2.5*cm,
        )
        styles = self._build_styles()
        self._story = []

        cb(5, "Generando portada…")
        self._add_cover(styles)
        self._story.append(PageBreak())

        cb(15, "Sección 1: Datos generales…")
        self._add_section_general(styles, envelope_results)

        cb(30, "Sección 2: Geometría…")
        for i, env in enumerate(envelope_results):
            self._add_section_geometry(styles, env, i + 1)

        cb(45, "Sección 3: Elementos mecánicos…")
        for i, env in enumerate(envelope_results):
            self._add_section_forces(styles, env, i + 1)

        cb(60, "Sección 4: Verificaciones de resistencia…")
        for i, env in enumerate(envelope_results):
            self._add_section_verification(styles, env, i + 1)

        cb(75, "Sección 5: Diseño de refuerzo…")
        for i, env in enumerate(envelope_results):
            self._add_section_reinforcement(styles, env, i + 1)

        cb(85, "Sección 6: Gráficas…")
        self._add_section_graphics(styles, fig_plan, fig_elev, fig_3d)

        cb(92, "Sección 7: Conclusiones…")
        self._add_section_conclusions(styles, envelope_results)

        cb(97, "Compilando PDF…")
        doc.build(self._story,
                  onFirstPage=self._page_template,
                  onLaterPages=self._page_template)
        cb(100, "PDF generado")
        return True

    # ── Portada ───────────────────────────────────────────────────────────────
    def _add_cover(self, styles):
        s = self._story
        s.append(Spacer(1, 2*cm))
        s.append(Paragraph("JOINT DESIGN PRO", styles["cover_title"]))
        s.append(Spacer(1, 0.5*cm))
        s.append(HRFlowable(width="100%", thickness=3, color=C_PRIMARY))
        s.append(Spacer(1, 0.3*cm))
        s.append(Paragraph("MEMORIA DE CÁLCULO", styles["cover_subtitle"]))
        s.append(Paragraph("DISEÑO DE NUDOS COLUMNA-TRABE", styles["cover_subtitle"]))
        s.append(Spacer(1, 1.5*cm))
        info = [
            ["Proyecto:",  self.project_name],
            ["Ingeniero:", self.engineer or "—"],
            ["Fecha:",     datetime.now().strftime("%d/%m/%Y")],
            ["Revisión:",  self.revision],
            ["Normativas:", "NTC 2023 DEC  |  ACI 318-25"],
        ]
        t = Table(info, colWidths=[5*cm, 10*cm])
        t.setStyle(TableStyle([
            ("FONT",      (0,0), (-1,-1), "Helvetica",    9),
            ("FONT",      (0,0), (0,-1),  "Helvetica-Bold", 9),
            ("TEXTCOLOR", (0,0), (0,-1),  C_PRIMARY),
            ("ROWBACKGROUNDS", (0,0), (-1,-1), [C_LIGHT, colors.white]),
            ("GRID",      (0,0), (-1,-1), 0.3, C_ACCENT),
            ("TOPPADDING",(0,0), (-1,-1), 4),
            ("BOTTOMPADDING",(0,0), (-1,-1), 4),
        ]))
        s.append(t)
        s.append(Spacer(1, 2*cm))
        s.append(Paragraph("Ingeniería Estructural", styles["cover_footer"]))

    # ── Sección 1 — Datos generales ───────────────────────────────────────────
    def _add_section_general(self, styles, envelope_results):
        s = self._story
        s.append(Paragraph("1. DATOS GENERALES", styles["h1"]))
        s.append(Spacer(1, 0.2*cm))

        # Normativas
        norms = [
            ["NTC 2023 DEC", "Normas Técnicas Complementarias para Diseño y Construcción de "
             "Estructuras de Concreto — CDMX 2023"],
            ["ACI 318-25", "Building Code Requirements for Structural Concrete — ACI 2025"],
        ]
        t = Table([["Normativa", "Descripción"]] + norms,
                  colWidths=[4*cm, 12*cm])
        _table_style(t, has_header=True)
        s.append(t)
        s.append(Spacer(1, 0.3*cm))

        # Parámetros de materiales
        if envelope_results:
            env0 = envelope_results[0]
            conf = env0.combos[0].confinement if env0.combos else None
            if conf:
                from design.code_parameters import CodeParameters
                # Recuperar fc/fy del primer confinamiento (guardado en code_params)
                pass
        s.append(Paragraph(
            "Los parámetros de materiales fueron definidos por el usuario en la interfaz de "
            "configuración. Se usaron los valores más desfavorables de las combinaciones de carga "
            f"en el intervalo seleccionado.",
            styles["body"]
        ))
        s.append(Spacer(1, 0.3*cm))

    # ── Sección 2 — Geometría ─────────────────────────────────────────────────
    def _add_section_geometry(self, styles, env, idx):
        s = self._story
        jg = env.joint_geometry
        s.append(Paragraph(f"2.{idx}  Geometría — Col {env.col_id} | Nodo {env.node_id}",
                           styles["h2"]))
        data = [
            ["Parámetro", "Valor", "Unidad", "Norma"],
            ["Tipo de nudo",       jg.joint_type.upper(), "—",   "NTC §8.3 / ACI §18.8.3"],
            ["b columna",          f"{jg.b_col:.1f}",   "cm",   "STAAD Pro"],
            ["h columna",          f"{jg.h_col:.1f}",   "cm",   "STAAD Pro"],
            ["Área efectiva Aj",   f"{jg.Aj:.1f}",      "cm²",  "Aj = b×h"],
            ["Lados confinados",   str(jg.confinement_sides), "—", "Trabes conectadas"],
            ["h_col/h_trabe",      f"{jg.h_col_over_h_trabe:.2f}", "—",
             "NTC §8.3.1 ≥ 1.20"],
            ["Trabes conectadas",  str(jg.n_trabes_framing), "—",  "STAAD Pro"],
        ]
        # Revisión por trabe — dimensiones y relación de alturas en AMBOS lados
        for d in getattr(jg, "trabe_details", []) or []:
            ok = "CUMPLE" if d.get("ok", True) else "NO CUMPLE"
            data.append([
                f"Trabe {d.get('id', '?')} (b×h)",
                f"{d.get('b', 0):.0f}×{d.get('h', 0):.0f}",
                "cm",
                f"h_col/h_trabe = {d.get('ratio', 0):.2f} ≥ 1.20 → {ok}",
            ])
        t = Table(data, colWidths=[6*cm, 3*cm, 2*cm, 6*cm])
        _table_style(t, has_header=True)
        # Colorear fila de verificación
        if not jg.ok_rel_heights:
            t.setStyle(TableStyle([("BACKGROUND", (0,6), (-1,6), C_FAIL)]))
        s.append(t)
        for w in jg.warnings:
            s.append(Paragraph(f"⚠ {w}", styles["warning"]))
        s.append(Spacer(1, 0.3*cm))

    # ── Sección 3 — Elementos mecánicos ───────────────────────────────────────
    def _add_section_forces(self, styles, env, idx):
        s = self._story
        s.append(Paragraph(f"3.{idx}  Elementos Mecánicos — Col {env.col_id} | Nodo {env.node_id}",
                           styles["h2"]))
        s.append(Paragraph(
            "Se muestran los valores más desfavorables de la envolvente de combinaciones de carga.",
            styles["body"]
        ))
        header = ["LC", "Vjh [ton]", "vu [kgf/cm²]", "DCR NTC", "DCR ACI",
                  "NTC", "ACI"]
        rows = [header]
        for cr in env.combos:
            jf = cr.joint_force
            if not jf:
                continue
            rows.append([
                str(jf.lc_id),
                f"{jf.Vjh/1000:.2f}",
                f"{jf.vu:.3f}",
                f"{jf.DCR_NTC:.3f}",
                f"{jf.DCR_ACI:.3f}",
                "✓" if jf.ok_shear_NTC else "✗",
                "✓" if jf.ok_shear_ACI else "✗",
            ])
        t = Table(rows, colWidths=[1.5*cm, 3*cm, 3*cm, 2.5*cm, 2.5*cm, 1.5*cm, 1.5*cm])
        _table_style(t, has_header=True)
        # Colorear filas
        for i, row in enumerate(rows[1:], start=1):
            ntc_ok = row[5] == "✓"
            aci_ok = row[6] == "✓"
            if not ntc_ok or not aci_ok:
                t.setStyle(TableStyle([("BACKGROUND", (0,i), (-1,i), C_FAIL)]))
        s.append(t)
        s.append(Spacer(1, 0.3*cm))

    # ── Sección 4 — Verificaciones ────────────────────────────────────────────
    def _add_section_verification(self, styles, env, idx):
        s = self._story
        s.append(Paragraph(f"4.{idx}  Verificaciones — Col {env.col_id} | Nodo {env.node_id}",
                           styles["h2"]))
        worst_cr = env.combos[env.worst_shear_ntc] if env.combos else None
        if not worst_cr:
            return
        jf   = worst_cr.joint_force
        conf = worst_cr.confinement
        cap  = worst_cr.capacity_design
        jg   = env.joint_geometry

        # Cortante en nudo NTC
        s.append(Paragraph("4.1  Cortante en el Nudo (NTC 2023 §8.3 / ACI §18.8.4)", styles["h3"]))
        s.append(Paragraph(
            f"La fuerza horizontal en el nudo se calcula como:<br/>"
            f"<b>Vjh = (Mci + Mcs) / jd − Vcol</b>  [NTC §8.3.2]<br/>"
            f"donde: jd = 0.875 × h_col = 0.875 × {jg.h_col:.1f} = {0.875*jg.h_col:.2f} cm",
            styles["formula"]
        ))
        if jf:
            s.append(Paragraph(
                f"Sustituyendo: Vjh = ({jf.Mci/100000:.2f} + {jf.Mcs/100000:.2f}) ton·m / "
                f"{0.875*jg.h_col/100:.3f} m − {jf.Vcol/1000:.2f} ton<br/>"
                f"<b>Vjh = {jf.Vjh/1000:.2f} ton</b><br/><br/>"
                f"Presión unitaria: vu = Vjh / Aj = {jf.Vjh/1000:.2f} × 1000 / {jg.Aj:.0f}"
                f" = <b>{jf.vu:.3f} kgf/cm²</b><br/><br/>"
                f"Capacidad NTC: φ·vn = 0.75 × {jf.Vn_NTC/jg.Aj/0.75:.3f} × {jg.Aj:.0f}/1000"
                f" = <b>{jf.Vn_NTC/1000:.2f} ton</b><br/>"
                f"Capacidad ACI: φ·vn = <b>{jf.Vn_ACI/1000:.2f} ton</b><br/><br/>"
                f"DCR NTC = {jf.DCR_NTC:.3f}  {'→ CUMPLE ✓' if jf.ok_shear_NTC else '→ NO CUMPLE ✗'}<br/>"
                f"DCR ACI = {jf.DCR_ACI:.3f}  {'→ CUMPLE ✓' if jf.ok_shear_ACI else '→ NO CUMPLE ✗'}",
                styles["formula_values"]
            ))

        # Confinamiento
        s.append(Paragraph("4.2  Confinamiento (NTC §8.6 / ACI §18.7.5)", styles["h3"]))
        if conf:
            s.append(Paragraph(
                f"Ash ≥ max(0.3·s·bc·(Ag/Ach−1)·f'c/fy,  0.12·s·bc·f'c/fy)<br/>"
                f"<b>Ash req NTC = {conf.Ash_req_NTC:.2f} cm²</b><br/>"
                f"<b>Ash req ACI = {conf.Ash_req_ACI:.2f} cm²</b><br/>"
                f"Ash gobernante = {conf.Ash_req:.2f} cm²<br/><br/>"
                f"Estribo propuesto: Ø{conf.db_est_cm*10:.0f}mm, {conf.n_ramas} ramas<br/>"
                f"Ash provista = {conf.Ash_prov:.2f} cm²  "
                f"{'→ CUMPLE ✓' if conf.ok_Ash else '→ NO CUMPLE ✗'}<br/>"
                f"Espaciamiento = {conf.s_prov_cm:.0f} cm ≤ s_max = {conf.s_max_cm:.0f} cm<br/>"
                f"Longitud zona confinada lo = {conf.lo_cm:.1f} cm",
                styles["formula_values"]
            ))

        # Diseño por capacidad
        if cap and cap.applies:
            s.append(Paragraph("4.3  Diseño por Capacidad (NTC §7.3.3 / ACI §18.7.3.2)", styles["h3"]))
            s.append(Paragraph(
                f"ΣMnc / ΣMnb ≥ {cap.required_ratio:.2f}  (columna fuerte – viga débil)<br/>"
                f"ΣMnc = {cap.sum_Mnc/100000:.2f} ton·m<br/>"
                f"ΣMnb = {cap.sum_Mnb/100000:.2f} ton·m<br/>"
                f"Relación = {cap.ratio:.3f}  "
                f"{'→ CUMPLE ✓' if cap.ok else '→ NO CUMPLE ✗'}",
                styles["formula_values"]
            ))
        s.append(Spacer(1, 0.3*cm))

    # ── Sección 5 — Refuerzo ──────────────────────────────────────────────────
    def _add_section_reinforcement(self, styles, env, idx):
        s = self._story
        s.append(Paragraph(f"5.{idx}  Diseño de Refuerzo — Col {env.col_id}", styles["h2"]))
        worst_cr = (env.combos[env.worst_Ash]
                    if env.combos and env.worst_Ash < len(env.combos) else None)
        conf = worst_cr.confinement if worst_cr else None
        lap  = worst_cr.lap_splice  if worst_cr else None
        if conf:
            data = [
                ["Parámetro",       "NTC",                  "ACI",              "Unidad"],
                ["Ash req",         f"{conf.Ash_req_NTC:.2f}", f"{conf.Ash_req_ACI:.2f}", "cm²"],
                ["Ash gobernante",  f"{conf.Ash_req:.2f}",  f"{conf.Ash_req:.2f}", "cm²"],
                ["Ash provista",    f"{conf.Ash_prov:.2f}", f"{conf.Ash_prov:.2f}", "cm²"],
                ["s_max",           f"{conf.s_max_cm:.0f}", f"{conf.s_max_cm:.0f}", "cm"],
                ["s_prov",          f"{conf.s_prov_cm:.0f}",f"{conf.s_prov_cm:.0f}", "cm"],
                ["lo",              f"{conf.lo_cm:.1f}",    f"{conf.lo_cm:.1f}",    "cm"],
                ["Ø estribo",       f"{conf.db_est_cm*10:.0f}mm", f"{conf.db_est_cm*10:.0f}mm", "—"],
                ["No. ramas",       str(conf.n_ramas),      str(conf.n_ramas),  "—"],
            ]
            t = Table(data, colWidths=[6*cm, 3.5*cm, 3.5*cm, 2.5*cm])
            _table_style(t, has_header=True)
            s.append(t)
        if lap:
            s.append(Spacer(1, 0.2*cm))
            s.append(Paragraph(f"Longitud de desarrollo Ld = {lap.Ld_cm:.1f} cm  |  "
                               f"Ldh = {lap.Ldh_cm:.1f} cm  |  Ls (traslape) = {lap.Ls_cm:.1f} cm",
                               styles["body"]))
        prop = getattr(env, "estribos_prop", None)
        if prop is not None:
            s.append(Spacer(1, 0.2*cm))
            s.append(Paragraph("Propuesta de estribos (ACI Detailing Manual MNL-66):",
                               styles["h2"]))
            _n = getattr(env, "estribos_prop_nvar", 0)
            if _n:
                s.append(Paragraph(f"Armado longitudinal estimado: {_n} varillas.",
                                   styles["body"]))
            s.append(Paragraph(prop.descripcion, styles["body"]))
            for nota in getattr(prop, "notas", []):
                s.append(Paragraph(f"Nota: {nota}", styles["body"]))
        s.append(Spacer(1, 0.3*cm))

    # ── Sección 6 — Gráficas ─────────────────────────────────────────────────
    def _add_section_graphics(self, styles, fig_plan, fig_elev, fig_3d):
        s = self._story
        s.append(Paragraph("6. GRÁFICAS Y ESQUEMAS", styles["h1"]))
        for fig, title in [(fig_plan, "Vista en Planta"),
                           (fig_elev, "Vista en Elevación"),
                           (fig_3d,   "Render 3D")]:
            if fig is None:
                continue
            s.append(Paragraph(title, styles["h2"]))
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
            buf.seek(0)
            img = Image(buf, width=15*cm, height=10*cm, kind="proportional")
            s.append(img)
            s.append(Spacer(1, 0.4*cm))

    # ── Sección 7 — Conclusiones ──────────────────────────────────────────────
    def _add_section_conclusions(self, styles, envelope_results):
        s = self._story
        s.append(Paragraph("7. CONCLUSIONES Y RECOMENDACIONES", styles["h1"]))
        for env in envelope_results:
            color = C_OK if env.all_ok else C_FAIL
            mark  = "✓ CUMPLE" if env.all_ok else "✗ NO CUMPLE"
            s.append(Paragraph(
                f"<b>Col {env.col_id} | Nodo {env.node_id}:</b>  {mark}",
                styles["conclusion_ok" if env.all_ok else "conclusion_fail"]
            ))
            for w in env.warnings[:5]:   # máximo 5 advertencias por nudo
                s.append(Paragraph(f"  • {w}", styles["warning"]))
        s.append(Spacer(1, 0.3*cm))
        s.append(Paragraph(
            "Las verificaciones se realizaron conforme a NTC 2023 DEC y ACI 318-25. "
            "Los valores más desfavorables de la envolvente de combinaciones de carga "
            "son los que gobiernan el diseño. Se recomienda revisar el detallado de "
            "refuerzo con un ingeniero especialista antes de su ejecución.",
            styles["body"]
        ))

    # ── Template de página ────────────────────────────────────────────────────
    def _page_template(self, canvas, doc):
        canvas.saveState()
        # Encabezado
        canvas.setFillColor(C_PRIMARY)
        canvas.rect(doc.leftMargin, doc.height + doc.topMargin - 0.5*cm,
                    doc.width, 0.5*cm, fill=1, stroke=0)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica-Bold", 8)
        canvas.drawString(doc.leftMargin + 0.2*cm,
                          doc.height + doc.topMargin - 0.35*cm,
                          "JOINT DESIGN PRO — Memoria de Cálculo de Nudos")
        canvas.drawRightString(doc.width + doc.leftMargin,
                               doc.height + doc.topMargin - 0.35*cm,
                               f"Rev. {self.revision}")
        # Pie de página
        canvas.setFillColor(C_ACCENT)
        canvas.setFont("Helvetica", 7)
        canvas.drawString(doc.leftMargin, doc.bottomMargin - 0.5*cm,
                          f"{self.project_name}  |  {datetime.now().strftime('%d/%m/%Y')}")
        canvas.drawRightString(doc.width + doc.leftMargin, doc.bottomMargin - 0.5*cm,
                               f"Página {doc.page}")
        canvas.restoreState()

    # ── Estilos ───────────────────────────────────────────────────────────────
    def _build_styles(self) -> dict:
        base = getSampleStyleSheet()
        st = {}
        st["cover_title"] = ParagraphStyle(
            "cover_title", fontSize=22, leading=28,
            textColor=C_PRIMARY, alignment=TA_CENTER, fontName="Helvetica-Bold"
        )
        st["cover_subtitle"] = ParagraphStyle(
            "cover_subtitle", fontSize=13, leading=18,
            textColor=C_ACCENT, alignment=TA_CENTER, fontName="Helvetica"
        )
        st["cover_footer"] = ParagraphStyle(
            "cover_footer", fontSize=9, textColor=C_ACCENT,
            alignment=TA_CENTER, fontName="Helvetica-Oblique"
        )
        st["h1"] = ParagraphStyle(
            "h1", fontSize=12, leading=16, fontName="Helvetica-Bold",
            textColor=C_PRIMARY, spaceBefore=12, spaceAfter=4,
            borderPad=2, backColor=C_LIGHT,
        )
        st["h2"] = ParagraphStyle(
            "h2", fontSize=10, leading=14, fontName="Helvetica-Bold",
            textColor=C_SECOND, spaceBefore=8, spaceAfter=3,
        )
        st["h3"] = ParagraphStyle(
            "h3", fontSize=9, leading=13, fontName="Helvetica-Bold",
            textColor=C_ACCENT, spaceBefore=6, spaceAfter=2,
        )
        st["body"] = ParagraphStyle(
            "body", fontSize=8, leading=12, fontName="Helvetica",
            textColor=C_DARK, spaceAfter=3, alignment=TA_JUSTIFY,
        )
        st["formula"] = ParagraphStyle(
            "formula", fontSize=8, leading=13, fontName="Courier",
            textColor=C_DARK, backColor=C_LIGHT,
            leftIndent=12, spaceAfter=4,
        )
        st["formula_values"] = ParagraphStyle(
            "formula_values", fontSize=8, leading=13, fontName="Courier",
            textColor=C_DARK, leftIndent=20, spaceAfter=4,
        )
        st["warning"] = ParagraphStyle(
            "warning", fontSize=8, leading=12, fontName="Helvetica-Oblique",
            textColor=colors.HexColor("#922B21"), leftIndent=12, spaceAfter=2,
        )
        st["conclusion_ok"] = ParagraphStyle(
            "conclusion_ok", fontSize=9, fontName="Helvetica-Bold",
            textColor=colors.HexColor("#1E8449"), spaceAfter=2,
        )
        st["conclusion_fail"] = ParagraphStyle(
            "conclusion_fail", fontSize=9, fontName="Helvetica-Bold",
            textColor=colors.HexColor("#922B21"), spaceAfter=2,
        )
        return st


def _table_style(t, has_header: bool = True):
    style = [
        ("FONT",      (0,0), (-1,-1), "Helvetica",      8),
        ("TOPPADDING",(0,0), (-1,-1), 3),
        ("BOTTOMPADDING",(0,0), (-1,-1), 3),
        ("GRID",      (0,0), (-1,-1), 0.3, colors.HexColor("#9E9E9E")),
        ("ROWBACKGROUNDS", (0,0 if not has_header else 1), (-1,-1),
         [colors.white, colors.HexColor("#EAECEE")]),
    ]
    if has_header:
        style += [
            ("BACKGROUND", (0,0), (-1,0),  colors.HexColor("#1B4F72")),
            ("TEXTCOLOR",  (0,0), (-1,0),  colors.white),
            ("FONT",       (0,0), (-1,0),  "Helvetica-Bold", 8),
            ("ALIGN",      (0,0), (-1,0),  "CENTER"),
        ]
    t.setStyle(TableStyle(style))
