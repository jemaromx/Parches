﻿# -*- coding: utf-8 -*-
"""Vista en planta del nudo de concreto (seccion horizontal a media altura columna)."""
from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from viz.styles_viz import (
    COL_CONCRETE, COL_CONC_EDGE, COL_STEEL_L, COL_STEEL_T,
    COL_CONFINEMENT, COL_BEAM, COL_DIM, COL_BG,
    FONT_TITLE, FONT_LABEL, FONT_DIM,
    apply_global_style, draw_dimension, DPI_EXPORT, DPI_SCREEN,
)


def draw_plan_view(envelope_result, extractor=None,
                   project: str = "", output_path: str = "",
                   dpi: float | None = None) -> plt.Figure:
    """Genera vista en planta profesional del nudo.

    Devuelve una figura aunque envelope_result este parcialmente vacio.
    """
    apply_global_style()
    _dpi = dpi if dpi is not None else DPI_SCREEN
    fig, ax = plt.subplots(figsize=(8.5, 7.0), dpi=_dpi)
    ax.set_aspect("equal")
    ax.set_facecolor(COL_BG)

    jg     = getattr(envelope_result, "joint_geometry", None)
    col_id = getattr(envelope_result, "col_id", 0)
    node_id = getattr(envelope_result, "node_id", 0)

    # Dimensiones por defecto si no hay geometria
    b_col = (jg.b_col / 100.0) if jg else 0.40
    h_col = (jg.h_col / 100.0) if jg else 0.40

    x0, y0 = -b_col / 2, -h_col / 2

    # ── Columna ───────────────────────────────────────────────────────────────
    ax.add_patch(Rectangle(
        (x0, y0), b_col, h_col,
        facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
        linewidth=1.5, zorder=2,
    ))

    # Zona confinada
    rec = 0.04
    ax.add_patch(Rectangle(
        (x0 + rec, y0 + rec), b_col - 2*rec, h_col - 2*rec,
        facecolor="none", edgecolor=COL_CONFINEMENT,
        linestyle="--", linewidth=1.0, zorder=3,
    ))
    ax.fill_between(
        [x0 + rec, x0 + b_col - rec], y0 + rec, y0 + h_col - rec,
        alpha=0.08, color=COL_CONFINEMENT, zorder=2,
    )

    # ── Trabes que llegan al nodo ──────────────────────────────────────────────
    # Direcciones REALES desde el modelo (esquina/borde/central) usando las
    # coordenadas de los nodos lejanos de cada trabe; con etiqueta = ID de barra.
    trabe_dirs = _trabe_directions(envelope_result, extractor)
    if not trabe_dirs:
        n_trabes = (jg.n_trabes_framing if jg else 2)
        trabe_dirs = [((1, 0), None), ((-1, 0), None),
                      ((0, 1), None), ((0, -1), None)][:n_trabes]
    trabe_len = 0.60

    for i, ((dx, dy), tid) in enumerate(trabe_dirs):
        norm = (dx*dx + dy*dy) ** 0.5 or 1.0
        dx, dy = dx / norm, dy / norm
        bx = b_col / 2 * abs(dx) + h_col / 2 * abs(dy)
        sx, sy = dx * bx, dy * bx
        ex, ey = sx + dx * trabe_len, sy + dy * trabe_len
        bw_t = 0.30
        if abs(dx) >= abs(dy):
            trx, try_ = min(sx, ex), -bw_t / 2
            tw, th = abs(ex - sx), bw_t
        else:
            trx, try_ = -bw_t / 2, min(sy, ey)
            tw, th = bw_t, abs(ey - sy)
        ax.add_patch(Rectangle(
            (trx, try_), tw, th,
            facecolor=COL_BEAM, edgecolor=COL_CONC_EDGE,
            alpha=0.35, linewidth=1.0, zorder=1,
        ))
        lbl = f"T{tid}" if tid is not None else f"T{i+1}"
        # Etiqueta sobre la trabe, dentro del recuadro visible
        ax.text(sx + dx * trabe_len * 0.45, sy + dy * trabe_len * 0.45,
                lbl, ha="center", va="center", zorder=6,
                fontdict=FONT_DIM, color="#0D47A1",
                bbox=dict(boxstyle="round,pad=0.15", facecolor="white",
                          edgecolor="#90CAF9", alpha=0.9))

    # ── Acero longitudinal (n barras del armado propuesto) ──────────────────
    db = 0.025
    _n_prop = getattr(envelope_result, "estribos_prop_nvar", 0) or None
    _bars = _column_bars(b_col, h_col, rec, db, n=_n_prop)
    for bx, by in _bars:
        ax.add_patch(plt.Circle(
            (x0 + bx, y0 + by), db / 2,
            facecolor=COL_STEEL_L, edgecolor="#0D0D0D",
            linewidth=0.5, zorder=5,
        ))

    # ── Estribo perimetral + diamante/grapas (MNL-66) ────────────────────────
    r = rec
    ax.plot(
        [x0+r, x0+b_col-r, x0+b_col-r, x0+r, x0+r],
        [y0+r, y0+r, y0+h_col-r, y0+h_col-r, y0+r],
        color=COL_STEEL_T, linewidth=1.5, zorder=4,
    )
    _draw_ties_2d(ax, x0, y0, b_col, h_col, rec, db,
                  getattr(envelope_result, "estribos_prop", None), _bars, COL_STEEL_T)

    # ── Ejes ──────────────────────────────────────────────────────────────────
    ax.axhline(0, color="#AAAAAA", linewidth=0.5, linestyle=":", zorder=1)
    ax.axvline(0, color="#AAAAAA", linewidth=0.5, linestyle=":", zorder=1)

    # ── Cotas ─────────────────────────────────────────────────────────────────
    draw_dimension(ax, x0, y0, x0 + b_col, y0,
                   f"b={b_col*100:.0f} cm", offset=0.15, axis="x")
    draw_dimension(ax, x0 + b_col, y0, x0 + b_col, y0 + h_col,
                   f"h={h_col*100:.0f} cm", offset=0.15, axis="y")

    # ── Leyenda ───────────────────────────────────────────────────────────────
    Aj_txt = f"{jg.Aj:.0f} cm2" if jg else "—"
    ax.legend(handles=[
        mpatches.Patch(facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
                       label=f"Concreto Aj={Aj_txt}"),
        mpatches.Patch(facecolor="none", edgecolor=COL_CONFINEMENT,
                       linestyle="--", label="Nucleo confinado"),
        mpatches.Patch(facecolor=COL_BEAM, alpha=0.5, label="Trabes"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=COL_STEEL_L,
               markersize=6, label="Acero longitudinal"),
        Line2D([0], [0], color=COL_STEEL_T, linewidth=2, label="Estribo"),
    ], loc="lower right", fontsize=7, framealpha=0.9)

    # ── Panel de resultados ───────────────────────────────────────────────────
    _results_panel(ax, envelope_result)

    # ── Titulo ────────────────────────────────────────────────────────────────
    jtype = (jg.joint_type.upper() if jg else "—")
    ax.set_title(
        f"PLANTA — NUDO  |  Columna {col_id}  |  Nodo {node_id}\n"
        f"Tipo: {jtype}  |  Ductilidad: {_duct_label(envelope_result)}",
        fontdict=FONT_TITLE, pad=10, color="#1B4F72",
    )
    ax.set_xlabel("X  [m]", fontdict=FONT_LABEL)
    ax.set_ylabel("Y  [m]", fontdict=FONT_LABEL)
    # Límite que abarca la columna + las trabes (trabe_len=0.60 m por lado)
    reach = max(b_col, h_col) / 2.0 + 0.65
    ax.set_xlim(-reach, reach)
    ax.set_ylim(-reach, reach)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if output_path:
        try:
            fig.savefig(output_path, dpi=DPI_EXPORT, bbox_inches="tight")
        except Exception:
            pass

    return fig


# ── Helpers ────────────────────────────────────────────────────────────────────

def _column_bars(b, h, rec, db, n=None):
    """Posiciones de barras. Si se conoce ``n`` (armado propuesto por el
    diseño) se distribuyen exactamente n barras en el perímetro; si no,
    se usa la heurística visual anterior."""
    x_lo, x_hi = rec + db/2, b - rec - db/2
    y_lo, y_hi = rec + db/2, h - rec - db/2
    corners = [(x_lo, y_lo), (x_hi, y_lo), (x_hi, y_hi), (x_lo, y_hi)]
    if not n or n <= 4:
        if n:
            return corners[:max(int(n), 1)] if n < 4 else corners
        # heurística legada (sin dato de armado)
        positions = list(corners)
        if b > 0.40:
            positions += [(b/2, y_lo), (b/2, y_hi)]
        if h > 0.40:
            positions += [(x_lo, h/2), (x_hi, h/2)]
        return positions
    positions = list(corners)
    m = int(n) - 4
    caras = {"bottom": 0, "top": 0, "left": 0, "right": 0}
    orden = ["bottom", "top", "left", "right"]
    for i in range(m):
        caras[orden[i % 4]] += 1
    for cara, k in caras.items():
        for j in range(1, k + 1):
            if cara == "bottom":
                positions.append((x_lo + j*(x_hi - x_lo)/(k + 1), y_lo))
            elif cara == "top":
                positions.append((x_lo + j*(x_hi - x_lo)/(k + 1), y_hi))
            elif cara == "left":
                positions.append((x_lo, y_lo + j*(y_hi - y_lo)/(k + 1)))
            else:
                positions.append((x_hi, y_lo + j*(y_hi - y_lo)/(k + 1)))
    return positions


def _draw_ties_2d(ax, x0, y0, b, h, rec, db, prop, bars, color, lw=1.3):
    """Dibuja diamante o grapas (MNL-66) sobre el corte de la columna."""
    if prop is None:
        return
    x_lo, x_hi = rec + db/2, b - rec - db/2
    y_lo, y_hi = rec + db/2, h - rec - db/2
    if getattr(prop, "diamante", False):
        cx, cy = x0 + b/2, y0 + h/2
        dxs, dys = b/2 - rec - db/2, h/2 - rec - db/2
        ax.plot([cx, cx + dxs, cx, cx - dxs, cx],
                [cy - dys, cy, cy + dys, cy, cy - dys],
                color=color, linewidth=lw, zorder=4)
    elif getattr(prop, "config", "") == "perimetral+grapas":
        eps = 1e-6
        for bx, by in bars:
            on_cx = abs(bx - x_lo) < eps or abs(bx - x_hi) < eps
            on_cy = abs(by - y_lo) < eps or abs(by - y_hi) < eps
            if on_cx and on_cy:        # esquina: soportada por el perimetral
                continue
            if on_cy:                  # barra en cara horizontal → grapa vertical
                ax.plot([x0 + bx, x0 + bx], [y0 + rec, y0 + h - rec],
                        color=color, linewidth=lw*0.85, zorder=4)
            else:                      # barra en cara vertical → grapa horizontal
                ax.plot([x0 + rec, x0 + b - rec], [y0 + by, y0 + by],
                        color=color, linewidth=lw*0.85, zorder=4)


def _duct_label(env) -> str:
    combos = getattr(env, "combos", [])
    if not combos:
        return "—"
    jf = getattr(combos[0], "joint_force", None)
    return getattr(jf, "ductility", "—") if jf else "—"


def _results_panel(ax, env):
    combos = getattr(env, "combos", [])
    if not combos:
        return
    worst = getattr(env, "worst_shear_ntc", 0)
    jf_all = [c.joint_force for c in combos if c.joint_force]
    if not jf_all:
        return
    # El indice worst puede apuntar a jf_all (que puede tener menos elementos que combos)
    idx = min(worst, len(jf_all) - 1)

    Vjh_max    = getattr(env, "Vjh_max",    0.0)
    vu_max     = getattr(env, "vu_max",     0.0)
    DCR_NTC    = getattr(env, "DCR_NTC_max",0.0)
    DCR_ACI    = getattr(env, "DCR_ACI_max",0.0)
    ok_ntc     = getattr(env, "ok_shear_NTC", True)
    ok_aci     = getattr(env, "ok_shear_ACI", True)

    lines = [
        f"Vjh max = {Vjh_max/1000:.2f} ton",
        f"vu  max = {vu_max:.2f} kgf/cm2",
        f"DCR NTC = {DCR_NTC:.3f}  {'OK' if ok_ntc else 'FALLA'}",
        f"DCR ACI = {DCR_ACI:.3f}  {'OK' if ok_aci else 'FALLA'}",
    ]
    color = "#D5F5E3" if ok_ntc and ok_aci else "#FADBD8"
    ax.text(-0.01, 0.99, "\n".join(lines), transform=ax.transAxes,
            va="top", ha="left", fontsize=7,
            bbox=dict(boxstyle="round,pad=0.4", facecolor=color,
                      edgecolor="#888", linewidth=0.8),
            family="monospace")


def _trabe_directions(env, extractor):
    """[(dir(dx,dy), trabe_id), ...] con coordenadas reales del modelo (planta
    X-Z). La config esquina/borde/central se refleja por las direcciones.
    Regresa [] si no hay datos suficientes."""
    if env is None or extractor is None:
        return []
    tids = list(getattr(env, "trabe_ids", []) or [])
    node_id = getattr(env, "node_id", None)
    if not tids or node_id is None:
        return []
    try:
        nc = extractor.get_node_coord(node_id)
        n0 = (nc.x, nc.z)
    except Exception:
        return []
    out = []
    for tid in tids:
        try:
            inc = extractor.get_member_incidence(tid)
            far = inc.node_end if inc.node_start == node_id else inc.node_start
            fc  = extractor.get_node_coord(far)
            # STAAD: +Z apunta hacia ABAJO en planta → se niega para el dibujo
            dx, dy = fc.x - n0[0], -(fc.z - n0[1])
            if abs(dx) < 1e-6 and abs(dy) < 1e-6:
                continue
            out.append(((dx, dy), tid))
        except Exception:
            continue
    return out
