﻿# -*- coding: utf-8 -*-
"""Vista en elevacion del nudo: armado longitudinal, estribos, confinamiento."""
from __future__ import annotations
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from viz.styles_viz import (
    COL_CONCRETE, COL_CONC_EDGE, COL_STEEL_L, COL_STEEL_T,
    COL_CONFINEMENT, COL_BEAM, COL_FORCE, COL_BG,
    FONT_TITLE, FONT_LABEL, FONT_DIM,
    apply_global_style, draw_dimension, DPI_EXPORT, DPI_SCREEN,
)


def draw_elevation_view(envelope_result, extractor=None,
                        project: str = "", output_path: str = "",
                        dpi: float | None = None) -> plt.Figure:
    """Genera vista en elevacion del nudo — robusta ante datos parciales."""
    apply_global_style()
    _dpi = dpi if dpi is not None else DPI_SCREEN
    fig, (ax_main, ax_trans) = plt.subplots(1, 2, figsize=(12, 8), dpi=_dpi)

    jg      = getattr(envelope_result, "joint_geometry", None)
    col_id  = getattr(envelope_result, "col_id",  0)
    node_id = getattr(envelope_result, "node_id", 0)

    b_col = (jg.b_col / 100.0) if jg else 0.40
    h_col = (jg.h_col / 100.0) if jg else 0.40
    rec   = 0.04
    db    = 0.025
    db_t  = 0.0095

    # Confinamiento: primer combo con datos
    conf = None
    for c in getattr(envelope_result, "combos", []):
        if getattr(c, "confinement", None) is not None:
            conf = c.confinement
            break

    # ── Corte longitudinal ────────────────────────────────────────────────────
    _draw_longitudinal(ax_main, b_col, h_col, rec, db, db_t, conf, envelope_result, jg, extractor)

    # ── Corte transversal ─────────────────────────────────────────────────────
    _draw_transversal(ax_trans, b_col, rec, db, conf, envelope_result)

    jtype = (jg.joint_type.upper() if jg else "—")
    fig.suptitle(
        f"ELEVACION — NUDO  |  Col {col_id}  |  Nodo {node_id}  |  Tipo: {jtype}",
        fontsize=11, fontweight="bold", color="#1B4F72", y=1.00,
    )
    fig.tight_layout()

    if output_path:
        try:
            fig.savefig(output_path, dpi=DPI_EXPORT, bbox_inches="tight")
        except Exception:
            pass

    return fig


def _draw_longitudinal(ax, b, h_nudo, rec, db, db_t, conf, env, jg, extractor=None):
    ax.set_aspect("equal")
    ax.set_facecolor(COL_BG)

    h_seg  = 0.60
    total_h = 2 * h_seg + h_nudo
    x0, y0 = -b / 2, 0.0
    lo     = (conf.lo_cm / 100.0) if conf and hasattr(conf, "lo_cm") else 0.45
    s_prov = (conf.s_prov_cm / 100.0) if conf and hasattr(conf, "s_prov_cm") else 0.10

    # Columna
    ax.add_patch(Rectangle((x0, y0), b, total_h,
                            facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
                            linewidth=1.4, zorder=2))

    # Zonas de confinamiento
    for y_zona in [y0, y0 + total_h - lo]:
        ax.add_patch(Rectangle((x0, y_zona), b, lo,
                                facecolor=COL_CONFINEMENT, alpha=0.10,
                                edgecolor=COL_CONFINEMENT, linestyle="--",
                                linewidth=0.8, zorder=3))

    ax.annotate("", xy=(x0 - 0.10, y0 + lo), xytext=(x0 - 0.10, y0),
                arrowprops=dict(arrowstyle="<->", color=COL_CONFINEMENT, lw=0.9))
    ax.text(x0 - 0.14, y0 + lo / 2, f"lo={lo*100:.0f}cm",
            ha="right", va="center", fontdict=FONT_DIM,
            color=COL_CONFINEMENT, rotation=90)

    # Barras longitudinales
    for bx in [x0 + rec + db/2, x0 + b - rec - db/2]:
        ax.plot([bx, bx], [y0 + rec, y0 + total_h - rec],
                color=COL_STEEL_L, linewidth=2.5, zorder=5,
                solid_capstyle="round")

    # Estribos
    _draw_stirrups_elevation(ax, x0, y0, b, total_h, rec, db_t,
                              s_prov, lo, s_general=0.20)

    # Trabes — solo los lados que REALMENTE tienen trabe en la dirección X
    # (una elevación es un corte en el plano X-Y; las trabes en Z no aparecen).
    h_trabe, trabe_len = 0.40, 0.50
    trabe_y = y0 + h_seg + h_nudo / 2 - h_trabe / 2
    lados = _lados_trabe_x(env, extractor)   # {"+": id|None, "-": id|None}
    if lados["-"] is not None:
        ax.add_patch(Rectangle((x0 - trabe_len, trabe_y), trabe_len, h_trabe,
                                facecolor=COL_BEAM, edgecolor=COL_CONC_EDGE,
                                alpha=0.35, linewidth=1.0, zorder=1))
        ax.text(x0 - trabe_len * 0.5, trabe_y + h_trabe + 0.03,
                f"T{lados['-']}", ha="center", fontsize=8, color="#0D47A1")
    if lados["+"] is not None:
        ax.add_patch(Rectangle((x0 + b, trabe_y), trabe_len, h_trabe,
                                facecolor=COL_BEAM, edgecolor=COL_CONC_EDGE,
                                alpha=0.35, linewidth=1.0, zorder=1))
        ax.text(x0 + b + trabe_len * 0.5, trabe_y + h_trabe + 0.03,
                f"T{lados['+']}", ha="center", fontsize=8, color="#0D47A1")

    # Vector de fuerza Vjh
    combos = getattr(env, "combos", [])
    if combos:
        worst = getattr(env, "worst_shear_ntc", 0)
        jf_all = [c.joint_force for c in combos if c.joint_force]
        if jf_all:
            idx = min(worst, len(jf_all) - 1)
            jf  = jf_all[idx]
            Vjh = getattr(jf, "Vjh", 0.0)
            if abs(Vjh) > 0:
                _draw_force_arrow(ax, 0, y0 + h_seg + h_nudo / 2,
                                  Vjh / 1e6, 0,
                                  label=f"Vjh={Vjh/1000:.1f}t")

    # Cotas
    if jg:
        draw_dimension(ax, x0 + b, y0, x0 + b, y0 + total_h,
                       f"H={total_h*100:.0f}cm", offset=0.15, axis="y")
        draw_dimension(ax, x0, y0 + total_h, x0 + b, y0 + total_h,
                       f"b={jg.b_col:.0f}cm", offset=0.10, axis="x")

    ax.set_xlim(x0 - 0.40, x0 + b + 0.40)
    ax.set_ylim(y0 - 0.10, y0 + total_h + 0.30)
    ax.set_title("Corte Longitudinal", fontdict=FONT_TITLE, color="#1B4F72", pad=6)
    ax.set_xlabel("X [m]", fontdict=FONT_LABEL)
    ax.set_ylabel("Y [m]", fontdict=FONT_LABEL)
    _add_legend_elevation(ax)


def _draw_transversal(ax, b, rec, db, conf, env=None):
    from viz.plan_view import _column_bars
    ax.set_aspect("equal")
    ax.set_facecolor(COL_BG)
    h = b
    x0, y0 = -b / 2, -h / 2

    ax.add_patch(Rectangle((x0, y0), b, h,
                            facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE,
                            linewidth=1.4, zorder=2))
    ax.add_patch(Rectangle((x0 + rec, y0 + rec), b - 2*rec, h - 2*rec,
                            facecolor="none", edgecolor=COL_CONFINEMENT,
                            linestyle="--", linewidth=1.0, zorder=3))

    # Barras (n del armado propuesto si está disponible)
    from viz.plan_view import _column_bars   # noqa: F811
    _n_prop = (getattr(env, "estribos_prop_nvar", 0) or None) if env else None
    for bx, by in _column_bars(b, h, rec, db, n=_n_prop):
        ax.add_patch(plt.Circle((x0 + bx, y0 + by), db / 2,
                                facecolor=COL_STEEL_L, edgecolor="#0D0D0D",
                                linewidth=0.5, zorder=5))

    # Estribo perimetral
    r = rec
    ax.plot([x0+r, x0+b-r, x0+b-r, x0+r, x0+r],
            [y0+r, y0+r, y0+h-r, y0+h-r, y0+r],
            color=COL_STEEL_T, linewidth=1.5, zorder=4)

    # Estribo en diamante / grapas segun propuesta MNL-66
    prop = getattr(env, "estribos_prop", None) if env is not None else None
    bars = _column_bars(b, h, rec, db, n=_n_prop)
    n_bars = len(bars)
    if (prop is not None and getattr(prop, "diamante", False)) or \
       (prop is None and n_bars == 8):
        # Diamante: une las 4 barras centrales de cara (rombo)
        cx, cy = x0 + b/2, y0 + h/2
        dxs = b/2 - rec - db/2
        dys = h/2 - rec - db/2
        ax.plot([cx, cx + dxs, cx, cx - dxs, cx],
                [cy - dys, cy, cy + dys, cy, cy - dys],
                color=COL_STEEL_T, linewidth=1.3, zorder=4)
    elif prop is not None and getattr(prop, "config", "") == "perimetral+grapas":
        # Grapas: lineas que cruzan por las barras intermedias de cara
        for bx, by in bars:
            px, py = x0 + bx, y0 + by
            on_corner = (abs(bx - (rec + db/2)) < 1e-6 or
                         abs(bx - (b - rec - db/2)) < 1e-6) and \
                        (abs(by - (rec + db/2)) < 1e-6 or
                         abs(by - (h - rec - db/2)) < 1e-6)
            if on_corner:
                continue
            if abs(by - (rec + db/2)) < 1e-6 or abs(by - (h - rec - db/2)) < 1e-6:
                # barra en cara horizontal -> grapa vertical
                ax.plot([px, px], [y0 + rec, y0 + h - rec],
                        color=COL_STEEL_T, linewidth=1.1,
                        linestyle="-", zorder=4)
            else:
                # barra en cara vertical -> grapa horizontal
                ax.plot([x0 + rec, x0 + b - rec], [py, py],
                        color=COL_STEEL_T, linewidth=1.1,
                        linestyle="-", zorder=4)

    # Info de confinamiento
    if conf:
        db_e = getattr(conf, "db_est_cm", 0)
        s_p  = getattr(conf, "s_prov_cm", 0)
        n_r  = getattr(conf, "n_ramas", 0)
        Ash_p = getattr(conf, "Ash_prov", 0.0)
        Ash_r = getattr(conf, "Ash_req",  0.0)
        ok    = getattr(conf, "ok_Ash",   True)
        info  = (f"d={db_e*10:.0f}mm c/{s_p:.0f}cm ({n_r} ramas)\n"
                 f"Ash={Ash_p:.2f} cm2  >=  {Ash_r:.2f} cm2")
        color = "#D5F5E3" if ok else "#FADBD8"
    else:
        info  = "Sin datos de confinamiento"
        color = "#F2F3F4"

    ax.text(0.02, 0.02, info, transform=ax.transAxes, fontsize=7,
            va="bottom", family="monospace",
            bbox=dict(boxstyle="round", facecolor=color,
                      edgecolor="#888", alpha=0.9))

    ax.set_xlim(x0 - 0.20, x0 + b + 0.20)
    ax.set_ylim(y0 - 0.20, y0 + h + 0.20)
    ax.set_title("Corte Transversal (Zona Nudo)",
                 fontdict=FONT_TITLE, color="#1B4F72", pad=6)
    ax.set_xlabel("X [m]", fontdict=FONT_LABEL)
    ax.set_ylabel("Z [m]", fontdict=FONT_LABEL)


def _draw_stirrups_elevation(ax, x0, y0, b, total_h, rec, db_t,
                              s_prov, lo, s_general):
    if s_prov <= 0:
        s_prov = 0.10
    y = y0 + rec
    while y < y0 + lo:
        ax.plot([x0 + rec, x0 + b - rec], [y, y],
                color=COL_STEEL_T, linewidth=1.2, zorder=4)
        y += s_prov
    y = y0 + lo
    while y < y0 + total_h - lo:
        ax.plot([x0 + rec, x0 + b - rec], [y, y],
                color=COL_STEEL_T, linewidth=0.9, linestyle="--", zorder=4)
        y += s_general
    y = y0 + total_h - lo
    while y <= y0 + total_h - rec:
        ax.plot([x0 + rec, x0 + b - rec], [y, y],
                color=COL_STEEL_T, linewidth=1.2, zorder=4)
        y += s_prov


def _draw_force_arrow(ax, x, y, fx, fy, label=""):
    scale = 0.3
    ax.annotate("", xy=(x + fx * scale, y + fy * scale), xytext=(x, y),
                arrowprops=dict(arrowstyle="-|>", color=COL_FORCE,
                                lw=1.8, mutation_scale=15))
    if label:
        ax.text(x + fx * scale * 0.5, y + fy * scale * 0.5 + 0.04,
                label, fontdict=FONT_DIM, color=COL_FORCE, ha="center")


def _add_legend_elevation(ax):
    ax.legend(handles=[
        mpatches.Patch(facecolor=COL_CONCRETE, edgecolor=COL_CONC_EDGE, label="Concreto"),
        mpatches.Patch(facecolor=COL_CONFINEMENT, alpha=0.15,
                       edgecolor=COL_CONFINEMENT, linestyle="--", label="Zona confinada (lo)"),
        Line2D([0], [0], color=COL_STEEL_L, linewidth=2.5, label="Acero longitudinal"),
        Line2D([0], [0], color=COL_STEEL_T, linewidth=1.5, label="Estribos confinados"),
        Line2D([0], [0], color=COL_STEEL_T, linewidth=1.0, linestyle="--",
               label="Estribos generales"),
        mpatches.Patch(facecolor=COL_BEAM, alpha=0.4, label="Trabes"),
    ], loc="upper right", fontsize=7, framealpha=0.9)


def _lados_trabe_x(env, extractor):
    """Determina qué lados (+X, -X) del nudo tienen trabe, usando las
    direcciones reales del modelo. Regresa {"+": id|None, "-": id|None}.
    Para nudo de esquina, solo un lado en X estará ocupado."""
    lados = {"+": None, "-": None}
    if env is None or extractor is None:
        # Sin datos: asumir borde (una trabe hacia +X)
        return {"+": None, "-": None}
    tids = list(getattr(env, "trabe_ids", []) or [])
    node_id = getattr(env, "node_id", None)
    if not tids or node_id is None:
        return lados
    try:
        nc = extractor.get_node_coord(node_id)
        x0, z0 = nc.x, nc.z
    except Exception:
        return lados
    for tid in tids:
        try:
            inc = extractor.get_member_incidence(tid)
            far = inc.node_end if inc.node_start == node_id else inc.node_start
            fc  = extractor.get_node_coord(far)
            dx, dz = fc.x - x0, fc.z - z0
            # Solo trabes predominantemente en X aparecen en la elevación X-Y
            if abs(dx) >= abs(dz):
                if dx >= 0:
                    lados["+"] = tid
                else:
                    lados["-"] = tid
        except Exception:
            continue
    return lados
