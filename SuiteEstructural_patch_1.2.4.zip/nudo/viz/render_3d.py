﻿# -*- coding: utf-8 -*-
"""Render 3D del nudo usando matplotlib 3D."""
from __future__ import annotations
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D           # noqa: F401 registro implicito
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from viz.styles_viz import (
    COL_CONCRETE, COL_STEEL_L, COL_STEEL_T, COL_CONFINEMENT,
    COL_BEAM, FONT_TITLE, FONT_LABEL,
    apply_global_style, DPI_EXPORT, DPI_SCREEN,
)


def draw_3d_render(envelope_result, extractor=None, output_path: str = "",
                   dpi: float | None = None) -> plt.Figure:
    """Genera render 3D del nudo.

    Robusto ante EnvelopeResult vacio o sin datos de confinamiento.
    """
    apply_global_style()
    _dpi = dpi if dpi is not None else DPI_SCREEN
    fig = plt.figure(figsize=(10, 8), dpi=_dpi)
    ax  = fig.add_subplot(111, projection="3d")
    ax.set_facecolor("#F0F4F8")

    jg     = getattr(envelope_result, "joint_geometry", None)
    combos = getattr(envelope_result, "combos", [])

    # Confinamiento: buscar el primero disponible en combos
    conf = None
    for c in combos:
        if getattr(c, "confinement", None) is not None:
            conf = c.confinement
            break

    b = (jg.b_col / 100.0) if jg else 0.40
    h = (jg.h_col / 100.0) if jg else 0.40
    L = h      # sección real de la columna en planta: b (X) x h (Y)

    # ── Cuerpo de concreto ────────────────────────────────────────────────────
    _draw_box(ax, 0, 0, 0, b, L, h, color=COL_CONCRETE, alpha=0.20)

    # ── Trabes ────────────────────────────────────────────────────────────────
    # Posición REAL según el modelo: plot X = X STAAD, plot Y = -Z STAAD
    # (en STAAD +Z apunta "hacia abajo" en planta). Cada lado se dibuja solo
    # si existe trabe en esa dirección, con su etiqueta T<id>.
    bw_t, h_t, t_len = 0.30, 0.40, 0.50
    z_t = (h - h_t) / 2 if h > h_t else 0.0
    _offsets = {
        "+X": (b,      (L - bw_t) / 2, z_t, t_len, bw_t, h_t),
        "-X": (-t_len, (L - bw_t) / 2, z_t, t_len, bw_t, h_t),
        "+Y": ((b - bw_t) / 2, L,      z_t, bw_t, t_len, h_t),
        "-Y": ((b - bw_t) / 2, -t_len, z_t, bw_t, t_len, h_t),
    }
    _lbl_pos = {
        "+X": (b + t_len,  L / 2, z_t + h_t + 0.06),
        "-X": (-t_len,     L / 2, z_t + h_t + 0.06),
        "+Y": (b / 2, L + t_len,  z_t + h_t + 0.06),
        "-Y": (b / 2, -t_len,     z_t + h_t + 0.06),
    }
    lados = _lados_trabe(envelope_result, extractor)
    if lados is None:
        # Sin extractor: distribución genérica por número de trabes
        n_trabes = (jg.n_trabes_framing if jg else 2)
        lados = {k: None for k in list(_offsets)[:min(n_trabes, 4)]}
    for lado, tid in lados.items():
        _draw_box(ax, *_offsets[lado], color=COL_BEAM, alpha=0.30)
        if tid is not None:
            lx, ly, lz = _lbl_pos[lado]
            ax.text(lx, ly, lz, f"T{tid}", ha="center", fontsize=8,
                    color="#0D47A1", fontweight="bold")

    # ── Columna superior e inferior ───────────────────────────────────────────
    h_ext = 0.50
    _draw_box(ax, 0, 0, -h_ext, b, L, h_ext,  color=COL_CONCRETE, alpha=0.12)
    _draw_box(ax, 0, 0, h,      b, L, h_ext,  color=COL_CONCRETE, alpha=0.12)

    # ── Acero longitudinal — TODAS las varillas del arreglo ─────────────────
    db = 0.025
    rec = 0.04
    from viz.plan_view import _column_bars
    _n_prop = getattr(envelope_result, "estribos_prop_nvar", 0) or None
    for bx, by in _column_bars(b, L, rec, db, n=_n_prop):
        ax.plot([bx, bx], [by, by], [-h_ext, h + h_ext],
                color=COL_STEEL_L, linewidth=3, alpha=0.9,
                solid_capstyle="round")

    # ── Estribos (perimetral + diamante/grapas segun MNL-66) ────────────────
    s_prov = (conf.s_prov_cm / 100.0) if conf and hasattr(conf, "s_prov_cm") else 0.10
    lo     = (conf.lo_cm / 100.0)     if conf and hasattr(conf, "lo_cm")     else 0.45
    prop   = getattr(envelope_result, "estribos_prop", None)
    _bars3d = _column_bars(b, L, rec, db, n=_n_prop)
    n_bars = len(_bars3d)
    diamante = (getattr(prop, "diamante", False) if prop is not None
                else n_bars == 8)
    # Grapas: lineas que cruzan la seccion por las barras intermedias
    grapas_seg = []
    if prop is not None and getattr(prop, "config", "") == "perimetral+grapas":
        eps = 1e-6
        x_lo, x_hi = rec + db/2, b - rec - db/2
        y_lo, y_hi = rec + db/2, L - rec - db/2
        for bx, by in _bars3d:
            on_cx = abs(bx - x_lo) < eps or abs(bx - x_hi) < eps
            on_cy = abs(by - y_lo) < eps or abs(by - y_hi) < eps
            if on_cx and on_cy:
                continue                     # esquina: la toma el perimetral
            if on_cy:                        # barra en cara horizontal → grapa en Y
                grapas_seg.append(((bx, rec), (bx, L - rec)))
            else:                            # barra en cara vertical → grapa en X
                grapas_seg.append(((rec, by), (b - rec, by)))
    _draw_3d_stirrups(ax, rec, b, L, h, lo, s_prov,
                      diamante=diamante, grapas=grapas_seg)

    # ── Zona confinada (contorno) ─────────────────────────────────────────────
    _draw_box_wire(ax, rec, rec, rec, b - 2*rec, L - 2*rec, h - 2*rec,
                   color=COL_CONFINEMENT, lw=0.8, ls="--")

    # ── Etiqueta ──────────────────────────────────────────────────────────────
    col_id  = getattr(envelope_result, "col_id",  "?")
    node_id = getattr(envelope_result, "node_id", "?")
    ax.text(b/2, L/2, h + h_ext + 0.05,
            f"Col {col_id} | Nodo {node_id}",
            ha="center", fontsize=7, color="#1B4F72", fontweight="bold")

    # ── Info panel ────────────────────────────────────────────────────────────
    DCR_NTC = getattr(envelope_result, "DCR_NTC_max", 0.0)
    DCR_ACI = getattr(envelope_result, "DCR_ACI_max", 0.0)
    jtype   = (jg.joint_type if jg else "—")
    conf_str = ""
    if conf:
        db_e = getattr(conf, "db_est_cm", 0)
        s_p  = getattr(conf, "s_prov_cm", 0)
        if db_e and s_p:
            conf_str = f"\nEstribo: d={db_e*10:.0f}mm c/{s_p:.0f}cm"

    info = (
        f"b x h = {b*100:.0f} x {h*100:.0f} cm\n"
        f"Tipo: {jtype}\n"
        f"DCR NTC: {DCR_NTC:.3f}\n"
        f"DCR ACI: {DCR_ACI:.3f}"
        + conf_str
    )
    ax.text2D(0.01, 0.98, info, transform=ax.transAxes,
              fontsize=7, va="top", family="monospace",
              bbox=dict(boxstyle="round", facecolor="#EBF5FB",
                        edgecolor="#888", alpha=0.9))

    ax.set_xlabel("X [m]", fontdict=FONT_LABEL, labelpad=6)
    ax.set_ylabel("Y [m]", fontdict=FONT_LABEL, labelpad=6)
    ax.set_zlabel("Z [m]", fontdict=FONT_LABEL, labelpad=6)
    ax.set_title(
        f"RENDER 3D — Nudo Col {col_id} | Tipo: {jtype.upper()}",
        fontdict=FONT_TITLE, color="#1B4F72", pad=14,
    )
    # Proporción REAL en las 3 direcciones (evita distorsión del nudo).
    try:
        x_lo = -t_len if "-X" in lados else -0.10
        x_hi = b + t_len if "+X" in lados else b + 0.10
        y_lo = -t_len if "-Y" in lados else -0.10
        y_hi = L + t_len if "+Y" in lados else L + 0.10
        z_lo, z_hi = -h_ext, h + h_ext
        ax.set_xlim(x_lo, x_hi)
        ax.set_ylim(y_lo, y_hi)
        ax.set_zlim(z_lo, z_hi)
        ax.set_box_aspect((x_hi - x_lo, y_hi - y_lo, z_hi - z_lo))
    except Exception:
        pass
    ax.view_init(elev=22, azim=-60)
    fig.tight_layout()

    if output_path:
        try:
            fig.savefig(output_path, dpi=DPI_EXPORT, bbox_inches="tight")
        except Exception:
            pass

    return fig


# ── Helpers 3D ────────────────────────────────────────────────────────────────

def _draw_box(ax, x0, y0, z0, dx, dy, dz, color="#AAAAAA", alpha=0.25):
    xs = [x0, x0+dx]
    ys = [y0, y0+dy]
    zs = [z0, z0+dz]
    verts = []
    for i, (a, b_) in enumerate([(xs, ys), (xs, zs), (ys, zs)]):
        for v0 in [a[0], a[1]]:
            for c0, c1 in [(b_[0], b_[1])]:
                if i == 0:
                    verts.append([(v0, c0, zs[0]), (v0, c1, zs[0]),
                                   (v0, c1, zs[1]), (v0, c0, zs[1])])
                elif i == 1:
                    verts.append([(v0, ys[0], c0), (v0, ys[0], c1),
                                   (v0, ys[1], c1), (v0, ys[1], c0)])
                else:
                    verts.append([(xs[0], v0, c0), (xs[0], v0, c1),
                                   (xs[1], v0, c1), (xs[1], v0, c0)])
    ax.add_collection3d(Poly3DCollection(
        verts, alpha=alpha, facecolor=color, edgecolor=color, linewidth=0.3,
    ))


def _draw_box_wire(ax, x0, y0, z0, dx, dy, dz, color="#E53935", lw=0.8, ls="--"):
    bot = [(x0, y0, z0), (x0+dx, y0, z0), (x0+dx, y0+dy, z0),
           (x0, y0+dy, z0), (x0, y0, z0)]
    ax.plot(*zip(*bot), color=color, lw=lw, ls=ls)
    for cx, cy in [(x0, y0), (x0+dx, y0), (x0+dx, y0+dy), (x0, y0+dy)]:
        ax.plot([cx, cx], [cy, cy], [z0, z0+dz], color=color, lw=lw, ls=ls)
    top = [(x0, y0, z0+dz), (x0+dx, y0, z0+dz), (x0+dx, y0+dy, z0+dz),
           (x0, y0+dy, z0+dz), (x0, y0, z0+dz)]
    ax.plot(*zip(*top), color=color, lw=lw, ls=ls)


def _draw_3d_stirrups(ax, rec, b, L_y, h, lo, s_prov,
                      diamante=False, grapas=None):
    cx, cy = b / 2.0, L_y / 2.0
    dxs, dys = b / 2.0 - rec, L_y / 2.0 - rec
    grapas = grapas or []

    def _stirrup(z):
        xs = [rec, b-rec, b-rec, rec, rec]
        ys = [rec, rec, L_y-rec, L_y-rec, rec]
        ax.plot(xs, ys, [z]*5, color=COL_STEEL_T, linewidth=1.2, zorder=4)
        if diamante:
            # Estribo en diamante (rombo) sobre las barras centrales de cara
            ax.plot([cx, cx + dxs, cx, cx - dxs, cx],
                    [cy - dys, cy, cy + dys, cy, cy - dys],
                    [z]*5, color=COL_STEEL_T, linewidth=1.0, zorder=4)
        for (xa, ya), (xb, yb) in grapas:
            ax.plot([xa, xb], [ya, yb], [z]*2,
                    color=COL_STEEL_T, linewidth=1.0, zorder=4)

    if s_prov <= 0:
        s_prov = 0.10
    z = rec
    while z < lo and z < h:
        _stirrup(z)
        z += s_prov
    while z < h - lo:
        _stirrup(z)
        z += max(s_prov * 2, 0.01)
    while z <= h - rec:
        _stirrup(z)
        z += s_prov


def _lados_trabe(env, extractor):
    """Determina en qué lados del nudo llegan trabes, con sus IDs.

    Regresa dict {"+X"|"-X"|"+Y"|"-Y": trabe_id} usando coordenadas reales
    del modelo (plot Y = -Z de STAAD), o None si no hay datos suficientes.
    """
    if env is None or extractor is None:
        return None
    tids = list(getattr(env, "trabe_ids", []) or [])
    node_id = getattr(env, "node_id", None)
    if not tids or node_id is None:
        return None
    try:
        nc = extractor.get_node_coord(node_id)
    except Exception:
        return None
    lados = {}
    for tid in tids:
        try:
            inc = extractor.get_member_incidence(tid)
            far = inc.node_end if inc.node_start == node_id else inc.node_start
            fc  = extractor.get_node_coord(far)
            dx, dy = fc.x - nc.x, -(fc.z - nc.z)
            if abs(dx) >= abs(dy):
                lados["+X" if dx >= 0 else "-X"] = tid
            else:
                lados["+Y" if dy >= 0 else "-Y"] = tid
        except Exception:
            continue
    return lados or None
