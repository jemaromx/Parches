﻿# -*- coding: utf-8 -*-
"""Panel izquierdo de entrada de parametros — Joint Design Pro.

Cambios respecto a la version anterior:
  - Seleccion por NODO (no por columna): el usuario selecciona nodos en STAAD Pro.
  - La tabla de acero longitudinal es ahora el widget SteelTableWidget (pestaña Topologia).
  - Se eliminan los spinboxes de As_col / As_trabe (la tabla los reemplaza).
  - Se agregan señales sig_select_nodes y sig_refresh_nodes.
  - Botones de importacion de JSON movidos a SteelTableWidget.
"""
from __future__ import annotations
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QGroupBox,
    QLabel, QPushButton, QDoubleSpinBox, QSpinBox, QComboBox,
    QCheckBox, QRadioButton, QButtonGroup, QTableWidget, QTableWidgetItem,
    QSizePolicy, QFrame, QFileDialog, QLineEdit,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QColor


class InputPanel(QWidget):
    """Panel izquierdo con todos los parametros de diseno."""

    sig_connect_staad     = Signal()
    sig_refresh_selection = Signal()   # actualiza nodos/columnas seleccionados
    sig_run_design        = Signal()
    sig_demo_mode         = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(360)
        self._output_dir = ""
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Encabezado ────────────────────────────────────────────────────────
        header = QLabel("  JOINT DESIGN PRO")
        header.setStyleSheet(
            "background:#1B4F72; color:white; font-size:12pt; font-weight:bold; "
            "padding:10px 0;"
        )
        header.setFixedHeight(42)
        outer.addWidget(header)

        sub = QLabel("  Nudos Columna-Trabe  |  NTC 2023 DEC  |  ACI 318-25")
        sub.setStyleSheet(
            "background:#2874A6; color:#D6EAF8; font-size:8pt; padding:3px 0 3px 10px;"
        )
        sub.setFixedHeight(22)
        outer.addWidget(sub)

        # ── Contenido scrollable ──────────────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        container = QWidget()
        self._main_layout = QVBoxLayout(container)
        self._main_layout.setContentsMargins(8, 8, 8, 8)
        self._main_layout.setSpacing(8)
        scroll.setWidget(container)
        outer.addWidget(scroll)

        self._add_staad_group()
        self._add_load_range_group()
        self._add_materials_group()
        self._add_ductility_group()
        self._add_codes_group()
        self._add_phi_group()
        self._add_output_group()

        self._main_layout.addStretch()

        # ── Boton ejecutar ────────────────────────────────────────────────────
        self.btn_run = QPushButton("EJECUTAR DISENO")
        self.btn_run.setObjectName("btn_run")
        self.btn_run.setEnabled(False)
        self.btn_run.setToolTip("Complete la topologia y las areas de acero antes de ejecutar")
        self.btn_run.clicked.connect(self.sig_run_design)
        outer.addWidget(self.btn_run)

    # ── Grupos ────────────────────────────────────────────────────────────────

    def _add_staad_group(self):
        grp = QGroupBox("Conexion STAAD Pro 2024/2025")
        lay = QVBoxLayout(grp)
        lay.setSpacing(5)

        self.lbl_status = QLabel("Desconectado")
        self.lbl_status.setObjectName("status_fail")
        lay.addWidget(self.lbl_status)

        row = QHBoxLayout()
        self.btn_connect = QPushButton("Conectar STAAD")
        self.btn_connect.setObjectName("btn_connect")
        self.btn_connect.clicked.connect(self.sig_connect_staad)

        self.btn_refresh = QPushButton("Actualizar nodos/cols")
        self.btn_refresh.setToolTip(
            "Lee los NODOS (o columnas) seleccionados actualmente en STAAD Pro.\n"
            "Primero seleccione los nodos en STAAD Pro, luego presione este boton."
        )
        self.btn_refresh.clicked.connect(self.sig_refresh_selection)
        self.btn_refresh.setEnabled(False)
        row.addWidget(self.btn_connect)
        row.addWidget(self.btn_refresh)
        lay.addLayout(row)

        # Modo demo
        self.btn_demo = QPushButton("Modo Demo (sin STAAD)")
        self.btn_demo.setStyleSheet(
            "background:#475C6B; color:white; border-radius:4px; "
            "padding:4px 8px; font-size:8pt; font-weight:bold;"
        )
        self.btn_demo.clicked.connect(self.sig_demo_mode)
        lay.addWidget(self.btn_demo)

        self.lbl_file = QLabel("Archivo: —")
        self.lbl_file.setStyleSheet("font-size:7.5pt; color:#475C6B; font-style:italic;")
        lay.addWidget(self.lbl_file)

        # Instruccion de seleccion
        info = QLabel(
            "Seleccione NODOS en STAAD Pro\n"
            "(o columnas si el modelo no permite\n"
            "seleccion de nodos) y presione\n"
            "'Actualizar nodos/cols'."
        )
        info.setStyleSheet(
            "font-size:7.5pt; color:#1B4F72; background:#EBF5FB; "
            "padding:4px; border-radius:3px;"
        )
        lay.addWidget(info)

        # Tabla resumen de nodos detectados
        lbl = QLabel("Nodos / nudos a disenar:")
        lbl.setStyleSheet("font-weight:bold; font-size:8pt;")
        lay.addWidget(lbl)
        self.tbl_nodes = QTableWidget(0, 4)
        self.tbl_nodes.setHorizontalHeaderLabels(
            ["Nodo", "Columna", "# Trabes", "# Diag"]
        )
        self.tbl_nodes.setFixedHeight(120)
        self.tbl_nodes.horizontalHeader().setStretchLastSection(True)
        self.tbl_nodes.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl_nodes.setAlternatingRowColors(True)
        lay.addWidget(self.tbl_nodes)

        self._main_layout.addWidget(grp)

    def _add_load_range_group(self):
        grp = QGroupBox("Combinaciones de carga")
        lay = QVBoxLayout(grp)
        self.spin_lc_ini = self._spin_int("Caso inicial:", 1, 9999, 1, lay)
        self.spin_lc_fin = self._spin_int("Caso final:",   1, 9999, 10, lay)
        self._main_layout.addWidget(grp)

    def _add_materials_group(self):
        grp = QGroupBox("Materiales")
        lay = QVBoxLayout(grp)
        self.spin_fc         = self._dbl("f'c (kgf/cm2):",    100, 700, 250, lay)
        self.spin_fy         = self._dbl("fy  (kgf/cm2):",   2000, 8000, 4200, lay)
        self.spin_rec_col    = self._dbl("Recub. columna (cm, def. 5):", 2, 10, 5, lay)
        self.spin_rec_trabe  = self._dbl("Recub. trabe   (cm, def. 5):", 2, 10, 5, lay)
        self.spin_db_long    = self._dbl("Diam. barra long. (cm):", 0.5, 5, 2.54, lay, 2)
        self.spin_db_est     = self._dbl("Diam. estribo (cm):",     0.5, 2.5, 0.95, lay, 2)
        self._main_layout.addWidget(grp)

    def _add_ductility_group(self):
        grp = QGroupBox("Nivel de Ductilidad")
        lay = QVBoxLayout(grp)
        self._duct_grp = QButtonGroup(self)
        self.rb_duct: dict[str, QRadioButton] = {}
        for text, key in [
            ("Q=2  Baja ductilidad",  "Q2"),
            ("Q=3  Media ductilidad", "Q3"),
            ("Q=4  Alta ductilidad",  "Q4"),
        ]:
            rb = QRadioButton(text)
            rb.setProperty("key", key)
            if key == "Q2":
                rb.setChecked(True)
            self._duct_grp.addButton(rb)
            lay.addWidget(rb)
            self.rb_duct[key] = rb
        self._main_layout.addWidget(grp)

    def _add_codes_group(self):
        grp = QGroupBox("Normativas")
        lay = QVBoxLayout(grp)
        self.chk_ntc = QCheckBox("NTC 2023 DEC")
        self.chk_ntc.setChecked(True)
        self.chk_aci = QCheckBox("ACI 318-25")
        self.chk_aci.setChecked(True)
        lay.addWidget(self.chk_ntc)
        lay.addWidget(self.chk_aci)
        self._main_layout.addWidget(grp)

    def _add_phi_group(self):
        grp = QGroupBox("Factores de reduccion phi")
        lay = QVBoxLayout(grp)
        self.spin_phi_flex  = self._dbl("phi flexion:",  0.50, 1.00, 0.90, lay, 2)
        self.spin_phi_shear = self._dbl("phi cortante:", 0.50, 1.00, 0.75, lay, 2)
        self.spin_phi_axial = self._dbl("phi axial:",    0.50, 1.00, 0.65, lay, 2)
        self._main_layout.addWidget(grp)

    def _add_output_group(self):
        # Apartado "Proyecto y salida" eliminado de la UI (solicitud 2026-07).
        # Los campos se conservan ocultos para no romper get_params() ni los
        # reportes; la carpeta de salida se pide al exportar si hace falta.
        self.edit_project  = QLineEdit("Sin nombre")
        self.edit_engineer = QLineEdit("")
        self.lbl_out_path  = QLabel("Carpeta: (por definir)")

    # ── API publica ────────────────────────────────────────────────────────────

    def get_params(self) -> dict:
        ductility = "Q2"
        for key, rb in self.rb_duct.items():
            if rb.isChecked():
                ductility = key
                break
        return {
            "lc_ini":     self.spin_lc_ini.value(),
            "lc_fin":     self.spin_lc_fin.value(),
            "fc":         self.spin_fc.value(),
            "fy":         self.spin_fy.value(),
            "rec_col":    self.spin_rec_col.value(),
            "rec_trabe":  self.spin_rec_trabe.value(),
            "db_long":    self.spin_db_long.value(),
            "db_est":     self.spin_db_est.value(),
            "ductility":  ductility,
            "use_ntc":    self.chk_ntc.isChecked(),
            "use_aci":    self.chk_aci.isChecked(),
            "phi_flex":   self.spin_phi_flex.value(),
            "phi_shear":  self.spin_phi_shear.value(),
            "phi_axial":  self.spin_phi_axial.value(),
            "project":    self.edit_project.text(),
            "engineer":   self.edit_engineer.text(),
            "output_dir": self._output_dir,
        }

    def set_connected(self, connected: bool, file_name: str = ""):
        if connected:
            self.lbl_status.setText("Conectado a STAAD Pro")
            self.lbl_status.setObjectName("status_ok")
            self.btn_refresh.setEnabled(True)
        else:
            self.lbl_status.setText("Desconectado")
            self.lbl_status.setObjectName("status_fail")
            self.btn_refresh.setEnabled(False)
        if file_name:
            self.lbl_file.setText(f"Archivo: {file_name}")
        self.lbl_status.style().unpolish(self.lbl_status)
        self.lbl_status.style().polish(self.lbl_status)

    def load_nodes(self, node_joints: list) -> None:
        """Popula la tabla resumen de nodos seleccionados.

        Args:
            node_joints: lista de NodeJointData
        """
        self.tbl_nodes.setRowCount(len(node_joints))
        for r, njd in enumerate(node_joints):
            col_id = (njd.col_member.member_id if njd.col_member else "—")
            self.tbl_nodes.setItem(r, 0, QTableWidgetItem(str(njd.node_id)))
            self.tbl_nodes.setItem(r, 1, QTableWidgetItem(str(col_id)))
            self.tbl_nodes.setItem(r, 2, QTableWidgetItem(str(len(njd.trabe_members))))
            self.tbl_nodes.setItem(r, 3, QTableWidgetItem(str(len(njd.diag_members))))
        self.tbl_nodes.resizeColumnsToContents()
        self.btn_run.setEnabled(len(node_joints) > 0)

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _dbl(self, label: str, lo: float, hi: float, default: float,
             layout, decimals: int = 1) -> QDoubleSpinBox:
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(170)
        sp  = QDoubleSpinBox()
        sp.setRange(lo, hi)
        sp.setValue(default)
        sp.setDecimals(decimals)
        sp.setMinimumWidth(80)
        row.addWidget(lbl)
        row.addWidget(sp)
        layout.addLayout(row)
        return sp

    def _spin_int(self, label: str, lo: int, hi: int, default: int,
                  layout) -> QSpinBox:
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(170)
        sp  = QSpinBox()
        sp.setRange(lo, hi)
        sp.setValue(default)
        sp.setMinimumWidth(80)
        row.addWidget(lbl)
        row.addWidget(sp)
        layout.addLayout(row)
        return sp

    def _select_output(self):
        path = QFileDialog.getExistingDirectory(self, "Carpeta de salida")
        if path:
            self._output_dir = path
            self.lbl_out_path.setText(f"Carpeta: {path}")
