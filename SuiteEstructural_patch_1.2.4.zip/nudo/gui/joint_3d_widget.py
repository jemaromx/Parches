﻿"""Widget con render 3D embebido en Qt."""
from __future__ import annotations
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QLabel
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
import matplotlib.pyplot as plt


class Joint3DWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._envelopes = []
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        top = QHBoxLayout()
        top.addWidget(QLabel("Nudo:"))
        self.cmb_joint = QComboBox()
        self.cmb_joint.currentIndexChanged.connect(self._draw)
        top.addWidget(self.cmb_joint)
        top.addStretch()
        lbl = QLabel("Rotar: arrastrar con mouse")
        lbl.setStyleSheet("color:#475C6B; font-size:8pt; font-style:italic;")
        top.addWidget(lbl)
        lay.addLayout(top)
        self.fig = plt.figure(figsize=(10, 8))
        self.canvas = FigureCanvas(self.fig)
        self.toolbar = NavToolbar(self.canvas, self)
        lay.addWidget(self.toolbar)
        lay.addWidget(self.canvas)

    def load_results(self, envelopes, extractor=None):
        self._envelopes = envelopes
        self._extractor = extractor
        self.cmb_joint.clear()
        for env in envelopes:
            self.cmb_joint.addItem(f"Col {env.col_id} | Nodo {env.node_id}")
        if envelopes:
            self._draw()

    def _draw(self):
        idx = self.cmb_joint.currentIndex()
        if idx < 0 or idx >= len(self._envelopes):
            return
        env = self._envelopes[idx]
        from viz.render_3d import draw_3d_render
        new_fig = draw_3d_render(env, getattr(self, "_extractor", None))
        _swap_canvas(self, new_fig)


def _swap_canvas(widget, new_fig):
    """Reemplaza limpiamente la figura embebida (evita distorsión por dpi/tamaño)."""
    import matplotlib.pyplot as _plt
    lay = widget.layout()
    try:
        lay.removeWidget(widget.toolbar); widget.toolbar.deleteLater()
    except Exception:
        pass
    lay.removeWidget(widget.canvas)
    _plt.close(widget.fig)
    widget.canvas.deleteLater()
    widget.fig = new_fig
    widget.canvas = FigureCanvas(new_fig)
    widget.toolbar = NavToolbar(widget.canvas, widget)
    lay.addWidget(widget.toolbar)
    lay.addWidget(widget.canvas)
    widget.canvas.draw()
