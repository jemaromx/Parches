﻿# -*- coding: utf-8 -*-
"""Widget de tabla editable con areas de acero por miembro conectado al nudo.

Flujo de datos:
    1. El usuario importa JSON de beam_design_pro  → auto-llena As de trabes
    2. El usuario importa JSON de column_design_pro → auto-llena As de columnas
    3. El usuario puede editar cualquier celda antes de ejecutar el diseno
    4. El diseno lee las areas directamente de esta tabla (no de spinboxes globales)

Columnas de la tabla:
    Nodo | ID Barra | Tipo | b (cm) | h (cm) | As inf (cm2) | As sup (cm2) | Fuente
"""
from __future__ import annotations
import json
import os
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog,
    QAbstractItemView, QMessageBox, QSizePolicy,
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QBrush


# Colores por tipo de elemento
_COLOR_COL  = QColor("#D6EAF8")   # azul claro — columna
_COLOR_TRAB = QColor("#D5F5E3")   # verde claro — trabe
_COLOR_DIAG = QColor("#FEF9E7")   # amarillo claro — diagonal
_COLOR_IGN  = QColor("#F2F3F4")   # gris — ignorado

# Indices de columna
COL_NODO   = 0
COL_ID     = 1
COL_TIPO   = 2
COL_B      = 3
COL_H      = 4
COL_AS_INF = 5   # editable — As inf (trabe) o As total (columna)
COL_AS_SUP = 6   # editable — As sup (trabe) o "" para columnas
COL_DB     = 7   # editable — diámetro barra longitudinal (varilla #)
COL_FUENTE = 8

_HEADERS = ["Nodo", "ID", "Tipo", "b (cm)", "h (cm)",
            "As inf / total\n(cm²)", "As sup\n(cm²)", "Ø barra\n(#)", "Fuente"]

# Varilla # → diámetro en cm (octavos de pulgada)
_VAR_DB_CM = {3: 0.95, 4: 1.27, 5: 1.59, 6: 1.91, 8: 2.54, 10: 3.18}


def _parse_db_cm(txt: str, default: float = 2.54) -> float:
    """Convierte '#8', '8' o '2.54' al diámetro en cm."""
    t = str(txt).strip().lstrip("#")
    try:
        v = float(t)
    except (ValueError, TypeError):
        return default
    if v in _VAR_DB_CM:                 # número de varilla
        return _VAR_DB_CM[v]
    return v if 0.3 <= v <= 6.0 else default   # ya viene en cm


class SteelTableWidget(QWidget):
    """Tabla editable de areas de acero por miembro en cada nudo.

    Signals:
        sig_data_changed: emitido cuando el usuario edita alguna celda
    """
    sig_data_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()
        self._beam_json: dict  = {}    # {str(beam_id): {...}}
        self._col_json:  dict  = {}    # {str(col_id):  {...}}

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        # ── Encabezado ────────────────────────────────────────────────────────
        lbl = QLabel("Acero longitudinal por miembro — editable previo al diseno")
        lbl.setStyleSheet("font-weight:bold; font-size:8pt; color:#1B4F72;")
        lay.addWidget(lbl)

        # ── Botones de importacion ────────────────────────────────────────────
        btn_row = QHBoxLayout()

        self.btn_import_beams = QPushButton("Importar JSON Trabes (beam_design_pro)")
        self.btn_import_beams.setStyleSheet(
            "background:#2874A6; color:white; border-radius:4px; "
            "padding:4px 8px; font-size:7.5pt;"
        )
        self.btn_import_beams.setToolTip(
            "Seleccionar el archivo beam_results_*.json generado\n"
            "por beam_design_pro con el boton 'Exportar a Nudos'."
        )
        self.btn_import_beams.clicked.connect(self._import_beams)

        self.btn_import_cols = QPushButton("Importar JSON Columnas (column_design_pro)")
        self.btn_import_cols.setStyleSheet(
            "background:#1B4F72; color:white; border-radius:4px; "
            "padding:4px 8px; font-size:7.5pt;"
        )
        self.btn_import_cols.setToolTip(
            "Seleccionar el archivo column_results_*.json generado\n"
            "por column_design_pro con el boton 'Exportar a Nudos'."
        )
        self.btn_import_cols.clicked.connect(self._import_columns)

        self.btn_clear = QPushButton("Limpiar")
        self.btn_clear.setStyleSheet(
            "background:#922B21; color:white; border-radius:4px; "
            "padding:4px 8px; font-size:7.5pt;"
        )
        self.btn_clear.clicked.connect(self.clear_all)

        btn_row.addWidget(self.btn_import_beams)
        btn_row.addWidget(self.btn_import_cols)
        btn_row.addStretch()
        btn_row.addWidget(self.btn_clear)
        lay.addLayout(btn_row)

        # ── Tabla ─────────────────────────────────────────────────────────────
        self.table = QTableWidget(0, len(_HEADERS))
        self.table.setHorizontalHeaderLabels(_HEADERS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(
            QAbstractItemView.DoubleClicked | QAbstractItemView.AnyKeyPressed
        )
        self.table.verticalHeader().setDefaultSectionSize(22)
        self.table.setFont(QFont("Consolas", 8))
        self.table.itemChanged.connect(self._on_item_changed)
        lay.addWidget(self.table)

        # ── Leyenda ───────────────────────────────────────────────────────────
        leg = QHBoxLayout()
        for color, label in [(_COLOR_COL, "Columna"), (_COLOR_TRAB, "Trabe"),
                              (_COLOR_DIAG, "Diagonal"), (_COLOR_IGN, "Ignorado")]:
            dot = QLabel("  ")
            dot.setFixedWidth(18)
            dot.setStyleSheet(f"background:{color.name()}; border:1px solid #AAA;")
            leg.addWidget(dot)
            leg.addWidget(QLabel(label))
            leg.addSpacing(12)
        leg.addStretch()
        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("font-size:7.5pt; color:#1E8449;")
        leg.addWidget(self.lbl_status)
        lay.addLayout(leg)

    # ── API publica ────────────────────────────────────────────────────────────

    def populate(self, node_joints: list) -> None:
        """Llena la tabla desde una lista de NodeJointData.

        Args:
            node_joints: lista de NodeJointData (de STAADSelector)
        """
        self.table.blockSignals(True)
        self.table.setRowCount(0)

        for njd in node_joints:
            nid = njd.node_id
            for info in njd.members:
                self._add_row(nid, info)

        self.table.blockSignals(False)
        self._apply_json_data()
        self.table.resizeColumnsToContents()

    def get_steel_data(self) -> dict:
        """Lee la tabla y devuelve las areas de acero actuales.

        Returns:
            {
              "beams": {member_id_int: {"As_inf": float, "As_sup": float}},
              "columns": {member_id_int: {"As_total": float}}
            }
        """
        beams   = {}
        columns = {}
        for row in range(self.table.rowCount()):
            tipo = self._cell_text(row, COL_TIPO)
            if tipo == "ignorar":
                continue
            mid = int(self._cell_text(row, COL_ID) or "0")
            As_inf = self._cell_float(row, COL_AS_INF)
            As_sup = self._cell_float(row, COL_AS_SUP)
            db_cm = _parse_db_cm(self._cell_text(row, COL_DB))
            if tipo == "columna":
                columns[mid] = {"As_total": As_inf, "db_cm": db_cm}
            elif tipo in ("trabe", "diagonal"):
                beams[mid] = {"As_inf": As_inf, "As_sup": As_sup,
                              "db_cm": db_cm}
        return {"beams": beams, "columns": columns}

    def clear_all(self):
        self.table.setRowCount(0)
        self._beam_json = {}
        self._col_json  = {}
        self.lbl_status.setText("")

    # ── Importacion JSON ───────────────────────────────────────────────────────

    def _import_beams(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Importar resultados de trabes",
            "", "Archivos JSON (*.json)"
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("source") != "beam_design_pro":
                QMessageBox.warning(self, "Formato incorrecto",
                                    "El archivo no es de beam_design_pro.\n"
                                    "Usa el boton 'Exportar a Nudos' en ese script.")
                return
            self._beam_json = data.get("beams", {})
            self._apply_json_data()
            n = len(self._beam_json)
            self.lbl_status.setText(
                f"Trabes importadas: {n} elementos — {os.path.basename(path)}"
            )
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"No se pudo leer el archivo:\n{exc}")

    def _import_columns(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Importar resultados de columnas",
            "", "Archivos JSON (*.json)"
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("source") != "column_design_pro":
                QMessageBox.warning(self, "Formato incorrecto",
                                    "El archivo no es de column_design_pro.\n"
                                    "Usa el boton 'Exportar a Nudos' en ese script.")
                return
            self._col_json = data.get("columns", {})
            self._apply_json_data()
            n = len(self._col_json)
            self.lbl_status.setText(
                f"Columnas importadas: {n} elementos — {os.path.basename(path)}"
            )
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"No se pudo leer el archivo:\n{exc}")

    def _apply_json_data(self):
        """Rellena la tabla con los datos del JSON cargado."""
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            tipo = self._cell_text(row, COL_TIPO)
            mid  = self._cell_text(row, COL_ID)
            if tipo == "columna" and mid in self._col_json:
                d = self._col_json[mid]
                self._fill_db_cell(row, d)
                self._set_editable(row, COL_AS_INF, d.get("As_total_cm2", 0.0))
                self._set_readonly(row, COL_AS_SUP, "—")
                self._set_readonly(row, COL_FUENTE, "JSON-Columnas")
            elif tipo in ("trabe", "diagonal") and mid in self._beam_json:
                d = self._beam_json[mid]
                self._fill_db_cell(row, d)
                # NOTA (2026-07): el JSON de beam_design_pro trae los lechos
                # invertidos respecto a la convencion del nudo (verificado
                # con ejercicio del usuario) → se cruzan al importar.
                self._set_editable(row, COL_AS_INF, d.get("As_sup_cm2", 0.0))
                self._set_editable(row, COL_AS_SUP, d.get("As_inf_cm2", 0.0))
                self._set_readonly(row, COL_FUENTE, "JSON-Trabes")
        self.table.blockSignals(False)

    def _fill_db_cell(self, row: int, d: dict):
        """Llena la celda de diametro con el dato del JSON (si existe)."""
        it = self.table.item(row, COL_DB)
        if it is None:
            return
        var = d.get("var_num") or 0
        db  = d.get("db_cm") or 0.0
        if var:
            it.setText(f"#{int(var)}")
        elif db:
            it.setText(f"{float(db):.2f}")

    # ── Helpers de tabla ───────────────────────────────────────────────────────

    def _add_row(self, node_id: int, info) -> int:
        row = self.table.rowCount()
        self.table.insertRow(row)

        color = {
            "columna":  _COLOR_COL,
            "trabe":    _COLOR_TRAB,
            "diagonal": _COLOR_DIAG,
        }.get(info.kind, _COLOR_IGN)

        editable = info.kind != "ignorar"

        self._set_readonly(row, COL_NODO,  str(node_id))
        self._set_readonly(row, COL_ID,    str(info.member_id))
        self._set_readonly(row, COL_TIPO,  info.kind)
        self._set_readonly(row, COL_B,     f"{info.b_cm:.1f}" if info.b_cm else "—")
        self._set_readonly(row, COL_H,     f"{info.h_cm:.1f}" if info.h_cm else "—")

        if editable:
            self._set_editable(row, COL_AS_INF, info.As_inf_cm2)
            if info.kind == "columna":
                self._set_readonly(row, COL_AS_SUP, "—")
            else:
                self._set_editable(row, COL_AS_SUP, info.As_sup_cm2)
        else:
            self._set_readonly(row, COL_AS_INF, "—")
            self._set_readonly(row, COL_AS_SUP, "—")

        if editable:
            var_def = "#8" if info.kind == "columna" else "#6"
            it = QTableWidgetItem(getattr(info, "var_label", "") or var_def)
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
            it.setForeground(QBrush(QColor("#0D47A1")))
            it.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
            it.setToolTip("Varilla # (3, 4, 5, 6, 8, 10) o diámetro en cm.")
            self.table.setItem(row, COL_DB, it)
        else:
            self._set_readonly(row, COL_DB, "—")

        self._set_readonly(row, COL_FUENTE, info.steel_source)

        # Color de fila por tipo
        for col in range(self.table.columnCount()):
            it = self.table.item(row, col)
            if it:
                it.setBackground(QBrush(color))

        return row

    def _set_readonly(self, row: int, col: int, text: str):
        it = QTableWidgetItem(str(text))
        it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        it.setForeground(QBrush(QColor("#333")))
        self.table.setItem(row, col, it)

    def _set_editable(self, row: int, col: int, value: float):
        it = QTableWidgetItem(f"{value:.2f}")
        it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
        it.setForeground(QBrush(QColor("#0D47A1")))
        it.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.table.setItem(row, col, it)

    def _cell_text(self, row: int, col: int) -> str:
        it = self.table.item(row, col)
        return it.text().strip() if it else ""

    def _cell_float(self, row: int, col: int) -> float:
        txt = self._cell_text(row, col)
        try:
            return float(txt)
        except (ValueError, TypeError):
            return 0.0

    def _on_item_changed(self, item):
        if item.column() == COL_DB:
            db = _parse_db_cm(item.text(), default=-1.0)
            if db <= 0:
                item.setText("#8")
            self.sig_data_changed.emit()
            return
        if item.column() in (COL_AS_INF, COL_AS_SUP):
            # Validar que sea numerico
            try:
                float(item.text())
            except ValueError:
                item.setText("0.00")
            self.sig_data_changed.emit()
