﻿"""Widget de resultados por combinación de carga — tabla detallada y semáforo."""
from __future__ import annotations
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLabel, QSplitter, QTreeWidget, QTreeWidgetItem, QHeaderView,
    QAbstractItemView, QGroupBox,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QBrush
from gui.table_utils import install_copy_shortcut, color_dcr_cell


class ResultsWidget(QWidget):
    """Muestra resultados tabulados por nudo y combinación de carga."""

    _COL_HEADERS = [
        "Col", "Nodo", "LC", "Tipo nudo",
        "Vjh [ton]", "vu [kgf/cm²]",
        "φVn NTC [ton]", "DCR NTC",
        "φVn ACI [ton]", "DCR ACI",
        "Ash_req [cm²]", "Ash_prov [cm²]",
        "lo [cm]", "s [cm]",
        "ΣMnc/ΣMnb", "NTC", "ACI",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)

        # ── Título y semáforo resumen ─────────────────────────────────────────
        top = QHBoxLayout()
        self.lbl_title = QLabel("Resultados por Nudo y Combinación de Carga")
        self.lbl_title.setStyleSheet(
            "font-size:10pt; font-weight:bold; color:#1B4F72; padding:4px;"
        )
        self.lbl_summary = QLabel("")
        self.lbl_summary.setStyleSheet("font-size:9pt; font-weight:bold; padding:4px;")
        top.addWidget(self.lbl_title)
        top.addStretch()
        top.addWidget(self.lbl_summary)
        lay.addLayout(top)

        # ── Tabla principal ───────────────────────────────────────────────────
        self.tbl = QTableWidget(0, len(self._COL_HEADERS))
        self.tbl.setHorizontalHeaderLabels(self._COL_HEADERS)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.tbl.horizontalHeader().setStretchLastSection(False)
        self.tbl.setSortingEnabled(True)
        install_copy_shortcut(self.tbl)
        lay.addWidget(self.tbl)

    # Columnas asociadas a cada normativa (índices en _COL_HEADERS)
    _NTC_COLS = (6, 7, 15)   # φVn NTC, DCR NTC, ✓NTC
    _ACI_COLS = (8, 9, 16)   # φVn ACI, DCR ACI, ✓ACI

    def load_results(self, envelope_results: list,
                     use_ntc: bool = True, use_aci: bool = True):
        """Popula la tabla; solo muestra columnas de los códigos activos."""
        self._use_ntc, self._use_aci = use_ntc, use_aci
        self.tbl.setSortingEnabled(False)
        rows = []
        for env in envelope_results:
            jg = env.joint_geometry
            for cr in env.combos:
                jf   = cr.joint_force
                conf = cr.confinement
                cap  = cr.capacity_design
                if not jf:
                    continue
                rows.append({
                    "col":        str(env.col_id),
                    "nodo":       str(env.node_id),
                    "lc":         str(jf.lc_id),
                    "tipo":       jg.joint_type,
                    "Vjh":        f"{jf.Vjh/1000:.2f}",
                    "vu":         f"{jf.vu:.3f}",
                    "Vn_NTC":     f"{jf.Vn_NTC/1000:.2f}",
                    "DCR_NTC":    jf.DCR_NTC,
                    "Vn_ACI":     f"{jf.Vn_ACI/1000:.2f}",
                    "DCR_ACI":    jf.DCR_ACI,
                    "Ash_req":    f"{conf.Ash_req:.2f}" if conf else "—",
                    "Ash_prov":   f"{conf.Ash_prov:.2f}" if conf else "—",
                    "lo":         f"{conf.lo_cm:.1f}" if conf else "—",
                    "s":          f"{conf.s_prov_cm:.0f}" if conf else "—",
                    "ratio_cap":  f"{cap.ratio:.3f}" if (cap and cap.applies) else "N/A",
                    "ok_ntc":     "✓" if jf.ok_shear_NTC else "✗",
                    "ok_aci":     "✓" if jf.ok_shear_ACI else "✗",
                })

        self.tbl.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [
                row["col"], row["nodo"], row["lc"], row["tipo"],
                row["Vjh"], row["vu"],
                row["Vn_NTC"], f"{row['DCR_NTC']:.3f}",
                row["Vn_ACI"], f"{row['DCR_ACI']:.3f}",
                row["Ash_req"], row["Ash_prov"],
                row["lo"], row["s"],
                row["ratio_cap"],
                row["ok_ntc"], row["ok_aci"],
            ]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(str(v))
                item.setTextAlignment(Qt.AlignCenter)
                # Colorear DCR
                if c == 7:
                    color_dcr_cell(item, row["DCR_NTC"])
                elif c == 9:
                    color_dcr_cell(item, row["DCR_ACI"])
                elif c in (15, 16):
                    ok = v == "✓"
                    item.setForeground(QBrush(QColor("#1E8449" if ok else "#922B21")))
                    item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                self.tbl.setItem(r, c, item)

        # Ocultar columnas de códigos NO seleccionados
        for c in self._NTC_COLS:
            self.tbl.setColumnHidden(c, not use_ntc)
        for c in self._ACI_COLS:
            self.tbl.setColumnHidden(c, not use_aci)

        self.tbl.setSortingEnabled(True)
        self.tbl.resizeColumnsToContents()

        # Semáforo resumen — solo códigos activos
        n_fail_ntc = sum(1 for r in rows if r["ok_ntc"] == "✗") if use_ntc else 0
        n_fail_aci = sum(1 for r in rows if r["ok_aci"] == "✗") if use_aci else 0
        if n_fail_ntc == 0 and n_fail_aci == 0:
            self.lbl_summary.setText(f"✓ Todos los nudos CUMPLEN  ({len(rows)} verificaciones)")
            self.lbl_summary.setStyleSheet("color:#1E8449; font-weight:bold; font-size:9pt;")
        else:
            self.lbl_summary.setText(
                f"✗ {max(n_fail_ntc, n_fail_aci)} verificaciones NO CUMPLEN"
            )
            self.lbl_summary.setStyleSheet("color:#922B21; font-weight:bold; font-size:9pt;")
